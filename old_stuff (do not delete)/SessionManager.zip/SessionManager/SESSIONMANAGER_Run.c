#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"


#define N_DIG_REPETITIONS 99999
#define MAX_DISPLAY_TIMEINTERVALS 500

#define N_MULTIPLES_DISPLAY_TIMEINTERVAL 50
#define TIMEINTERVAL_INSERT_IN_ORDER 0

int RUN_busyFlag = RUN_STATE_INACTIVE;

int lastPanel = -1;

extern int panelRun;
extern int panelSMain;
extern int ctrlButtonStop;


t_run *activeRun = NULL;


t_run *activeRunPtr(void) 
{
	return activeRun;
}

int lastActivePanel (void)
{
	return lastPanel;
}






t_run *RUN_init_activeRun (void)
{
	t_graph *plotWindow;
	
//	if (mode != global_activeRun) PLOT_
	RUN_free (activeRun);
	// changed detection mode
	if (activeRun == NULL) {
		activeRun = (t_run *) malloc (sizeof (t_run));
		plotWindow = NULL;
	}
	else {
		plotWindow = activeRun->plotWindow;
	}
	RUN_init (activeRun, plotWindow);
	return activeRun;
}


int RUN_getState (void)
{
	return RUN_busyFlag;
}



void RUN_setState (int state)
{

	int color;
	
	RUN_busyFlag = state;
//	SetCtrlVal (panelSessionMain(), SMAN_LED_busy, state);
	switch (RUN_busyFlag) {
		case RUN_STATE_STOPPED: 
			color = VAL_YELLOW;
			break;
		case RUN_STATE_PAUSED: 
			color = VAL_ORANGE;
			break;
		case RUN_STATE_ACTIVE: 
			color = VAL_RED;
			break;
		default:
			color = VAL_GREEN;
			break;
	}
			

	SetCtrlAttribute (panelSMain, SMAN_BUTTON_start, ATTR_VISIBLE, RUN_busyFlag == RUN_STATE_INACTIVE);
	SetCtrlAttribute (panelSMain, ctrlButtonStop, ATTR_VISIBLE, RUN_busyFlag != RUN_STATE_INACTIVE);
//	SetCtrlAttribute (panelSMain, SMAN_COMMANDBUTTON_start,
//					  ATTR_LABEL_TEXT,
//					  RUN_busyFlag ? "STOP (ESC)" : "START (F9)");


//	SetCtrlAttribute (panelSMain, SMAN_COMMANDBUTTON_start,
//					  ATTR_SHORTCUT_KEY,
//					  RUN_busyFlag ? VAL_ESC_VKEY : VAL_F9_VKEY);

//	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_COMMANDBUTTON_resume,
//					  ATTR_LABEL_TEXT,
//					  RUN_busyFlag == RUN_STATE_PAUSED ? "Pause" : "Resume");
	
	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_COMMANDBUTTON_resume,
					  ATTR_DIMMED, !RUN_busyFlag);
	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_NUMERIC_nRun_R,
					  ATTR_DIMMED, RUN_busyFlag != RUN_STATE_PAUSED);
	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_TEXTMSG_resumeAt,
					  ATTR_DIMMED, RUN_busyFlag != RUN_STATE_PAUSED);
	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_NUMERIC_nRepetition_R,
					  ATTR_DIMMED, RUN_busyFlag != RUN_STATE_PAUSED);
	
	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_run,
					  ATTR_DIMMED, RUN_busyFlag == RUN_STATE_STOPPED);
	
	if (state == RUN_STATE_INACTIVE) GRAPH_setAllCurvesNotActive (); 	
	ProcessDrawEvents();

	
/*	
	int color;
	
	RUN_busyFlag = state;
//	SetCtrlVal (panelSessionMain(), SMAN_LED_busy, state);
	switch (RUN_busyFlag) {
		case RUN_STATE_STOPPED: 
			color = VAL_YELLOW;
			break;
		case RUN_STATE_PAUSED: 
			color = VAL_ORANGE;
			break;
		case RUN_STATE_ACTIVE: 
			color = VAL_RED;
			break;
		default:
			color = VAL_GREEN;
			break;
	}
			

			
	SetCtrlAttribute (panelSMain, SMAN_COMMANDBUTTON_start,
					  ATTR_CMD_BUTTON_COLOR, color);
	SetCtrlAttribute (panelSMain, SMAN_COMMANDBUTTON_start,
					  ATTR_LABEL_TEXT,
					  RUN_busyFlag ? "STOP (ESC)" : "START (F9)");
	SetCtrlAttribute (panelSMain, SMAN_COMMANDBUTTON_start,
					  ATTR_SHORTCUT_KEY,
					  RUN_busyFlag ? VAL_ESC_VKEY : VAL_F9_VKEY);
	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_COMMANDBUTTON_resume,
					  ATTR_LABEL_TEXT,
					  RUN_busyFlag == RUN_STATE_PAUSED ? "Pause" : "Resume");
	
	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_COMMANDBUTTON_resume,
					  ATTR_DIMMED, !RUN_busyFlag);
	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_NUMERIC_nRun_R,
					  ATTR_DIMMED, RUN_busyFlag != RUN_STATE_PAUSED);
	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_TEXTMSG_resumeAt,
					  ATTR_DIMMED, RUN_busyFlag != RUN_STATE_PAUSED);
	SetCtrlAttribute (RUN_subPanelResume(), RUN_RESUME_NUMERIC_nRepetition_R,
					  ATTR_DIMMED, RUN_busyFlag != RUN_STATE_PAUSED);
	
	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_run,
					  ATTR_DIMMED, RUN_busyFlag == RUN_STATE_STOPPED);
	
	if (state == RUN_STATE_INACTIVE) GRAPH_setAllCurvesNotActive (); 	
	ProcessDrawEvents();
*/
}





void RUN_resetParameters (t_session *s)
{
//	SetCtrlVal (
}


void RUN_setParametersDuringRun (t_session *s,  t_run *r)
{
	

}


void RUN_deleteAllCurrentCurves (t_run *r)
{
	t_session *s;
	int i;
	t_plotItem *p;
	t_graph *w;

	if (r == NULL) return;
	s = r->session;

	for (i = 0; i <= ListNumItems (s->lPlotItems); i++) {
		if (i == 0) p = PLOTITEM_dig (s);
		else ListGetItem (s->lPlotItems, &p, i);
		if ((p->curve != NULL) && (p->active) && (p->curve->nValuesVisibleAvg > 0)) {
			// plot has one current and one averagerd curve
			// --> delete current
			p->curve->showCurrentCurve = 0;
			p->curve->markerPoint = -1;
			w = GRAPH_getFromCurve (p->curve);
			CURVE_displayCross (w, p->curve, 0); 
			CURVE_displayTreeItem (w, p->curve, 1);
		}
	}

	
	GRAPH_setAllDisplayed (0);
	for (i = 0; i <= ListNumItems (s->lPlotItems); i++) {
		if (i == 0) p = PLOTITEM_dig (s);
		else ListGetItem (s->lPlotItems, &p, i);
		if ((p->curve != NULL) && (p->active)) {
			p->curve->active = 1;
			w = GRAPH_getFromCurve (p->curve);
			if (!w->displayed) {
				GRAPH_displayAllCurves (w, 1, 1);
				DisplayPanel (w->panelHandle);
			}
			w->displayed = 1;
			p->curve->active = 0;
		}
	}
	
}

/*

void RUN_displayAllGraphs (t_run *r)
{
	t_session *s;
	int i;
	t_plotItem *p;
	t_graph *w;

	if (r == NULL) return;
	s = r->session;
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
	}
}
*/





// save all run data
// if sequence is already in INI-format
// save it
int RUN_saveAll (t_run *r, int calledDuringRun) 
{
	t_session *s;
	
	if (r == NULL) goto ERROR;
	s = r->session;
	
//	RUN_SAVING_displayPanel ();
	if (mkDirs (r->dataDirectory) != 0) goto ERROR;

	// save all curves
	
	PLOTITEM_saveAllCurves (r->dataDirectory, r->session, 0);

	if (RUN_save (r->filenameRun, r, calledDuringRun) != 0) goto ERROR;
	r->dataSaved = 1;
	s->readOnly = 1;
	s->startNr = r->startNr;
	strcpy (s->dateStr, r->dateStr);
	

	if (!calledDuringRun) {
		SetFileAttrs (r->filenameSession, 0, -1, -1, -1);
		if (SESSION_save (r->filenameSession, s)  != 0) goto ERROR;
		SetFileAttrs (r->filenameSession, 1, -1, -1, -1);		
		
		// save sequence
		SetFileAttrs (r->filenameSequence, 0, -1, -1, -1);		
		if (Ini_saveSequence (r->seqIni, r->filenameSequence) != 0) goto ERROR;
		SetFileAttrs (r->filenameSequence, 1, -1, -1, -1);	
	}

	
//	RUN_SAVING_removePanel ();
	return 0;
ERROR:
//	RUN_SAVING_removePanel ();
	return -1;
}


int RUN_inactive (void) 
{
   return RUN_getState() == RUN_STATE_INACTIVE;
}

int RUN_start (t_session *s)
{

	t_run *r;
	char commandStr[50];
	IniText seqIni = 0;
	t_sequence *seq;
	int currentRepetition= 1;
	int currentRun = 1;
	char *errorStr = NULL;
	t_plotItem *p;
	int progressDialog = 0;
	
	RUN_protocolCls();
	
	writeSessionManagerConfig (smanagerConfig);

//	if (RUN_getState() != RUN_STATE_INACTIVE) return 0;
	if (RUN_parametersError(s)) return -1;
	
	if (PLOTITEM_checkAllForDifferentPlotRanges(s) != 0) return -1;

	
	if (!PLOTITEM_isOneActive (s) && (s->mode != SESSIONMODE_DIG)) {
		MessagePopup ("Error", "Could not start run.\n\n"
					  "No plot item selected.");
		return -1;
	}
	
	if (PLOTITEM_hasError (s, &p) && (s->mode != SESSIONMODE_DIG)) {
		MessagePopupf ("Plot item error", "Error in plot item '%s':\n\n%s",
					   p->name, PLOTITEM_errStr (p->error, s, p));
		return -1;
	}

	SetWaitCursor (1);

	EasyTab_GetAttribute (panelSMain, SMAN_CANVAS_tabCtrl,
						  ATTR_EASY_TAB_ACTIVE_PANEL,
						  &lastPanel);
	EasyTab_SetAttribute (panelSMain, SMAN_CANVAS_tabCtrl,
						  ATTR_EASY_TAB_ACTIVE_PANEL,
						  panelRun);

//	RUN_protocolCls ();

	r = RUN_init_activeRun ();	

	if (SESSION_nTotalAtoms (s)> MIN_ATOMS_DISPLAY_PROGRESS) { progressDialog = 
			  CreateProgressDialog ("Compiling Sequence",
									"Creating event list...", 1,
									VAL_NO_MARKERS, "Cancel");
	
	}	
	if (RUN_addSessionInfo (r, s) != 0) goto ERROR;
	currentRepetition = 1;
	currentRun	     = 1;
	
	RUN_setParameters (s, 0);
	SESSIONMANAGER_dimControls (activeSession(), 1);

	if (progressDialog) DiscardProgressDialog (progressDialog);
	if (SESSIONMANAGER_createSequence (s, r->filenameSequence, 1) != 0) goto ERROR;
	PLOTITEM_deleteAllReferencesToCurves (s);
	
	seq = s->sequence;
	r-> nCopiesPerRepetition = seq->nCopies;
	r->nRepetitionsPerRun = seq->nRepetitions;
	r->nRuns			  = seq->nRuns;
//	r->nRepetitionsPerSweepPoint = s->nRepetitionsPerSweepPoint;
	
	// create sequence as "*.ini" structure

	Ini_PutSequence (r->seqIni, s->sequence);
	if (s->saveRunData) {
		if (RUN_saveAll (r, 0) != 0) goto ERROR;
	}
	
	// transmit sequence to experiment control
	sprintf (commandStr, "%s %d %d %d", TCP_CMD_RUN, currentRepetition-1, currentRun-1, r->startNr);

#ifndef EXPERIMENTCONTROL
	if (launchExperimentControl (1, 0) != 0) goto ERROR;
#endif

	
	if (TCP_clientIniTransmit (r->seqIni, commandStr, 0) != 0) {
		#ifdef EXPERIMENTCONTROL
			goto ERROR;
		#else
			// no communication with Experiment Control: launch
			if (launchExperimentControl (1, 1) != 0) goto ERROR;
			// second try
			if (TCP_clientIniTransmit (r->seqIni, commandStr, 0) != 0) goto ERROR;
		#endif
	}
	SESSIONMANAGER_displayActiveTreeItem ();

	RUN_initGraphWindows (r);
	CURVES_displayPanel();
			
	SetWaitCursor (0);
	return 0;
ERROR:
	SetWaitCursor (0);
	RUN_setState (RUN_STATE_INACTIVE);
	SESSIONMANAGER_dimControls (activeSession(), 0);
	
	return -1;
	
}


void RUN_createTodaysDataPath (t_smanagerConfig *c) 
{
	int month, day, year;
	int hours, minutes, seconds;
	
	GetSystemDate (&month, &day, &year);
	GetSystemTime (&hours, &minutes, &seconds);
	
	// if before 7:00 am, use date of previous day
	if (hours < 7) day--;
	if (day <= 0) { 
		day = 1; 
		month--;
	}
	if (month <= 0) {
		month = 1;
		year--;
	}
	
	sprintf (c->dataPathToday, "%s\\%d\\%s\\%02d\\",
			c->dataPath, year, monthStr(month), day);
}


int RUN_getCurrentStartNumber (t_run *r) 
{
	char searchStr[MAX_PATHNAME_LEN];
	char found[MAX_PATHNAME_LEN];
	int startNr;
	int help;
	char h[N_STARTNR_DIGITS + 2];
	
	RUN_createTodaysDataPath (smanagerConfig);
	strcpy (searchStr, smanagerConfig->dataPathToday);
	strcat (searchStr, startSearchName);
	startNr = 0;
	if (GetFirstFile (searchStr, 1, 1, 1, 1, 1, 1, found) == 0) {
		do {
			strncpy (h, found, N_STARTNR_DIGITS);
			h[N_STARTNR_DIGITS] = 0;
			if (!StrToInt (h, &help)) help = 0;
			if (help  > startNr) startNr = help;
		} while (GetNextFile (found) == 0);
	}
	startNr ++;
	
	if (r != NULL) {
		r->startNr = startNr;
//		r->lastStarted = startNr;
		strcpy (r->dataDirectory, smanagerConfig->dataPathToday);
	}
	
	return startNr;
}



void RUN_displayRunNr (t_run *r) 
{
	if (r->lastData == NULL) return;
	setCtrlStrf (panelSMain, SMAN_STRING_status, 
					"received data: repetition=%d, run=%d, start=%d, counter=%d",
					r->lastData->repetition, r->lastData->run, r->startNr, r->lastData->counterNr);
//	SetCtrlVal (panelSMain, SMAN_NUMERICSLIDE_runD, r->currentRun+1);
//	SetCtrlVal (panelSMain, SMAN_NUMERICSLIDE_repD, r->currentRepetition+1);
}	
	

void RUN_addSweep (t_run *r)
{
	t_session *s;
	
	if (r == NULL) return;
	s = r->session;
	if (s == NULL) return;
	
	switch (s->mode) {
		case SESSIONMODE_DIG:
			r->sweep = SWEEP_dig (s);
			break;
		default:
			r->sweep = SWEEP_ptr (s, s->plotSweepParameter);
			
			if ((r->sweep == NULL) || (!r->sweep->sweepOn)) {
				// sweep not active or no sweep
				// --> look for other activated sweep
				s->plotSweepParameter = SWEEP_getLastActiveNr (s);
				r->sweep = SWEEP_ptr (s, s->plotSweepParameter);
			}
			if ((r->sweep == NULL) || (!r->sweep->sweepOn)) r->sweep = SWEEP_repetitionNr (s);
	}
}	




int RUN_addSessionInfo (t_run *r, t_session *s)
{

	char helpStr[MAX_PATHNAME_LEN];
	int i;

	r->session 				= s;

	getDateAndTime (r->dateStr, r->timeStr);

	// insert creation date
 	sprintf (r->softwareVersionStr, "Version %1.2f (built: %s)", 
 		ProgramVersion, __DATE__);


	RUN_getCurrentStartNumber (r);
	sprintf (helpStr, startDirName, r->startNr, extractFilename(s->filename));
	strcat (r->dataDirectory, helpStr);
	changeSuffix (r->dataDirectory, r->dataDirectory, "\\");

	strcpy (r->filenameSession, r->dataDirectory);
	strcat (r->filenameSession, extractFilename (s->filename));
//	changeSuffix (r->runFilename, r->sessionFilename, "_RUN.info");

	changeSuffix (helpStr, extractFilename (s->filename), ".seq");
	strcpy (r->filenameSequence, r->dataDirectory);
	strcat (r->filenameSequence, helpStr);

	changeSuffix (helpStr, extractFilename (s->filename), ".run");
	strcpy (r->filenameRun, r->dataDirectory);
	strcat (r->filenameRun, helpStr);
	
//	changeSuffix (helpStr, extractFilename (s->filename), "%s);
	strcpy (r->filenameData, r->dataDirectory);
	strcat (r->filenameData, "\\run%03d_repetition%d_det%d.data");

//	RUN_createBinFilename (r);
//	sprintf (r->binFilename, "%s\\dataDetector%d_%d, %s", r->masterDirectory, extractFilename (session->filename));

	r->mode					= s->mode;
	TIMEINTERVAL_calculateAll (s, 0, 0);
	for (i = 0; i < N_DETECTORS; i++) {
		TIMEINTERVAL_duplicateList (r->lTimeIntervals[i], s->lTimeIntervals[i], 1);
	}
	
	RUN_addSweep (r);

	if (r->sweep == NULL) {
		MessagePopup ("Error", "Could not start run\n\nNo sweep parameter selected");
		return -1;
	}
	else strcpy (r->infoStr, r->sweep->name);

	return 0;
}


void RUN_getPlotHandle (t_run *r, char *xAxisName, char *yAxisName)
{


}



/*
void displayShotNr (t_run *r, unsigned long nr)
{

	unsigned long *ones;
	unsigned long i;
	
	ones = (unsigned long *) malloc (sizeof (unsigned long) * r->bufferSize[nr]);
	for (i = 0; i < r->bufferSize[nr]; i++)
		ones[i] = 1;
	
	
	SetCtrlVal (panelAcq, AMAIN_NUMERIC_nCounts, r->bufferSize[nr]);
	DeleteGraphPlot (panelAcq, AMAIN_GRAPH, -1, VAL_IMMEDIATE_DRAW);
	PlotLine (panelAcq, AMAIN_GRAPH, 0, 0, r->duration[nr], 0,
			  VAL_RED);
	PlotXY (panelAcq, AMAIN_GRAPH, r->buffer[nr], ones,
			r->bufferSize[nr], VAL_UNSIGNED_INTEGER,
			VAL_UNSIGNED_INTEGER, VAL_BASE_ZERO_VERTICAL_BAR,
			VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);
			
	free (ones);
}
*/








/*
char *RUN_createBinFilename (t_run *r)
{
	int nDataset;
	static char binFilename[MAX_PATHNAME_LEN];
	
	nDataset =  r->nRepetitionsPerRun * r->currentRun + r->currentRepetition;
	if ((r->filenamesCounterData != NULL) && (nDataset < r->nDatasets))
		r->filenamesCounterData[nDataset] = strnewcopy(r->filenamesCounterData[nDataset], binFilename);
	return binFilename;
}
*/




void RUN_addCurrentRunToSum (t_run *r);




//==========================================================================
//
//      display time intervals
//
// =========================================================================



void TIMEINTERVAL_printf (char* format, ... )
{
	va_list arg;

	va_start( arg, format );
    vpprintf(panelRun, RUN_TEXTBOX_errTimes, format, arg  );
    va_end( arg );
}
		
		
enum {  
	TIMEINTERVAL_COL_NR,
	TIMEINTERVAL_COL_ATOM,
	TIMEINTERVAL_COL_LEVEL,
	TIMEINTERVAL_COL_TIME_START,
	TIMEINTERVAL_COL_TIME_END,
	TIMEINTERVAL_COL_NAME,
	
	N_TIMEINTERVAL_COL
};


void TIMEINTERVAL_initTree (int panel, int ctrl)
{
	int i;
	int nColumns;
	
	GetNumTreeColumns (panel, ctrl, &nColumns);
	for (i = 0; i < nColumns-1; i++) {
		DeleteTreeColumn (panel, ctrl, -1);
	}
	
	// create new tree columns
	SetCtrlAttribute (panel, ctrl,
					  ATTR_COLUMN_LABELS_VISIBLE, 1);
	for (i = 1; i < N_TIMEINTERVAL_COL; i++) 
		InsertTreeColumn (panel, ctrl, -1, "");

	// set attributes for columns
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_NR,
							ATTR_COLUMN_WIDTH, 60);
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_NR, 
							ATTR_LABEL_TEXT, "intvl. no.");
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_NR,
							ATTR_LABEL_JUSTIFY,
							VAL_CENTER_CENTER_JUSTIFIED);

	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_ATOM,
							ATTR_COLUMN_WIDTH, 40);
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_ATOM, 
							ATTR_LABEL_TEXT, "atom");

	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_LEVEL,
							ATTR_COLUMN_WIDTH, 40);
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_LEVEL, 
							ATTR_LABEL_TEXT, "level");

	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_NAME,
							ATTR_COLUMN_WIDTH, 80);
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_NAME, 
							ATTR_LABEL_TEXT, "name");

	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_TIME_START,
							ATTR_COLUMN_WIDTH, 70);
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_TIME_START,
							ATTR_LABEL_JUSTIFY,
							VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_TIME_START, 
							ATTR_LABEL_TEXT, "start [�s]");

	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_TIME_END,
							ATTR_COLUMN_WIDTH, 70);
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_TIME_END,
							ATTR_LABEL_JUSTIFY,
							VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_TIME_END, 
							ATTR_LABEL_TEXT, "end [�s]");

}


void TIMEINTERVAL_insertTreeItem (int panel, int ctrl, t_session *s, int timeIntervalNr, int detector, int *repetition)
{
	char *help;
	int newItem;
	int detItem = -1;
	t_timeInterval *t;
	t_sequence *seq;
	t_atom *a;

	t = TIMEINTERVAL_ptrList (s->lTimeIntervals[detector], timeIntervalNr);
	if (t == NULL) return;
	help = getTmpString();
	seq = s->sequence;


	// -----------------------------
	//      display "detector"
	// -----------------------------
	GetTreeItemFromValue (panel, ctrl, VAL_SIBLING, 0, VAL_FIRST,
						  VAL_NEXT_PLUS_SELF, 0, &detItem,
						  detector);

	if (detItem < 0) {
		sprintf (help, "det. %d", detector+1);
		detItem = InsertTreeItem (panel, ctrl, 
								  VAL_SIBLING, 0, VAL_LAST, help, NULL,
								  NULL, detector);
	}
	if (*repetition != t->repetition) {
		// print line if repetition changed
		newItem = InsertTreeItem (panel, ctrl, VAL_CHILD, detItem,
							      VAL_LAST, "..............", NULL, NULL, 0);
		SetTreeCellAttribute (panel, ctrl, newItem, VAL_ALL_OBJECTS,
							  ATTR_LABEL_TEXT, "...............");
		*repetition = t->repetition;
		
	}

	// -----------------------------
	//      display name
	// -----------------------------
	newItem = InsertTreeItem (panel, ctrl, VAL_CHILD, detItem,
							  VAL_LAST, t->idStr, NULL, NULL, 0);
	SetTreeItemAttribute (panel, ctrl, VAL_ALL_OBJECTS,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display name
	// -----------------------------
	SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_NAME,
						  ATTR_LABEL_TEXT, t->name);
	SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_NAME,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display atom number
	// -----------------------------
	if (t->atom != 0) {
/*	    a = ATOM_ptr (s, t->atomNr);
	    if ((a != NULL) && (strlen (a->name) != 0))
	    	sprintf (help, "%d (%s)", t->atomNr, a->name);
	    else 
	    	strcpy (help, intToStr(t->atomNr));
*/	    	
		SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_ATOM,
							  ATTR_LABEL_TEXT, t->atomNrStr);
		SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_ATOM,
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_CENTER_JUSTIFIED);
		if ((t->levelNr >= 0) && (t->levelNr < s->nLevels)) {
			SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_LEVEL,
								  ATTR_LABEL_TEXT, s->levelNames[t->levelNr]);
			SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_LEVEL,
								  ATTR_LABEL_JUSTIFY,
								  VAL_CENTER_CENTER_JUSTIFIED);
		}
	}
	// -----------------------------
	//      display start time
	// -----------------------------
	if (t->timeStart == INT_MIN) {
		strcpy (help, "START");
	}
	else {
		sprintf (help, "%03.1f", ((double) t->timeStart) * 0.05);
	}
	SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_TIME_START,
						  ATTR_LABEL_TEXT, help);
	SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_TIME_START,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display end time
	// -----------------------------
	if (t->timeEnd == INT_MAX) strcpy (help, "END");
	else sprintf (help, "%03.1f", ((double) t->timeEnd) * 0.05);
	SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_TIME_END,
						  ATTR_LABEL_TEXT, help);
	SetTreeCellAttribute (panel, ctrl, newItem, TIMEINTERVAL_COL_TIME_END,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------------
	//     dim unimportant time intervals
	// -----------------------------------
	
	SetTreeCellAttribute (panel, ctrl, newItem, VAL_ALL_OBJECTS,
						  ATTR_LABEL_COLOR, t->atom == 0 ? VAL_DK_GRAY : VAL_BLACK);
	
}



void TIMEINTERVAL_fillToRing (int panel, int ctrl, t_session *s, int det)
{
	int i, n;
	t_timeInterval *t;
	char help[MAX_INTERVAL_NAME_LEN+MAX_LEVELNAME_LEN+30];
	char levelStr[MAX_LEVELNAME_LEN+1];
	
	n = ListNumItems (s->lTimeIntervals[det]);
	setNumListItems (panel, ctrl, n);
	for (i = 1; i <= n; i++) {
		t = TIMEINTERVAL_ptrList (s->lTimeIntervals[det], i);
		if (t->levelNr >= 0) {
			strcpy (levelStr, ", ");
			strcat (levelStr, s->levelNames[t->levelNr]);
		}
		else levelStr[0] = 0;
		if (t->atom > 0) {
			sprintf (help, "%s (atom %s%s)", t->idStr, t->atomNrStr, levelStr);
		}
		else {
			sprintf (help, "%s", t->idStr);
		}
		ReplaceListItem (panel, ctrl, i-1, help, i);
	}
}


void TIMEINTERVAL_addIdStrings (t_session *s, int det)
{
	int i;
	t_timeInterval *t;
	int sub;
	
	sub = ListNumItems (s->lTimeIntervals[det]) / 2;
	for (i = ListNumItems (s->lTimeIntervals[det]); i >= 1; i--) {
		ListGetItem (s->lTimeIntervals[det], &t, i);
		if (s->transferOn) {
			sprintf (t->idStr, " %d%c", i - (t->repetition * sub), 'a'+t->repetition);
		}
		else {
			sprintf (t->idStr, " %d", i - (t->repetition * sub) );
		}
	}
}


void TIMEINTERVAL_displayAll (t_session *s, int det)
{
	int i, n;
	int oldRepetition = 0;
	
	TIMEINTERVAL_addIdStrings (s, det);
	n = ListNumItems (s->lTimeIntervals[det]);
	if (n > MAX_DISPLAY_TIMEINTERVALS) n = MAX_DISPLAY_TIMEINTERVALS;
	for (i = 1; i <= n; i++) {
		TIMEINTERVAL_insertTreeItem (panelRun, RUN_TREE_timeIntervals, s, i, det, &oldRepetition);
	}
}


int ATOMS_firstDetected (t_session *s)
{
	int i;
	t_atom *a;
	
	for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
		a = ATOM_ptr (s, i);
		if ((a->active) && (a->detect)) return i;
	}
	return 0;
}


void TIMEINTERVAL_add (t_session *s, char *name, int atomNr, int multiple, int levelNr, 
					   int detector, int timeStart, int timeEnd, int putStrings, int position)
{
	t_timeInterval *t;

	t = (t_timeInterval *) malloc (sizeof (t_timeInterval));
	TIMEINTERVAL_init (t);
	
//	t = TIMEINTERVAL_new (s->lTimeIntervals[detector]);
	if (putStrings) {
		strncpy (t->name, name, MAX_INTERVAL_NAME_LEN);
		t->name[MAX_INTERVAL_NAME_LEN-1] = 0;
		if (atomNr == 0) t->atomNrStr[0] = 0;
		else {
			if (multiple == 0) strcpy (t->atomNrStr, intToStr (atomNr));
			else sprintf (t->atomNrStr, "%d.%d", atomNr, multiple);
		}
	}
	t->atom = atomNr;
	t->multiple = multiple;
	t->levelNr = levelNr;
	t->timeEnd = timeEnd;
	t->timeStart = timeStart;
	if (position <= 0) TIMEINTERVAL_insertInOrder (s->lTimeIntervals[detector], t);
	else ListInsertItem (s->lTimeIntervals[detector], &t, position);
}


int TIMEINTERVAL_checkIfConsistent (t_session *s, int det)
{
	int i, first;
	int error = 0;
//	int det;
	t_atom *a, *firstAtom;
	t_detectionParameters *d;

	if (ListNumItems (s->lAtoms) == 0) {
		TIMEINTERVAL_printf ("ERROR: Session contains no atoms.\n");
		return -1;
	}
	
	
	if (det == 0) {
		// ------------------------------------
		//     check for consistency detector 1
		// ------------------------------------
		for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
			a = ATOM_ptr (s, i);
			if ((a->active) && (a->detect)) {
				d = DETECTIONPAR_ptr (s, a->detectionParameters);
				if (d == NULL) {
					TIMEINTERVAL_printf ("ERROR: No detection parameters selected for atom %d.\n", i);
					error = -1;
				} 
				else if (DETECTIONPAR_inconsistentNr (s, a->detectionParameters, det)) {
					TIMEINTERVAL_printf ("ERROR: Inconsistent detection parameters (%s) for atom %d.\n",
										 d->name, i);
					return -1;
				}
			}
		}
		return error;
	}
	
	// ------------------------------------
	//     check for consistency detector 2
	// ------------------------------------
	
	first = ATOMS_firstDetected (s);
	if (first == 0) {
		TIMEINTERVAL_printf ("ERROR: No atom is selected for detection. "
				    "Enable detection in menu 'Atoms/Detection'.\n");
		return -1;							   
	}
	firstAtom = ATOM_ptr (s, first);
	error = 0;
	
	for (i = first+1; i <= ListNumItems (s->lAtoms); i++) {
		a = ATOM_ptr (s, i);
		if ((a->active) && (a->detect)) {
			if (DETECTIONPAR_ptr (s, firstAtom->detectionParameters) == NULL) {
				TIMEINTERVAL_printf ("ERROR: More than one atom has been selected for detection.\n"
							"Specify detection parameters for atom %d.\n", first);
				error = 1;
			}
			if (DETECTIONPAR_ptr (s, a->detectionParameters) == NULL) {
				if (!error) TIMEINTERVAL_printf ("ERROR: More than one atom has been selected for detection.\n");
				TIMEINTERVAL_printf ("Specify detection parameters for atom %d.\n", i);
				error = 1;
			}
			if (error) return -1;
		}
	}
	
	return 0;
}		
		

int TIMEINTERVAL_checkWidths (t_session *s, int d)
{
	int i, n;
	t_timeInterval *t;
	
	n = ListNumItems (s->lTimeIntervals[d]);
	for (i = 1; i <= n; i++) {
		ListGetItem (s->lTimeIntervals[d], &t, i);
		if (t->timeStart >= t->timeEnd) {
			TIMEINTERVAL_printf ("ERROR: Time interval %d (detector %d) has negative or zero width.", i, d);
			return -1;
		}
	}
	return 0;
}




int TIMEINTERVAL_fillTimesBetweenIntervals  (t_session *s, int d)
{
	t_timeInterval *t, *prev;
	int i;
	int max;
	
//	TIMEINTERVAL_sort (s->lTimeIntervals[d]);
	if ((ListNumItems (s->lTimeIntervals[d]) == 0) && s->counterOn[d]) {
		TIMEINTERVAL_printf ("ERROR: No time interval defined for detector %d.\n", d);
		return -1;
	}	
	if (TIMEINTERVAL_checkWidths (s, d) != 0) return -1;
		
	prev = NULL;
	for (i = 1; i <= ListNumItems (s->lTimeIntervals[d]); i++) {
		ListGetItem (s->lTimeIntervals[d], &t, i);
		if (prev != NULL) {
			if (prev->timeEnd > t->timeStart) {
				TIMEINTERVAL_printf ("ERROR: time intervals %d and %d overlap.\n",
							 i-1, i);
				return -1;
			}
			if (prev->timeEnd < t->timeStart) {
				TIMEINTERVAL_add (s, "--", 0,0, -1, d, prev->timeEnd, t->timeStart, prev->atomNrStr[0] != 0, i);
				i++;
			}
		}
		prev = t;
	}

//	TIMEINTERVAL_sort (s->lTimeIntervals[d]);
	if (TIMEINTERVAL_checkWidths (s, d) != 0) return -1;
	return 0;	
}




/*
int TIMEINTERVAL_calculateLevel (t_session *s, t_plotItem *p)
{
	t_timeInterval *t;
	
	t = TIMEINTERVAL_ptrList (s->lTimeIntervals[p->detector], p->countsInterval);
	if (t == NULL) {
		p->countsAtom = -1;
		p->countsLevel = -1;
	}
	else {
		p->countsAtom  = t->atomNr;
		p->countsLevel = t->levelNr;
		if (p->countsAtom < 1) {
			p->countsAtom = -1;
			p->countsLevel = -1;
		}
	}
	return 0;
}
*/





int TIMEINTERVAL_calculateAllDet (t_session *s, int d, int display, int speedMode);


int TIMEINTERVAL_calculateAll (t_session *s, int display, int speedMode)
{
	int error = 0;
	int d;
	int counter;
	
	if (s == 0) return 0;
	if (display) {
		DeleteListItem (panelRun, RUN_TREE_timeIntervals, 0, -1);
		cls (panelRun, RUN_TEXTBOX_errTimes);
	}
	for (d = 0; d < N_DETECTORS; d++) {
    	if (TIMEINTERVAL_calculateAllDet (s, d, display,speedMode) != 0) error = -1;
	}
	
	
	if (display) TIMEINTERVALS_copyTree ();
	
	return error;
}


void TIMEINTERVAL_createListOfLevelsInOrder (t_detectionParameters *d, int nLevels, int *listOfLevelsInOrder, int *nElements)
{
	int list[MAX_LEVELS];
	int n, i, k;
	
	n = 0;
	for (i = 0; i < nLevels; i++) {
		if (d->det1_levelActive[i]) {
			k = 0;
			while ((k < n) && (d->det1_timeStart[list[k]] < d->det1_timeStart[i])) k++;
			if (k < n) memmove (&list[k+1], &list[k], (n-k)*sizeof(int));
			list[k] = i;
			n++;
		}
	}

	*nElements = n;
	memcpy (listOfLevelsInOrder, list, n * sizeof(int));
}




void TIMEINTERVAL_addAllIntervalsForAtom_Det1 (t_session *s, t_atom *a, int atomNr,int speedMode)
{
	int det = 0;
	t_detectionParameters *d;
	int startT, duration;
	
	int k, u, j;
	char *help;
	int listOfLevelsInOrder[MAX_LEVELS];
	int nElementsInList;
	int putString;
	
	help = getTmpString();
	d = DETECTIONPAR_ptr (s, a->detectionParameters);
	if (d == NULL) return;
	// add time intervals for each level
	if (!d->detectorActive[det]) return;
	
    TIMEINTERVAL_createListOfLevelsInOrder (d, s->nLevels, listOfLevelsInOrder, &nElementsInList);
    
	if (a->hasMultiples) {
   		for (j = 0; j < a->nMultiples; j++) { 
			if (speedMode && (j == N_MULTIPLES_DISPLAY_TIMEINTERVAL)) j = a->nMultiples - N_MULTIPLES_DISPLAY_TIMEINTERVAL;
			for (u = 0; u < nElementsInList; u++) {
				k = listOfLevelsInOrder[u];
				putString = ((j < N_MULTIPLES_DISPLAY_TIMEINTERVAL) || (a->nMultiples - j < N_MULTIPLES_DISPLAY_TIMEINTERVAL));
				//	putString = 1;
				if ((d->det1_timeEnd[k] != 0.0) || (d->det1_timeStart[k] != 0.0)) {
					duration =  round (VAL_us * (d->det1_timeEnd[k] - d->det1_timeStart[k]));
					if (putString) sprintf (help, "at.%d.%d,%s", atomNr, j, s->levelNames[k]);
					else help[0] = 0;
					startT    = round (VAL_us * (a->delay*j+a->time[d->det1_rampTriggerReference] + d->det1_timeStart[k] + d->det1_rampTrigger));
					TIMEINTERVAL_add (s, help, atomNr, j+1, k, det, startT, startT+duration, putString, TIMEINTERVAL_INSERT_IN_ORDER);
				}
			}
		}
	}
	else {
		for (u = 0; u < nElementsInList; u++) {
			k = listOfLevelsInOrder[u];
			if ((d->det1_timeEnd[k] != 0.0) || (d->det1_timeStart[k] != 0.0)) {
				duration =  round (VAL_us * (d->det1_timeEnd[k] - d->det1_timeStart[k]));
				sprintf (help, "at.%d,%s", atomNr, s->levelNames[k]);
				startT    = round (VAL_us * (a->time[d->det1_rampTriggerReference] + d->det1_timeStart[k] + d->det1_rampTrigger));
				TIMEINTERVAL_add (s, help, atomNr, 0, k, det, startT, startT+duration, 1, TIMEINTERVAL_INSERT_IN_ORDER);
			}
		}
	}

}




int TIMEINTERVAL_calculateAllDet (t_session *s, int det, int display,int speedMode)
{
	t_atom *a;
	int i, j,k, n;
	int startT, duration;
	t_detectionParameters *d;
	int min, max;
	int error;
	char *help;
	int curveDurationSet;
	t_timeInterval *t1, *new;
	int level;
	int counter;

	help = getTmpString();
	TIMEINTERVAL_freeList (s->lTimeIntervals[det]);
	
//	ListPreAllocate (s->lTimeIntervals[det], 6 * SESSION_nTotalAtoms (s));
	ListSetAllocationPolicy (s->lTimeIntervals[det], 1000, 50);
	
	// check for consistency
	if (TIMEINTERVAL_checkIfConsistent (s, det) < 0) return -1;

	counter = COUNTERS_NCOUNTS[det];
    if (!s->counterOn[counter]) return 0;
	
	switch (det) {
		case 0:
			// --------------------------------------
			//   insert time intervals for all atoms
			// --------------------------------------
			for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
				// get ptr to atom
				a = ATOM_ptr (s, i);
				if ((a->active) && (a->detect)) {
					TIMEINTERVAL_addAllIntervalsForAtom_Det1 (s, a, i,speedMode);
				}
			}
			break;
		case 1:  // DETECTOR2
			// --------------------------------------
			//   insert time intervals for all atoms
			// --------------------------------------
			curveDurationSet = 0;
			for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
				a = ATOM_ptr (s, i);
				if ((a->active) && (a->detect)) {
					d = DETECTIONPAR_ptr (s, a->detectionParameters);
					sprintf (help, "atom %d", i);
					if (d == NULL) {
						// no detection parameters set for atom
						// select total curve duration as time interval
						if (!curveDurationSet) {
							TIMEINTERVAL_add (s, help, i, 0,-1, det, getIntTime (s->curveStart_us), getIntTime (s->curveEnd_us), 1, TIMEINTERVAL_INSERT_IN_ORDER);
						}
						curveDurationSet = 1;
					}
					else {
						if (curveDurationSet) return -1;
						// 
						if (d->detectorActive[1]) {
							level = a->detectionLevel;
							if (s->transferOn && a->detectionUseLevelsOfTransfer) level = s->transferLevel[0]; // transfer selected
							else level = a->detectionLevel; // no transfer: use default level of atom
							duration = round ((d->det2_timeEnd - d->det2_timeStart) * VAL_us);
							if (a->hasMultiples) {
								for (j = 0; j < a->nMultiples; j++) {
									sprintf (help, "atom %d.%d", i,j);
									startT = round ((a->delay*j + a->time[d->det2_timeReference] + d->det2_timeStart) * VAL_us);
									// insert detection level:
									TIMEINTERVAL_add (s, help, i, j+1, level, det, startT, startT+duration, 1, TIMEINTERVAL_INSERT_IN_ORDER);
						 		}
						 	}
						 	else {
							 	sprintf (help, "atom %d", i);
								startT = round ((a->time[d->det2_timeReference] + d->det2_timeStart) * VAL_us);
								// insert detection level:
								TIMEINTERVAL_add (s, help, i, 0, level, det, startT, startT+duration, 1, TIMEINTERVAL_INSERT_IN_ORDER);
							}
						}
					}
				}
			}
			break;
	}

	TIMEINTERVAL_getMinMax (s->lTimeIntervals[det], &min, &max);
//	TIMEINTERVAL_add (s, "init", 0, INT_MIN, min);
	TIMEINTERVAL_add (s, "end", 0, 0, -1, det, max, INT_MAX, 1, TIMEINTERVAL_INSERT_IN_ORDER);
	error = TIMEINTERVAL_fillTimesBetweenIntervals (s, det);

//	TIMEINTERVAL_calculateIntervalsTransfer (s, p);

	// transfer selected for det. 2: double number of time intervals
	if ((s->transferOn) && (s->mode != SESSIONMODE_DIG)) {
		n = ListNumItems (s->lTimeIntervals[det]);
		for (i = 1; i <= n; i++) {
			ListGetItem (s->lTimeIntervals[det], &t1, i);
			new = TIMEINTERVAL_new (s->lTimeIntervals[det]);
			TIMEINTERVAL_duplicate (new, t1);
			new->repetition = 1;

			a = ATOM_ptr (s, t1->atom);
			if ((a != NULL) && (a->detectionUseLevelsOfTransfer)) new->levelNr = s->transferLevel[1];

//			if ((t1->atomNr == s->transferAtom) && (t1->levelNr == s->transferLevel[0])) 
//				new->levelNr = s->transferLevel[1];
		}
	}
	
//	s->nRepetitionsPerSweepPoint = 2;}
//	else s->nRepetitionsPerSweepPoint = 1;

	if (display) TIMEINTERVAL_displayAll (s, det);

	return error;	
}



int RUN_checkNumberOfCounters (t_session *s)
{
	int c;
	int nCtr;
	
	nCtr = 0;
	for (c = 0; c < N_COUNTERS; c++) nCtr += s->counterOn[c];
	if (nCtr > MAX_COUNTERS_ON) {
		RUN_printf ("TOO MANY COUNTERS: %d counters are activated. Maximum number is %d.\n",
					 nCtr, MAX_COUNTERS_ON);
		return 1;
	}
	return 0;
}



int RUN_parametersError (t_session *s)
{
	int error = 0;


//	RUN_protocolCls();

	error |= RUN_checkNumberOfCounters (s);

//	SetCtrlAttribute (panelSMain, SMAN_COMMANDBUTTON_start, 
//					  ATTR_DIMMED, s->readOnly);
	
	return error;
}




int RUN_stop (void)
{
	if (RUN_getState () == RUN_STATE_STOPPED) return 0;
	RUN_setState (RUN_STATE_STOPPED);

	TCP_clientSendStrf (TCP_CMD_STOP);
	SESSIONMANAGER_dimControls (activeSession(), 0);
	
//	RUN_deleteAllCurrentCurves (activeRun);
	if ((activeRun != NULL) && (activeRun->mode == SESSIONMODE_DIG)) {
		// keep current DIG curve at screen
		CURVE_displayTreeItem (NULL, PLOTITEM_dig(0)->curve, 1);
	}
	
	CURVES_displayPanel();

	RUN_setParameters (activeSession(), 1);
	return 0;
}


void RUN_cmdStoppedReceived (t_run *r)
{
	RUN_setState (RUN_STATE_INACTIVE);
	if (r == NULL) return;
	if (r->session->saveRunData) {
		RUN_SAVING_displayPanel ();
		PLOTITEM_saveAllCurves (r->dataDirectory, r->session, 0);
		RUN_save (r->filenameRun, r, 1);
		RUN_SAVING_removePanel ();
	}
	RUN_deleteAllCurrentCurves (r);

	SESSIONMANAGER_dimControls (activeSession(), 0);
	
	RUN_setParameters (activeSession(), 1);
}

