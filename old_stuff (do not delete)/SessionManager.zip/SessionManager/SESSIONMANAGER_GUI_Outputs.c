#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"




int panelOutputs = -1;
int panelDirect = -1;

int ctrl_outputActive[N_DIO_CHANNELS];
int ctrl_switchOnOff[N_DIO_CHANNELS];


void OUTPUTS_DIRECT_valueChanged (int control);


int OUTPUTS_initPanel (void)
{
	int i;
	int nameCtrl;
	int top, diff, height;
	int left1, left2, left3;
	int add;
	
	if (panelOutputs < 0) return -1;

	// init digital channels
	
	height = ctrlHeight (panelOutputs, OUTPUTS_STRING_name) + 2;
	left1 = ctrlLeft (panelOutputs, OUTPUTS_RADIOBUTTON_active);
	left2 = ctrlLeft (panelOutputs, OUTPUTS_STRING_name);
	left3 = ctrlLeft (panelOutputs, OUTPUTS_BINARYSWITCH_onOff);
	add = ctrlRight (panelOutputs, OUTPUTS_BINARYSWITCH_onOff) + 40;
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		if (i % (N_DIO_CHANNELS/2) == 0) {
			top = ctrlTop (panelOutputs, OUTPUTS_STRING_name);
			diff = ctrlTop (panelOutputs, OUTPUTS_RADIOBUTTON_active) - top;
		}
		ctrl_outputActive[i] = DuplicateCtrl (panelOutputs,
											  OUTPUTS_RADIOBUTTON_active,
											  panelOutputs,
											  str_ChannelNames(i), top+diff,
											  left1 + (i/(N_DIO_CHANNELS/2)) * add);
		nameCtrl = DuplicateCtrl (panelOutputs, OUTPUTS_STRING_name, panelOutputs,
					   "", top, left2 + (i/(N_DIO_CHANNELS/2) ) * add);
		SetCtrlVal (panelOutputs, nameCtrl, strDIGlabel (i));
		ctrl_switchOnOff[i] = DuplicateCtrl (panelOutputs,
											  OUTPUTS_BINARYSWITCH_onOff,
											  panelOutputs,
											  "", top+diff,
											  left3 + (i / (N_DIO_CHANNELS/2) ) * add);
		top += height;
	}
	SetCtrlAttribute (panelOutputs, OUTPUTS_DECORATION, ATTR_WIDTH,
					  ctrlRight(panelOutputs, ctrl_switchOnOff[N_DIO_CHANNELS-1])+30);
	SetCtrlAttribute (panelOutputs, OUTPUTS_DECORATION, ATTR_HEIGHT, top+10);
	SetAttributeForCtrls (panelOutputs, ATTR_VISIBLE, 0, 0, 
						  OUTPUTS_RADIOBUTTON_active,
						  OUTPUTS_STRING_name,
						  OUTPUTS_BINARYSWITCH_onOff, 0);
	SetCtrlAttribute (panelOutputs, OUTPUTS_COMMANDBUTTON_done, ATTR_VISIBLE, 0);						  
	SetCtrlAttribute (panelOutputs,  OUTPUTS_COMMANDBUTTON_manual, ATTR_TOP,
					  ctrlBottom (panelOutputs, OUTPUTS_DECORATION) + 10);
	SetCtrlAttribute (panelOutputs, OUTPUTS_COMMANDBUTTON_manual, ATTR_LEFT,
					  (ctrlWidth (panelOutputs, OUTPUTS_DECORATION)
					  - ctrlWidth (panelOutputs, OUTPUTS_COMMANDBUTTON_manual))/2
					 + ctrlLeft (panelOutputs, OUTPUTS_DECORATION));
	return 0;
}


void OUTPUTS_setColor (int panel, int channel, int active, int state)
{
	int color;

	if (active) 
		color = state ? VAL_GREEN : VAL_RED;
	else color = VAL_GRAY;
	SetCtrlAttribute (panel, ctrl_switchOnOff[channel], ATTR_BINARY_SWITCH_COLOR, color);
}


void OUTPUTS_setValues (t_session *s)
{
	int i;
	
	if (s == NULL) return;
	
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		SetCtrlVal (panelOutputs, ctrl_outputActive[i], s->digitalOutputs_preset[i]);
		SetCtrlAttribute (panelOutputs, ctrl_switchOnOff[i], ATTR_DIMMED, !s->digitalOutputs_preset[i]);
		SetCtrlVal (panelOutputs, ctrl_switchOnOff[i], s->digitalOutputs_onOff[i]);
		OUTPUTS_setColor (panelOutputs, i, s->digitalOutputs_preset[i], s->digitalOutputs_onOff[i]);
	}
}



void OUTPUTS_getValues (t_session *s)
{
	int i;

	if (s == NULL) return;
	
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		GetCtrlVal (panelOutputs, ctrl_outputActive[i], &s->digitalOutputs_preset[i]);
		GetCtrlVal (panelOutputs, ctrl_switchOnOff[i], &s->digitalOutputs_onOff[i]);
	}
	OUTPUTS_setValues (s);
}





				 

int CVICALLBACK OUTPUTS_valueChanged_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			if (panel == panelOutputs) {
				OUTPUTS_getValues (activeSession());
				SESSION_setChanges (activeSession(), 1);
			}
			else if (panel == panelDirect) {
				OUTPUTS_DIRECT_valueChanged (control);
			}
			break;
		}
	return 0;
}



int CVICALLBACK OUTPUTS_manuallyOperate_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			OUTPUTS_DIRECT_start ();
			break;
	}
	return 0;
}

// =============================================================================
//
//		direct switching of digital lines
//
// =============================================================================

void OUTPUTS_DIRECT_getLastStateDigitalLine (int *lastState, t_sequence *seq)
{
	int i;
	t_digitalBlock *b;
	
	for (i = 0; i < N_DIO_CHANNELS; i++) lastState[i] = 0;
	if (seq == NULL) return;
	
	b = DIGITALBLOCK_ptr (seq, ListNumItems (seq->lDigitalBlocks));
	for (i = 0; i < N_DIO_CHANNELS; i++) {
    	switch (seq->DIO_channelStatus[i]) {
    		case DIO_CHANNELSTATUS_ALWAYSON:
    			lastState[i] = 1;
    			break;
    		case DIO_CHANNELSTATUS_ALWAYSOFF:
    			lastState[i] = 0;
    			break;
    		default:
        		lastState[i] = b->channels[i];
        }
        lastState[i] ^= CREATESEQ_isChannelInverted (i);
	}
}


void OUTPUTS_DIRECT_initPanel (void)
{
	t_run *r;
	t_sequence *seq = NULL;
	int i;
	
	int lastStateDigitalLine[N_DIO_CHANNELS];
	
	if (panelDirect <=  0) {
		panelDirect = DuplicatePanel (0, panelOutputs, "Digital lines",
									  VAL_AUTO_CENTER, VAL_AUTO_CENTER);
		SetCtrlAttribute (panelDirect,  OUTPUTS_COMMANDBUTTON_done, ATTR_VISIBLE, 1);
		SetCtrlAttribute (panelDirect,  OUTPUTS_COMMANDBUTTON_manual, ATTR_VISIBLE, 0);
		SetPanelAttribute (panelDirect, ATTR_TITLEBAR_VISIBLE, 1);
		SetPanelAttribute (panelDirect, ATTR_BACKCOLOR, VAL_ORANGE);
		SetCtrlAttribute (panelDirect,  OUTPUTS_COMMANDBUTTON_done, ATTR_TOP, 
						  ctrlBottom (panelDirect, OUTPUTS_DECORATION) + 10);
		SetCtrlAttribute (panelDirect,  OUTPUTS_COMMANDBUTTON_done, ATTR_LEFT, 
						    ctrlRight (panelDirect, OUTPUTS_DECORATION) 
						  - ctrlWidth (panelDirect,  OUTPUTS_COMMANDBUTTON_done));
		SetPanelSize (panelDirect, ctrlBottom (panelDirect,  OUTPUTS_COMMANDBUTTON_done) + 10,
								   ctrlRight (panelDirect,  OUTPUTS_COMMANDBUTTON_done) + 10);									
	}
	r = activeRunPtr();
	if ((r != NULL) && (r->session != NULL)) seq = r->session->sequence;
	OUTPUTS_DIRECT_getLastStateDigitalLine (lastStateDigitalLine, seq);
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		SetCtrlAttribute (panelDirect, ctrl_outputActive[i], ATTR_VISIBLE, 0);
		SetCtrlAttribute (panelDirect, ctrl_switchOnOff[i], ATTR_DIMMED, 0);
		SetCtrlAttribute (panelDirect, ctrl_switchOnOff[i], ATTR_CTRL_VAL, lastStateDigitalLine[i]);
		OUTPUTS_setColor (panelDirect, i, 1, lastStateDigitalLine[i]);
	}
	InstallPopup (panelDirect);	
	OUTPUTS_DIRECT_valueChanged (0);
}



void OUTPUTS_DIRECT_start (void)
{
	OUTPUTS_DIRECT_initPanel ();
}


void OUTPUTS_DIRECT_sendCommandTCP (int *digitalLines)
{
	char commandLine[500];
	int i;
	
	strcpy (commandLine, TCP_CMD_DIGITAL_LINES);
	strcat (commandLine, " ");
	
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		if (i > 0) strcat (commandLine, ",");
		strcat (commandLine, intToStr (digitalLines[i]));
	}
	
	TCP_clientSendStrf (commandLine);
}


void OUTPUTS_DIRECT_getValues (int *digitalLines)
{
	int i;
	
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		GetCtrlVal (panelDirect, ctrl_switchOnOff[i], &digitalLines[i]);
		OUTPUTS_setColor (panelDirect, i, 1, digitalLines[i]);
		digitalLines[i] ^= CREATESEQ_isChannelInverted (i);
	}
}


void OUTPUTS_DIRECT_valueChanged (int control)
{
	int digitalLines[N_DIO_CHANNELS];
	
	OUTPUTS_DIRECT_getValues (digitalLines);
	OUTPUTS_DIRECT_sendCommandTCP (digitalLines);
}



int CVICALLBACK OUTPUT_DIRECT_done_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			RemovePopup (1);
			break;
	}
	return 0;
}
