
#if !defined (SESSIOMANAGER_RUN)
#define SESSIOMANAGER_RUN
#define TIMEINTERVAL_SPEEDMODE 1

enum {
	RUN_STATE_INACTIVE = 0,
	RUN_STATE_ACTIVE,
	RUN_STATE_PAUSED,
	RUN_STATE_STOPPED
};


//t_run *activeRun(void);



//void RUN_init_activeRun (void);
//void RUN_init_activeRun (int mode);

t_run *activeRunPtr(void);

int lastActivePanel (void);

t_run *RUN_init_activeRun (void);


int RUN_getState (void);

void RUN_setState (int state);


void RUN_filterData (t_run *r);

//void RUN_allocateMemory (t_run *r);


//char *RUN_createBinFilename (t_run *r);

int RUN_getCurrentStartNumber (t_run *r);

void RUN_addSweep (t_run *r);

int RUN_addSessionInfo (t_run *r, t_session *s);

void RUN_processReceivedData (t_run *r);

void RUN_createTodaysDataPath (t_smanagerConfig *c);

void RUN_deleteAllCurrentCurves (t_run *r);


int RUN_saveAll (t_run *r, int calledDuringRun);


int RUN_start (t_session *s);

int RUN_stop (void);





//int TIMEINTERVAL_calculateAll (t_session *s);

void TIMEINTERVAL_addIdStrings (t_session *s, int det);


int TIMEINTERVAL_calculateAll (t_session *s, int display,int speedMode);

void TIMEINTERVAL_initTree (int panel, int ctrl);

void TIMEINTERVAL_fillToRing (int panel, int ctrl, t_session *s, int det);




//int TIMEINTERVAL_calculateLevel (t_session *s, t_plotItem *p);

int RUN_parametersError (t_session *s);

void RUN_cmdStoppedReceived (t_run *r);



#endif
