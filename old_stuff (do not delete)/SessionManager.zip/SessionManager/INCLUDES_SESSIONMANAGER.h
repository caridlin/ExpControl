//
//    contains all include files for "Session Manager"
//

#define SESSIONMANAGER 1

#ifdef _CVI_DEBUG_
// for debugging purposes only
//	#define MEASUREDURATION 1
//	#define DISPLAY_TESTDATA 1
#endif

#if !defined(INCLUDES_SESSIONMANAGER)
#define INCLUDES_SESSIONMANAGER

#include "UIR_SessionManager.h"


#include <cvirte.h>		
#include <analysis.h>
#include <ansi_c.h>
#include <userint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <formatio.h>
#include <utility.h>
#include <userint.h>
#include <time.h>
#include <float.h>  
#include "nidaqcns.h"  

#include "easytab.h"
#include "toolbox.h"
#include "easyio.h"
#include "inifile.h"
#include "tools.h"		   			// some useful functions

#include "UIR_common.h"
//#include "UIR_TCP_IP.h"
#include "INTERFACE_TCP_IP.h"

#include "CONTROL/CONTROL_Definitions.h"
#include "CONTROL/CONTROL_GUI_EditPoints.h"
#include "CONTROL/CONTROL_DataStructure.h"
#include "CONTROL/CONTROL_CalculateOutput.h" 
#include "CONTROL/CONTROL_LoadSave.h"


#include "SESSIONMANAGER/SESSIONMANAGER_DataStructure.h"
#include "SESSIONMANAGER/SESSIONMANAGER_DataProcessing.h"
#include "SESSIONMANAGER/SESSIONMANAGER_LoadSave.h"
#include "SESSIONMANAGER/SESSIONMANAGER_Run.h"
#include "SESSIONMANAGER/SESSIONMANAGER_Diagram.h"

#include "SESSIONMANAGER/SESSIONMANAGER_GUI_Atoms.h"
#include "SESSIONMANAGER/SESSIONMANAGER_GUI_Config.h"
#include "SESSIONMANAGER/SESSIONMANAGER_GUI_Main.h"
#include "SESSIONMANAGER/SESSIONMANAGER_GUI_Sweep.h"
#include "SESSIONMANAGER/SESSIONMANAGER_GUI_Run.h"
#include "SESSIONMANAGER/SESSIONMANAGER_GUI_Detection.h"
#include "SESSIONMANAGER/SESSIONMANAGER_GUI_PreviousRuns.h" 
#include "SESSIONMANAGER/SESSIONMANAGER_GUI_Outputs.h" 
#include "SESSIONMANAGER/SESSIONMANAGER_GUI_PlotItems.h" 
#include "SESSIONMANAGER/SESSIONMANAGER_GUI_Filters.h" 
#include "SESSIONMANAGER/SESSIONMANAGER_CreateSequence.h"
#include "SESSIONMANAGER/SESSIONMANAGER_Curves.h"
#include "SESSIONMANAGER/SESSIONMANAGER_CustomEvaluation1.h"    
#include "SESSIONMANAGER/SESSIONMANAGER_CustomEvaluation2.h"    



#endif

