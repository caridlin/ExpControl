#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"
#include "GPIB_DRIVER_LeCroy.h"



//int ATOMS_TABLE_MENU_CHANGE_VALUE = -1;
//int ATOMS_TABLE_MENU_SELECT_ITEMS = -1;
#define ATOMS_TABLE_ROW_HEIGHT 25

#define VAL_COL_REFERENCE_ATOM MakeColor(100,100,255)
#define VAL_COL_ACTIVE_ATOM    MakeColor(255,200,130)
#define VAL_COL_ACTIVE_ATOM_DK MakeColor(255,160,100)


#define STRING_POWER4 "Power 4 (=RF Rhode Schwarz #10)"
//int menuTable = -1;
//int BITMAP_YesNo[2] = { -1, -1 };

int panelAtoms;

t_controls ctrlKiller;



enum {	
	N_PANEL_VELOCITY,
	N_PANEL_CIRC,
	N_PANEL_STATE,
	N_PANEL_EVENTS,
	N_PANEL_CAVITY1,
	N_PANEL_CAVITY2,
	N_PANEL_DETECTORS,
	
	N_SUBPANELS
};


int ATOMS_subPanels[N_SUBPANELS] = {  -1, -1, -1, -1 };
int panelTimeReference = -1;
int panelKillerPoints  = -1;

int allowEdit;

int menuTable = -1;
int menuItemsTable[N_TABLE_CONFIGS] = {
	TABLEMENU_1_SETCONFIG_CONFIG1,
	TABLEMENU_1_SETCONFIG_CONFIG2,
	TABLEMENU_1_SETCONFIG_CONFIG3
};

int panelTableCol = -1;






int subPanelCirc (void)
{
    return ATOMS_subPanels[N_PANEL_CIRC];
}	

int subPanelVelocity (void)
{
    return ATOMS_subPanels[N_PANEL_VELOCITY];
}	

int subPanelEvents (void) 
{
    return ATOMS_subPanels[N_PANEL_EVENTS];
}


int subPanelCavity (int i) 
{
    return ATOMS_subPanels[N_PANEL_CAVITY1+i];
}

int subPanelState (void) 
{
    return ATOMS_subPanels[N_PANEL_STATE];
}


int subPanelDetection (void) 
{
    return ATOMS_subPanels[N_PANEL_DETECTORS];
}

const char *strState (int state)
{
	switch (state) {
		case STATE_G: return "|g>";
		case STATE_E: return "|e>";
		case STATE_NONE: return "NONE";
		default: return "";
	}
}


int ATOMS_activeCavityNr (void)
{
	int i;
	int activePanel;
	
	EasyTab_GetAttribute (panelAtoms, ATOMS_CANVAS,
						  ATTR_EASY_TAB_ACTIVE_PANEL, &activePanel);
	
	for (i = 0; i < N_CAVITIES; i++) {
		if (activePanel == subPanelCavity(i)) return i;
	}
	DebugPrintf ("Wrong panel number!\n");
	Breakpoint();
	return -1;
}


void setCtrlMode (int panel, int control, int hot, int reference) 
{
	int color;
	
	if (control == -1) return;
	if (reference) color = VAL_COL_REFERENCE_ATOM;
//		else color = VAL_DK_YELLOW;
		else color = VAL_MED_GRAY;
	SetCtrlAttribute (panel, control, ATTR_FRAME_COLOR, 
					 (hot || reference) ? VAL_LT_GRAY : VAL_DK_YELLOW);
					  
	SetCtrlAttribute (panel, control , ATTR_CTRL_MODE, 
					  (hot) ? VAL_HOT : VAL_INDICATOR);
	SetCtrlAttribute (panel, control, ATTR_SHOW_INCDEC_ARROWS,
					  hot);
	SetCtrlAttribute (panel, control, ATTR_TEXT_BGCOLOR,
					  (hot) ? VAL_WHITE : color);
}

/*	
double ATOMS_getSmallestTime (t_session *s, int atomNr)
{
	t_atomEvent *e;
	double smallestTime;
	static ListType list = NULL;
	
	if (list == NULL) list = ListCreate (sizeof (t_event*));
	
	CREATESEQ_insertEventsAtoms (list, s, atomNr, 0);
	smallestTime = EVENTS_calculateSmallestTime (list, NULL);
	EVENT_freeAll (list);
	ListClear (list);
	
	return smallestTime;
}
*/

/*
double ATOMS_getSmallestTimeAll (t_session *s)
{
	double time = 0.0;
	double smallestTime = DBL_MAX;
	int i;
	t_atom *a;
	
	for (i = 1; i <= ListNumItems(s->lAtoms); i++) {
		ListGetItem (s->lAtoms, &a, i);
		if (a->active) {
			time = ATOMS_getSmallestTime (s, i);
			if (time < smallestTime) smallestTime = time;
		}
	}
	// just in case there was no active atom...
	if (time < smallestTime) smallestTime = time;
	return smallestTime;
}
*/


void ATOMS_checkForCircles (t_session *s)
{

}





void ATOMS_fillAtomNamesToRing (int panel, int control, t_session *s, int addNone, int checkForCrossRefs)
{
	int nItems, itemSelected;
	t_atom *a;
	char help[100];
	int i,u,k;
	
	/////calculate the number of atoms including copies
	nItems = ListNumItems(s->lAtoms) + addNone;
	setNumListItems (panel, control, nItems);
	if (addNone) ReplaceListItem (panel, control, 0, "???", 0);
	k=1;
	for (i = 1; i <= ListNumItems(s->lAtoms); i++) {
		a = ATOM_ptr (s, i);
		
		if ((a->name == NULL) || (strcmp (a->name, "") == 0)) 
			strcpy (help, intToStr (i));
		else sprintf (help, "%d (%s)", i, a->name);
		ReplaceListItem (panel, control, k+addNone-1, help, k);
		k++;

	}
}



void ATOMS_fillLevelsToRing (int panel, int control, t_session *s, int showVoltages)
{
	t_atom *a;
	char *help;
	int i;
	
	help = getTmpString();
	setNumListItems (panel, control, s->nLevels);
	for (i = 0; i < s->nLevels; i++) {
		if (showVoltages) {
			sprintf (help, "%s (%1.3fV)", s->levelNames[i], s->levelVoltages[i]);
			ReplaceListItem (panel, control, i, help, i);
		}
		else ReplaceListItem (panel, control, i, s->levelNames[i], i); 
	}
}


void ATOMS_setAsActive (t_session *s, int nr)
{
	if (nr > 0) {
		s->activeAtomNo = nr;
//		DebugPrintf ("setActive %d ", nr);
		SetCtrlVal (panelAtoms, ATOMS_NUMERIC_number, nr);
	}
	ATOMS_EVENTS_displayAll (s, activeAtom());

}


t_atom *activeAtom (void)
{
	t_session *s;
	
	s = activeSession();
	return ATOM_ptr (s, s->activeAtomNo);
}






void ATOMS_calculateTimesForAtom (t_session *s, t_atom *a)
{
	t_atomConfig *c;
	double dist;
	int i;
	double timeOffset;
	double referencePos;
	
	if (a->velocity == 0) {
		ATOM_resetAbsoluteTimes  (a);
		return;
	}
	
	c = s->atomConfig;
	
	referencePos = c->position[c->referenceAtomPosition];
	timeOffset = a->time[c->referenceAtomPosition];
	// circularization
	for (i = 0; i < N_POSITIONS; i++) {
		dist = c->position[i] - referencePos;
		a->time[i] = timeOffset + (dist / a->velocity * 1E3);
	}	

}


void ATOMS_calculateAllTimes (t_session *s)
{
	int i, n;
	t_atom *a;
	double sub;
	
	for (n = 1; n <= ListNumItems(s->lAtoms); n++) {
		a = ATOM_ptr (s, n);
		ATOMS_calculateTimesForAtom (s, a);
	}

	a = ATOM_ptr (s, s->atomConfig->referenceAtom);
	sub = a->time[s->atomConfig->referenceAtomPosition];
	
	for (n = 1; n <= ListNumItems(s->lAtoms); n++) {
		a = ATOM_ptr (s, n);
		for (i = 0; i < N_POSITIONS; i++) a->time[i] -= sub;
	}
}








int ATOMS_initPanel (void)
{
	int i;
	int panelDummy;
	int panelIDs [N_SUBPANELS] = {
		ATOMS_VEL,  
		ATOMS_CIRC, 		
		ATOMS_STAT, 		
		ATOMS_EVTS, 		
		ATOMS_CAV,  		
		ATOMS_CAV,  		
		ATOMS_DET
	};
	
#define N_PANELS_ATOMS

	for (i = 0; i < N_SUBPANELS; i++) {
		ATOMS_subPanels[i] = LoadPanel (panelAtoms, SESSIONMANAGER_uirFile, panelIDs [i]);
	}
	

	DATAFIELD_initAll ();
// -----------------------------------------
//     first call: create menus
// -----------------------------------------
		// -----------------------------------------
		//     hide built-in menus
		// -----------------------------------------
		HideBuiltInCtrlMenuItem (panelAtoms, ATOMS_TABLE, VAL_GOTO);
		HideBuiltInCtrlMenuItem (panelAtoms, ATOMS_TABLE, VAL_SEARCH);
		HideBuiltInCtrlMenuItem (panelAtoms, ATOMS_TABLE, VAL_SORT);
		// -----------------------------------------
		// 		create new menus
		// -----------------------------------------
		
	ChainCtrlCallback (panelAtoms, ATOMS_TABLE, TABLE_processEvents_CB, &allowEdit,
					   "TABLE_processEvents");
	panelDummy = LoadPanel (0, SESSIONMANAGER_uirFile, PTABLEMENU);
	menuTable = GetPanelMenuBar (panelDummy);
	
	ATOMS_TABLE_init ( activeSession());
	// init ring select state
	ClearListCtrl (subPanelState(), ATOMS_STAT_RING_state);
	InsertListItem (subPanelState(), ATOMS_STAT_RING_state, -1, "None",
					STATE_NONE);
	InsertListItem (subPanelState(), ATOMS_STAT_RING_state, -1, "|e>",
					STATE_E);
	InsertListItem (subPanelState(), ATOMS_STAT_RING_state, -1, "|g>",
					STATE_G);
	for (i = 0; i < N_POSITIONS; i++) 
		if ((df(i)->controlID != -1) && (df(i)->panelID != -1)) {
			SetCtrlAttribute (df(i)->panelID, df(i)->controlID,
							  ATTR_MAX_VALUE, 10000.0);
			SetCtrlAttribute (df(i)->panelID, df(i)->controlID,
							  ATTR_MIN_VALUE, -10000.0);
			SetCtrlAttribute (df(i)->panelID, df(i)->controlID,
							  ATTR_INCR_VALUE, 1.0);
			SetCtrlAttribute (df(i)->panelID, df(i)->controlID,
							  ATTR_CHECK_RANGE, VAL_COERCE);
			SetCtrlAttribute (df(i)->panelID, df(i)->controlID,
							  ATTR_SHOW_INCDEC_ARROWS, 0);
		}
	ATOMS_KILLER_initPanel ();
	ATOMS_VELOCITY_initPanel (activeSession());
	ATOMS_EVENTS_initPanel ();
	ATOMS_CAVITY_initPanel (0);
	ATOMS_CAVITY_initPanel (1); 				
	ATOMS_DETECTOR_initPanel (activeSession());

	EasyTab_ConvertFromCanvas (panelAtoms,
							   ATOMS_CANVAS);
	EasyTab_AddPanels (panelAtoms, ATOMS_CANVAS, 1,
						ATOMS_subPanels[N_PANEL_VELOCITY],
						ATOMS_subPanels[N_PANEL_CIRC],
						ATOMS_subPanels[N_PANEL_STATE],
						ATOMS_subPanels[N_PANEL_EVENTS],
						ATOMS_subPanels[N_PANEL_CAVITY1], 
						ATOMS_subPanels[N_PANEL_CAVITY2], 
						ATOMS_subPanels[N_PANEL_DETECTORS], 0);
	EasyTab_SetTabAttribute (panelAtoms, ATOMS_CANVAS, subPanelCavity(1),
							 ATTR_EASY_TAB_LABEL_TEXT, "Cavity 2");

//	DisplayPanel (panelAtoms);
	return 0;
}

/*
void ATOMS_setCtrlModeReadOnly (t_session *s)
{
	int controlMode;
	int presentMode;
	int i;
	
	controlMode = s->readOnly ? VAL_INDICATOR : VAL_HOT;
	GetCtrlAttribute (panelAtoms, ATOMS_RADIOBUTTON_active, 
					  ATTR_CTRL_MODE, &presentMode);
	if (presentMode == controlMode) return;
	
	SetAttributeForCtrls (panelAtoms, ATTR_DIMMED, 
						  s->readOnly, 0, 
						  ATOMS_BTN_deleteAtom, 
						  ATOMS_BTN_newAtom,
						  0);
	SetAttributeForCtrls (panelAtoms, ATTR_CTRL_MODE, controlMode, 0, 
						  ATOMS_STRING_name, 
						  ATOMS_RADIOBUTTON_active,
						  ATOMS_TABLE_edited,
						  0);
	// sub panel "velocity selection"
	SetAttributeForCtrls (subPanelVelocity(), ATTR_CTRL_MODE, controlMode, 0, 
						  ATOMS_VEL_BTN_velocitySelection, 
						  ATOMS_VEL_NUMERIC_velocity,
						  ATOMS_VEL_RING_frequency,
						  ATOMS_VEL_RING_power,
						  ATOMS_VEL_NUMERIC_repStart,
						  ATOMS_VEL_RING_referencePos,
						  ATOMS_VEL_NUMERIC_durationRep,
						  0);
	SetAttributeForCtrls (subPanelCirc(), ATTR_CTRL_MODE, controlMode, 0, 
						  ATOMS_CIRC_RADIOBUTTON_always, 
						  ATOMS_CIRC_NUMERIC_timeLaser1,
						  ATOMS_CIRC_NUMERIC_durationL1,
						  ATOMS_CIRC_NUMERIC_trigRFcirc,
						  ATOMS_CIRC_NUMERIC_trigCircRamp,
						  0);
	SetAttributeForCtrls (subPanelState(), ATTR_CTRL_MODE, controlMode, 0, 
						  ATOMS_STAT_RING_state, 
						  ATOMS_STAT_NUMERIC_purifStart_e,
						  ATOMS_STAT_NUMERIC_purifDur_e,
						  ATOMS_STAT_NUMERIC_purifStart_g,
						  ATOMS_STAT_NUMERIC_purifDur_g,
						  0);
	SetAttributeForCtrls (subPanelDetection(), ATTR_CTRL_MODE, controlMode, 0, 
						  ATOMS_DET_CHECKBOX_detectAtom, 
						  ATOMS_DET_RING_detectionParams,
						  0);
	// sub panel Events
	SetAttributeForCtrls (subPanelEvents(), ATTR_DIMMED, 
						  s->readOnly, 0, 
						  ATOMS_EVTS_BTN_deleteEvent, 
						  ATOMS_EVTS_BTN_newEvent,
						  ATOMS_EVTS_BTN_importEvent,
						  0);
	SetAttributeForCtrls (subPanelEvents(), ATTR_CTRL_MODE, controlMode, 0, 
						  ATOMS_EVTS_LISTBOX_events,
						  ATOMS_EVTS_RADIOBUTTON_active,
						  ATOMS_EVTS_STRING_name,
						  ATOMS_EVTS_RING_digitalChannel,
						  ATOMS_EVTS_NUMERIC_start,
						  ATOMS_EVTS_RING_referencePos,
						  ATOMS_EVTS_CHECKBOX_varyStart,
						  ATOMS_EVTS_NUMERIC_startIncr,
						  ATOMS_EVTS_NUMERIC_durationFirst,
						  ATOMS_EVTS_CHECKBOX_varyDuration,
						  ATOMS_EVTS_NUMERIC_durationIncr,
						  0);
	for (i = 0; i < N_CAVITIES; i++) {
		SetAttributeForCtrls (subPanelCavity(i), ATTR_CTRL_MODE, controlMode, 0, 
						  ATOMS_CAV_RING_referencePos,
						  ATOMS_CAV_NUMERIC_killerStart,
						  0);
		SetCtrlAttribute (subPanelCavity(i), ATOMS_CAV_BTN_importParameters,
						  ATTR_DIMMED, s->readOnly);
	}
}

*/


void ATOMS_changeVisibility (t_session *s)
{
   	int i;
   	int refPos;
   	int isReference;
   	t_dataField *d;
   	int dimmed;
   	
    // -----------------------------------------
	//   dimm controls if no atom present
	// -----------------------------------------
	SetAttributeForCtrls (panelAtoms, ATTR_DIMMED, ListNumItems(s->lAtoms) == 0, 0, 
		ATOMS_NUMERIC_number, 		 
		ATOMS_RADIOBUTTON_active,    
		ATOMS_TABLE,                 
		ATOMS_STRING_name,           
		ATOMS_BTN_deleteAtom,        
		ATOMS_CANVAS,
		0);


	
	dimmed = ListNumItems(s->lAtoms) == 0;
	if (dimmed) {
		SetAttributeForCtrls (panelAtoms, ATTR_DIMMED, dimmed, 0, 
			ATOMS_CHECKBOX_multiple,
			ATOMS_NUMERIC_delai,
			ATOMS_NUMERIC_multiplicity,
			0);
	}
	for (i = 0; i < N_SUBPANELS; i++) {
		SetPanelAttribute (ATOMS_subPanels[i], ATTR_DIMMED, dimmed);
	}
	
	
//	ATOMS_setCtrlModeReadOnly (s);
	if (ListNumItems(s->lAtoms) == 0) return;
	// dimm all time except for reference
	
	refPos      = s->atomConfig->referenceAtomPosition;
	isReference = s->activeAtomNo == s->atomConfig->referenceAtom;
	for (i = 0; i < N_POSITIONS; i++) {
		if (i != refPos) {
			setCtrlMode (df(i)->panelID, df(i)->controlID, 0, 0 );
/*			setCtrlMode (df(i)->panelID, df(i)->controlID, 
									   (!activeAtom()->autoCalculateTimes), 0 );*/
		}
		else {
			setCtrlMode (df(i)->panelID, df(i)->controlID, 
						 !isReference, isReference);
		}
		
	}
/*	if (s->activeAtomNo == s->atomConfig->referenceAtom)
		setCtrlMode (df(refPos)->panelID, 
					 df(refPos)->controlID, 
					 0, 1);
*/		

}



void ATOMS_displayAllValues (t_session *s)
{
	int nAtoms;
	int i;
	
	if (s == NULL) return;
	nAtoms = ListNumItems(s->lAtoms);
	SetCtrlVal (panelAtoms, ATOMS_NUMERIC_total, nAtoms);
//	ATOMS_fillAtomNamesToRing (panelAtoms, ATOMS_RING_referenceStartL1, s, 0);
	for (i = 0; i < N_POSITIONS; i++) {
		df(i)->isEditable = (i == s->atomConfig->referenceAtomPosition);
	}
	
	if (nAtoms > 0) {
		SetCtrlAttribute (panelAtoms, ATOMS_NUMERIC_number,
						  ATTR_MAX_VALUE, nAtoms);
		ATOMS_setAsActive (s, s->activeAtomNo);	
		if (s->activeAtomNo > nAtoms) {
			ATOMS_setAsActive (s, nAtoms);
		}
		ATOMS_displayAtomParameters(s, activeAtom());
	}
	ATOMS_TABLE_displayAllAtoms (s);
	ATOMS_changeVisibility (s); 
	ATOMS_EVENTS_displayAll (s, activeAtom());
}



void ATOMS_displayParameters_velocitySelection (t_session *s, t_atom *a)
{
	SetCtrlVal (subPanelVelocity(), ATOMS_VEL_BTN_velocitySelection, a->velocitySelection);
	SetCtrlVal (subPanelVelocity(), ATOMS_VEL_NUMERIC_velocity, a->velocity);


	SetCtrlVal (subPanelVelocity(), ATOMS_VEL_RING_frequency, a->repumperFrequency);
	SetCtrlVal (subPanelVelocity(), ATOMS_VEL_RING_power,     a->repumperPower);
	SetCtrlVal (subPanelVelocity(), ATOMS_VEL_NUMERIC_durationRep, a->repumperDuration);
}



void ATOMS_setDataField (t_atom *a, int dataFieldID)
{
	double dValue;
	int iValue;
	char *cValue;
	t_dataField *d;
	void *sourcePtr;
	
	d = df(dataFieldID);
	
	if (d->contentOffset == ULONG_MAX) return;
	if ((d->controlID < 0) || (d->panelID < 0)) return;

	sourcePtr = (void*) ((unsigned) a + d->contentOffset);
	switch (d->dataType) {
		case VAL_DOUBLE:
			memcpy (&dValue, sourcePtr, sizeof (double));
			SetCtrlVal (d->panelID, d->controlID, dValue);
			break;
		case VAL_YES_NO:
		case VAL_INTEGER:
			memcpy (&iValue, sourcePtr, sizeof (int));
			SetCtrlVal (d->panelID, d->controlID, iValue);
			break;
		case VAL_STRING:
			memcpy (&cValue, &sourcePtr, sizeof (char *));
			SetCtrlVal (d->panelID, d->controlID, cValue);
			break;
		default:
			return;
	}
}






int ATOMS_getDataField (t_atom *a, int dataFieldID)
{
	double dValue;
	int iValue;
	char *cValue;
	t_dataField *d;
	void *destPtr;
	
	d = df(dataFieldID);
	
	if (d->contentOffset == ULONG_MAX) return 0;
	if ((d->controlID < 0) || (d->panelID < 0)) return 0;

	destPtr = (void*) ((unsigned) a + d->contentOffset);
	switch (d->dataType) {
		case VAL_DOUBLE:
			GetCtrlVal (d->panelID, d->controlID, &dValue);
			switch (d->timebase) {
				case TIMEBASE_DIGITAL:
					break;
				case TIMEBASE_ANALOG:
					dValue = roundTimeAnalogBoard (dValue);
					break;
			}
			memcpy (destPtr, &dValue, sizeof (double));
			break;
		case VAL_YES_NO:
		case VAL_INTEGER:
			GetCtrlVal (d->panelID, d->controlID, &iValue);
			memcpy (destPtr, &iValue, sizeof (int));
			break;
		case VAL_STRING:
			GetCtrlVal (d->panelID, d->controlID, (char *) destPtr);
			break;
		default:
			return 0;
	}
	return 1;
}



int ATOMS_getDataFieldFromPanel (t_atom *a, int panel, int control)
{
    int i;
    
    for (i = 0; i < N_DATAFIELDS; i++) {
    	if ((control == df(i)->controlID) && (panel == df(i)->panelID)) {
    		return ATOMS_getDataField (a, i);
    	}
	}
	return 0;
}


void ATOMS_setTableCellValFromDataField (int panel, int control, Point p, 
									     t_atom *a, int dataFieldID)
{
	double dValue, old_dValue;
	int iValue, old_iValue;
	char *cValue, *old_cValue;
	t_dataField *d;
	void *sourcePtr;
	
	if (dataFieldID > N_DATAFIELDS) return;
	d = df(dataFieldID);
	
	if (d->contentOffset == ULONG_MAX) return;
	sourcePtr = (void*) ((unsigned) a + d->contentOffset);
	switch (d->dataType) {
		case VAL_DOUBLE:
			memcpy (&dValue, sourcePtr, sizeof (double));
			break;
		case VAL_YES_NO:
		case VAL_INTEGER:
			memcpy (&iValue, sourcePtr, sizeof (int));
			break;
		case VAL_STRING:
			memcpy (&cValue, &sourcePtr, sizeof (char *));
			break;
		default:
			return;
	}	
	
	switch (dataFieldID) {
		case DF_STATE:
			cValue = (char *) strState(iValue);
			break;
		case DF_NR:
			return;
	}

	switch (d->tableCellType) {
		case VAL_DOUBLE:
			GetTableCellVal (panel, control, p, &old_dValue);
			if (dValue != old_dValue) 
				SetTableCellVal (panel, control, p, dValue);
			break;
		case VAL_YES_NO:
			TABLE_setCellValueYesNo (panel, control, p, iValue);
			break;
		case VAL_INTEGER:
			GetTableCellVal (panel, control, p, &old_iValue);
			if (iValue != old_iValue) 
				SetTableCellAttribute (panel, control, p, ATTR_CTRL_VAL, iValue);
			break;
		case VAL_STRING:
			SetTableCellAttribute (panel, control, p, ATTR_CTRL_VAL, cValue);
			break;
	}	
	
}


int ATOMS_getTableCellValToDataField (int panel, int control, Point p, 
									  t_atom *a, int dataFieldID)
{
	double dValue;
	int iValue;
	char *cValue;
	t_dataField *d;
	void *destPtr;
	
	d = df(dataFieldID);
	
	if (d->contentOffset == ULONG_MAX) return 0;
	if (!d->isEditable) return 1;

	destPtr = (void*) ((unsigned) a + d->contentOffset);
	switch (d->tableCellType) {
		case VAL_DOUBLE:
			GetTableCellVal (panel, control, p, &dValue);
			break;
		case VAL_YES_NO:
			TABLE_getCellValueYesNo (panel, control, p, &iValue);
			break;
		case VAL_INTEGER:
			GetTableCellVal (panel, control, p, &iValue);
			break;
		case VAL_STRING:
			GetTableCellVal (panel, control, p, (char *) destPtr);
			break;
		default:
			return 0;
	}
	
	
	switch (dataFieldID) {
		case DF_NR:
		case DF_STATE:
			return 1;
	}
			
	
	switch (d->dataType) {
		case VAL_DOUBLE:
			memcpy (destPtr, &dValue, sizeof (double));
			break;
		case VAL_YES_NO:
		case VAL_INTEGER:
			memcpy (destPtr, &iValue, sizeof (int));
		case VAL_STRING:
			break;
		default:
			return 0;
	}
	return 1;
}


void ATOMS_CIRC_setValues (t_session *s, t_atom *a)
{
	SetAttributeForCtrls (subPanelCirc(), ATTR_DIMMED, 
						  s->laser1AlwaysOn, 0,
						  ATOMS_CIRC_NUMERIC_timeLaser1,
						  ATOMS_CIRC_NUMERIC_durationL1,
						  0);
	SetCtrlVal (subPanelCirc(), ATOMS_CIRC_RADIOBUTTON_always, s->laser1AlwaysOn);
	
	SetAttributeForCtrls (subPanelCirc(), ATTR_DIMMED, 
						  s->laser2AlwaysOn, 0,
						  ATOMS_CIRC_TEXTMSG_time2,
						  ATOMS_CIRC_TEXTMSG_duration2,
						  ATOMS_CIRC_NUMERIC_timeLaser2,
						  ATOMS_CIRC_NUMERIC_durationL2,
						  0);
	SetCtrlVal (subPanelCirc(), ATOMS_CIRC_RADIOBUTTON_alwaysOn2, 
				s->laser2AlwaysOn);

	SetAttributeForCtrls (subPanelCirc(), ATTR_DIMMED, 
						  s->optPumpingAlwaysOn, 0,
						  ATOMS_CIRC_TEXTMSG_time3,
						  ATOMS_CIRC_TEXTMSG_duration3,
						  ATOMS_CIRC_NUMERIC_timeLaserOP,
						  ATOMS_CIRC_NUMERIC_durationOP,
						  0);
	
	SetCtrlVal (subPanelCirc(), ATOMS_CIRC_RADIOBUTTON_alwaysOn3, 
				s->optPumpingAlwaysOn);
	
			  
}




void ATOMS_CIRC_getValues (t_session *s, t_atom *a)
{
	GetCtrlVal (subPanelCirc(), ATOMS_CIRC_RADIOBUTTON_always, 
				&s->laser1AlwaysOn);
	GetCtrlVal (subPanelCirc(), ATOMS_CIRC_RADIOBUTTON_alwaysOn2, 
				&s->laser2AlwaysOn);
	GetCtrlVal (subPanelCirc(), ATOMS_CIRC_RADIOBUTTON_alwaysOn3, 
				&s->optPumpingAlwaysOn);
}

void ATOMS_STATES_setValues (t_atom *a)
{
	SetCtrlAttribute (subPanelState(), ATOMS_STAT_NUMERIC_purifStart_g,
				      ATTR_DIMMED, a->state != STATE_G);
	SetCtrlAttribute (subPanelState(), ATOMS_STAT_NUMERIC_purifDur_g,
				      ATTR_DIMMED, a->state != STATE_G);
	SetCtrlAttribute (subPanelState(), ATOMS_STAT_TEXTMSG_start_g,
				      ATTR_DIMMED, a->state != STATE_G);
	SetCtrlAttribute (subPanelState(), ATOMS_STAT_TEXTMSG_dur_g,
				      ATTR_DIMMED, a->state != STATE_G);

	SetCtrlAttribute (subPanelState(), ATOMS_STAT_NUMERIC_purifStart_e,
				      ATTR_DIMMED, a->state != STATE_E);
	SetCtrlAttribute (subPanelState(), ATOMS_STAT_NUMERIC_purifDur_e,
				      ATTR_DIMMED, a->state != STATE_E);
	SetCtrlAttribute (subPanelState(), ATOMS_STAT_TEXTMSG_start_e,
				      ATTR_DIMMED, a->state != STATE_E);
	SetCtrlAttribute (subPanelState(), ATOMS_STAT_TEXTMSG_dur_e,
				      ATTR_DIMMED, a->state != STATE_E);
}


void ATOMS_VELOCITY_getValues (t_session *s, t_atom *a)
{
	GetCtrlVal (subPanelVelocity(), ATOMS_VEL_RADIOBUTTON_always, &s->repumperAlwaysOn);
	GetCtrlVal (subPanelVelocity(), ATOMS_VEL_RING_frequencyAll,  &s->repumperFrequency);
	GetCtrlVal (subPanelVelocity(), ATOMS_VEL_RING_powerAll, &s->repumperPower);
}



void ATOMS_VELOCITY_setValues (t_session *s, t_atom *a)
{
/*	SetAttributeForCtrls (subPanelVelocity(), ATTR_DIMMED, 
						  !a->velocitySelection, 0,
						  ATOMS_VEL_NUMERIC_velocity,
						  ATOMS_VEL_NUMERIC_spread,
						  ATOMS_VEL_TEXTMSG_ms_2,
						  ATOMS_VEL_TEXTMSG_display,
						  0);
						  */
	SetAttributeForCtrls (subPanelVelocity(), ATTR_DIMMED, 
						  !a->velocitySelection || s->repumperAlwaysOn, 0,
						  ATOMS_VEL_RING_frequency,
						  ATOMS_VEL_RING_power,
						  ATOMS_VEL_NUMERIC_durationRep,
						  ATOMS_VEL_TEXTMSG_duration,
						  ATOMS_VEL_TEXTMSG_repumper,
						  ATOMS_VEL_NUMERIC_timeRep,
						  ATOMS_VEL_TEXTMSG_time1,
						  ATOMS_VEL_RING_referencePos,
						  ATOMS_VEL_TEXTMSG_calcTime,
						  ATOMS_VEL_NUMERIC_repStart,
						  0);
	SetAttributeForCtrls (subPanelVelocity(), ATTR_DIMMED,
						  !s->repumperAlwaysOn, 0,
						  ATOMS_VEL_RING_frequencyAll,
						  ATOMS_VEL_RING_powerAll,
						  0);
	
	SetCtrlVal (subPanelVelocity(), ATOMS_VEL_RADIOBUTTON_always, s->repumperAlwaysOn);
	SetCtrlVal (subPanelVelocity(), ATOMS_VEL_RING_frequencyAll,  s->repumperFrequency);
	SetCtrlVal (subPanelVelocity(), ATOMS_VEL_RING_powerAll,      s->repumperPower);
}


void ATOMS_VELOCITY_initPanel (t_session *s)
{
 	int i;
 	char help[50];
 	t_atom *a;
 	
	SCONFIG_POSITIONS_initRingReference (subPanelVelocity(), ATOMS_VEL_RING_referencePos);

	if (s == NULL) return;
 	// -----------------------------------------
    //     init rings frequency / power
	// -----------------------------------------
	setNumListItems (subPanelVelocity(), ATOMS_VEL_RING_frequency, N_RF_CHANNELS);
	setNumListItems (subPanelVelocity(), ATOMS_VEL_RING_power, N_RF_CHANNELS);
	setNumListItems (subPanelVelocity(), ATOMS_VEL_RING_frequencyAll, N_RF_CHANNELS);
	setNumListItems (subPanelVelocity(), ATOMS_VEL_RING_powerAll, N_RF_CHANNELS);

//	ReplaceListItem (subPanelVelocity(), ATOMS_VEL_RING_power, 0, "OFF", 0);
//	ReplaceListItem (subPanelVelocity(), ATOMS_VEL_RING_powerAll, 0, "OFF", 0);
	for (i = 0; i < N_RF_CHANNELS; i++) {
		sprintf (help, "RF%d (%2.1f m/s, %2.1f MHz)", i+1, 
			s->atomConfig->rfMultiplexerVelocity[i],
			s->atomConfig->rfMultiplexerFrequency[i]);
		ReplaceListItem (subPanelVelocity(), ATOMS_VEL_RING_frequency, i, help,
						i+1);
		ReplaceListItem  (subPanelVelocity(), ATOMS_VEL_RING_frequencyAll, i, help,
						i+1);
		if (i == 3) strcpy (help, STRING_POWER4);
		else sprintf (help, "Power %d (%2.1f dBm)",
			i+1, s->atomConfig->rfMultiplexerPower[i]);
		ReplaceListItem  (subPanelVelocity(), ATOMS_VEL_RING_power, i, help,
						i+1);
		ReplaceListItem  (subPanelVelocity(), ATOMS_VEL_RING_powerAll, i, help,
						i+1);
	}

}



void ATOMS_DETECTOR_initPanel (t_session *s)
{
 	if (s == NULL) return;
 	DETECTORS_fillNamesToListbox (subPanelDetection(),
 								  ATOMS_DET_RING_detectionParams, s);
  	ATOMS_fillLevelsToRing (subPanelDetection(), ATOMS_DET_RING_voltDet2, s, 1);

 								  
//	InsertListItem (subPanelDetection(),
//					ATOMS_DET_RING_detectionParams, 0, "NONE", 0);
}



void ATOMS_DETECTOR_setValues (t_session *s, t_atom *a)
{
	int index;
	
	SetCtrlVal (subPanelDetection(), ATOMS_DET_CHECKBOX_detectAtom, 
				a->detect);
	SetCtrlVal (subPanelDetection(), ATOMS_DET_RING_detectionParams, 
				a->detectionParameters);
	SetCtrlVal (subPanelDetection(), ATOMS_DET_CHECKBOX_useDetTransf, 
				a->detectionUseLevelsOfTransfer);
	SetCtrlVal (subPanelDetection(), ATOMS_DET_CHECKBOX_setDetLevel, 
				a->detectionSetLevel);
	SetCtrlVal (subPanelDetection(), ATOMS_DET_NUMERIC_time, 
				a->detectionTime);
	SetCtrlVal (subPanelDetection(), ATOMS_DET_RING_referencePos, 
				a->detectionTimeReference);						  
	SetCtrlVal (subPanelDetection(), ATOMS_DET_RING_voltDet2, 
				a->detectionLevel);
	if (!a->detect) {
		SetAttributeForCtrls (subPanelDetection(), ATTR_DIMMED, 
							  //(s->detector != 1) || 
							  (!a->detect), 0,
			     			   ATOMS_DET_RING_detectionParams,
			     			   ATOMS_DET_RING_referencePos,
			     			   ATOMS_DET_NUMERIC_time, 
			     			   ATOMS_DET_CHECKBOX_setDetLevel,  
			     			   ATOMS_DET_CHECKBOX_useDetTransf,
			     			   0);
			     			   
	}
	else {
		SetCtrlAttribute (subPanelDetection(), ATOMS_DET_CHECKBOX_useDetTransf, 
						  ATTR_DIMMED, a->detectionSetLevel);
		SetCtrlAttribute (subPanelDetection(), ATOMS_DET_CHECKBOX_setDetLevel, 
						  ATTR_DIMMED, a->detectionUseLevelsOfTransfer);
		SetCtrlAttribute (subPanelDetection(), ATOMS_DET_RING_voltDet2, 
						  ATTR_DIMMED, a->detectionUseLevelsOfTransfer);

	}
}


void ATOMS_DETECTOR_getValues (t_atom *a)
{
	GetCtrlVal (subPanelDetection(), ATOMS_DET_CHECKBOX_detectAtom, 
				&a->detect);
	GetCtrlVal (subPanelDetection(), ATOMS_DET_RING_detectionParams, 
				&a->detectionParameters);
	GetCtrlVal (subPanelDetection(), ATOMS_DET_CHECKBOX_useDetTransf, 
				&a->detectionUseLevelsOfTransfer);
	GetCtrlVal (subPanelDetection(), ATOMS_DET_CHECKBOX_setDetLevel, 
				&a->detectionSetLevel);
	GetCtrlVal (subPanelDetection(), ATOMS_DET_NUMERIC_time, 
				&a->detectionTime);
	GetCtrlVal (subPanelDetection(), ATOMS_DET_RING_referencePos, 
				&a->detectionTimeReference);						  
	GetCtrlVal (subPanelDetection(), ATOMS_DET_RING_voltDet2, 
				&a->detectionLevel);
				
}

int CVICALLBACK ATOMS_DETECTOR_parameterChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	t_atomEvent *activeEvent;
	
	switch (event) {
		case EVENT_COMMIT:
			ATOMS_DETECTOR_getValues (activeAtom());
			SESSION_setChanges (activeSession(), 1);
			ATOMS_DETECTOR_setValues (activeSession(),activeAtom());
			break;
	}
	return 0;
}
  
  
void ATOMS_displayAtomParameters (t_session *s, t_atom *a)
{
	int i;
	t_filter *f;
	
	if (a == NULL) return;
	for (i = 0; i < N_DATAFIELDS; i++) ATOMS_setDataField (a, i);
	SetCtrlAttribute (panelAtoms, ATOMS_NUMERIC_delai,
								  ATTR_DIMMED, !a->hasMultiples);
	SetCtrlAttribute (panelAtoms, ATOMS_NUMERIC_multiplicity,
								  ATTR_DIMMED, !a->hasMultiples);
	SetCtrlAttribute (panelAtoms, ATOMS_TEXTMSG_us,
								  ATTR_DIMMED, !a->hasMultiples);
	
	
	ATOMS_VELOCITY_setValues (s, a);
	ATOMS_CIRC_setValues (s, a);
	ATOMS_STATES_setValues (a);
	ATOMS_DETECTOR_setValues (s, a);
	ATOMS_EVENTS_displayAll (s, a);
	for (i = 0; i < N_CAVITIES; i++) {
		ATOMS_CAVITY_setValues (s, a, i);
		ATOMS_CAVITY_displayKillerPoints (a, i);
	}
	
	ATOMS_changeVisibility (s);

}



void ATOMS_getParmeters (t_session *s, t_atom *a)
{
	ATOMS_VELOCITY_getValues (s, a);
	ATOMS_CIRC_getValues (s,a);
}



//=======================================================================
//
//    parameters of atom changed 
//
//=======================================================================
int CVICALLBACK Atom_ParameterChanged (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    int changes;
    t_atom *a;
    char help[100];
    t_session *s;
    int nr;
    int found = 0;
    int i;
    int runState;

//	printf ("%s\n", eventStr (event, eventData1, eventData2));
    if (event == EVENT_LEFT_CLICK) QueueUserEvent (EVENT_LEFT_DOUBLE_CLICK, panel, control);
    if (event == EVENT_KEYPRESS) {
    	if (eventData1 == ',') FakeKeystroke ('.');
/*			GetCtrlAttribute (panel, control, ATTR_RUN_STATE, &runState);
			if ((runState != VAL_EDIT_STATE)) {
				SetCtrlAttribute (panel, control, ATTR_RUN_STATE, VAL_EDIT_STATE);
			}
		}*/
	}
    	
    
    if ((event != EVENT_COMMIT) && (event != EVENT_VAL_CHANGED)) return 0;
	s = activeSession();
    if (ListNumItems (s->lAtoms) == 0) return 0;
	a = activeAtom();
    changes = 1;
	if (ATOMS_getDataFieldFromPanel (a, panel, control)) 
		goto CHANGES;
/*    for (i = 0; i < N_POSITIONS; i++) {
    	if ((control == df(i)->controlID) && (panel == df(i)->panelID)) {
    		GetCtrlVal (panel, control, &a->time[i]);
    		found = 1;
    	}
	}
*/
	//if (found) goto CHANGES;
	if (panel == panelAtoms) {
		switch (control) {
		/*
				
	SetCtrlAttribute (panelAtoms, ATOMS_NUMERIC_delai,
								  ATTR_DIMMED, !a->hasMultiples);
	SetCtrlAttribute (panelAtoms, ATOMS_NUMERIC_multiplicity,
								  ATTR_DIMMED, !a->hasMultiples);
	
		
			
				
				break;
			case ATOMS_NUMERIC_multiplicity: 
				GetCtrlVal (panelAtoms, ATOMS_NUMERIC_multiplicity,
							&a->multiplicity);
				break;
			case ATOMS_NUMERIC_delai: 
				GetCtrlVal (panelAtoms, ATOMS_NUMERIC_delai, &a->delay);
				break;*/
	        case ATOMS_NUMERIC_number:
            	changes = 0;
				GetCtrlVal (panel, ATOMS_NUMERIC_number, &nr);
				ATOMS_setAsActive (s, nr);
				a = activeAtom();
				ATOMS_displayAtomParameters (s, a);
				ATOMS_changeVisibility (s);
				ATOMS_TABLE_displayColors (panel, ATOMS_TABLE, s);
				break;
            case ATOMS_RADIOBUTTON_active:
				GetCtrlVal (panelAtoms, ATOMS_RADIOBUTTON_active, &a->active);
				break;
			case ATOMS_STRING_name:
				GetCtrlVal (panelAtoms, ATOMS_STRING_name, a->name);
				break;
			default:
            	changes = 0;
    	
        }
    }
	else if (panel == subPanelState()) {
		switch (control) {
			case ATOMS_STAT_RING_state:
				GetCtrlVal (subPanelState(), ATOMS_STAT_RING_state, &a->state);
				break;
/*			case ATOMS_STAT_NUMERIC_purifStart:
			case ATOMS_STAT_NUMERIC_purifEnd:
				if (a->state == STATE_E) {
					GetCtrlVal (subPanelState(), ATOMS_STAT_NUMERIC_purifStart, &a->purifStart_e);
					GetCtrlVal (subPanelState(), ATOMS_STAT_NUMERIC_purifEnd,   &a->purifEnd_e);
				}
				else {
					GetCtrlVal (subPanelState(), ATOMS_STAT_NUMERIC_purifStart, &a->purifStart_g);
					GetCtrlVal (subPanelState(), ATOMS_STAT_NUMERIC_purifEnd,   &a->purifEnd_g);
				}
				break;
*/			default:
				changes = 0;
		}
	}
	else if (panel == subPanelCirc()) {
		ATOMS_CIRC_getValues (s, a);
	}
	else if (panel == subPanelCavity(0)) {
		switch (control) {
			default:
				changes = 0;
		}
	}
	else if (panel == subPanelCavity(1)) {
		switch (control) {
			default:
				changes = 0;
		}
	
	}
	else if (panel == subPanelVelocity()) {
		ATOMS_VELOCITY_getValues (s, a);
		switch (control) {
//			case ATOMS_VEL_BTN_velocitySelection:
//				GetCtrlVal (subPanelVelocity(), ATOMS_VEL_BTN_velocitySelection, &a->velocitySelection);
//				break;
			case ATOMS_VEL_NUMERIC_velocity:
				GetCtrlVal (subPanelVelocity(), ATOMS_VEL_NUMERIC_velocity, &a->velocity);
				ATOMS_calculateAllTimes (s);
//				ATOMS_calculateTimesForAtom (s, a);
				break;
			case ATOMS_VEL_RING_frequency:
				GetCtrlVal (subPanelVelocity(), ATOMS_VEL_RING_frequency, &a->repumperFrequency);
				break;
			case ATOMS_VEL_RING_power:
				GetCtrlVal (subPanelVelocity(), ATOMS_VEL_RING_power,     &a->repumperPower);
				break;
//			case ATOMS_VEL_NUMERIC_durationRep:
//				GetCtrlVal (subPanelVelocity(), ATOMS_VEL_NUMERIC_durationRep, &a->repumperDuration);
//				break;		
			case ATOMS_VEL_NUMERIC_spreadDoppler:
				GetCtrlVal (subPanelVelocity(), ATOMS_VEL_NUMERIC_spreadDoppler,     &a->velocitySpreadDoppler);
				break;
			default:
				changes = 0;
		}
	
	}
	
	
	else changes = 0;

CHANGES:

	
	SESSION_setChanges (s, changes);
	ATOMS_calculateAllTimes (s);
	ATOMS_TABLE_displayAllAtoms (s);
//	ATOMS_TABLE_displayActiveAtom (s);
	ATOMS_displayAtomParameters (s, a);
	ATOMS_changeVisibility (s);

	return 0;

}





/************************************************************************
 ************************************************************************

	 	editing table of atoms

 ************************************************************************
 ************************************************************************/



//=======================================================================
//
//    'right click' on table
//
//=======================================================================

/*
void CVICALLBACK ATOMS_TABLE_menuItemSelected (int panelHandle, int controlID,
                              int menuItemID, void *callbackData)
{
	t_session *s;
	}
	
}
*/


void ATOMS_TABLE_init (t_session *s)
{
	int i;
	int panel;
	int table;

	t_atomConfig *c;
	int columns;
	int valueID;
	int cellType;
	int nRows;
	
	panel = panelAtoms;
	table = ATOMS_TABLE;
	// -----------------------------------------
	// 		set table attributes
	// -----------------------------------------
	SetCtrlAttribute (panel, table, ATTR_TABLE_MODE, VAL_COLUMN);
	SetCtrlAttribute (panel, table, ATTR_ENABLE_ROW_SIZING, 0);
	SetCtrlAttribute (panel, table, ATTR_ENABLE_COLUMN_SIZING, 0);
	SetCtrlAttribute (panel, table, ATTR_WIDTH, panelWidth (panel));
	
	SetTableRowAttribute (panel, table, -1, ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTableRowAttribute (panel, table, -1, ATTR_ROW_HEIGHT, ATOMS_TABLE_ROW_HEIGHT);
	
// -----------------------------------------
//    create columns 
// -----------------------------------------
    SetCtrlAttribute (panel, table, ATTR_VISIBLE, 0);
	GetNumTableRows (panel, table, &nRows);
	if (nRows > 0) DeleteTableRows (panel, table, 1, -1);
	GetNumTableColumns (panel, table, &columns);
	if (columns > 0) DeleteTableColumns (panel, table, 1, -1);
	if (s == NULL) return;
	c = s->atomConfig;
	if (c == NULL) return;
	for (i = 1; i <= c->nTableColumns[c->activeConfig]; i++) {
		valueID = c->tableColumns[c->activeConfig][i-1];
		if (valueID < N_DATAFIELDS) {
			switch (df(valueID)->tableCellType) {
				  case VAL_STRING:
				  	  cellType = VAL_CELL_STRING;
				  	  break;
				  case VAL_YES_NO:
				  	  cellType = VAL_CELL_STRING;
				  	  break;
				  default:
				      cellType = VAL_CELL_NUMERIC;
				      break;
			}
			InsertTableColumns (panel, table, i, 1, cellType);
			
			SetTableColumnAttribute (panel, table, i,
					ATTR_COLUMN_WIDTH, df(valueID)->tableColumnWidth);
			SetTableColumnAttribute (panel, table, i, ATTR_LABEL_TEXT, df(valueID)->tableColumnName);
			SetTableColumnAttribute (panel, table, i, ATTR_USE_LABEL_TEXT, 1);
			SetTableColumnAttribute (panel, table, i, ATTR_LABEL_WRAP_MODE,
									 VAL_WORD_WRAP);
			SetTableColumnAttribute (panel, table, i, ATTR_CELL_TYPE,
									 cellType);

			if (df(valueID)->tableCellType == VAL_YES_NO) {
				TABLE_setColumnAttributesYesNo (panel, table, i);
			}
			else {
				if (cellType == VAL_CELL_NUMERIC)
					SetTableColumnAttribute (panel, table, i, ATTR_DATA_TYPE,
										 df(valueID)->tableCellType);
				SetTableColumnAttribute (panel, table, i, ATTR_CELL_MODE,
						df(valueID)->isEditable ? VAL_HOT : VAL_INDICATOR);
			}

			// some columns have special settings
			switch (valueID) {
				case DF_NR:
				case DF_REPUMPER_FREQ:
				case DF_REPUMPER_POWER:
				case DF_STATE:
					SetTableColumnAttribute (panel, table, i, ATTR_CELL_JUSTIFY,
											 VAL_CENTER_CENTER_JUSTIFIED);
					break;
				case DF_NAME:
					SetTableColumnAttribute (panel, table, i, ATTR_CELL_JUSTIFY,
											 VAL_TOP_CENTER_JUSTIFIED);
					break;
			}
		}		
	}

    SetCtrlAttribute (panel, table, ATTR_VISIBLE, 1);

}

/*
void ATOMS_TABLE_displayReferenceAtom (t_session *s)
{
	char nameStr[10];
	int row, col, columnID;
	int i;
	t_atomConfig *c;
	
	c = s->atomConfig;
/*	strcpy (nameStr, intToStr (c->referenceAtom));
	GetTableRowFromLabel (panelAtoms, ATOMS_TABLE, 1, &row,
						  nameStr, 1);
	
	row = c->referenceAtom;
	if (row == -1) return;
	columnID = tableColFromPos[s->atomConfig->referenceAtomPosition];
	col = 0;
	for (i = 0; i < c->nDisplayedTableColumns; i++) {
		if (c->displayedTableColumns[i] == columnID) col = i+1;
	}
	
	if ((row > 0) && (col > 0)) {
    	SetTableCellRangeAttribute (panelAtoms, ATOMS_TABLE,
								MakeRect(row, col, 1, 1),
								ATTR_TEXT_BGCOLOR, VAL_BLUE);
	}
}
*/



void ATOMS_TABLE_displayActiveAtom (t_session *s)
{
	int row;
	
	row = ATOMS_TABLE_getRowFromAtomNr (panelAtoms, ATOMS_TABLE, s, s->activeAtomNo);
	ATOMS_TABLE_displayAtom	(row, intToStr (s->activeAtomNo), ATOM_ptr(s, s->activeAtomNo), s);
}



void ATOMS_TABLE_displayAtom (int row, char *atomLabel, t_atom *a, t_session *s)
{
	int i;
	int dataFieldID;
	Point p;
	t_atomConfig *c;
	c = s->atomConfig;
	for (i = 0; i < c->nTableColumns[c->activeConfig]; i++) {
		dataFieldID = c->tableColumns[c->activeConfig][i];
		p = MakePoint (i+1, row);
//		if (i == 3) Breakpoint();
		ATOMS_setTableCellValFromDataField (panelAtoms, ATOMS_TABLE, p, a, dataFieldID);
//		ProcessDrawEvents();
	}		
	SetTableCellAttribute (panelAtoms, ATOMS_TABLE, MakePoint (1, row), ATTR_CTRL_VAL, atomLabel); 
}

//	ATOMS_TABLE_displayColors (panel, table, s);


/*
void ATOMS_TABLE_updateAllAtoms (int panel, int table, t_session *s)
{
    int i;
    
    for (i = 1; i <= ListNumItems(s->lAtoms); i++) {
		ATOMS_TABLE_displayAtom(i, intToStr (i), ATOM_ptr (s, i), s);
    }
	ATOMS_TABLE_displayColors (panel, table, s);
//	ProcessDrawEvents();
}
*/

//=======================================================================
//
//    displays the properties of the atoms in the
//
//=======================================================================
void ATOMS_TABLE_displayAllAtoms (t_session *s)
{
    int i;
    int rows = 0;
    int cols = 0;
	int panel;
	int table; 						
	
	panel = panelAtoms;
	table = ATOMS_TABLE;
	
	if (ListNumItems (s->lAtoms) == 0) return;
	// -----------------------------------------
	//      hide table
	// -----------------------------------------
//    SetCtrlAttribute (panel, table, ATTR_VISIBLE, 0);
	// -----------------------------------------
	//      insert new rows
	// -----------------------------------------
	setNumTableRows (panel, table, ListNumItems(s->lAtoms), ATOMS_TABLE_ROW_HEIGHT);

    for (i = 1; i <= ListNumItems(s->lAtoms); i++) {
		ATOMS_TABLE_displayAtom(i, intToStr (i), ATOM_ptr (s, i), s);
    }
	ATOMS_TABLE_displayColors (panel, table, s);

/*	GetNumTableRows (panel, table, &rows);
	GetNumTableColumns (panel, table, &cols);
	SetTableCellRangeAttribute (panel, table, MakeRect(1, 1, cols, rows),
								ATTR_USE_LABEL_TEXT, 1);
*/

//    SetCtrlAttribute (panel, table, ATTR_VISIBLE, 1);
}




int ATOMS_TABLE_getAtomNrFromLabel (int row)
{
	char helpStr[20];
	int nr;
	
	GetTableCellVal (panelAtoms, ATOMS_TABLE, MakePoint (1, row), helpStr);
	if (!StrToInt (helpStr, &nr)) {
//		DebugPrintf ("!!!");
//		Breakpoint();
		return 0;
	}
//	DebugPrintf (" %s %d ", helpStr, nr);
	return nr;
}

	 
void ATOMS_TABLE_getAtomDataFromRow (int row, t_session *s)
{
	char helpStr[100];
	int nr;
	t_atom *a;
	int changes;
	
	int dataFieldID;
	t_atomConfig *c;
	int i;
	Point p;
	

	nr = ATOMS_TABLE_getAtomNrFromLabel(row);
	a = ATOM_ptr (s, nr);
	if (a == NULL) return;

	c = s->atomConfig;
	
	for (i = 1; i <= c->nTableColumns[c->activeConfig]; i++) {
		dataFieldID = c->tableColumns[c->activeConfig][i-1];
		p = MakePoint (i, row);
		changes = 1;
		if (!ATOMS_getTableCellValToDataField (panelAtoms, ATOMS_TABLE, p, 
									      a, dataFieldID)) {
		}

		if (dataFieldID <= N_POSITIONS) {
			//GetTableCellVal (panel, table, p, &a->time[i]);  
		}

	}		
    if (changes) {
		SESSION_setChanges (s, 1);
//		ATOMS_displayAtomInTable (panelAtoms, ATOMS_TABLE, nr, a);
//		ATOMS_setAsActive (s, nr);
	}
}


void ATOMS_TABLE_getAtomData (t_session *s)
{
	int i, nRows;
	
	GetNumTableRows (panelAtoms, ATOMS_TABLE, &nRows);
	for (i = 1; i <= nRows; i++) {
		ATOMS_TABLE_getAtomDataFromRow (i, s);
	}
}


int ATOMS_TABLE_getRowFromAtomNr (int panel, int table, t_session *s, int atomNr)
{
	int i;
	char strSearchName[10];
	char strLabelName[20] = "x";
	int nRows;
	int col;
	
	strcpy (strSearchName, intToStr(atomNr));
	if (GetNumTableRows (panel, table, &nRows) < 0) return -1;
	col = ATOMS_TABLE_columnFromDataFieldID (s, DF_NR);
	if (col == 0) return 0;
	for (i = 1; i <= nRows; i++) {
	    GetTableCellVal (panel, table, MakePoint(col, i), strLabelName);
	    if (strcmp (strLabelName, strSearchName) == 0) return i;
	}
	return 0;
}



int ATOMS_TABLE_columnFromDataFieldID (t_session *s, int dataFieldID)
{
	t_atomConfig *c;
	int i;

	c = s->atomConfig;
	for (i = 0; i < c->nTableColumns[c->activeConfig]; i++) {
		if (c->tableColumns[c->activeConfig][i] == dataFieldID) return i+1;
	}
	return 0;
}




void ATOMS_TABLE_displayColors (int panel, int table, t_session *s)
{
	
	int nRows;
	t_atomConfig *c;
	int i;
	int row;
	int column;
	int rowReference, columnReference, rowActive;
	int isReference, isEditable;
	t_atom *a;
	Rect r;
	int color;
	int old, mode;

	GetNumTableRows (panel, table, &nRows);
   	c = s->atomConfig;
	rowReference    = ATOMS_TABLE_getRowFromAtomNr (panel, table, s, c->referenceAtom);
	if (rowReference < 1) return;
	columnReference = ATOMS_TABLE_columnFromDataFieldID (s, s->atomConfig->referenceAtomPosition);
	rowActive       = ATOMS_TABLE_getRowFromAtomNr (panel, table, s, s->activeAtomNo);
	if (rowActive < 1) return;
	// --------------------------------------------
	//    set white background for editable fields
	// --------------------------------------------
	
//	DebugPrintf ("------------------------\n");
	for (row = 1; row <= nRows; row++) {
		a = ATOM_ptr (s, ATOMS_TABLE_getAtomNrFromLabel(row));
//		if (a == NULL) editable = 1; else editable = !a->autoCalculateTimes
		for (i = 0; i < c->nTableColumns[c->activeConfig]; i++) {
			column = c->tableColumns[c->activeConfig][i];
			isReference = (i+1 == columnReference) && (row == rowReference);
			isEditable  = df(column)->isEditable && !isReference;
			if (isReference) {
				color = VAL_COL_REFERENCE_ATOM;
				//DebugPrintf ("i=%d, ref=%d, row=%d, col=%d\n", i, isReference, row, column);
			}
			
			else if (row == rowActive) color = isEditable ? VAL_COL_ACTIVE_ATOM : VAL_COL_ACTIVE_ATOM_DK;
			else color = isEditable ? VAL_WHITE : VAL_MED_GRAY;
			
			r = MakeRect(row, i+1, 1, 1);
			
			// set background color
			GetTableCellAttribute (panel, table, MakePoint(i+1,row),
								   ATTR_TEXT_BGCOLOR, &old);
			if (color != old)								   
				SetTableCellRangeAttribute (panel, table, r, ATTR_TEXT_BGCOLOR, color);
			// set ctrl mode
			mode = (isEditable) ? VAL_HOT : VAL_INDICATOR;
			GetTableCellAttribute (panel, table, MakePoint(i+1,row),
								    ATTR_CTRL_MODE, &old);
			  
			if (mode != old)								   
				SetTableCellRangeAttribute (panel, table, r, ATTR_CTRL_MODE, mode);
			// set arrows
			GetTableCellAttribute (panel, table, MakePoint(i+1,row),
								   ATTR_SHOW_INCDEC_ARROWS, &old);
			if (isEditable != old)								   
				SetTableCellRangeAttribute (panel, table, r, ATTR_SHOW_INCDEC_ARROWS,
							  			isEditable);
		}
	}
		
}




/*void ATOMS_TABLE_changeSelection (int panel, int table, int row)
{
	static int lastRow = 1;
	int nColumns;
	
	ATOMS_TABLE_displayColors (panel, table);
	GetNumTableColumns (panel, table, &nColumns);
/*	if (lastRow > 0)
		SetTableCellRangeAttribute (panel, table,
								MakeRect(lastRow, 1, 1, nColumns),
								ATTR_TEXT_BGCOLOR, VAL_WHITE);
*/	
	
	


void testPoint(int panel, int control)
{
	int x, y;
	Point p;
	
	DebugPrintf ("(%d,%d)\n", ctrlTop(panel, control), ctrlLeft(panel, control));
	for (y = 0; y < 300; y += 20) {
		for (x = 240; x < 400; x += 20) {
			GetTableCellFromPoint (panel, control, MakePoint (x,y), &p); 
			DebugPrintf ("(%d,%d)->(%d,%d)   ", x, y, p.x, p.y);
		}
		DebugPrintf ("\n");
	}
}


/*
void ATOMS_TABLE_changeRow (int panel, int control, Point *last)
{
	int nRows, nColumns;
	Point p;
	
/*	GetNumTableRows    (panel, control, &nRows);
	GetNumTableColumns (panel, control, &nColumns);
	if (p.x < 1)     p.x = 1; 
	if (p.x > nColumns) p.x = nColumns;
	if (p.y < 1)     p.y = 1; 
	if (p.y > nRows) p.y = nRows;
//	if ((p.y != last.y) || (p.x != last.x)) {
		


	GetActiveTableCell (panel, control, &p);
	DebugPrintf ("last =(%d,%d)\n", (*last).x, (*last).y);
    ATOMS_TABLE_getAtomDataFromRow ((*last).y, activeSession());
	ATOMS_calculateAllTimes	(activeSession());
	ATOMS_setAsActive (activeSession(), ATOMS_TABLE_getAtomNrFromLabel (p.y));
	ATOMS_TABLE_displayColors (panel, control, activeSession());
	ATOMS_TABLE_updateAllAtoms (panel, control, activeSession());
	SetActiveTableCell (panel, control, p);
//		ATOMS_displayAtomParameters (activeSession(), activeAtom());
//		ATOMS_TABLE_display
//		ProcessDrawEvents ();
	*last = p;
//	}
}
*/


void ATOMS_TABLE_COL_getTableCols (int nr)
{
	int i;
	int nItems;
	t_atomConfig *c;
	
	c = activeSession()->atomConfig;
	GetNumListItems (panelTableCol, TABLECOL_TREE_displayed, &nItems);
	for (i = 0; i < nItems; i++) {
		GetValueFromIndex (panelTableCol, TABLECOL_TREE_displayed, i, &c->tableColumns[nr][i+1]);
	}
	c->tableColumns[nr][0] = DF_NR;
	c->nTableColumns[nr] = nItems + 1;
}



void ATOMS_TABLE_COL_displayConfig (int nr)
{
	int i, n;
	int *visible;
	t_atomConfig *c;
	
	c = activeSession()->atomConfig;
	
	visible = (int *) calloc (sizeof(int), N_DATAFIELDS);

	DeleteListItem (panelTableCol, TABLECOL_TREE_displayed, 0, -1);
	for (n = 1; n < c->nTableColumns[nr]; n++) {
		i = c->tableColumns[nr][n];
		InsertTreeItem (panelTableCol, TABLECOL_TREE_displayed, 
						VAL_SIBLING, 0, VAL_LAST,
						df(i)->tableColumnName, NULL, NULL, i);
		visible[i] = 1;
	};
	visible[DF_NR] = 1;

	DeleteListItem (panelTableCol, TABLECOL_TREE_all, 0, -1);
	for (i = 0; i < N_DATAFIELDS; i++) {
		if ((df(i)->active) && !visible[i]) {
			InsertTreeItem (panelTableCol, TABLECOL_TREE_all, 
							VAL_SIBLING, 0, VAL_LAST,
							df(i)->tableColumnName, NULL, NULL, i);
		}
	}
	
	SetCtrlVal (panelTableCol, TABLECOL_STRING_name, c->tableConfigName[nr]);
	SetCtrlVal (panelTableCol, TABLECOL_NUMERIC_nConfig, nr+1);
	free (visible);
}


void ATOMS_TABLE_COL_displayPanel (t_session *s)
{
	int i;
	t_atomConfig *c;
	static t_atomConfig backup;
	
	c = s->atomConfig;
	if (panelTableCol == -1) {
		panelTableCol = LoadPanel (0, SESSIONMANAGER_uirFile, TABLECOL);  
		SetCtrlAttribute (panelTableCol, TABLECOL_NUMERIC_nConfig, ATTR_MAX_VALUE, N_TABLE_CONFIGS);
		SetCtrlAttribute (panelTableCol, TABLECOL_STRING_name,
						  ATTR_MAX_ENTRY_LENGTH, N_TABLECONFIG_NAME_LEN-1);
		SetCtrlAttribute (panelTableCol, TABLECOL_COMMANDBUTTON_abort,
						  ATTR_CALLBACK_DATA, &backup);
		SetCtrlAttribute (panelTableCol, TABLECOL_COMMANDBUTTON_done,
						  ATTR_CALLBACK_DATA, &backup);
	}
	memcpy (&backup, c, sizeof (t_atomConfig));	
	ATOMS_TABLE_COL_displayConfig (c->activeConfig) ;
	InstallPopup (panelTableCol);								  
}




int CVICALLBACK ATOMS_TABLE_COL_callback_tree (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int lastParent = 0;
	int nItems;
	int i;
	int level;
	int nr;
	int selected = 0;

//	DebugPrintf ("%s (WAVEFORMS_editPoints)\n", eventStr(event, eventData1, eventData2));
	switch (event) {
		case EVENT_COMMIT:
		case EVENT_DROPPED:
		case EVENT_MARK_STATE_CHANGE:		
			GetNumListItems (panelTableCol, TABLECOL_TREE_displayed, &nItems);
			for (i = 0; i < nItems; i++) {
				GetTreeItemLevel (panelTableCol, TABLECOL_TREE_displayed, i, &level);
				if (level == 0) lastParent = i;
				else MoveTreeItem (panelTableCol, TABLECOL_TREE_displayed, i, VAL_SIBLING, lastParent, VAL_NEXT);
			}
			
			GetCtrlVal (panelTableCol, TABLECOL_NUMERIC_nConfig, &nr);
			nr--;
			ATOMS_TABLE_COL_getTableCols (nr);
			break;
	}
	return 0;
}


void moveSelectedTreeItems (int panel, int from, int to)
{
	int nItems;
	int i;
	int selected;
	int value;

	GetNumListItems (panelTableCol, from, &nItems);
	for (i = 0; i < nItems; i++) {
		GetTreeItemAttribute (panelTableCol, from, i,
							  ATTR_SELECTED, &selected);
		GetValueFromIndex (panelTableCol, from, i, &value);
		if (selected) {
			InsertTreeItem (panelTableCol, to,
							VAL_SIBLING, 0, VAL_LAST,
							df(value)->tableColumnName, NULL, NULL, value);
			DeleteListItem (panelTableCol, from, i, 1);
			i--;
			nItems --;
		}
	}
	
}

int CVICALLBACK ATOMS_TABLE_COL_callback_arrowLeft (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
	switch (event) {
		case EVENT_COMMIT:
			moveSelectedTreeItems (panel, TABLECOL_TREE_all, TABLECOL_TREE_displayed);
			CallCtrlCallback (panelTableCol, TABLECOL_TREE_displayed,
							  EVENT_COMMIT, 0, 0, NULL);
			break;
	}
	return 0;
}

int CVICALLBACK ATOMS_TABLE_COL_callback_arrowRight (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			moveSelectedTreeItems (panel, TABLECOL_TREE_displayed, TABLECOL_TREE_all);
			CallCtrlCallback (panelTableCol, TABLECOL_TREE_displayed,
							  EVENT_COMMIT, 0, 0, NULL);
			break;
	}
	return 0;
}


int CVICALLBACK ATOMS_TABLE_COL_callback_setAsDefault (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_atomConfig *c, *def;
	int nr;
	
	
	switch (event) {
		case EVENT_COMMIT:
			c = activeSession()->atomConfig;
			def = smanagerConfig->defaultAtomConfig;
			GetCtrlVal (panelTableCol, TABLECOL_NUMERIC_nConfig, &nr);
			nr--;
			// copy to default values
			strcpy (def->tableConfigName[nr], c->tableConfigName[nr]);
			def->nTableColumns[nr] = c->nTableColumns[nr];
			memcpy (def->tableColumns[nr], c->tableColumns[nr], sizeof (int)*c->nTableColumns[nr]);
			// write default values to registry
	    	writeSessionManagerConfig (smanagerConfig);
			break;
	}
	return 0;
}

int CVICALLBACK ATOMS_TABLE_COL_callback_recallDefault (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	t_atomConfig *c, *def;
	int nr;
	
	switch (event) {
		case EVENT_COMMIT:
			c = activeSession()->atomConfig;
			def = smanagerConfig->defaultAtomConfig;
			GetCtrlVal (panelTableCol, TABLECOL_NUMERIC_nConfig, &nr);
			nr--;
			// copy default values
			strcpy (c->tableConfigName[nr], def->tableConfigName[nr]);
			c->nTableColumns[nr] = def->nTableColumns[nr];
			memcpy (c->tableColumns[nr], def->tableColumns[nr], sizeof (int)*c->nTableColumns[nr]);
			// display values
			ATOMS_TABLE_COL_displayConfig (nr);

			break;
	}
	return 0;
}

int CVICALLBACK ATOMS_TABLE_COL_callback_name (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr;
	t_atomConfig *c;
	
	switch (event) {
		case EVENT_COMMIT:
			c = activeSession()->atomConfig;
			GetCtrlVal (panelTableCol, TABLECOL_NUMERIC_nConfig, &nr);
			nr--;
			GetCtrlVal (panelTableCol, TABLECOL_STRING_name, c->tableConfigName[nr]);
			break;
	}
	return 0;
}


int CVICALLBACK ATOMS_TABLE_COL_callback_nrChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr;
	
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlVal (panelTableCol, TABLECOL_NUMERIC_nConfig, &nr);
			nr--;
			ATOMS_TABLE_COL_displayConfig (nr);
			break;
	}
	return 0;
}

int CVICALLBACK ATOMS_TABLE_COL_callback_done(int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	t_atomConfig *backup;
	int changes;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			ATOMS_TABLE_init (s);
			ATOMS_TABLE_displayAllAtoms (s);
			backup = (t_atomConfig *)callbackData;
			changes = memcmp (backup, s->atomConfig, sizeof (t_atomConfig)) != 0;
			SESSION_setChanges (s, changes);
			RemovePopup (0);
			break;
	}
	return 0;
}



int CVICALLBACK ATOMS_TABLE_COL_callback_abort (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_atomConfig *c, *backup;
	
	switch (event) {
		case EVENT_COMMIT:
			c = activeSession()->atomConfig;
			backup = (t_atomConfig *)callbackData;
			memcpy (c, backup, sizeof(t_atomConfig));
			break;
	}
	return 0;
}



void ATOMS_TABLE_changeRow (int panel, int control, Point p)
{
	static Point last = {1, 1};
	int nRows, nColumns;
	
	GetNumTableRows    (panel, control, &nRows);
	GetNumTableColumns (panel, control, &nColumns);
	if (p.x < 1)     p.x = 1; 
	if (p.x > nColumns) p.x = nColumns;
	if (p.y < 1)     p.y = 1; 
	if (p.y > nRows) p.y = nRows;
	SetActiveTableCell (panel, control, p);
//	ATOMS_TABLE_getAtomDataFromRow (last.y, activeSession());
	ATOMS_calculateAllTimes	(activeSession());
	ATOMS_setAsActive (activeSession(), ATOMS_TABLE_getAtomNrFromLabel (p.y));
//	ATOMS_TABLE_displayColors (panel, control, activeSession());
	ATOMS_TABLE_displayAllAtoms (activeSession());
	SetActiveTableCell (panel, control, p);
	ATOMS_displayAtomParameters (activeSession(), activeAtom());
	last = p;
}



//=======================================================================
//
//    values changed in table
//
//=======================================================================
/*
int CVICALLBACK WAVEFORMS_EditTable_Points (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr, ch, wfmNo;
	t_waveform *k;
 	
 	
// 	if (POINTS_processEvents (panel, control, event, callbackData, eventData1, eventData2) > 0)
// 		return 1;
 	
	DebugPrintf ("%s (WAVEFORMS_editPoints)\n", eventStr(event, eventData1, eventData2));
//	DebugPrintf ("\n");
	if ((event == EVENT_KEYPRESS) && (eventData1 != VAL_ENTER_VKEY)) return 0;
	switch (event) {
		case EVENT_LOST_FOCUS:
		case EVENT_VAL_CHANGED:
		case EVENT_KEYPRESS:
		case EVENT_COMMIT:
			// -----------------------------------------
			//    get ptr to current waveform
			// -----------------------------------------
    		DebugPrintf ("val changed");
    		GetCtrlVal (panelWaveforms(), WFM_LISTBOX_Waveforms, &nr);
			k = WFM_ptr (activeSeq(), nr);
			// -----------------------------------------
			//    convert table to waveform
			// -----------------------------------------
			POINTS_tableToListOfPoints ((t_controls *) callbackData, &k->points, &k->nPoints);
			POINTS_tableToGraph ((t_controls *) callbackData, 0);
			for (ch = 0; ch < N_AO_CHANNELS; ch ++) {
    			if (isAnalogChannelActive(ch)) { 						  
				    GetCtrlVal (getDACpanelHandle(ch), DAC_MASTER_RING_WFMs, &wfmNo);
				    if (wfmNo == nr) plotWaveform (getDACpanelHandle(ch), DAC_MASTER_GRAPH_WFM, k, NULL);
				}
			}
			// -----------------------------------------
			//    enforce digitalization at next start
			// -----------------------------------------
			k->digParameters.timebase_50ns = 0;
			wfmShowNPoints (k);
    		setChanges (activeSeq(), 1);
			break;
	}
	return 0;
	
}

*/

int ATOMS_TABLE_runPopupMenu (t_session *s, int panel, int top, int left)
{
    char *help;
    t_atomConfig *c;
    int i;
    int choice;
   
    help = getTmpString();
   	c = s->atomConfig;
  	for (i = 0; i < N_TABLE_CONFIGS; i++) {
   		if (c->tableConfigName[i][0] == 0) sprintf (help, "config %d",i+1);
		else sprintf (help, "config %d (%s)", i+1, c->tableConfigName[i]);
		SetMenuBarAttribute (menuTable, menuItemsTable[i],
							 ATTR_ITEM_NAME, help);
		SetMenuBarAttribute (menuTable, menuItemsTable[i],
							 ATTR_CHECKED, i == c->activeConfig);
	}
	choice = RunPopupMenu (menuTable, TABLEMENU_1, panel,
						   top, left, 0, 0, 0, 0);
//			choice = RunPopupMenu (menuCurves, menuCurves_Items[MENU_CURVES],
//								   panel, eventData1, eventData2, 0, 0, 0, 0);
//			choice = arrayFind (menuCurves_Items, N_ITEMS_MENU_CURVES, choice);
	switch (choice) {
		case TABLEMENU_1_SETVALUE:
			break;
		case TABLEMENU_1_SETCONFIG_EDITCONFIG:
			ATOMS_TABLE_COL_displayPanel (s);
			break;
		default:
			for (i = 0; i < N_TABLE_CONFIGS; i++) {
				if (choice == menuItemsTable[i]) {
					c->activeConfig = i;
					ATOMS_TABLE_init (s);
					ATOMS_TABLE_displayAllAtoms (s);
					return 1;
				}
			}
	};
	return 1;
		
}


int CVICALLBACK ATOMS_TABLE_edited (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	Point p, oldP;
//	int allowEdit;
	int color;
	int returnVal;
	t_session *s;
//	int help;

//	DebugPrintf ("%s (ATOMS_TABLE_edited) \n", eventStr (event, eventData1, eventData2));
	GetActiveTableCell (panel, control, &oldP);
	GetTableCellAttribute (panel, control, oldP, ATTR_TEXT_BGCOLOR,
						   &color);
	allowEdit = 1 | TABLE_NOT_CHANGE_COLORS;
	
	//!((color == VAL_COL_REFERENCE_ATOM) || (color == VAL_COL_ACTIVE_ATOM_DK) 
//			   || (color == VAL_DK_GRAY)); 
	if (!allowEdit) {
		SetTableCellRangeAttribute (panel, control, MakeRect (oldP.x, oldP.y, 1, 1), 
									ATTR_CTRL_MODE, VAL_INDICATOR);
		SetCtrlAttribute (panel, control, ATTR_TABLE_RUN_STATE, VAL_SELECT_STATE);
	}

	
//	help = allowEdit | TABLE_NOT_CHANGE_COLORS;
//	returnVal = TABLE_processEvents (panel, control, event,
//						 &help, eventData1, eventData2);
	GetActiveTableCell (panel, control, &p);
	s = activeSession();
	ATOMS_setAsActive (s, ATOMS_TABLE_getAtomNrFromLabel (p.y));
	
	
//	ATOMS_TABLE_changeRow (panel, control, p);

//	if (returnVal == 0) return 0;
/*
	if (returnVal == 1) {
		return 1;
	}
*/	
	switch (event) {
		case EVENT_LEFT_DOUBLE_CLICK:
		case EVENT_LEFT_CLICK:
			ATOMS_TABLE_getAtomData (s);
			//ATOMS_TABLE_getAtomDataFromRow (oldP.y, activeSession());
//			ATOMS_calculateAllTimes (s);
//			ATOMS_TABLE_displayAllAtoms (s);
			ATOMS_TABLE_changeRow (panel, control, p);
			break;
		case EVENT_KEYPRESS:
			switch (eventData1) {
				case VAL_ENTER_VKEY: 
//				if (allowEdit) ATOMS_TABLE_getAtomDataFromRow (p.y, activeSession());
					ATOMS_TABLE_getAtomData (s);
					ATOMS_TABLE_changeRow (panel, control, p);
//				ATOMS_displayAtomParameters (s, activeAtom());
					break;
				
			}
			break;
		case EVENT_COMMIT:
//		case EVENT_VAL_CHANGED:
			//if (allowEdit) ATOMS_TABLE_getAtomDataFromRow (p.y, activeSession());
			ATOMS_TABLE_getAtomData (s);
			ATOMS_TABLE_changeRow (panel, control, p);
//			ATOMS_calculateAllTimes (s);
//			ATOMS_TABLE_displayAllAtoms (s);
//			ATOMS_displayAtomParameters (s, activeAtom());
			break;
			
		case EVENT_LOST_FOCUS:
			break;
		case EVENT_RIGHT_CLICK:	
			return ATOMS_TABLE_runPopupMenu (s, panel, eventData1, eventData2);
			break;
	}
	
	return 0;

}





//=======================================================================
//
//    delete atom
//
//=======================================================================
int CVICALLBACK ATOMS_BTN_delete (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
    int nr;
    t_atom *a;
    t_session *s;
    t_plotItem *p;
    int i;

  	switch (event)
		{
		case EVENT_COMMIT:
			if (ListNumItems (activeSession()->lAtoms)  == 0) return 0;
	
			// -----------------------------------------
		    //    delete waveform
			// -----------------------------------------
			a = activeAtom();
			s = activeSession();
			nr = s->activeAtomNo;
			if (ConfirmPopupf ("Delete atom", 
							   "Do you really want to delete atom %d ?", 
							   s->activeAtomNo) == 0) return 0;
			ATOM_delete (s, nr);
			if (s->atomConfig->referenceAtom >= nr) {
				s->atomConfig->referenceAtom --;
				if (s->atomConfig->referenceAtom < 1) s->atomConfig->referenceAtom = 1;
			}
			
			for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
				p = PLOTITEM_ptr (s, i);
				if (p->atomNr >= nr) {
					p->atomNr --;
					if (p->atomNr < 0) p->atomNr = 0;
				}
			}
			SESSION_setChanges (s, 1);
			ATOMS_displayAllValues (s);
			break;
		}
	return 0;

}



//=======================================================================
//
//    new atom
//
//=======================================================================
int CVICALLBACK ATOMS_BTN_New (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
    t_atom *new;
    int nr;
    int n;
    t_session *s;

	switch (event)
		{
		case EVENT_COMMIT:
			s = activeSession();
			// -----------------------------------------
	        //    create & init new atom
			// -----------------------------------------
		    new = ATOM_new (s);
    		ATOM_init (new);
			// -----------------------------------------
	        //    edit atom
			// -----------------------------------------
			SetCtrlAttribute (panelAtoms, ATOMS_NUMERIC_number,
							  ATTR_MAX_VALUE, ListNumItems(s->lAtoms));
			ATOMS_setAsActive (s, ListNumItems(s->lAtoms));
			ATOMS_displayAllValues (s);
			SESSION_setChanges (s, 1);
			SetActiveCtrl (panelAtoms, ATOMS_STRING_name);
			break;
		}
	return 0;
}




/*
int CVICALLBACK ATOMS_startTimeEdited (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int ref;
	t_session *s;
	t_atom *a;
	
	switch (event)
		{
		case EVENT_COMMIT:
			s = activeSession();
			a = activeAtom();
			ref = s->atomConfig->referenceAtomPosition;
			GetCtrlVal (panel, control, &a->time[ref]);
			ATOMS_calculateTimesForAtom (s, a);
			ATOMS_displayAtomParameters (a);
			ATOMS_TABLE_displayActiveAtom (s);
			break;
		}
	return 0;
}

*/



void ATOMS_TIMEREF_initPanel (t_session *s)
{
 	int i;
 	t_atom *a;
 	char help[50];
 	
 	if (panelTimeReference == -1) {
 		panelTimeReference = LoadPanel (0, SESSIONMANAGER_uirFile, TIMEREF);
	 	SCONFIG_POSITIONS_initRingReference (panelTimeReference , TIMEREF_RING_referencePos);
 	}
 	// -----------------------------------------
    //     init ring "reference Atom"
	// -----------------------------------------
/*	ClearListCtrl (panelTimeReference, TIMEREF_RING_referenceAtom);
	for (i = 1; i <= ListNumItems(s->lAtoms); i++) {
		a = ATOM_ptr (s, i);
		if ((a->name == NULL) || (strcmp (a->name, "") == 0)) 
			strcpy (help, intToStr (i));
		else sprintf (help, "%d (%s)", i, a->name);
		InsertListItem (panelTimeReference, TIMEREF_RING_referenceAtom, -1, help, i);
	}
*/
	ATOMS_fillAtomNamesToRing(panelTimeReference, TIMEREF_RING_referenceAtom,
							  s, 0, 0);
	SetCtrlAttribute (panelTimeReference, TIMEREF_RING_referenceAtom, ATTR_CTRL_VAL,
		s->atomConfig->referenceAtom);
	SetCtrlAttribute (panelTimeReference, TIMEREF_RING_referencePos, ATTR_CTRL_VAL,
		s->atomConfig->referenceAtomPosition);
	InstallPopup (panelTimeReference);
}


int CVICALLBACK ATOMS_TIMEREF_change (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			ATOMS_TIMEREF_initPanel (activeSession());
			break;
		}
	return 0;
}


int CVICALLBACK ATOMS_TIMEREF_done (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			GetCtrlVal (panelTimeReference, TIMEREF_RING_referenceAtom, 
				&s->atomConfig->referenceAtom);
			GetCtrlVal (panelTimeReference, TIMEREF_RING_referencePos, 
				&s->atomConfig->referenceAtomPosition);
			ATOMS_calculateAllTimes (s);
			ATOMS_displayAllValues (s);
			ATOMS_TABLE_displayColors (panel, ATOMS_TABLE, s);
			if (control == TIMEREF_COMMANDBUTTON_done) RemovePopup (1);
			break;
	}
	return 0;
}



int CVICALLBACK ATOMS_CALLBACK_panel (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	int nr;
	t_session *s;
	t_atom *a;
	
	switch (event) {
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:

			break;
		case EVENT_KEYPRESS:
			 switch (eventData1) {
			 	case VAL_PAGE_UP_VKEY:
					s = activeSession();
					GetCtrlVal (panel, ATOMS_NUMERIC_number, &nr);
					if (nr > 1) {
						nr--;
						goto SET_CHANGES;
					}
			 		break;
			 	case VAL_PAGE_DOWN_VKEY:
					s = activeSession();
					GetCtrlVal (panel, ATOMS_NUMERIC_number, &nr);
					if (nr < ListNumItems (s->lAtoms)) {
						nr++;
						goto SET_CHANGES;
					}
					break;
			 }
	}
	return 0;
	
SET_CHANGES:
	ATOMS_setAsActive (s, nr);
	a = activeAtom();
	ATOMS_changeVisibility (s);
	ATOMS_TABLE_displayColors (panel, ATOMS_TABLE, s);
	ATOMS_displayAtomParameters (s, a);
	return 1;
}



//=======================================================================
//
//    display event
//
//=======================================================================
void ATOMS_EVENTS_setValues (t_session *s, t_atomEvent *e, int nr)
{
	int panel;
	
	if (e == NULL) return;
	
	panel = subPanelEvents();
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_nPoints, 
				s->nSweepPoints);

	SetCtrlVal (panel, ATOMS_EVTS_RADIOBUTTON_active, e->active);
	//////////////////////////
	SetCtrlVal (panel, ATOMS_EVTS_RING_eventStyle,e->eventStyle); 
	////////////////////////////////////
	SetCtrlVal (panel, ATOMS_EVTS_STRING_name, 
				e->name);
	SetCtrlVal (panel, ATOMS_EVTS_RINGSLIDE_deviceType, 
				e->deviceType);
	SetCtrlVal (panel, ATOMS_EVTS_RING_digitalChannel, 
				e->digitalChannel);
	SetCtrlVal (panel, ATOMS_EVTS_RING_analogChannel, 
				e->analogChannel);
	// pulse start
	SetCtrlVal (panel, ATOMS_EVTS_RING_referencePos, 
				e->pulseStartReference);
	SetCtrlVal (panel, ATOMS_EVTS_CHECKBOX_varyStart, 
				e->pulseStartVary);
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_start, 
				e->pulseStartFirst);
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_startIncr, 
				e->pulseStartIncrement);
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_timeLast, 
				e->pulseStartFirst + e->pulseStartIncrement * (s->nSweepPoints - 1));
	// pulse duration
	SetCtrlVal (panel, ATOMS_EVTS_CHECKBOX_varyDuration, 
				e->pulseDurationVary);
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_durationFirst, 
				e->pulseDurationFirst);
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_durationIncr, 
				e->pulseDurationIncrement);
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_durationLast, 
				e->pulseDurationFirst + e->pulseDurationIncrement * (s->nSweepPoints - 1));
	// voltage
	SetCtrlVal (panel, ATOMS_EVTS_CHECKBOX_varyVoltage, 
				e->voltageVary);
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_voltageFirst, 
				e->voltageFirst);
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_voltageIncr, 
				e->voltageIncrement);
	SetCtrlVal (panel, ATOMS_EVTS_NUMERIC_voltageLast, 
				e->voltageFirst + e->voltageIncrement * (s->nSweepPoints - 1));
	
	SetCtrlAttribute (subPanelEvents(), ATOMS_EVTS_RING_digitalChannel, ATTR_DIMMED, 
					  e->deviceType != ATOMEVENT_DEVICETYPE_DIGITAL);
	SetCtrlAttribute (subPanelEvents(), ATOMS_EVTS_RING_analogChannel, ATTR_DIMMED, 
					  e->deviceType != ATOMEVENT_DEVICETYPE_ANALOG);
	SetAttributeForCtrls (subPanelEvents(), ATTR_DIMMED, !e->active, 0,
						  ATOMS_EVTS_RING_referencePos,  
						  ATOMS_EVTS_CHECKBOX_varyStart, 
						  ATOMS_EVTS_NUMERIC_start,
						  ATOMS_EVTS_NUMERIC_durationIncr,  
						  ATOMS_EVTS_TEXTMSG_pluseStart,
						  ATOMS_EVTS_TEXTMSG_voltage,
						  ATOMS_EVTS_TEXTMSG_incr1,
						  0);
	SetAttributeForCtrls (subPanelEvents(), ATTR_DIMMED, 
						  !e->active || (e->deviceType != 0), 0,
						  ATOMS_EVTS_NUMERIC_durationFirst, 
						  ATOMS_EVTS_NUMERIC_durationIncr,  
						  ATOMS_EVTS_TEXTMSG_pulseDuration,
						  ATOMS_EVTS_CHECKBOX_varyDuration, 
						  0);

	SetAttributeForCtrls (subPanelEvents(), ATTR_DIMMED, 
						  !e->active || (e->deviceType != 1), 0,
						  ATOMS_EVTS_TEXTMSG_voltage,
						  ATOMS_EVTS_CHECKBOX_varyVoltage, 
						  ATOMS_EVTS_NUMERIC_voltageFirst, 
						  ATOMS_EVTS_NUMERIC_voltageIncr,  
						  0);


  	SetAttributeForCtrls (subPanelEvents(), ATTR_DIMMED, 
  						  !e->pulseStartVary || !e->active, 0,
						  ATOMS_EVTS_NUMERIC_startIncr,  
						  ATOMS_EVTS_TEXTMSG_incr1,
						  ATOMS_EVTS_TEXTMSG_timeLast,
						  ATOMS_EVTS_NUMERIC_timeLast,
						  0);

  	SetAttributeForCtrls (subPanelEvents(), ATTR_DIMMED, 
  						  !e->pulseDurationVary || !e->active || (e->deviceType!= 0), 0,
						  ATOMS_EVTS_NUMERIC_durationIncr,  
						  ATOMS_EVTS_TEXTMSG_incr2,
						  ATOMS_EVTS_TEXTMSG_durationLast,
						  ATOMS_EVTS_NUMERIC_durationLast,
						  0);

  	SetAttributeForCtrls (subPanelEvents(), ATTR_DIMMED, 
  						  !e->voltageVary || !e->active || (e->deviceType!= 1), 0,
						  ATOMS_EVTS_NUMERIC_voltageIncr,  
						  ATOMS_EVTS_TEXTMSG_incr3,
						  ATOMS_EVTS_TEXTMSG_voltageLast,
						  ATOMS_EVTS_NUMERIC_voltageLast,
						  0);

						  
	SetCtrlAttribute (panel, ATOMS_EVTS_NUMERIC_nPoints, 
					  ATTR_DIMMED, 
					  !(e->pulseStartVary || e->pulseDurationVary) || !e->active);
	SetCtrlAttribute (panel, ATOMS_EVTS_TEXTMSG_alwaysOn, ATTR_VISIBLE,
					  (e->deviceType == ATOMEVENT_DEVICETYPE_DIGITAL)
					  && (s->digitalOutputs_preset[e->digitalChannel]) 
					  && (s->digitalOutputs_onOff[e->digitalChannel] == 1));
	SetCtrlAttribute (panel, ATOMS_EVTS_TEXTMSG_alwaysOff, ATTR_VISIBLE,
					  (e->deviceType == ATOMEVENT_DEVICETYPE_DIGITAL)
					  && (s->digitalOutputs_preset[e->digitalChannel]) 
					  && (s->digitalOutputs_onOff[e->digitalChannel] == 0));
					  
	CheckListItem (panel, ATOMS_EVTS_LISTBOX_events, nr-1, e->active);
}



void ATOMS_EVENTS_getValues (t_session *s, t_atomEvent *e)
{
	int panel;
	
	if (e == NULL) return;
	
	panel = subPanelEvents();
	GetCtrlVal (panel, ATOMS_EVTS_RING_eventStyle, 
				&e->eventStyle);
	GetCtrlVal (panel, ATOMS_EVTS_RADIOBUTTON_active, 
				&e->active);
	GetCtrlVal (panel, ATOMS_EVTS_STRING_name, 
				e->name);
	GetCtrlVal (panel, ATOMS_EVTS_RINGSLIDE_deviceType, 
				&e->deviceType);
	GetCtrlVal (panel, ATOMS_EVTS_RING_digitalChannel, 
				&e->digitalChannel);
	GetCtrlVal (panel, ATOMS_EVTS_RING_analogChannel, 
				&e->analogChannel);
	// pulse start
	GetCtrlVal (panel, ATOMS_EVTS_RING_referencePos, 
				&e->pulseStartReference);
	GetCtrlVal (panel, ATOMS_EVTS_CHECKBOX_varyStart, 
				&e->pulseStartVary);
	GetCtrlVal (panel, ATOMS_EVTS_NUMERIC_start, 
				&e->pulseStartFirst);
	GetCtrlVal (panel, ATOMS_EVTS_NUMERIC_startIncr, 
				&e->pulseStartIncrement);
	// pulse duration
	GetCtrlVal (panel, ATOMS_EVTS_CHECKBOX_varyDuration, 
				&e->pulseDurationVary);
	GetCtrlVal (panel, ATOMS_EVTS_NUMERIC_durationFirst, 
				&e->pulseDurationFirst);
	GetCtrlVal (panel, ATOMS_EVTS_NUMERIC_durationIncr, 
				&e->pulseDurationIncrement);
	// voltage
	GetCtrlVal (panel, ATOMS_EVTS_CHECKBOX_varyVoltage, 
				&e->voltageVary);
	GetCtrlVal (panel, ATOMS_EVTS_NUMERIC_voltageFirst, 
				&e->voltageFirst);
	GetCtrlVal (panel, ATOMS_EVTS_NUMERIC_voltageIncr, 
				&e->voltageIncrement);
				
	GetCtrlVal (panel, ATOMS_EVTS_NUMERIC_nPoints, 
				&s->nSweepPoints);
}


void ATOMS_EVENTS_displayAllNames (t_session *s, t_atom *a)
{
    int i;
    t_atomEvent *e;
    char help[MAX_EVENTNAME_LEN+70];
    int nr = -1;
    
    if (a == NULL) return;
//	GetCtrlVal (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, &nr);
	setNumListItems (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, ListNumItems (a->lAtomEvents));
	for (i = 1; i <= ListNumItems (a->lAtomEvents); i++) {
		e = ATOMEVENT_ptr (a, i);
/*		help[0] = 0;
		appendColorSpec (help, e->active ? MakeColor (100, 200, 255):VAL_WHITE, 
						 VAL_BLACK);
		strcat (help, e->name);
		strcat (help, strSpace50);												*/
	    ReplaceListItem (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, i-1, e->name, i);
		CheckListItem (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, i-1, e->active);
	}
/*	if (nr >= 0) {
		SetCtrlVal (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, nr);
	}
*/
	GetCtrlVal (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, &nr);
	e = ATOMEVENT_ptr (a, nr);
	ATOMS_EVENTS_setValues (s, e, nr);
}



void ATOMS_EVENTS_initPanel (void)
{
	int i;

	setNumListItems (subPanelEvents(), ATOMS_EVTS_RING_digitalChannel, N_DIO_CHANNELS);
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		ReplaceListItem (subPanelEvents(),
						 ATOMS_EVTS_RING_digitalChannel, i,
						 strNameName (str_ChannelNames(i), strDIGlabel (i)),
						 i);
	}
	SWEEP_fillAnalogChannelNamesToRing (subPanelEvents(), ATOMS_EVTS_RING_analogChannel);
	SCONFIG_POSITIONS_initRingReference (subPanelEvents(), ATOMS_EVTS_RING_referencePos);
	DIAGRAM_fillEventStylesToRing (subPanelEvents(), ATOMS_EVTS_RING_eventStyle);

}





void ATOMS_EVENTS_displayAll (t_session *s, t_atom *a)
{
	int dimmed;
	
	dimmed = (a == NULL) || (ListNumItems (a->lAtomEvents) == 0);
	SetAttributeForCtrls (subPanelEvents(), ATTR_DIMMED, dimmed, 0,
						  ATOMS_EVTS_RADIOBUTTON_active,
						  ATOMS_EVTS_LISTBOX_events,
						  ATOMS_EVTS_STRING_name, 
						  ATOMS_EVTS_RING_digitalChannel, 
						  ATOMS_EVTS_RING_referencePos,  
						  ATOMS_EVTS_CHECKBOX_varyStart, 
						  ATOMS_EVTS_NUMERIC_start,
						  ATOMS_EVTS_NUMERIC_startIncr,
						  ATOMS_EVTS_CHECKBOX_varyDuration, 
						  ATOMS_EVTS_NUMERIC_durationFirst, 
						  ATOMS_EVTS_NUMERIC_durationIncr,  
						  ATOMS_EVTS_BTN_deleteEvent,
						  ATOMS_EVTS_TEXTMSG_pluseStart,
						  ATOMS_EVTS_TEXTMSG_pulseDuration,
						  ATOMS_EVTS_TEXTMSG_incr1,
						  ATOMS_EVTS_TEXTMSG_incr2,
  						  ATOMS_EVTS_TEXTMSG_timeLast,
						  ATOMS_EVTS_NUMERIC_timeLast,
  						  ATOMS_EVTS_TEXTMSG_durationLast,
						  ATOMS_EVTS_NUMERIC_durationLast,
						  ATOMS_EVTS_NUMERIC_nPoints,
						  0);
	ATOMS_EVENTS_displayAllNames (s, a);
	SetCtrlAttribute (subPanelEvents(), ATOMS_EVTS_BTN_importEvent,
					  ATTR_DIMMED, ListNumItems(s->lAtoms) <= 1);
}
	
	

/*CH_A0, CH_A1, CH_A2, CH_A3, CH_A4, CH_A5, CH_A6, CH_A7,
	CH_B0, CH_B1, CH_B2, CH_B3, CH_B4, CH_B5, CH_B6, CH_B7,
	CH_C0, CH_C1, CH_C2, CH_C3, CH_C4, CH_C5, CH_C6, CH_C7,
	CH_D0, CH_D1, CH_D2, CH_D3, CH_D4, CH_D5, CH_D6, CH_D7 
	*/
	/*
		POS_REPUMPER = 0,
	POS_LASER1,
	POS_PURIF,
	POS_HOLE_CIRC_BOX,
	POS_SHIELDINGBOX_ENTRANCE,

	POS_RAMSEY1,
	POS_RING1_C1,
	POS_START_CAVITY1,
	POS_CENTER_CAVITY1,
	POS_END_CAVITY1,
	POS_RING2_C1,
	POS_RAMSEY2,

	POS_RING1_C2,
	POS_START_CAVITY2,
	POS_CENTER_CAVITY2,
	POS_END_CAVITY2,
	POS_RING2_C2,
	POS_RAMSEY3,
	
	POS_SHIELDINGBOX_EXIT,
	
	POS_DETECTOR1,
	POS_DETECTOR2,
	*/
int ATOMS_EVENTS_positionOfChannel(int channel) {
	switch(channel) {
		case CH_A0:
			return POS_PURIF;
			break;
		case CH_A1 :
			return POS_PURIF;
			break;
		case CH_A2 :
			return POS_PURIF;
			break;
		case CH_A3 :
			return POS_RAMSEY1;
			break;
		case CH_A4 :
			return POS_RAMSEY2;
			break;
		case CH_A5 :
			return POS_RAMSEY3;
			break;
		case CH_A6 :
			return POS_CENTER_CAVITY1;
			break;
		case CH_A7 :
			return POS_CENTER_CAVITY2;
			break;
		/*case CH_B0 :
		case CH_B1 :
		case CH_B2 :
		case CH_B3 :
		case CH_B4 :
		case CH_B5 :
		case CH_B6 :
		case CH_B7 :
		case CH_C0 :
		case CH_C1 :
		case CH_C2 :
		case CH_C3 :
		case CH_C4 :
		case CH_C5 :
		case CH_C6 :
		case CH_C7 :
		case CH_D0 :
		case CH_D1 :
		case CH_D2 :
		case CH_D3 :
		case CH_D4 :
		case CH_D5 :
		case CH_D6 :
		case CH_D7 :  */
		}
	return 0;			
}		
	
	
	
//=======================================================================
//
//     clicked on an event name in Listbox 
//
//=======================================================================
int CVICALLBACK ATOMS_EVENTS_listboxClicked (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	t_atomEvent *activeEvent;
	int checked = 1;
	t_session *s;
						 
	switch (event) {
		case EVENT_VAL_CHANGED:
		case EVENT_COMMIT:
            GetCtrlVal (panel, control, &nr);
			activeEvent = ATOMEVENT_ptr (activeAtom(), nr);
			if (activeEvent == NULL) return 0;
			s = activeSession ();
			IsListItemChecked (panel, control, nr-1, &checked);
			activeEvent->active = checked;
            ATOMS_EVENTS_setValues (s, activeEvent, nr);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}




int CVICALLBACK ATOMS_EVENTS_parameterChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	t_atomEvent *activeEvent;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlVal (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, &nr);
			activeEvent = ATOMEVENT_ptr (activeAtom(), nr);
			s = activeSession();
			ATOMS_EVENTS_getValues (s, activeEvent);
        	switch (control) {
        		case ATOMS_EVTS_STRING_name:
					ATOMS_EVENTS_displayAllNames (s, activeAtom());
        	   		break;
        		case ATOMS_EVTS_LISTBOX_events:
        			break;
        	}
            ATOMS_EVENTS_setValues (s, activeEvent, nr);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}

int CVICALLBACK ATOMS_EVENTS_newEvent (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_atomEvent *new;
	t_atom *a;
	
	switch (event) {
		case EVENT_COMMIT:
			a = activeAtom();
		    new = ATOMEVENT_new (a);
		    ATOMEVENT_init (new);
		    strcpy (new->name, "?");
 			ATOMS_EVENTS_displayAll (activeSession(), a);
 			SetCtrlVal (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, 
 						ListNumItems (a->lAtomEvents));
			SetActiveCtrl (subPanelEvents(), ATOMS_EVTS_STRING_name);
			SESSION_setChanges (activeSession(), 1);
			break;
	}
	return 0;
}

int CVICALLBACK ATOMS_EVENTS_deleteEvent (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	t_atomEvent *activeEvent;
	t_atom *a;
	t_session *s;

	switch (event) {
		case EVENT_COMMIT:
 			GetCtrlVal (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, &nr);
			activeEvent = ATOMEVENT_ptr (activeAtom(), nr);
			if (activeEvent == NULL) return 0;
			if (ConfirmPopupf ("Delete event",
							 "Do you really want to delete\nevent '%s'?", 
							 activeEvent->name) == 0) return 0;							 
			a = activeAtom();
			s = activeSession();
			ATOMEVENT_delete (a, nr);
			ATOMS_EVENTS_displayAllNames (s, a);
 			GetCtrlVal (subPanelEvents(), ATOMS_EVTS_LISTBOX_events, &nr);
			activeEvent = ATOMEVENT_ptr (activeAtom(), nr);
            ATOMS_EVENTS_setValues (s, activeEvent, nr);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}


int CVICALLBACK ATOMS_EVENTS_importEvent (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:

			break;
	}
	return 0;
}




//=======================================================================
//=======================================================================
//
//     subpanel "Cavity"
//
//=======================================================================
//=======================================================================


void ATOMS_CAVITY_initPanel (int cavityNr)
{
	SCONFIG_POSITIONS_initRingReference (subPanelCavity (cavityNr),
										 ATOMS_CAV_RING_referencePos);
}



void ATOMS_CAVITY_setValues (t_session *s, t_atom *a, int cavityNr)
{
	int panel;
	
	if (a == NULL) return;
	panel = subPanelCavity(cavityNr);
	
	SetCtrlVal (panel, ATOMS_CAV_RING_referencePos, 
				a->killerTimeReference[cavityNr]);
	SetCtrlVal (panel, ATOMS_CAV_NUMERIC_killerStart, 
				a->killerStartFirst[cavityNr]);
	SetCtrlVal (panel, ATOMS_CAV_RADIOBUTTON_active, 
				a->killerActive[cavityNr]);
				
	SCONFIG_KILLER_setDefaultVoltages (panel, ATOMS_CAV_NUMERIC_defaultV, ATOMS_CAV_NUMERIC_defaultDet, 
										s, cavityNr);
				
//	SetCtrlVal (panel, ATOMS_CAV_NUMERIC_defaultV, s->killerDefaultVoltage[cavityNr]);
//	ATOMS_KILLER_setTransferFunctionInv (panel, ATOMS_CAV_NUMERIC_defaultDet, s, cavityNr);
				
}



void ATOMS_CAVITY_getValues (t_atom *a, int cavityNr)
{
	int panel;
	
	if (a == NULL) return;
	panel = subPanelCavity(cavityNr);
	
	GetCtrlVal (panel, ATOMS_CAV_RING_referencePos, 
				&a->killerTimeReference[cavityNr]);
	GetCtrlVal (panel, ATOMS_CAV_NUMERIC_killerStart, 
				&a->killerStartFirst[cavityNr]);
	GetCtrlVal (panel, ATOMS_CAV_RADIOBUTTON_active, 
				&a->killerActive[cavityNr]);
}


void ATOMS_CAVITY_importKiller_fillNamesToListbox (int panel, int control, 
										     t_session *s)
{
    int i, c;
    t_atom *a;
    char help[200];

	ClearListCtrl (panel, control);
	for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
		a = ATOM_ptr (s, i);
		for (c = 0; c < N_CAVITIES; c++) {
			sprintf (help, "Atom %d (%s), cavity %d", i, a->name, c);
			InsertListItem (panel, control, -1, help, i*N_CAVITIES+c);
		}
	}
}


int CVICALLBACK ATOMS_CAVITY_importKillerParameters (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int newPanel;
    char filename[MAX_PATHNAME_LEN];
    const char titleStr[] = "Import killer paramaters";
    static t_session *new;
	
	switch (event) {				
		case EVENT_COMMIT:
		    if (FileSelectPopup (smanagerConfig->defaultPath, "*.ses", "*.ses",
								 titleStr, VAL_LOAD_BUTTON, 0, 1, 1, 0,
								 filename) <= 0) return 0; 
		    new = SESSION_new ();
		    if (SESSION_load (filename, new) == 0) {
				newPanel = LoadPanel (0, SESSIONMANAGER_uirFile, IMPORT_KIL);
				SetCtrlAttribute (newPanel , IMPORT_KIL_COMMANDBUTTON_done,
								  ATTR_CALLBACK_DATA, new);
				SetCtrlAttribute (newPanel , IMPORT_KIL_COMMANDBUTTON_abort,
								  ATTR_CALLBACK_DATA, new);
				SetCtrlAttribute (newPanel , IMPORT_KIL_LISTBOX_names,
								  ATTR_CALLBACK_DATA, new);
				ATOMS_CAVITY_importKiller_fillNamesToListbox (newPanel, IMPORT_KIL_LISTBOX_names, new);
				SetActiveCtrl (newPanel, IMPORT_KIL_LISTBOX_names);
				InstallPopup (newPanel);
			}
			else { 
				SESSION_free (new);
			}
			break;
	}
	return 0;
}


int CVICALLBACK ATOMS_CAVITY_importKillerParameters_selected (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *import;
	t_atom *a;
	int cavityNr;
	int i;

	switch (event) {
		case EVENT_VAL_CHANGED:
		case EVENT_GOT_FOCUS:
		case EVENT_COMMIT:
			import = (t_session *) callbackData;
			GetCtrlVal (panel, IMPORT_KIL_LISTBOX_names, &i);
			a = ATOM_ptr (import, i / N_CAVITIES);
			cavityNr = i % N_CAVITIES;
			POINTS_plot (panel, IMPORT_KIL_GRAPH,
					     a->killerPoints[cavityNr], a->nKillerPoints[cavityNr], 
					     0, TIME_MULTIPLY_us);
			POINTS_showInvalid (panel, IMPORT_KIL_TEXTMSG_invalid, 
							    a->killerPoints[cavityNr], a->nKillerPoints[cavityNr]);
			break;
	}
	return 0;
}



int CVICALLBACK ATOMS_CAVITY_importKillerParameters_Done (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *import;
	t_atom *importAtom, *a;
	int importCavityNr, cavityNr;
	int i;
	
	switch (event) {
		case EVENT_COMMIT:
			import = (t_session *) callbackData;
			// check if "done" pressed
			if (control == IMPORT_KIL_COMMANDBUTTON_done) {
				GetCtrlVal (panel, IMPORT_KIL_LISTBOX_names, &i);
				importAtom = ATOM_ptr (import, i / N_CAVITIES);
				importCavityNr = i % N_CAVITIES;
				a = activeAtom();
				cavityNr = ATOMS_activeCavityNr ();
				// -----------------------------------------
				//    copy points
				// -----------------------------------------
				a->nKillerPoints[cavityNr] = importAtom->nKillerPoints[importCavityNr];
				a->killerPoints[cavityNr] = (t_point *) realloc (a->killerPoints[cavityNr], a->nKillerPoints[cavityNr] * sizeof (t_point));
				memcpy (a->killerPoints[cavityNr], 
						importAtom->killerPoints[importCavityNr], 
						a->nKillerPoints[cavityNr] * sizeof (t_point));
				// -----------------------------------------
				//    convert table to points
				// -----------------------------------------
				SESSION_setChanges (activeSession(), 1);
				ATOMS_CAVITY_displayKillerPoints (a, cavityNr);
			}
			SESSION_free (import);
			RemovePopup (1);    
			break;
	}
	return 0;
}

	

						

//=======================================================================
//=======================================================================
//
//     "edit killer points"
//
//=======================================================================
//=======================================================================


void ATOMS_KILLER_makeTransferFunction  (t_transferFunction *f, 
									     double par1, double par2, double par3)
{

/*	f->type = TRANSFERFUNCT_TYPE_SQRT;
	f->nParameters = 3;
	f->parameters = (double *) realloc (f->parameters, sizeof(double) * f->nParameters);
	f->parameters[0] = par1;
	f->parameters[1] = sqr(par2);
	f->parameters[2] = par3;
	strcpy (f->axis, "freq. [kHz]");
	f->defaultVoltage = defaultV;
*/
	
	f->type = TRANSFERFUNCT_TYPE_ABC_FORMULA;
	f->nParameters = 3;
	f->parameters[0] = par1;
	f->parameters[1] = par2;
	f->parameters[2] = par3;
	strcpy (f->yAxis, "freq. [kHz]");
	strcpy (f->xAxis, "killer (V)");
	strcpy (f->yVariable, "freq");
	strcpy (f->xVariable, "V");

}


void ATOMS_KILLER_displayCalculatedCurve (t_session *s, t_point *points, int n, int cavityNr) 
{
	t_transferFunction f;
	t_waveform wfm;
	int nPoints = 100;
	t_digitizeParameters *p;
	int i, idx, rep;
	double *yValues;
	int repetition;
	
	// display points in window
	if (points == NULL) return;
	TRANSFERFUNCT_init (&f);

	CREATESEQ_makeTransferFunction (&f, s, cavityNr);
	CREATESEQ_makeWaveform (&wfm, s, points, n, CREATESEQ_getKillerDefaultDetuning (s, cavityNr), 0);
	

	wfm.DIG_Values = (short  *) 		malloc (sizeof(short)         * nPoints);
    wfm.DIG_Repeat = (unsigned long *) malloc (sizeof(unsigned long) * nPoints);

	p = digitizeParameters_LeCroyLW120(-1, TIMEBASE_LECROY_KILLER);
    GetCtrlVal (panelKillerPoints, KILLER_NUMERIC_repetition, &repetition);
    POINTS_calculateValues (wfm.points, wfm.nPoints, repetition, 1);
	for (i = wfm.nPoints-1; i >= 0; i--) {
		wfm.points[i].timeStart_ns -= wfm.points[0].thisTime_ns;
		wfm.points[i].thisTime_ns -= wfm.points[0].thisTime_ns;
	}
	WFM_calculateDuration (&wfm, repetition, 1);

	calculateNPoints (&wfm, nPoints, nPoints, 
					  &f, 0, p);
	
	yValues = (double *) malloc (sizeof(double)*nPoints);
	idx = 0;
	rep = 0;
	for (i = 0; i < nPoints; i++) {
		if (idx < wfm.DIG_NValues) 
			yValues[i] = DigitalToAnalog (wfm.DIG_Values[idx], p);
		else 
			yValues[i] = 0;
		rep++;
		if (rep == wfm.DIG_Repeat[idx]) {
			idx++;
			rep = 0;
		}
	}	
	DeleteGraphPlot (panelKillerPoints, KILLER_GRAPH_leCroy, -1,
					 VAL_DELAYED_DRAW);
	PlotY (panelKillerPoints, KILLER_GRAPH_leCroy, yValues, nPoints, VAL_DOUBLE,
		   VAL_THIN_LINE, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);
	
	free (yValues);
	WFM_free (&wfm); 	
	TRANSFERFUNCT_free (&f);
}


/*
void ATOMS_KILLER_setTransferFunctionInv (int panel, int ctrl, t_session *s, int cavity)
{
	ATOMS_KILLER_makeTransferFunction (ctrlKiller.f, s->parametersTransferFunct[cavity][0],
									   s->parametersTransferFunct[cavity][1],
									   s->parametersTransferFunct[cavity][2]);
	SetCtrlVal (panel, ctrl, 
				TRANSFERFUNCT_applyInv (ctrlKiller.f, s->killerDefaultVoltage[cavity]));
}

*/

void ATOMS_KILLER_setValues (t_session *s, int cavityNr) 
{
	t_transferFunction f;
	
	SetCtrlVal (panelKillerPoints, KILLER_NUMERIC_A, s->atomConfig->parametersTransferFunct[cavityNr][0]);
	SetCtrlVal (panelKillerPoints, KILLER_NUMERIC_B, s->atomConfig->parametersTransferFunct[cavityNr][1]);
	SetCtrlVal (panelKillerPoints, KILLER_NUMERIC_C, s->atomConfig->parametersTransferFunct[cavityNr][2]);

	CREATESEQ_makeTransferFunction (&f, s, cavityNr);
	TRANSFERFUNCT_writeFormulasToTextbox (&f, panelKillerPoints, KILLER_TEXTBOX_transferFunct);
	
}




void ATOMS_KILLER_initPanel (void)
{
	if (panelKillerPoints == -1) {
		panelKillerPoints = LoadPanel (0, SESSIONMANAGER_uirFile, KILLER);
		CONTROLS_init (&ctrlKiller);
		POINTS_defineControls (&ctrlKiller, panelKillerPoints,
							 KILLER_TABLE_points,
							 KILLER_GRAPH,
							 KILLER_NUMERIC_repetition,
							 KILLER_TEXTMSG_invalid, 25);
		POINTS_setParameterValues (&ctrlKiller, TIME_MULTIPLY_us,
								   "detuning [kHz]",
						  			"increment per repetition [kHz]",
						  			-100000.0, 100000.0, 2, 0, 1);
		ctrlKiller.f = TRANSFERFUNCT_new (NULL);
		ctrlKiller.allowNegativeTimes = 1;
		POINTS_initControls (&ctrlKiller);

	}

}

void ATOMS_KILLER_editPoints (t_session *s, t_atom *a, int cavityNr)
{
	SetCtrlVal (panelKillerPoints, KILLER_NUMERIC_cavity, cavityNr+1);
	ATOMS_KILLER_setValues (s, cavityNr);
	ATOMS_KILLER_makeTransferFunction  (ctrlKiller.f, s->atomConfig->parametersTransferFunct[cavityNr][0],
						          s->atomConfig->parametersTransferFunct[cavityNr][1],
						          s->atomConfig->parametersTransferFunct[cavityNr][2]);
	POINTS_createTableColumns (&ctrlKiller);
	POINTS_duplicate (&ctrlKiller, a->killerPoints[cavityNr], a->nKillerPoints[cavityNr]);

	POINTS_listOfPointsToTable (&ctrlKiller, a->killerPoints[cavityNr], a->nKillerPoints[cavityNr]);
	
	POINTS_showGraph (&ctrlKiller, a->killerPoints[cavityNr], a->nKillerPoints[cavityNr], 0);
	ATOMS_KILLER_displayCalculatedCurve (s, a->killerPoints[cavityNr], a->nKillerPoints[cavityNr], cavityNr);
	SetActiveCtrl (panelKillerPoints, KILLER_TABLE_points);
	SetCtrlVal (panelKillerPoints, KILLER_NUMERIC_repetition, 0);
	InstallPopup (panelKillerPoints);
}



//=======================================================================
//
//    values changed in table
//
//=======================================================================
int CVICALLBACK ATOMS_KILLER_callback_table (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{

	int cavityNr;
//	t_session *s;
//	t_point *killerPoints = NULL;
//	int nKillerPoints;
	
	if ((event == EVENT_KEYPRESS) && (eventData1 != VAL_ENTER_VKEY)) return 0;
	switch (event) {
		case EVENT_LOST_FOCUS:
		case EVENT_VAL_CHANGED:
//		case EVENT_KEYPRESS:
		case EVENT_COMMIT:
//			POINTS_tableToListOfPoints (&ctrlKiller, &killerPoints, &nKillerPoints);
			cavityNr = ATOMS_activeCavityNr ();
			ATOMS_KILLER_displayCalculatedCurve (activeSession(), ctrlKiller.lastPoints, ctrlKiller.nLastPoints, cavityNr);
//			free (killerPoints);
			break;
	}
	return 0;
	
}



int CVICALLBACK ATOMS_KILLER_done (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_atom *a;
	int cavityNr;
	t_session *s;

	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			if ((control == KILLER_COMMANDBUTTON_done) ) {
				a = activeAtom();
				cavityNr = ATOMS_activeCavityNr ();
				// -----------------------------------------
				//    convert table to points
				// -----------------------------------------
				POINTS_tableToListOfPoints (&ctrlKiller,
											&a->killerPoints[cavityNr],
											&a->nKillerPoints[cavityNr],1);
				POINTS_showGraph (&ctrlKiller, 
								  a->killerPoints[cavityNr], 
				  				  a->nKillerPoints[cavityNr], 0);
				SESSION_setChanges (s, 1);
				ATOMS_CAVITY_displayKillerPoints (a, cavityNr);
			}
			RemovePopup (0);
			break;
	}
	return 0;
}

















int CVICALLBACK ATOMS_CAVITY_parameterChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int cavityNr;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
		    cavityNr = ATOMS_activeCavityNr ();
		    s = activeSession ();
			ATOMS_CAVITY_getValues (activeAtom(), cavityNr);
			ATOMS_CAVITY_setValues (s, activeAtom(), cavityNr);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}





int CVICALLBACK ATOMS_CAVITY_editKiller (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_atom *a;
	int cavityNr;
	
	switch (event) {
		case EVENT_COMMIT:
		    cavityNr = ATOMS_activeCavityNr ();
			ATOMS_KILLER_editPoints (activeSession(), activeAtom(), cavityNr);
			break;
	}
	return 0;
}



void ATOMS_CAVITY_displayKillerPoints (t_atom *a, int cavityNr)
{
	
	POINTS_plot (subPanelCavity(cavityNr), ATOMS_CAV_GRAPH, 
	  		     a->killerPoints[cavityNr], a->nKillerPoints[cavityNr], 0,  TIME_MULTIPLY_us);
	POINTS_showInvalid (subPanelCavity(cavityNr), ATOMS_CAV_TEXTMSG_invalid,
	  				    a->killerPoints[cavityNr], a->nKillerPoints[cavityNr]);

}






char *ATOM_makeName (t_atom *a, int addName)
{
	char *help, *add;
	
	help = getTmpString();
	add = getTmpString();
	
	
	if (addName) strcpy (help, a->name);
	if (a->velocitySelection) {
		sprintf (add, "%s m/s", doubleToStr (a->velocity));
		if (help[0] != 0) strcat (help, ", ");
		strcat (help, add);
	}
	
	if (a->state != STATE_NONE) {
		if (help[0] != 0) strcat (help, ", ");
		strcat (help, strState(a->state));
	}
	if (help[0] != 0) strcat (help, ", ");
	sprintf (add, "L1=%s �s", doubleToStr (a->durationL1));
	strcat (help, add);
	
	if (ListNumItems (a->lAtomEvents) > 0) {
		sprintf (add, ", %d event", ListNumItems (a->lAtomEvents));
		if (ListNumItems (a->lAtomEvents) > 1) strcat (add, "s");
		strcat (help, add);
	}
	
	return help;
}


int CVICALLBACK ATOMS_BTN_import (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int newPanel;
	int i;
	t_atom *a;
    char filename[MAX_PATHNAME_LEN];
    static t_session *new;
	
	switch (event) {				
		case EVENT_COMMIT:
		    if (FileSelectPopup (smanagerConfig->defaultPath, "*.ses", "*.ses",
								 "Import atoms", VAL_LOAD_BUTTON, 0, 1, 1, 0,
								 filename) <= 0) return 0; 
		    new = SESSION_new ();
		    if (SESSION_load (filename, new) == 0) {
				newPanel = LoadPanel (0, SESSIONMANAGER_uirFile, IMPORT_AT);
				SetCtrlAttribute (newPanel , IMPORT_AT_COMMANDBUTTON_done,
								  ATTR_CALLBACK_DATA, new);
				SetCtrlAttribute (newPanel , IMPORT_AT_COMMANDBUTTON_abort,
								  ATTR_CALLBACK_DATA, new);
				SetCtrlAttribute (newPanel , IMPORT_AT_LISTBOX_names,
								  ATTR_CALLBACK_DATA, new);
				DeleteListItem (newPanel, IMPORT_AT_LISTBOX_names, 0, -1);
				for (i = 1; i <= ListNumItems (new->lAtoms); i++) {
					a = ATOM_ptr (new, i);
					InsertListItem (newPanel, IMPORT_AT_LISTBOX_names, -1, ATOM_makeName (a, 1), i);
				}
				SetActiveCtrl (newPanel, IMPORT_AT_LISTBOX_names);
				InstallPopup (newPanel);
			}
			else { 
				SESSION_free (new);
			}
			break;
	}
	return 0;
}

int CVICALLBACK ATOMS_importAtoms_Done (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *import;
	t_atom *importAtom, *newAtom;
	int i;
	int checked;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			import = (t_session *) callbackData;
			s = activeSession();
			// check if "done" pressed
			if (control == IMPORT_AT_COMMANDBUTTON_done) {
				for (i = 1; i <= ListNumItems (import->lAtoms); i++) {
					IsListItemChecked (panel, IMPORT_AT_LISTBOX_names, i-1, &checked);
					if (checked) {
						importAtom = ATOM_ptr (import, i);
						newAtom = ATOM_new (s);
						ATOM_duplicate (newAtom, importAtom);
					}
				}
			}
			SESSION_free (import);
			SetCtrlAttribute (panelAtoms, ATOMS_NUMERIC_number,
							  ATTR_MAX_VALUE, ListNumItems(s->lAtoms));
			ATOMS_setAsActive (s, ListNumItems(s->lAtoms));
			ATOMS_displayAllValues (s);
			SESSION_setChanges (s, 1);
			RemovePopup (1);   
			SetActiveCtrl (panelAtoms, ATOMS_STRING_name);
			break;
	}
	return 0;
}



int CVICALLBACK ATOMS_BTN_duplicate (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_atom *a, *newAtom;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			a = activeAtom();
			s = activeSession();
			if (a != NULL) {
				newAtom = ATOM_new (s);
				ATOM_duplicate (newAtom, activeAtom());
			}
			SetCtrlAttribute (panelAtoms, ATOMS_NUMERIC_number,
							  ATTR_MAX_VALUE, ListNumItems(s->lAtoms));
			ATOMS_setAsActive (s, ListNumItems(s->lAtoms));
			ATOMS_displayAllValues (s);
			SESSION_setChanges (s, 1);
			SetActiveCtrl (panelAtoms, ATOMS_STRING_name);
			break;
	}
	return 0;
}

int CVICALLBACK ATOMS_BTN_createName (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_atom *a;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			a = activeAtom();
			s = activeSession();
			strncpy (a->name, ATOM_makeName (a, 0),MAX_ATOMNAME_LEN);
			a->name[MAX_ATOMNAME_LEN] = 0;
			ATOMS_TABLE_displayAllAtoms (s);
			ATOMS_displayAtomParameters (s, a);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}

/*
void ATOM_GetAtomAndNCopyFromInt(int rawNumber,int* atomNr,int* NCopy) {
	int n;
	t_atom* a;
	n=rawNumber;
	for(*atomNr=1;*atomNr<=ListNumItems (activeSession()->lAtoms)&&n>0;(*atomNr)++) {
		a=ATOM_ptr(activeSession(),*atomNr);
		if(!a->hasMultiples) {
			n--;
			*NCopy=0;
		}
		else	
			for(*NCopy=0;*NCopy<a->nCopy&&n>0;(*NCopy)++)
				n--;
			}
	(*atomNr)--;
}
*/
