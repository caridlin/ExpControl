/*============================================================================
/*
/*                   Session Manager
/*
/*----------------------------------------------------------------------------
/*    
/*  Copyright (c) Stefan Kuhr 2003,2004
/*					
/*----------------------------------------------------------------------------
/*                                                                            
/* Title:       SESSIONMANAGER_CreateSequence.c       
/*
/* Purpose:     auto create "sequences" (.seq files) from session
/*                                                                            
/*============================================================================*/
#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"

#include "CONTROL/CONTROL_Hardware.h"
#include "driver_MI6021.h"


// name of first block 
const char strInit[] = "INIT";

// panel for list of events
int panelEvents = -1;

char CREATESEQ_errorStr[500] = "";

#define KILLER_DEFAULT_VALUE   -1000000.0
#define KILLER_DEFAULT_VOLTAGE 0.0

// define timebase for analog and digital boards
// analog:   40 * 50 ns =  2 �s
// digital    2 * 50 ns = 100 ns
#define SEQ_DIO_timeBase VAL_HARDWARE_TIMEBASE_50ns
#define SEQ_AO_timeBase  VAL_HARDWARE_TIMEBASE_50ns
#define SEQ_DIO_patternInterval 2
#define SEQ_AO_patternInterval  40

// duration of GATE pulse for counter board = 100 ns
#define DUARTION_GATE_PULSE_us 0.1  
#define DURATION_GATE_PULSE 2
#define SWITCHING_TIME_DET2_us 12.0

const int COUNTERS_NCOUNTS[2] = {
	COUNTER_NCOUNTS_DET1,
	COUNTER_NCOUNTS_DET2
};

const int COUNTERS_ARRIVALTIMES[2] = {
	COUNTER_ARRIVALTIMES_DET1,
	COUNTER_ARRIVALTIMES_DET2
};


const int GPIB_ADDRESSES_SIGNALGENERATORS[N_SIGNALGENERATORS] = 
{
	GPIB_ADDRESS_ANRITSU_fred,
	GPIB_ADDRESS_ANRITSU_george,
	GPIB_ADDRESS_ANRITSU_charly,
	GPIB_ADDRESS_ANRITSU_billy,
	GPIB_ADDRESS_SML02,
	GPIB_ADDRESS_SML02_2,
	GPIB_ADDRESS_AGILENT_33250A_1,
	GPIB_ADDRESS_AGILENT_33250A_2

};


const int GPIB_ADDRESSES_POWERSUPPLIES[N_POWERSUPPLIES] = 
{
	GPIB_ADDRESS_SRS_P350_1,
	GPIB_ADDRESS_SRS_P350_2,
	GPIB_ADDRESS_SRS_P350_3,
	GPIB_ADDRESS_SRS_P350_4,
	GPIB_ADDRESS_PL330DP,
	GPIB_ADDRESS_AGILENT_6612C
};


#define MAX_CONFLICTS_IN_EVENT_LIST 100


void DEBUG_printDigitalBlocks (t_sequence *seq);

 
//=======================================================================
//
//    display information for hardware signal routing
//
//=======================================================================

void SIGNALS_printInfo (int panel, int ctrl)
{
	cls (panel, ctrl);     
	pprintf (panel, ctrl, "DETECTORS + COUNTERS:\n");      
	pprintf (panel, ctrl, "=============================\n");      
	pprintf (panel, ctrl, "A) arrival times: \n");      
	pprintf (panel, ctrl, "    TTL det. 1 --> GATE%d\n", COUNTER_ARRIVALTIMES_DET1);      
	pprintf (panel, ctrl, "    TTL det. 2 --> GATE%d\n", COUNTER_ARRIVALTIMES_DET2);      
	pprintf (panel, ctrl, "B) counts per time intervals: \n");      
	pprintf (panel, ctrl, "    TTL det. 1 --> SRC%d,", COUNTER_NCOUNTS_DET1);      
	pprintf (panel, ctrl, "  %s --> GATE%d\n", str_ChannelNames(CH_GATE_DET1), COUNTER_NCOUNTS_DET1);      
	pprintf (panel, ctrl, "    TTL det. 2 --> SRC%d,", COUNTER_NCOUNTS_DET2);      
	pprintf (panel, ctrl, "  %s --> GATE%d\n", str_ChannelNames(CH_GATE_DET2), COUNTER_NCOUNTS_DET2);      
}



//=======================================================================
//
//    names of digital channels (A0, A1,... A7, B0, ...)
//
//=======================================================================
const char *strDIGlabel (int channel)
{
	char *help;
	
	switch (channel) {
		
		case CH_52D_52F: return "MW 52d->52f";
		case CH_RAMSEY1: return "MW Ramsey 1";
		case CH_RAMSEY2: return "MW Ramsey 2";
		case CH_RAMSEY3: return "MW Ramsey 3";
		case CH_CAVITY1: return "MW Cavity 1";
		case CH_CAVITY2: return "MW Cavity 2";
		case CH_PURIF_E: return "purif e";
		case CH_PURIF_G: return "purif g"; 
		
		case CH_TRIG_OSCILLOSCOPE: 		return "trig. oscilloscope";
		case CH_TRIG_LECROY_KILLER: 	return "trig. LeCroy killer";  
		case CH_TRIG_LECROY_CIRC: 		return "trig. LeCroy circ.";  
		case CH_TRIG_LECROY_DET_RAMP: 	return "trig. LeCroy det. ramp";  
		case CH_TRIG_RF_CIRC: 			return "trig. RF circ.";
		case CH_GATE_DET1: 
			help = getTmpString();
			sprintf (help, "GATE%d", COUNTER_NCOUNTS_DET1);
			return help;
		case CH_GATE_DET2: 
			help = getTmpString();
			sprintf (help, "GATE%d", COUNTER_NCOUNTS_DET2);
			return help;
		
//	    case CH_COPY_LASER1_L1: return "copy laser 1";
		case CH_LASER1:	  return "laser1 (420nm)";
		case CH_LASER2:	  return "laser2 (1015nm)";
		case CH_OPT_PUMPING: return "laser opt. pumping (780nm)";
		case CH_REPUMPER: return "repumper";
//		case CH_COUNTER0: return "Counter 0";
//		case CH_COUNTER1: return "Counter 1";

		case  CH_REP_POWER_E1: return "rep. power E1";
		case  CH_REP_POWER_E2: return "rep. power E2";			 
		case  CH_REP_FREQUENCY_E1: return "rep. frequency E1";
		case  CH_REP_FREQUENCY_E2: return "rep. frequency E2";
		case  CH_DEPUMPER_SHUTTER: return "depumper (0 deg.)-shutter";
		case  CH_DEPUMPER_ANGLE: return "depumper (angle)";
		case  CH_MW_AMPLIFIER: return "MW amplifier";
		case  CH_RAMAN: return "Raman lasers";
		case  CH_DET1_ON: return "det. 1 on";   	    
		default: return "";
	}
}


//=======================================================================
//
//    names of analog channels (DAC0, DAC1, ...)
//
//=======================================================================
const char *strAOlabel (int channel)
{
	char *help;
	
	switch (channel) {
		case A_CH_VOLTAGE_DETECTOR: 
			return "voltage detector 2";
		case A_CH_CONTREPLAQUE: 
			return "contre-plaque";  
		case A_CH_GPIB_KILLER:
		case FIRST_EXTERNAL_AO_CHANNEL:
			return "killer cavity 1";
		case A_CH_GPIB_KILLER+1:
		case FIRST_EXTERNAL_AO_CHANNEL+1:
			return "killer cavity 2";
	}
	
	return "";
}


//=======================================================================
//
//    names of GPIB devices
//
//=======================================================================
const char *strGPIBlabel (int channel)
{
	t_gpibDevice *g;
	char *help;
	
	switch (channel) {
		case GPIB_ADDRESS_KILLER: return "killer";
		case GPIB_ADDRESS_ANRITSU_fred: return "ANRITSU 'Fred'";
		case GPIB_ADDRESS_ANRITSU_george: return "ANRITSU 'George'";
		case GPIB_ADDRESS_ANRITSU_charly: return "ANRITSU 'Charly'";
		case GPIB_ADDRESS_ANRITSU_billy: return "ANRITSU 'Billy'";
		case GPIB_ADDRESS_SML02: return "RohdeSchwarz SML02 #1";
		case GPIB_ADDRESS_SML02_2: return "RohdeSchwarz SML02 #2";
		case GPIB_ADDRESS_AGILENT_33250A_1: return "Agilent 33250A #1";          
		case GPIB_ADDRESS_AGILENT_33250A_2: return "Agilent 33250A #2";
		case GPIB_ADDRESS_SRS_P350_1: return "HV Cavity1";
		case GPIB_ADDRESS_SRS_P350_2: return "HV Cavity2";
		case GPIB_ADDRESS_SRS_P350_3: return "HV SRS-P350 #3";
		case GPIB_ADDRESS_SRS_P350_4: return "HV SRS-P350 #4";
		case GPIB_ADDRESS_PL330DP: return "PowerSupply PL330DP";
		case GPIB_ADDRESS_AGILENT_6612C: return "Agilent 6612C";
		default: return "";
	}
}


int GPIBDEVICE_hasPulseMode (int channel)
{
	return (channel == GPIB_ADDRESS_ANRITSU_george) 
		 || (channel == GPIB_ADDRESS_SML02);
}



//=======================================================================
//
//    names of transferfunctions (killer)
//
//=======================================================================
const char *STR_transferFunctName (int cavity) 
{
	if (cavity == 0) return "killer cavity 1";
	else return "killer cavity 2";
}





//=======================================================================
//
//    get smallest time units of analog and digital board
//    (in units of 50 ns)
//
//=======================================================================
int CREATESEQ_deltaT_AO (void)
{
	return get_timeUnits (SEQ_AO_timeBase) * SEQ_AO_patternInterval;
}

int CREATESEQ_deltaT_DIO (void)
{
	return get_timeUnits (SEQ_DIO_timeBase) * SEQ_DIO_patternInterval;
}


double CREATESEQ_sequenceDuration_us (t_session *s)
{
	return (s->curveEnd_us - s->curveStart_us) + DURATION_FIRST_BLOCK_ns / 1000;
}


//=======================================================================
//
//    convert time in �s (double) in units of 50ns (int)
//
//=======================================================================
int getIntTime (double time_us)
{
	int iTime;
	
	iTime = RoundRealToNearestInteger (time_us * VAL_us);
	iTime -= iTime % CREATESEQ_deltaT_DIO ();
	return iTime;
}



//=======================================================================
//
//    convert time in �s (double) in units of 50ns (int)
//
//=======================================================================
int getIntTimeAnalogBoard (double time_us)
{
	int iTime;
	
	iTime = RoundRealToNearestInteger (time_us * VAL_us);
	iTime -= iTime % CREATESEQ_deltaT_DIO ();
	return iTime;
}


double roundTimeAnalogBoard (double time_us)
{
	int iTime;
	int deltaT;

	deltaT = CREATESEQ_deltaT_AO ();
	iTime = RoundRealToNearestInteger (time_us * VAL_us);
	iTime += sign(iTime)*deltaT/2;
	iTime -= iTime % deltaT;
	return (1.0 * iTime) / (1.0*VAL_us);
}



//=======================================================================
//
//    Insert into sequence: info of board timebase
//
//=======================================================================
int CREATESEQ_setTimebases (t_sequence *s)
{
    s->DIO_timeBase        = SEQ_DIO_timeBase;
    s->AO_timeBase         = SEQ_AO_timeBase;
    s->DIO_patternInterval = SEQ_DIO_patternInterval;
    s->AO_patternInterval  = SEQ_AO_patternInterval;
    s->trigger 			   = RTSI_START_TRIG;
//    s->trigger = ND_PFI_0;
    return 0;
}


//=======================================================================
//    logic levels E1, E2 for rf multiplexer (velocity selecion)
//    (inputs of hardware are set to high (+5V) if open and not terminated)
//    n = 1,2,3,4 for RF1, RF2, RF3, RF4
//=======================================================================
int E1 (int n)
{
	return (n % 2) == 0;
}

int E2 (int n)
{
  return n > 2;
}








//=======================================================================
//
//    AUTO GENERATE SEQUENCE:
//    insert names for digital and analog channels
//
//=======================================================================
void CREATESEQ_insertChannelNames (t_sequence *seq)
{
    int i;
    
    seq->maxDigitalChannel = 32;
    for (i = 0; i < N_DIO_CHANNELS; i ++) {
    	 if (strlen (strDIGlabel(i)) > 0) {
    	 	seq->DIO_channelNames[i] = strAlloc (strDIGlabel(i)); 
    	 }
    }
    for (i = 0; i < N_AO_CHANNELS; i ++) {
    	 if (strlen (strAOlabel (i)) > 0) {
    	 	seq->AO_channelNames[i] = strAlloc (strAOlabel(i)); 
    	 }
    }
}




//=======================================================================
//
//    AUTO GENERATE SEQUENCE:
//    create all digital blocks from list of events (s->lEvents)
//    (idea: first create a sorted list of all times, where "something happens",
//           i.e. start or end of digital pulse, start of analog pulse,
//           then create list of digital blocks;
//
//=======================================================================
int CREATESEQ_createAllDigitalBlocksFromEventList (t_session *s, int displayProgress)
{
	int newTime, oldTime;
	int curveDuration;
	int i;
	t_digitalBlock *newBlock, *oldBlock;
	ListType times;
	t_event *e;
	int curveStart;
	int progressDialog = 0;
	int n;
	int error = 0;
	

	if (displayProgress) 
		progressDialog = CreateProgressDialog ("Compiling Sequence",
		 									   "Creating list of digital blocks...", 1,
											   VAL_NO_MARKERS, "Cancel");
	
	// -----------------------------
	//   1. create list of all times
	// -----------------------------
	times = ListCreate (sizeof(unsigned long));
	// get start of curve
	curveStart = getIntTime (s->curveStart_us);
	
	n = ListNumItems(s->lEvents);
	ListPreAllocate (times, 4 * n);
	for (i = 1; i <= n; i++) {
		ListGetItem (s->lEvents, &e, i);
		if (!e->alwaysOn) {
			// insert start time of event
			newTime = e->time - curveStart;
			ListInsertInOrder (times, &newTime, ulongCompare);
			// insert end time of event,
			//  if events changes a digital channel
			if (((e->duration > 0) || (e->durationIncrement != 0)) && (e->DIG_channel >= 0)) {
				newTime = e->time - curveStart + e->duration;
				ListInsertInOrder (times, &newTime, ulongCompare);
			}
		}
	}

	// --------------------------------
	//   2. create all digital blocks
	// --------------------------------
	// create init block
	oldBlock = DIGITALBLOCK_insert (s->sequence, FRONT_OF_LIST); 
	DIGITALBLOCK_init (oldBlock);
	strcpy (oldBlock->blockName, "Init");
	
	curveDuration = round ((s->curveEnd_us - s->curveStart_us) * VAL_us) + DURATION_GATE_PULSE;
//	curveEnd = curveStart + curveDuration;
	oldTime = 0;
	
	// now: create digital block for every new time in the
	// above created list
//	printf ("start   = %8d %3.1f\n", curveStart, 1.0*curveStart / VAL_us);
//	printf ("duration= %8d %3.1f\n", curveDuration, 1.0*curveDuration / VAL_us);
	n = ListNumItems (times);
	ListPreAllocate (s->sequence->lDigitalBlocks, 4 * n);
	for (i = 1; i <= n; i++) {
		ListGetItem (times, &newTime, i);
//		printf ("%8d %3.1f\n", newTime, 1.0*newTime / VAL_us);
		// insert a new block if start times are different
		if ((oldTime != newTime) && (newTime >= 0) && (newTime <= curveDuration)) {
			newBlock = DIGITALBLOCK_insert (s->sequence, END_OF_LIST);
			DIGITALBLOCK_init (newBlock);
			if (oldBlock != NULL) {
				oldBlock->duration = newTime - oldTime;
				if (newTime - oldTime < 0) Breakpoint();
			}
			oldTime = newTime;
			oldBlock = newBlock;
		}
		if (progressDialog && (i % 50 == 0)) {
			if (UpdateProgressDialog (progressDialog, 100 * i / n, 1)) { 
				error = -1; 
				goto end;
			}
		}
	}
	if (progressDialog) UpdateProgressDialog (progressDialog, 100, 0);	
	// set parameters for last block
	newBlock->duration = 20;
	strcpy (newBlock->blockName, "END");    

end:
	// free list of times
	ListDispose (times);

	if (progressDialog) DiscardProgressDialog (progressDialog);
//	DEBUG_printDigitalBlocks (s->sequence);
	return error;
	
}


//=======================================================================
//
//    AUTO GENERATE SEQUENCE:
//    insert an "event" into the digital blocks 
//    (which are previously created by function 
// 	  'CREATESEQ_createAllDigitalBlocksFromEventList(...)'
//
//=======================================================================
int CREATESEQ_markChannel (t_session *s, t_event *e, int *searchStart, int *sumTimeAtSearchStart)
{
    int i, nBlocks;
    int startBlock, stopBlock;
    t_digitalBlock *b;
    t_sequence *seq;
    int sumTime, endTime;
    int curveStart;
    
    startBlock = *searchStart;
    sumTime = *sumTimeAtSearchStart;
    seq = s->sequence;
   	
   	// number of digital blocks
   	nBlocks = ListNumItems (seq->lDigitalBlocks);
   	// smalles time of session
   	curveStart = getIntTime (s->curveStart_us);   

  	// get startblock for event
   	while ((sumTime < e->time - curveStart) && (startBlock < nBlocks)) {
		b = NULL;
		ListGetItem (seq->lDigitalBlocks, &b, startBlock);
    	if (b != NULL) sumTime +=  b->duration;
    	startBlock++;
    } 
    *searchStart = startBlock;
    *sumTimeAtSearchStart = sumTime;
    

   	// set absolute time reference
   	if (e->isAbsoluteTimeReference) {
   		b = DIGITALBLOCK_ptr (seq, startBlock);
   		b->isAbsoluteTimeReference = 1;
   	}
    
	// -----------------------------------
	//    case 1: event = digital pulse: 
	// -----------------------------------
	if (e->DIG_channel >= 0) {
		endTime = e->time - curveStart + e->duration;
		stopBlock = startBlock;
		// calculate last block 
		while ((sumTime < endTime) && (stopBlock < nBlocks)) {
	    	b = DIGITALBLOCK_ptr (seq, stopBlock);
	    	if (b != NULL) sumTime +=  b->duration;
	    	stopBlock++;
	    } 
    
	    // set blocks from 'startBlock' to 'stopBlock' to 'high'
	    for (i = startBlock; i < stopBlock; i++) {
	    	b = DIGITALBLOCK_ptr (seq, i);
	    	if (b->channels[e->DIG_channel] == 1) {
	    		// two events ofverlap: --> return error
	    		return i;
	    	}
	    	b->channels[e->DIG_channel] = 1;
	    }
        
        // insert variable pulses (from atom events)
        if (e->timeIncrement != 0) {
       		for (i = startBlock; i < stopBlock; i++) {
	       		b = DIGITALBLOCK_ptr (seq, i);
	        	b->varyPulse              [e->DIG_channel] = 1;
	        	b->varyPulseStartIncrement[e->DIG_channel] = e->timeIncrement;
	        	b->varyPulseStopIncrement [e->DIG_channel] = e->timeIncrement;
	        	b->varyPulseStepRep	      [e->DIG_channel] = 1;
	        }
        }
        if (e->durationIncrement != 0) {
        	if (e->duration == 0) {
        		// special case: duration = 0:
        		b = DIGITALBLOCK_insert (seq, stopBlock-1);
        		DIGITALBLOCK_init (b);
        		b->duration = 0;
        		b->channels[e->DIG_channel] = 1; 
        	}
        	else b = DIGITALBLOCK_ptr (seq, stopBlock-1);
        	b->varyPulse              [e->DIG_channel] = 1;
        	b->varyPulseStopIncrement [e->DIG_channel] += e->durationIncrement;
        	b->varyPulseStepRep	      [e->DIG_channel] = 1;
        }
	 	
	 	// check if stopblock is empty
    	b = DIGITALBLOCK_ptr (seq, stopBlock);
    	if (b->channels[e->DIG_channel] != 0) return stopBlock;
    }
	// -----------------------------------
	//   case 2: event = analog waveform
	// -----------------------------------
    else {
    	b = DIGITALBLOCK_ptr (seq, startBlock);
		if (e->AO_channel >= 0) {
			b->waveforms[e->AO_channel]     = e->waveform;
			b->constVoltages[e->AO_channel] = e->constVoltage;
		}
    }
	
	// insert name of digital block
    strcpy (DIGITALBLOCK_ptr (seq, startBlock)->blockName, e->name);
    
	return 0;     	
}






//=======================================================================
//
//    AUTO GENERATE SEQUENCE:
//    insert all "events" into the digital blocks 
//
//=======================================================================

int CREATESEQ_markAllChannels (t_session *s, int showErrMsg, int displayProgress)
{
	t_event *e;
	int i;
	int err = 0;
	t_sequence *seq;
	int nEvents;
	int progressDialog;
	int searchStart;
	int sumTimeAtSearchStart;
	

	seq = s->sequence;
	nEvents = ListNumItems (s->lEvents);

	if (displayProgress) 
		progressDialog = CreateProgressDialog ("Compiling Sequence",
		 									   "Filling pulses to digital blocks...", 1,
											   VAL_NO_MARKERS, "");
	
	searchStart = 1;
	sumTimeAtSearchStart = 0;
	for (i = 1; i <= nEvents; i++) {
		ListGetItem (s->lEvents, &e, i);
		// channel 'always on':
		if (e->alwaysOn) {
			seq->DIO_channelStatus[e->DIG_channel] = DIO_CHANNELSTATUS_ALWAYSON;
		}
		else {
			if ((CREATESEQ_markChannel (s, e, &searchStart, &sumTimeAtSearchStart) != 0) && !err) {
	    		if (showErrMsg) MessagePopupf ("Error", "Could not generate sequence.\n\n Event %d (%s) overlaps with other events!",
	    					   i, e->name);
	    		err = 1;
//				return -1;
			}
		}
		if (displayProgress && (i % 50 == 0)) UpdateProgressDialog (progressDialog, 100 * i / nEvents, 0);
		
	}
	if (displayProgress) DiscardProgressDialog (progressDialog);
	
	return err;
}


//======================================================================
//
//    AUTO GENERATE SEQUENCE:
//    invert the (displayed) logic of a digital channel
//    i.e. for MW pulses switched by PIN diodes
//
//=======================================================================
int CREATESEQ_invertChannel (t_sequence *seq, int channel)
{
    int i, n;
    t_digitalBlock *b;

    
    seq->DIO_invertDisplay[channel] = !seq->DIO_invertDisplay[channel];
    n = ListNumItems (seq->lDigitalBlocks);
    for (i = 1; i <= n; i++) {
		ListGetItem (seq->lDigitalBlocks, &b, i);
    	b->channels[channel] = !b->channels[channel];
    }
	if (seq->DIO_channelStatus[channel] == DIO_CHANNELSTATUS_ALWAYSON) 
		seq->DIO_channelStatus[channel] = DIO_CHANNELSTATUS_ALWAYSOFF;
	else if (seq->DIO_channelStatus[channel] == DIO_CHANNELSTATUS_ALWAYSOFF)
		seq->DIO_channelStatus[channel] = DIO_CHANNELSTATUS_ALWAYSON;
	
	return 0;     	
}







//======================================================================
//
//    check if session contains 'active' atoms
//
//=======================================================================
int SESSIONMANAGER_createSequence_hasActiveAtoms (t_session *s)
{
	int i;
	int isActive;
	
	if (ListNumItems (s->lAtoms) == 0) return 0;

	isActive = 0;
	i = 1;
	while ((i <= ListNumItems (s->lAtoms)) && (!isActive)) {
		if (ATOM_ptr (s, i)->active) isActive = 1;
		i++;
	}		
	
	return isActive;
}

  
  



  
//======================================================================
//
//    AUTO GENERATE SEQUENCE:
//    insert the "DIG" sweep 
//
//=======================================================================
void CREATESEQ_insertDIGSweep (t_session *s)
{
	t_sequence *seq;
	t_waveform *wfm;
	t_sweep *sw;
	
	seq = s->sequence;
	sw  = SWEEP_dig (s);
	
	// change mode of analog channels
	seq->AO_voltageSweepsOnly = 1;
	// create waveforms for voltage sweeps of all channels
	SEQUENCE_createVoltageSweepWaveforms (seq);
	// get waveform ptr
	wfm = WFM_ptr (seq, seq->voltageSweepWaveforms[sw->channel]);
	// insert sweep parameters
	wfm->stepFrom = sw->from;
	wfm->stepTo   = sw->to;
	wfm->stepRep  = sw->stepRepetitions;
	wfm->stepChangeMode = SWEEP_CHANGEMODE_CURVE;
}


  
int CREATESEQ_insertAOChannelSweeps (t_session *s)
{
	t_sequence *seq;
	t_sweep *sw;
	t_waveform *wfm;
	t_digitalBlock *d;
	int i;
	
	seq = s->sequence;
	// voltage sweeps only (dependent of channel)
	// STEFAN 23/08/2006
	seq->AO_voltageSweepsOnly = (s->mode == SESSIONMODE_DIG);
	SEQUENCE_createVoltageSweepWaveforms (seq);
	for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
		sw = SWEEP_ptr (s, i);
		if ((sw->active) && (sw->type == SWEEP_TYPE_ANALOGCHANNEL)) {
			if (seq->AO_voltageSweepsOnly) {
				wfm = WFM_ptr (seq, seq->voltageSweepWaveforms[sw->channel]);
	    		wfm->stepFrom = sw->from;
	    		if (sw->sweepOn) wfm->stepTo   = sw->to;
	    		else wfm->stepTo = sw->from;
	    		wfm->stepRep  = sw->stepRepetitions;
	    		wfm->stepChangeMode = SWEEP_CHANGEMODE_REPETITION;
	    	}
	    	else {
				wfm = WFM_new (seq);
		   		WFM_init (wfm, WFM_TYPE_STEP);
		   		strcpy (wfm->name, sw->name);
		   		wfm->stepFrom = sw->from;
	    		if (sw->sweepOn) wfm->stepTo   = sw->to;
	    		else wfm->stepTo = sw->from;
	    		wfm->stepChangeMode = SWEEP_CHANGEMODE_REPETITION;
		   		wfm->stepRep  = sw->stepRepetitions;
//	   			a = ANALOGBLOCK_ptrFromName (seq, strInit);
				d = DIGITALBLOCK_ptr (seq, 1);
	   			d->waveforms[sw->channel] = WFM_nrFromPtr (seq, wfm);
			}
		}
	}
	return 0;
}



int CREATESEQ_insertGPIBPowerSupplySweeps (t_session *s)
{
	t_sequence *seq;
	int i;
	t_sweep *sw;
	t_gpibCommand *g;
	
	seq = s->sequence;
	for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
		sw = SWEEP_ptr (s, i);
		if ((sw->active) && (sw->type == SWEEP_TYPE_POWERSUPPLY)) {
			if (SWEEP_isSameDeviceActive (s, sw)) {
				MessagePopupf ("Error", "GPIB device %d (%s) is\n activated in two sweeps.\n",
							   sw->channel, strGPIBlabel(sw->channel));
				return -1;
				
			}
			g = GPIBCOMMAND_new (seq);
			GPIBCOMMAND_init (g, GPIB_COMMANDTYPE_POWERSUPPLY);
			// program sweeps of Anritsu
			sprintf (g->name, strGPIBlabel(sw->channel));
			g->gpibAddress = sw->channel;
			g->enableStep = sw->sweepOn && (s->mode != SESSIONMODE_DIG);
			if (g->enableStep)
				g->transmitBeforeEveryRepetition = 1;
			else 
				g->transmitBeforeFirstRepetition = 1;
			g->startVoltage = sw->from;
			g->stopVoltage  = sw->to;
			g->stepVoltage  = sw->sweepOn;
			
			g->startCurrent = sw->current_mA / 1000;
			g->stopCurrent  = sw->current_mA / 1000;
			g->stepCurrent  = 0;
			g->channel      = sw->deviceChannel;
			// if high voltage power supply, wait until stabilized
			if ((g->gpibAddress == GPIB_ADDRESS_SRS_P350_1) 
			  ||(g->gpibAddress == GPIB_ADDRESS_SRS_P350_2) 
			  ||(g->gpibAddress == GPIB_ADDRESS_SRS_P350_3) 
			  ||(g->gpibAddress == GPIB_ADDRESS_SRS_P350_4)) g->waitUntilStabilized = 1;
		}
	}
	
	return 0;
}



int CREATESEQ_insertGPIBSynthesizerSweeps (t_session *s)
{
	t_sequence *seq;
	int i;
	t_sweep *sw;
	t_gpibCommand *g;
	
	seq = s->sequence;
	for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
		sw = SWEEP_ptr (s, i);
		if ((sw->active) && (sw->type == SWEEP_TYPE_SYNTHESIZER)) {
			if (SWEEP_isSameDeviceActive (s, sw)) {
				MessagePopupf ("Error", "GPIB device %d (%s) is\n activated in two sweeps.\n",
							   sw->channel, strGPIBlabel(sw->channel));
				return -1;
				
			}
			g = GPIBCOMMAND_new (seq);
			GPIBCOMMAND_init (g, GPIB_COMMANDTYPE_FREQ);
			// program sweeps of Anritsu
			sprintf (g->name, strGPIBlabel(sw->channel));
			g->gpibAddress = sw->channel;
			g->enableStep = sw->sweepOn && (s->mode != SESSIONMODE_DIG);
			if (g->enableStep)
				g->transmitBeforeEveryRepetition = 1;
			else 
				g->transmitBeforeFirstRepetition = 1;
			g->divideFreq = sw->harmonic;
			g->startFreq  = sw->from * VAL_GHz;
			g->stopFreq   = sw->to   * VAL_GHz;
			g->startMultiply  = VAL_GHz;
			g->stopMultiply   = VAL_GHz;
			g->centerMultiply = VAL_GHz;
			g->spanMultiply   = VAL_kHz;
			g->stepTrigger    = GPIB_COMMAND_FREQ_TRIGGER_CALC;
			g->nStepPoints    = s->nSweepPoints;
			g->nStepRepetition = 1;
			g->rfOn 		  = sw->rfOn;
			g->outputPower 	  = sw->outputPower;
			if (GPIBDEVICE_hasPulseMode (sw->channel)) {
				g->pulseModeEnable = sw->pulseMode;
				g->pulseModeLogic = GPIB_PULSE_LOGIC_INVERTED;
			}
			else {
				g->pulseModeEnable = GPIB_PULSE_MODE_NOT_USED;
				g->pulseModeLogic = GPIB_PULSE_MODE_NOT_USED;
			}				
		}
	}
	
	return 0;
}





void CREATESEQ_insertFakeAtomCounts (t_session *s, int channel, 
									 double time, int nCounts)
{
	int i;
	double high = 0.1; // us
	double low  = 0.1; // us

	for (i = 0; i < nCounts; i++) {
		EVENTS_insertDIGPulse (s->lEvents, "", channel, time+i*(high+low), high,1, "fake counts");
	}
	
}


int CREATESEQ_addCounterNCounts (t_session *s, int nCurves, int counter)
{
	t_sequence *seq;
	t_counter *c;
	int detector;
	
	seq = s->sequence;
	// counter was already initialized
	// -->skip
	c = COUNTER_ptrFromNr (seq->lCounters, counter);
	if (c != NULL) return 0;
	c = COUNTER_new (seq->lCounters);	
	// initialize counter
	COUNTER_init (c);
	c->nr = counter;
	c->mode = COUNTER_MODE_GET_NCOUNTS;
	c->saveData = 0;
	
	if (counter < 2) {
		detector = counter;
		c->bufferSize = nCurves * ListNumItems (s->lTimeIntervals[detector]);
		if (s->mode == SESSIONMODE_DIG) c->bufferSize *= s->DIG_copiesPerStep;
		c->bufferSize += 20;
	}
	else Breakpoint();
	c->stopIfPointsLost = 1;
	return 0;
}



double absoluteTime_us (t_session *s, double time_us)
{
	double absTime_us;
	
	absTime_us = time_us - s->curveStart_us + DURATION_FIRST_BLOCK_ns / 1000.0;
	return absTime_us;
}


			    




int CREATESEQ_addCounterArrivalTimes (t_session *s, t_plotItem *p)
{
	t_sequence *seq;
	t_counter *c;
//	t_counter *cTrig;
	t_atom *a;
	double duration_us;
	int i;
	
	seq = s->sequence;
	
	// counter was already initialized
	// -->skip
	c = COUNTER_ptrFromNr (seq->lCounters, COUNTERS_ARRIVALTIMES[p->detector]);
	if (c == NULL) {
		c = COUNTER_new (seq->lCounters);	
		COUNTER_init (c);
	}
//	cTrig = &seq->counters[seq->nCounters-1];
//	COUNTER_init (cTrig);

	c->mode = COUNTER_MODE_GET_ARRIVALTIMES;
	c->nr = COUNTERS_ARRIVALTIMES[p->detector];
//	c->saveData = s->saveArrivalTimes;
	// if experimentcontrol.exe runs on different computer --> transmit arrival times
	c->saveData = 0;
	c->transmitData = s->saveArrivalTimes;
	strcpy (c->dataFilename, seq->filename);
	c->bufferSize = 100000 * s->nCurves;
	duration_us = CREATESEQ_sequenceDuration_us (s);
	c->curveDuration_us = RoundRealToNearestInteger (duration_us);
	c->nDuplicates = s->transferOn ? 2 : 1;
//	c->initBlockDuration_us = DURATION_FIRST_BLOCK_ns / 1000;
	
	switch (p->type) {
		case PLOT_TYPE_VELOCITYDIST:
			c->velocityStart   = p->velocityStart;
			c->velocityEnd     = p->velocityEnd;
			c->velocityNPoints = p->velocityNPoints;
			if (p->detector == 0) 
				c->velocityDistance_m = (s->atomConfig->position[POS_DETECTOR1] - s->atomConfig->position[POS_LASER1]) / 1000.0;
			else 
				c->velocityDistance_m = (s->atomConfig->position[POS_DETECTOR2] - s->atomConfig->position[POS_LASER1]) / 1000.0;
			a = ATOM_ptr (s, p->atomNr);
			if (a != NULL) {
//				c->timeOffset        = 0;
//				for (i = 0; i < c->nDuplicates; i++) {
//					c->velocityTStart_ns[i] = absoluteTime_us (s, a->time[POS_LASER1] + i * duration_us)*1000;
//				}
				c->velocityTStart_ns = absoluteTime_us (s, a->time[POS_LASER1])*1000;
				c->velocityMaxTimeOfFlight_ns = (s->curveEnd_us - a->time[POS_LASER1]) * 1000.0; 
			}
			break;
		case PLOT_TYPE_ARRIVALTIMES:
			c->binSize_us  = p->arrivalTimesBinSize_us;
			PLOTITEM_getBinStartEnd (s, p);
//			for (i = 0; i < c->nDuplicates; i++) {
//				c->binStart_us[i] = absoluteTime_us (s, p->arrivalTimesBinStart_us + i * duration_us);
//				c->binEnd_us[i]   = absoluteTime_us (s, p->arrivalTimesBinEnd_us + i * duration_us);
//			}
			c->binStart_us = absoluteTime_us (s, p->arrivalTimesBinStart_us);
			c->binEnd_us   = absoluteTime_us (s, p->arrivalTimesBinEnd_us);
			break;
	}											  
	c->mode = COUNTER_MODE_GET_ARRIVALTIMES;
//	cTrig->nr = 2;
//	c->counter_startSignals = cTrig->nr;
//	cTrig->bufferSize = 2 * s->nCurves + 4;
//	cTrig->stopIfPointsLost = 1;
	return 0;
}


int CREATESEQ_addAllCounters (t_session *s)
{
	int i;
	t_plotItem *p;
	
	//--------------------------------
	//   check for consistency
	//--------------------------------
	//... to implement

	//.....
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		p = PLOTITEM_ptr (s, i);
		if ((p->active) && (s->counterOn[p->counter])) {
			switch (p->type) {
				case PLOT_TYPE_VELOCITYDIST:
				case PLOT_TYPE_ARRIVALTIMES:
					CREATESEQ_addCounterArrivalTimes (s, p);
					break;
//				case PLOT_TYPE_TRANSFER:
				case PLOT_TYPE_NCOUNTS:
				case PLOT_TYPE_CORRELATIONS:
				case PLOT_TYPE_MULTIPLE_AS_INDEX:
					CREATESEQ_addCounterNCounts (s, s->nCurves, p->detector);
					break;
			}
		}
	}
	return 0;
}



int CREATESEQ_insertCounterGatePulses (t_session *s)
{
	int i, d;
	t_timeInterval * t;
	int startTime,n;
	int error = 0;

	
	for (d = 0; d < N_DETECTORS; d++) {
		n = ListNumItems (s->lTimeIntervals[d]);
		for (i = 1; i <= n; i++) {
			ListGetItem (s->lTimeIntervals[d], &t, i);
			if (t->repetition == 0) {
				startTime = t->timeStart;
				EVENTS_insertDIGPulse (s->lEvents, t->atomNrStr, 
									  d == 0 ? CH_GATE_DET1 : CH_GATE_DET2,
									  (1.0 * startTime) * 0.05 ,
									  DUARTION_GATE_PULSE_us,
									  (n < 500),"TI%d %s", i, t->name);
			}
		}
	}
	return error;
}



int CREATESEQ_setDetectionParameters (t_session *s)
{
	int i, d;
	int error = 0;


	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		PLOTITEM_getCounter (PLOTITEM_ptr (s, i));
	}
	
	switch (s->mode) {
		case SESSIONMODE_DIG:
			for (d = 0; d < N_DETECTORS; d++) {
				if (s->counterOn[d]) CREATESEQ_addCounterNCounts (s, s->DIG_nSteps, d);
			}
			break;
		default: 
			error = CREATESEQ_addAllCounters (s);
	}
	return error;
}


void CREATESEQ_appendLastBlock (t_sequence *seq, double curveDuration_us)
{
	t_digitalBlock *lastBlock, *newBlock;
	unsigned minCurveDuration;
	__int64 referenceTime;
	__int64 absoluteTime;
	
	referenceTime = DIGITALBLOCK_calculateAllAbsoluteTimes(seq);
	
	ListGetItem (seq->lDigitalBlocks, &lastBlock, END_OF_LIST);
	minCurveDuration = curveDuration_us * VAL_us;
	absoluteTime = lastBlock->absoluteTime + lastBlock->duration;
	
	if (absoluteTime  < minCurveDuration) {
		newBlock = DIGITALBLOCK_insert (seq, END_OF_LIST);
		DIGITALBLOCK_init (newBlock);
		newBlock->duration =  minCurveDuration - absoluteTime;
		strcpy (newBlock->blockName, "wait");
	}
	// append last block
	// stop gpctr
/*	
	newBlock = DIGITALBLOCK_insert (seq, END_OF_LIST);
	DIGITALBLOCK_init (newBlock);
	newBlock->duration =  VAL_us / 2;
	newBlock->channels[CH_GATE_GPCTR2] = 1;
	newBlock->name = strnewcopy (newBlock->name, "stop GPCTR2");

	// append last block
	// stop gpctr
	newBlock = DIGITALBLOCK_insert (seq, END_OF_LIST);
	DIGITALBLOCK_init (newBlock);
	newBlock->duration =  VAL_us / 2;
*/
}



int DIO_AlwaysOnOff (int x)
{
	return x ? DIO_CHANNELSTATUS_ALWAYSON :  DIO_CHANNELSTATUS_ALWAYSOFF; 	
}


double CREATESEQ_getKillerDefaultDetuning (t_session *s, int cavityNr)
{
	t_atomConfig *ac;
	t_transferFunction f;

	ac = s->atomConfig;

	if (!ac->setDefaultVoltage) {
		return ac->killerDefaultDetuning[cavityNr];
	}
	else {
		CREATESEQ_makeTransferFunction (&f, s, cavityNr);
		return TRANSFERFUNCT_applyInv (&f, ac->killerDefaultVoltage[cavityNr]);
	}
}


double CREATESEQ_getKillerDefaultVoltage (t_session *s, int cavityNr)
{
	t_atomConfig *ac;
	t_transferFunction f;

	ac = s->atomConfig;

	if (ac->setDefaultVoltage) {
		return ac->killerDefaultVoltage[cavityNr];
	}
	else {
		CREATESEQ_makeTransferFunction (&f, s, cavityNr);
		return TRANSFERFUNCT_apply (&f, ac->killerDefaultDetuning[cavityNr]);
	}
}


t_digitalBlock *CREATESEQ_insertInitBlock (t_session *s)
{
	t_digitalBlock *d;
	int i;
	t_sequence *seq;
	seq = s->sequence;
	
	// insert block at front of list
	d = DIGITALBLOCK_insert (seq, 1);
	DIGITALBLOCK_init (d);
	strcpy (d->blockName, strInit);
	d->duration = DURATION_FIRST_BLOCK_ns / VAL_MIN_ns;
	d->isAbsoluteTimeReference = 0;
	d->waveforms[A_CH_VOLTAGE_DETECTOR] = WFM_ID_CONSTVOLTAGE;
	if (s->transferOn) {
		d->constVoltages[A_CH_VOLTAGE_DETECTOR] = s->levelVoltages[s->transferLevel[0]];
	}
	else {
//		d->constVoltages[A_CH_VOLTAGE_DETECTOR] = s->
	// default voltage d->constVoltages[A_CH_VOLTAGE_DETECTOR] =
	}
	

	if (s->transmitKillerCurves) {
		d->channels[CH_TRIG_LECROY_KILLER] = 1;
		for (i = 0; i < N_CAVITIES; i++) {
			d->constVoltages[s->FIRST_KILLER_CHANNEL+i] = CREATESEQ_getKillerDefaultVoltage (s, i);
			d->waveforms[s->FIRST_KILLER_CHANNEL+i]     = WFM_ID_CONSTVOLTAGE;
		}
	}

	for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
		
	}
	if (s->laser1AlwaysOn) seq->DIO_channelStatus[CH_LASER1] = DIO_CHANNELSTATUS_ALWAYSON;
	if (s->laser2AlwaysOn) seq->DIO_channelStatus[CH_LASER2] = DIO_CHANNELSTATUS_ALWAYSON;
	if (s->optPumpingAlwaysOn) seq->DIO_channelStatus[CH_OPT_PUMPING] = DIO_CHANNELSTATUS_ALWAYSON;
	if (s->repumperAlwaysOn) {
		seq->DIO_channelStatus[CH_REP_POWER_E1] = DIO_AlwaysOnOff (E1(s->repumperPower));
		seq->DIO_channelStatus[CH_REP_POWER_E2] = DIO_AlwaysOnOff (E2(s->repumperPower));
		seq->DIO_channelStatus[CH_REP_FREQUENCY_E1] = DIO_AlwaysOnOff (E1(s->repumperFrequency));
		seq->DIO_channelStatus[CH_REP_FREQUENCY_E2] = DIO_AlwaysOnOff (E2(s->repumperFrequency));
	}
	return d;
	
}


void CREATESEQ_insertTransferFunctionKiller (t_session *s)
{
	t_transferFunction *t;
	
}



void CREATESEQ_makeTransferFunction (t_transferFunction *f, t_session *s, int cavityNr)
{
	TRANSFERFUNCT_init (f);
	ATOMS_KILLER_makeTransferFunction  (f, s->atomConfig->parametersTransferFunct[cavityNr][0],
						          s->atomConfig->parametersTransferFunct[cavityNr][1],
						          s->atomConfig->parametersTransferFunct[cavityNr][2]);
	
	
	strcpy (f->name, STR_transferFunctName(cavityNr));
}



void CREATESEQ_makeWaveform (t_waveform *wfm, t_session *s, t_point *points, int nPoints, double defaultValue, double *pretrig_us)
{
	
	int i;
	double minTime_ns;
	t_point *newPoints;

	
	WFM_init (wfm, WFM_TYPE_POINTS);
	if (pretrig_us != NULL) *pretrig_us = 0; 
	// insert number of points
	// (add one point to allow for variable killer start)
	wfm->nPoints = nPoints;
	if (nPoints == 0) return;
	wfm->points = (t_point *) malloc (sizeof (t_point) *wfm->nPoints);
	memcpy (wfm->points, points, sizeof (t_point) * nPoints);
	

	// check if there is a negative time
    // =================================
    // calculate for first repetition
    POINTS_calculateValues (wfm->points, wfm->nPoints, 0, 1);
    minTime_ns = wfm->points[0].thisTime_ns;

    POINTS_calculateValues (wfm->points, wfm->nPoints, s->nSweepPoints-1, 1);
    minTime_ns = min(wfm->points[0].thisTime_ns, minTime_ns);
    
	// shift waveform, if first time is negative
	if (minTime_ns < 0) {
		for (i = 0; i < wfm->nPoints; i++) {
			wfm->points[i].timeStart_ns -= minTime_ns;
		}
		if (pretrig_us != NULL) *pretrig_us = -minTime_ns / 1000.0;
	}


	// first point varies:
	// add additional 2 points
	if (wfm->points[0].varyTime) {
		// first point has varaiable time: add two other points
		wfm->nPoints += 2;
		newPoints = (t_point *) malloc (sizeof (t_point) *wfm->nPoints);
		memcpy (&newPoints[2], wfm->points, sizeof (t_point) * (wfm->nPoints-2));
		POINT_init (&newPoints[0]);
		POINT_init (&newPoints[1]);
		newPoints[0].valueStart = newPoints[2].valueStart;
		newPoints[0].varyValue = 0;
		newPoints[0].valueIncrement = 0;
		newPoints[1].valueStart = newPoints[2].valueStart;
		newPoints[1].varyValue = 0;
		newPoints[1].thisValue = defaultValue; 
		newPoints[1].timeStart_ns = newPoints[2].timeStart_ns;
		newPoints[1].varyTime     = newPoints[2].varyTime;
		newPoints[1].timeIncrement_ns = newPoints[2].timeIncrement_ns;
		
		free (wfm->points);
		wfm->points = newPoints;
	}
	else {
	}
	
	// -----------------------------------
	//      change from �s to ms
	// -----------------------------------
	for (i = 0; i < wfm->nPoints; i++) {
//		wfm->points[i].timeStart     /= 1000.0;
//		wfm->points[i].timeIncrement /= 1000.0;
		wfm->points[i].stepRepetitions = 1;
	}
	
}



void CREATESEQ_insertKillerPoints (ListType lEvents, t_session *s, int atomNr, int cavityNr, int createKillerWaveform,
								   double delay, char* atomStr, int *killerWaveformNr, double *pretrig_us)
{
//	CREATESEQ_insertDIGPulse (pulseList, CH_TRIGGER_LECROY_KILLER,
//			0, DURATION_LECROY_TRIG, dT, "trig. killer");
	t_atom *a;
	t_waveform *wfm = NULL;
	t_sequence *seq;
	t_transferFunction *t;
	
	int i;

	
	seq = s->sequence;
	a = ATOM_ptr (s, atomNr);

	if (!a->killerActive[cavityNr]) return;
	if (a->nKillerPoints[cavityNr] == 0) {
		// --------------------------------------------------
		//    no points present --> apply default voltage
		// --------------------------------------------------
/*
		EVENTS_insertAOPulse (lEvents, atomStr, 
						 s->FIRST_KILLER_CHANNEL+cavityNr,
						 WFM_ID_CONSTVOLTAGE,
						 s->killerDefaultVoltage[cavityNr],
						 a->time[a->killerTimeReference[cavityNr]] + a->killerStartFirst[cavityNr] + delay,
						 0,
						 "at.%s, killer cav. %d", atomStr, cavityNr+1);
*/
		return;
	}
	if (createKillerWaveform) {
		wfm = WFM_new (seq);
		CREATESEQ_makeWaveform (wfm, s, a->killerPoints[cavityNr], a->nKillerPoints[cavityNr], 
							    CREATESEQ_getKillerDefaultDetuning (s, cavityNr), pretrig_us);

		// -----------------------------------
		//      create transfer function
		// -----------------------------------
		wfm->transferFunction = TRANSFERFUNCT_nr (seq, STR_transferFunctName(cavityNr));
		if (wfm->transferFunction == 0) {
			// create transferfunction kHz --> V
			//  freq = 49.5 * [V_killer^2 - (0.62)^2] kHz
			//  V_killer = SQRT (freq [kHz]/ 49.5 + (0.62)^2)
			t = TRANSFERFUNCT_new (s->sequence);
			CREATESEQ_makeTransferFunction (t, s, cavityNr);
			wfm->transferFunction = TRANSFERFUNCT_nr (seq, STR_transferFunctName(cavityNr));
		}
		
	
		// insert name of waveform;
		sprintf (wfm->name, "killer atom %s cavity %d", atomStr, cavityNr+1);
		strcpy (wfm->strValueName, "detuning");
		strcpy (wfm->strValueUnits, "kHz");
		*killerWaveformNr = WFM_nrFromPtr (s->sequence, wfm);
	}
	// -------------------------------------
	//     insert event that calls waveform
	// -------------------------------------
	EVENTS_insertAOPulse (lEvents, atomStr, 
						 s->FIRST_KILLER_CHANNEL+cavityNr,
						 *killerWaveformNr, // WFM_nrFromPtr (s->sequence, wfm),
						 0,
						 a->time[a->killerTimeReference[cavityNr]] + a->killerStartFirst[cavityNr]+delay-*pretrig_us,
						 a->killerPoints[cavityNr][a->nKillerPoints[cavityNr]-1].timeStart_ns / 1000.0,
						 "at.%s, killer cav. %d", atomStr, cavityNr+1);
	
	
}



//=========================================================================
//
//    insert parameters of circularization
//
//=========================================================================
void CREATESEQ_insertParametersCirc (ListType lEvents, t_session *s, int atomNr, double delay, char* atomStr,int putStrings)
{			
	t_atom *a;
	
	a = ATOM_ptr (s, atomNr);
	// -------------------------------------------------
	//     laser 1 (420 nm)
	// -------------------------------------------------
	if (!s->laser1AlwaysOn) {
		EVENTS_insertDIGPulse (lEvents, atomStr, CH_LASER1, 	
							  a->time[POS_LASER1]+delay,
							  a->durationL1, 
							  putStrings,"atom%s laser420nm", atomStr);
	}
	// -------------------------------------------------
	//     laser 2 (1015 nm)
	// -------------------------------------------------
	if (!s->laser2AlwaysOn) {
		EVENTS_insertDIGPulse (lEvents, atomStr, CH_LASER2, 	
							  a->time[POS_LASER1] + a->timeL2+delay,
							  a->durationL2, 
							  putStrings,"atom%s laser1015nm", atomStr);
	}
	// -------------------------------------------------
	//     opt. pumping (780 nm)
	// -------------------------------------------------
	if (!s->optPumpingAlwaysOn) {
		EVENTS_insertDIGPulse (lEvents, atomStr, CH_OPT_PUMPING, 	
							  a->time[POS_LASER1] + a->timeOP+delay,
							  a->durationOP, 
							  putStrings,"atom%s opt.pump.", atomStr);
	}
	// -------------------------------------------------
	//      MW-pulse  52d --> 52f
	// -------------------------------------------------
	EVENTS_insertDIGPulse (lEvents, atomStr, CH_52D_52F,
						  a->time[POS_LASER1]+a->circ52dTime+delay,
						  a->circ52dDuration, 
						  putStrings,"atom%s trig.52d->52f", atomStr);

	// -------------------------------------------------
	//      trigger circ. ramp
	// -------------------------------------------------
	EVENTS_insertDIGPulse (lEvents, atomStr, CH_TRIG_LECROY_CIRC,
						  a->time[POS_LASER1]+a->circTriggerRamp+delay,
						  1, 
						  putStrings,"atom%s trig.circ.ramp", atomStr);
	// -------------------------------------------------
	//      trigger RF circ ramp
	// -------------------------------------------------
	EVENTS_insertDIGPulse (lEvents, atomStr, CH_TRIG_RF_CIRC,
						  a->time[POS_LASER1] + a->circTriggerRF+delay,
						  DURATION_LECROY_TRIG, 
						  putStrings,"atom%s trig.RF circ", atomStr);

	switch (a->state) {
		case STATE_E:
			EVENTS_insertDIGPulse (lEvents, atomStr, CH_PURIF_E,
								  a->time[POS_LASER1]+a->purifStart_e+delay,
								  a->purifDuration_e, 
								  putStrings,"atom%s purif_e", atomStr);
			break;
		case STATE_G:
			EVENTS_insertDIGPulse (lEvents, atomStr, CH_PURIF_G,
								  a->time[POS_LASER1]+a->purifStart_g+delay,
								  a->purifDuration_g, 
								  putStrings,"atom%s purif_g", atomStr);
			break;
	}
}



//=========================================================================
//
//       velocity selection 
//
//=========================================================================
void CREATESEQ_insertParametersVelocity (ListType lEvents, t_session *s, int atomNr, double delay, char* atomStr,int putStrings)
{
	double startTime;
	double freqSwitchOffset = 1;
	t_atom *a;
	
	a = ATOM_ptr (s, atomNr);
	if ((a->velocitySelection) && (a->repumperDuration > 0) && !s->repumperAlwaysOn) {
		startTime = a->time[a->repumperTimeReference];
		EVENTS_insertDIGPulse (lEvents, atomStr, CH_DEPUMPER_ANGLE,
							  startTime + a->depumperAngleTime+delay,
							  a->depumperAngleDuration, 
							  putStrings,"#%s depumper", atomStr);
		EVENTS_insertDIGPulse (lEvents, atomStr, CH_REPUMPER,
							  startTime + a->repumperTime + delay, 
							  a->repumperDuration, 
							  putStrings,"#%s repumper", atomStr);
		if (E1(a->repumperPower)) 
			EVENTS_insertDIGPulse (lEvents, atomStr, CH_REP_POWER_E1,
								  startTime + a->repumperTime - freqSwitchOffset+delay, 
								  a->repumperDuration + 2*freqSwitchOffset, 
								  putStrings,"#%s rep. power", atomStr);
		if (E2(a->repumperPower)) 
			EVENTS_insertDIGPulse (lEvents, atomStr, CH_REP_POWER_E2,
								  startTime + a->repumperTime - freqSwitchOffset+delay, 
								  a->repumperDuration + 2*freqSwitchOffset, 
								  putStrings,"#%s rep. power", atomStr);
		if (E1(a->repumperFrequency))
			EVENTS_insertDIGPulse (lEvents, atomStr, CH_REP_FREQUENCY_E1,
								  startTime + a->repumperTime - freqSwitchOffset+delay, 
								  a->repumperDuration+2*freqSwitchOffset, 
								  putStrings,"#%s rep. freq.", atomStr);
		if (E2(a->repumperFrequency))
			EVENTS_insertDIGPulse (lEvents, atomStr, CH_REP_FREQUENCY_E2,
								  startTime + a->repumperTime - freqSwitchOffset+delay, 
								  a->repumperDuration+2*freqSwitchOffset, 
								  putStrings,"#%s rep. freq.", atomStr);
	}

}


int CREATESEQ_insertPulsesAtomEvents (ListType lEvents, t_session *s, int atomNr,double delay, char* atomStr,int putStrings)
{
    int i;
    t_atomEvent *evt;
    t_event *e;
	t_atom *a;
	
	a = ATOM_ptr (s, atomNr);
   	if (a == NULL) return 0;
	for (i = 1; i <= ListNumItems (a->lAtomEvents); i++) {
		evt = ATOMEVENT_ptr (a, i);
		if (evt->active) {
			switch (evt->deviceType) {
				case ATOMEVENT_DEVICETYPE_DIGITAL:
					e= EVENTS_insertDIGPulse (lEvents, atomStr, evt->digitalChannel,
										      evt->pulseStartFirst + a->time[evt->pulseStartReference]+delay, 
										      evt->pulseDurationFirst, 
										      putStrings,"at.%s EVT %s", atomStr, evt->name);
					if (evt->pulseStartVary) 
						e->timeIncrement = getIntTime (evt->pulseStartIncrement);
					if (evt->pulseDurationVary) 
						e->durationIncrement = getIntTime (evt->pulseDurationIncrement);
					break;
				case ATOMEVENT_DEVICETYPE_ANALOG:
					e= EVENTS_insertAOPulse (lEvents, atomStr, evt->analogChannel,
									 		 WFM_ID_CONSTVOLTAGE,
									 		 evt->voltageFirst,
									         evt->pulseStartFirst + a->time[evt->pulseStartReference]+delay, 
									 		 0,
										      "at.%s EVT %s", atomStr, evt->name);
					e->voltageVary = evt->voltageVary;
					e->voltageIncrement = evt->voltageIncrement;
					break;
			}
					
		}
	}
	
	return 0;
}




t_waveform *createWaveformDetector2 (t_session *s, int level)
{
	t_waveform *wfm;
	// ------------------------------------------------------
	//   create new waveform
	// ------------------------------------------------------
	wfm = WFM_new (s->sequence);
	WFM_init (wfm, WFM_TYPE_STEP);
	sprintf (wfm->name, "%s <-> %s", s->levelNames[s->transferLevel[0]], s->levelNames[s->transferLevel[1]]);
	wfm->stepFrom = s->levelVoltages[s->transferLevel[level]];
	wfm->stepTo   = s->levelVoltages[s->transferLevel[level]];
	wfm->stepChangeMode = SWEEP_CHANGEMODE_REPETITION;
	wfm->stepAlternate = 1;
	wfm->stepRep  = 1;
	
	return wfm;
}


/*
int getTransferDetector2 (t_session *s, t_plotItem **pReturn)
{
	int i;
	int found;
	t_plotItem *p;
	
	p = NULL;
	s->transferLevel[0] = 0;
	s->transferLevel[1] = 0;	
	found = 0;   
	// ------------------------------------------------------
	//   get first active plot item for transfer detector2
	//   with plotType = TRANSFER
	// ------------------------------------------------------
	i = 1;

	while (!found && (i <= ListNumItems (s->lPlotItems))) {
		ListGetItem (s->lPlotItems, &p, i);
		if ((p->active) && (p->detector == 1) && (p->type == PLOT_TYPE_TRANSFER)) {
			found = 1;
			s->transferLevels[0] = p->transferLevel[0];
			s->transferLevels[1] = p->transferLevel[1];
		}   
		i++;
	}
	// exit procedure if no transfer should be measured
	if (pReturn != NULL) *pReturn = p;
	return found;
	
}
*/


int CREATESEQ_insert_WaveformsVoltageDetector2 (t_session *s, int atomNr, double delay, char* atomStr)
{
	t_waveform *wfm = NULL;
	t_timeInterval *t;
	t_detectionParameters *d;
	t_atom *a;
	int i;
	int found;
			  
//	*waveform = NULL;
	// init pointers
	a = ATOM_ptr (s, atomNr);
	if ((a == NULL) || (!a->detect)) return 0;
	d = DETECTIONPAR_ptr (s, a->detectionParameters);
	// ------------------------------------------------------
	//   get first active plot item for transfer detector2
	//   with plotType = TRANSFER
	// ------------------------------------------------------

	
	
	if (s->transferOn && (atomNr == s->transferAtom)) { 
		// atom whose transfer should be measured
		// alternate voltage in this time interval
		// insert waveform
		wfm = createWaveformDetector2 (s, 0);
		
		if (d == NULL) {
			// ---------------------------------------
			//    no detection parameters selected
			//    vary voltage at beginning of sequence
			// ---------------------------------------
			EVENTS_insertAOPulse (s->lEvents, atomStr, 
								 A_CH_VOLTAGE_DETECTOR,
								 WFM_nrFromPtr (s->sequence, wfm),
								 0,
								 a->time[POS_LASER1],
								 0, "at.%s, det.2", atomStr);
			s->waveformDet2 = wfm;
			return 0;
		}
		
		t = TIMEINTERVAL_ptrForAtom (s->lTimeIntervals[1], s->transferAtom);
		
//		t = TIMEINTERVAL_ptrList (s->lTimeIntervals[1], s->transferInterval[0]);
		if (t != NULL) EVENTS_insertAOPulse (s->lEvents, atomStr, 
							 A_CH_VOLTAGE_DETECTOR,
							 WFM_nrFromPtr (s->sequence, wfm), 0,
							 delay + 0.05 * t->timeStart - SWITCHING_TIME_DET2_us, 0.05 * (t->timeEnd - t->timeStart),
							 "at.%s, det.2", atomStr);
//		else Breakpoint();
	}
	if (!s->transferOn) {
		// insert only constant vol
		// insert default detection voltage
		EVENTS_insertAOPulse (s->lEvents, atomStr, 
							 A_CH_VOLTAGE_DETECTOR,
							 WFM_ID_CONSTVOLTAGE,
							 s->levelVoltages[a->detectionLevel],
							 a->detectionTime + a->time[a->detectionTimeReference] -SWITCHING_TIME_DET2_us + delay,
							 0, "at.%s, det.2", atomStr);
		
		t = TIMEINTERVAL_ptrForAtom (s->lTimeIntervals[1], atomNr);
		if (t != NULL) EVENTS_insertAOPulse (s->lEvents, atomStr, 
							A_CH_VOLTAGE_DETECTOR,
							 WFM_ID_CONSTVOLTAGE, s->levelVoltages[t->levelNr],
							 0.05 * t->timeStart-SWITCHING_TIME_DET2_us + delay, 0.05 * (t->timeEnd - t->timeStart),
							 "at.%s, det.2", atomStr);
	}

/* OLD:	
	if (s->transferOn) && (atomNr == s->transferAtom)) { 
		// atom whose transfer should be measured
		// alternate voltage in this time interval
		// insert waveform
		wfm = createWaveformDetector2 (s, 0);
		
		if (d == NULL) {
			// ---------------------------------------
			//    no detection parameters selected
			//    vary voltage at beginning of sequence
			// ---------------------------------------
			EVENTS_insertAOPulse (s->lEvents, atomStr, 
								 A_CH_VOLTAGE_DETECTOR,
								 WFM_nrFromPtr (s->sequence, wfm),
								 0,
								 a->time[POS_LASER1],
								 0, "at.%s, det.2", atomStr);
			*waveform = wfm;
			return 0;
		}
		
		t = TIMEINTERVAL_ptrForAtom (s->lTimeIntervals[1], s->transferAtom);
		
//		t = TIMEINTERVAL_ptrList (s->lTimeIntervals[1], s->transferInterval[0]);
		if (t != NULL) EVENTS_insertAOPulse (s->lEvents, atomStr, 
							 A_CH_VOLTAGE_DETECTOR,
							 WFM_nrFromPtr (s->sequence, wfm), 0,
							 delay + 0.05 * t->timeStart - SWITCHING_TIME_DET2_us, 0.05 * (t->timeEnd - t->timeStart),
							 "at.%s, det.2", atomStr);
//		else Breakpoint();
	}

	if (!s->transferOn) {
		// insert only constant vol
		// insert default detection voltage
		EVENTS_insertAOPulse (s->lEvents, atomStr, 
							 A_CH_VOLTAGE_DETECTOR,
							 WFM_ID_CONSTVOLTAGE,
							 s->levelVoltages[a->detectionLevel],
							 a->detectionTime + a->time[a->detectionTimeReference] -SWITCHING_TIME_DET2_us + delay,
							 0, "at.%s, det.2", atomStr);
		
		t = TIMEINTERVAL_ptrForAtom (s->lTimeIntervals[1], atomNr);
		if (t != NULL) EVENTS_insertAOPulse (s->lEvents, atomStr, 
							A_CH_VOLTAGE_DETECTOR,
							 WFM_ID_CONSTVOLTAGE, s->levelVoltages[t->levelNr],
							 0.05 * t->timeStart-SWITCHING_TIME_DET2_us + delay, 0.05 * (t->timeEnd - t->timeStart),
							 "at.%s, det.2", atomStr);
	}
*/
	if (wfm != NULL) s->waveformDet2 = wfm;
	return 0;
}


int	CREATESEQ_setNRepetitions (t_session *s)
{
	t_sequence *seq;
	
	seq = s->sequence;
	
	switch (s->mode) {
		case SESSIONMODE_DIG:
			seq->nRepetitions = N_DIG_REPETITIONS;
			seq->nRuns        = s->nRuns;
			seq->nCopies      = s->DIG_nSteps * s->DIG_copiesPerStep;
			break;
		case SESSIONMODE_STANDARD:
			seq->nRepetitions = s->nSweepPoints;
			seq->nRuns      = s->nRuns;
			seq->nCopies    = s->nCurves;
			break;
	}
	return 0;
}
    
    
int CREATESEQ_insertPulsesAtomDetection (ListType lEvents, t_session *s, int atomNr, double delay,char* atomStr,int putStrings)
{
	t_atom *a;
	t_detectionParameters *d;
	
	a = ATOM_ptr (s, atomNr);
   	if (a == NULL) return 0;
 	// trigger ramp detector 1;
	d = DETECTIONPAR_ptr (s, a->detectionParameters);
	if ((d != NULL) && (d->detectorActive[0])) {
		EVENTS_insertDIGPulse (lEvents, atomStr, CH_TRIG_LECROY_DET_RAMP, 
							   a->time[d->det1_rampTriggerReference] + d->det1_rampTrigger+delay,
							   DURATION_LECROY_TRIG,putStrings, "#%s ramp.det 1", atomStr);
		EVENTS_insertDIGPulse (lEvents, atomStr, CH_DET1_ON, 
							   a->time[d->det1_rampTriggerReference] + d->det1_rampTrigger + DELAY_PULSE_DET1_ON+delay,
							   DURATION_PULSE_DET1_ON,putStrings, "det1 ON");

	}
	return 0;
}
  	

    
int CREATESEQ_insertPulsesAtom (ListType lEvents, t_session *s, int i, int createKillerWaveform,
								int *atomCounter, int nAtoms, int progressDialog) 
{
	t_atom* a;
	int copy;
	int c;
	int m;
	double delay;
	char atomStr[10];
	t_detectionParameters *d;
	int killerWaveformNr = 0;
	double pretrig_us;
	
	
	a = ATOM_ptr (s,i);
	if(!a->hasMultiples) {
		copy=1;
		strcpy(atomStr,intToStr(i));
	}
	else copy = a->nMultiples;
	
	for(m =0;m<copy;m++) {
		delay=m*a->delay;
		if(a->hasMultiples) sprintf(atomStr,"%d.%d",i,m+1);
		//===================================================
		//       parameters circularization
		//===================================================
		CREATESEQ_insertParametersCirc (lEvents, s, i, delay, atomStr, copy < 500);
		//===================================================
		//       velocity selection 
		//===================================================
		CREATESEQ_insertParametersVelocity (lEvents, s, i, delay, atomStr,copy < 500);
		//===================================================
		//       events
		//===================================================
		CREATESEQ_insertPulsesAtomEvents (lEvents, s, i, delay, atomStr,copy < 500);
		//===================================================
		//       detection
		//===================================================
		CREATESEQ_insertPulsesAtomDetection (lEvents, s, i, delay, atomStr,copy < 500);

		for (c = 0; c < N_CAVITIES; c++) {
			CREATESEQ_insertKillerPoints (lEvents, s, i, c, createKillerWaveform && (m ==0), delay, atomStr, &killerWaveformNr, &pretrig_us);
		}
		if (s->mode == SESSIONMODE_STANDARD) 
		    CREATESEQ_insert_WaveformsVoltageDetector2 (s, i, delay, atomStr);

		if (atomCounter) {
			(*atomCounter)++;
			if (progressDialog && (*atomCounter % 30 == 0)) 
					if (UpdateProgressDialog (progressDialog, 95 * (*atomCounter) / nAtoms, 1)) return -1;
		}
	 }
	
	
	return 0;
}
    
    
void CREATESEQ_insertChannels_alwaysOn (t_session *s)
{
	int i;
	
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		if (s->digitalOutputs_preset[i]) {
			s->sequence->DIO_channelStatus[i] = 
				s->digitalOutputs_onOff[i] ? DIO_CHANNELSTATUS_ALWAYSON : DIO_CHANNELSTATUS_ALWAYSOFF;
		}
	}
}



void CREATESEQ_duplicateSequence (t_session *s, t_digitalBlock *initBlock)
{
	t_digitalBlock *b, *new;
	int i, n;
	t_waveform *wfm2;
	int wfmNr;
	t_sequence *seq;
	
	seq = s->sequence;
	wfmNr = WFM_nrFromPtr (seq, s->waveformDet2);
	n = ListNumItems (seq->lDigitalBlocks);
	for (i = 1; i <= n; i++) {
		ListGetItem (seq->lDigitalBlocks, &b, i);
		new = DIGITALBLOCK_new (seq);
		DIGITALBLOCK_duplicate (new, b);
		if ((wfmNr != WFM_ID_UNCHANGED) && (b->waveforms[A_CH_VOLTAGE_DETECTOR] == wfmNr)) {
			// found digital block waveform which alters detector 2
			// create new waveform with the other voltage
			wfm2 = createWaveformDetector2 (s, 1);
			// set new waveform to duplicated block
			new->waveforms[A_CH_VOLTAGE_DETECTOR] = WFM_nrFromPtr (s->sequence, wfm2); 
		}
		
		if (b == initBlock) {
			// change voltage at new init block
			new->constVoltages[A_CH_VOLTAGE_DETECTOR] = s->levelVoltages[s->transferLevel[1]];
		}
	}
	
	
	
}



void CREATESEQ_insertTestPulse (t_sequence *seq)
{
	t_digitalBlock *b;
	
	b = DIGITALBLOCK_ptr (seq, 7);
	if (b != NULL) b->channels[CH_D7] = 1;
	b = DIGITALBLOCK_ptr (seq, 19);
	if (b != NULL) b->channels[CH_D7] = 1;
	
	return;	
}



int CREATESEQ_isChannelInverted (int channel)
{
	return   ((channel == CH_OPT_PUMPING)
		  || (channel == CH_REPUMPER)        				
		  || (channel == CH_DEPUMPER_ANGLE)        
		  || (channel == CH_52D_52F)         
		  || (channel == CH_PURIF_E)         
		  || (channel == CH_PURIF_G)         
		  || (channel == CH_RAMSEY1)         
		  || (channel == CH_RAMSEY2)         
		  || (channel == CH_RAMSEY3)         
		  || (channel == CH_CAVITY1) 
		  || (channel == CH_DET1_ON)         
);
}


// get the maximum sequence duration 
// (imposed by hardware limits)
double CREATESEQ_maxSequenceDuration_us (void)
{
	
	unsigned deltaT;
	unsigned maxSamples;
	double maxDigitalDuration_us;
	double maxAnalogDuration_us;
	
	// get max. duration of digital signal (limited by memory buffer)
	deltaT = CREATESEQ_deltaT_DIO ();
	maxSamples = MAX_DIGITAL_BUFFER_SIZE / N_OUTPUT_PORTS;
	maxDigitalDuration_us = (VAL_FLOAT_MIN_us * deltaT) * maxSamples;
	
	// get max. duration of analog signal (limited by memory buffer)
	deltaT = CREATESEQ_deltaT_AO ();
	maxSamples = MAX_ANALOG_BUFFER_SIZE / 16; // 8 channels � 12 bit
	maxSamples = min (GPCTR_MAX_COUNTS - 1, maxSamples); 
	maxAnalogDuration_us = (VAL_FLOAT_MIN_us * deltaT) * maxSamples;
	
	return min (maxDigitalDuration_us, maxAnalogDuration_us );
	
}



int CREATESEQ_curveTooLong (t_session *s)
{

    double maxDuration_us;
    double sequenceDuration_us;
    int maxCopies;
   
   	maxDuration_us = CREATESEQ_maxSequenceDuration_us();
   	if (s->transferOn) maxDuration_us /=  N_SESSION_TRANSFER_LEVELS;
	sequenceDuration_us = CREATESEQ_sequenceDuration_us (s);
	
	if (sequenceDuration_us > maxDuration_us) {
		MessagePopupf ("Error", "Curve too long!\n\n"
		  			   "The duration of your curve is %3.3f ms.\n\n"
					   "Maximally allowed duration due to buffer memory limitations is %3.3f ms.\n",
					   sequenceDuration_us / 1000.0,
					   maxDuration_us / 1000.0);	
		return 1;
	}


	// check if too many copies:
	
	// get max. total duration of analog signal (limited by stop counter buffer)
	maxDuration_us = (VAL_FLOAT_MIN_us * CREATESEQ_deltaT_AO ()) * (GPCTR_MAX_COUNTS - 1) / 2;
   	if (s->transferOn) maxDuration_us /=  N_SESSION_TRANSFER_LEVELS;

	maxCopies = maxDuration_us / sequenceDuration_us;
	
	if (s->nCurves > maxCopies) {
		MessagePopupf ("Error", "Sequence too long!\n\n"
		  			   "The total duration of your sequence is %3.3f ms\n"
		  			   "(= %3.3f ms * %d curves per sweep point).\n\n"
					   "Maximally allowed duration due to hardware limitations is %3.3f ms.\n\n"
					   "You can at maximum have %d curves per sweep point.",
					   sequenceDuration_us / 1000.0 * s->nCurves,
					   sequenceDuration_us / 1000.0, s->nCurves,
					   maxDuration_us / 1000.0,
					   maxCopies);	
		return 1;
	}

	return 0;
}


//int CREATESEQ_displayError (const char formatStr)
int CREATESEQ_displayErrorf  (int showErrorMsg, const char *format, ...)
{
	char helpStr[500];
	
	va_list arg;

	va_start( arg, format );
    vsprintf(helpStr, format, arg  );
    va_end( arg );

	strcpy (CREATESEQ_errorStr, helpStr);
	SetWaitCursor (0);
	if (showErrorMsg) MessagePopup ("Error", helpStr);
	return -1;
}


char *CREATESEQ_getErrorStr (void)
{
	return CREATESEQ_errorStr;
}



void SEQUENCE_testDetectLoops (t_sequence *seq)
{
	t_outputData *o1, *o2;

	config = (t_config *) malloc (sizeof (t_config));
	CONFIG_init (config);
	 
	 config->nAnalogBoards = 1;

	 OUTPUTDATA_calculate (seq, 1);
	 o1 = seq->outData;
	 OUTPUTDATA_initOutputBuffers (o1);
	 OUTPUTDATA_writeDIOBytesToOutputBuffer (seq);
	 OUTPUTDATA_writeAOBytesToOutputBuffer (o1, 1);
	 seq->outData = NULL;
	 
	 SEQUENCE_detectLoops (seq, 100, 5, 0, 0);

	 OUTPUTDATA_calculate (seq, 1);
	 o2 = seq->outData;
	 OUTPUTDATA_initOutputBuffers (o2);
	 OUTPUTDATA_writeDIOBytesToOutputBuffer (seq);
	 OUTPUTDATA_writeAOBytesToOutputBuffer (o2, 1);

	 OUTPUTDATA_areOutBuffersIdentical (o1, o2);
}
	 
	 
	 
	 
	 
	 



int SESSIONMANAGER_createSequence (t_session *s, char *filename, int showErrMsg)
{
	t_digitalBlock *firstBlock, *lastBlock, *initBlock;
	t_sequence *seq;
	int i, c;
	t_atom *a;
	t_event *e;
//	t_waveform *waveformDet2 = NULL;
	char *errorMsg;
	double duration_us;
	int displayProgress;
	int progressDialog = 0;
	int nAtoms, atomCounter;
	int error;

	CREATESEQ_errorStr[0] = 0;
	if (!SESSIONMANAGER_createSequence_hasActiveAtoms (s)) {
		return CREATESEQ_displayErrorf (showErrMsg, "Session contains no atoms or none of\n"
							    					"the atoms is set to 'active'.");
	}
	
	// create new sequence
	if (TIMEINTERVAL_calculateAll (s, 1,0) != 0) {
		return CREATESEQ_displayErrorf (showErrMsg, "Could not generate sequence.\n\n"
					  "An error occured during the calculation\n"
					  "of the detection time intervals.");
	}

	duration_us = (s->curveEnd_us - s->curveStart_us);
	if ((s->transmitKillerCurves==TRANSMIT_KILLER_LECROY) && (duration_us > KILLER_MAX_DURATION_LECROY_us)) {
		return CREATESEQ_displayErrorf (showErrMsg, "Could not generate sequence (\"Killer\" waveform too long).\n\n"
					   "Curve duration of %2.1f �s exceeds maximum\n"
					   "waveform duration of LeCroy generator (%2.1f �s).\n",
					   duration_us , KILLER_MAX_DURATION_LECROY_us);
	}
	
	if ((s->transmitKillerCurves==TRANSMIT_KILLER_LECROY) && (duration_us > KILLER_MAX_DURATION_MI6021_us)) {
		return CREATESEQ_displayErrorf (showErrMsg, "Could not generate sequence (\"Killer\" waveform too long).\n\n"
					   "Curve duration of %2.1f �s exceeds maximum\n"
					   "waveform duration of MI6021 generator (%2.1f �s).\n",
					   duration_us, KILLER_MAX_DURATION_MI6021_us);
	}
	
	
	if (CREATESEQ_curveTooLong (s)) return -1;

	nAtoms = SESSION_nTotalAtoms (s);
	displayProgress = (nAtoms > MIN_ATOMS_DISPLAY_PROGRESS);
	if (displayProgress) progressDialog = 
			  CreateProgressDialog ("Compiling Sequence",
									"Creating event list...", 1,
									VAL_NO_MARKERS, "Cancel");

	// create new sequence
	EVENT_freeAll (s->lEvents);
	SEQUENCE_free (s->sequence);
	s->waveformDet2 = NULL;
	seq = SEQUENCE_new ();
	s->sequence = seq;
	SEQUENCE_init (seq);


	seq->remote = 1;
	ATOMS_calculateAllTimes (s);
	CREATESEQ_setNRepetitions (s);
	CREATESEQ_setTimebases (seq);
	
	
	// -------------------------------------
	//     display lecroy as AnalogChannel
	// -------------------------------------
	switch(s->transmitKillerCurves) {
		case TRANSMIT_KILLER_LECROY :
			s->FIRST_KILLER_CHANNEL = A_CH_GPIB_KILLER;
			for (i = 0; i < N_CAVITIES; i++) {
				seq->displayExternalAsAnalogChannel[s->FIRST_KILLER_CHANNEL+i] = 1;
				}
			break;
		case TRANSMIT_KILLER_MI6021 :
			s->FIRST_KILLER_CHANNEL = FIRST_EXTERNAL_AO_CHANNEL;
			for (i = 0; i < N_CAVITIES; i++) {
				seq->displayExternalAsAnalogChannel[s->FIRST_KILLER_CHANNEL+i] = 1;
				}
			break;
		default:
			s->FIRST_KILLER_CHANNEL = FIRST_EXTERNAL_AO_CHANNEL;
	}
	/*if (s->transmitKillerCurves) {
		for (i = 0; i < N_CAVITIES; i++) 
			seq->displayExternalAsAnalogChannel[A_CH_GPIB_KILLER+i] = 1;
	}*/

	// insert channel names and filename
	strcpy (seq->filename, filename);
	CREATESEQ_insertChannelNames (seq);

//	offs = CREATESEQ_calculateSmallestTime (s);

//	CREATESEQ_insertFakeAtomCounts (s, CH_COUNTER0, 500, 10);
	atomCounter = 0;
	ListPreAllocate (s->lEvents, 40 * nAtoms);
	ListSetAllocationPolicy (s->lEvents, 1000, 50);

	for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
		a = ATOM_ptr (s, i);
		if (a->active) {
//===================================================
//       trigger generation of counts
//===================================================
			// -------------------------------------------------
			//     TEST: trigger pulse generator
			// -------------------------------------------------
//			EVENTS_insertDIGPulse (s, i, CH_COUNTER1,
//								  a->time[POS_LASER1]+5,
//								  50, 
//								  "#%d trig.pulses", i);
			if (CREATESEQ_insertPulsesAtom (s->lEvents, s, i, 1, &atomCounter, nAtoms, progressDialog) != 0) {
				if (displayProgress) DiscardProgressDialog (progressDialog);
				return -1;
			}
			
		}			
	}
	
	switch (s->mode) {
		case SESSIONMODE_DIG:
			CREATESEQ_insertDIGSweep (s);
			seq->considerWatchdog = 0;
			break;
		case SESSIONMODE_STANDARD:
			
			break;
	}
//	displayPulseList (pulseList);

//===================================================
//       insert  absolute time reference
//===================================================
	a = ATOM_ptr (s, s->atomConfig->referenceAtom);
	if ((a != NULL) && (a->active)) {
		e = EVENTS_insertDIGPulse (s->lEvents, "", -1,
						  a->time[s->atomConfig->referenceAtomPosition],
						  0,
						  1,
						  "reference");
		e->isAbsoluteTimeReference = 1;
	}
	CREATESEQ_insertCounterGatePulses (s);
	UpdateProgressDialog (progressDialog, 100, 0);


//	EVENTS_calculateSmallestTime (s->lEvents, s);

	EVENTS_insertDIGPulse (s->lEvents, "", CH_TRIG_OSCILLOSCOPE,
						  s->curveStart_us, 
						  1.0,
						  1,
						  "trig. osc.");

	if (progressDialog) DiscardProgressDialog (progressDialog);
	
	if (CREATESEQ_createAllDigitalBlocksFromEventList (s, displayProgress) != 0) return -1;
	
	if (CREATESEQ_markAllChannels (s, showErrMsg, displayProgress) != 0) return -1;
	
	CREATESEQ_appendLastBlock (seq, s->curveEnd_us - s->curveStart_us);

	initBlock = CREATESEQ_insertInitBlock (s);

	CREATESEQ_setDetectionParameters (s);

//	DIGITALBLOCK_ptr (seq, 1)->isAbsoluteTimeReference = 0;
//	DIGITALBLOCK_ptr (seq, 2)->isAbsoluteTimeReference = 1;
	
	if (CREATESEQ_insertAOChannelSweeps (s) != 0) return -1;
	if (CREATESEQ_insertGPIBPowerSupplySweeps (s) != 0) return -1;
	if (CREATESEQ_insertGPIBSynthesizerSweeps (s) != 0) return -1;
	
// duplicate the sequence if transfer is measured	
	if ((s->mode != SESSIONMODE_DIG) && (s->transferOn)) CREATESEQ_duplicateSequence (s, initBlock);
	
// DEBUG: insert test pulse at channel D7
//	CREATESEQ_insertTestPulse (seq);
	
	
	CREATESEQ_insertChannels_alwaysOn (s);

// invert all channel with inverse logic
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		if (CREATESEQ_isChannelInverted (i)) CREATESEQ_invertChannel (seq, i);
	}		
	
// check if times are correct	
	if (displayProgress) progressDialog = 
			  CreateProgressDialog ("Compiling Sequence",
									"Checking for conflicts ...", 1,
									VAL_NO_MARKERS, "Cancel");
	error = EVENTS_checkTimesOfEvents (s, showErrMsg, &errorMsg, progressDialog);
	if (error != 0) {
		if (displayProgress) DiscardProgressDialog (progressDialog);
		return CREATESEQ_displayErrorf (0, errorMsg);
	}
	

	error = EVENTS_checkForConflicts (s, 1, showErrMsg, &errorMsg, progressDialog);
	if (displayProgress) DiscardProgressDialog (progressDialog);
	if (error != 0) {
		return CREATESEQ_displayErrorf (0, errorMsg);
	}
	
	seq->generateRandomCounterData = s->generateRandomCounterData;	

	
	if (displayProgress) progressDialog = CreateProgressDialog ("Compiling Sequence",
																"Compressing sequence data and preparing to start...", 1,
																VAL_NO_MARKERS, "");
	SEQUENCE_detectLoops (s->sequence, 20*ListNumItems (seq->lDigitalBlocks) / nAtoms,2, progressDialog, 0);

	if (displayProgress) DiscardProgressDialog (progressDialog);
	return 0;
	
}

 


int SESSIONMANAGER_executeRun (t_session *s)
{
	return 0;
}



int SESSIONMANAGER_transmitSequence (t_session *s)
{
	IniText ini;
	
	ini = Ini_New (0);
	
	if (Ini_PutSequence (ini, s->sequence) != 0) goto ERROR;
//	if (Ini_saveSequence (ini, s->sequence->filename) != 0) goto ERROR;
#ifndef EXPERIMENTCONTROL
	if (launchExperimentControl (1, 0) != 0) goto ERROR;
#endif
	if (TCP_clientIniTransmit (ini, TCP_CMD_SEQUENCE, 1) != 0) goto ERROR;
	Ini_saveSequence (ini, s->sequence->filename);

	Ini_Dispose (ini);
	return 0;
ERROR:
	Ini_Dispose (ini);
	return -1;
	
}








/*
double EVENTS_calculateSmallestTime (ListType listOfEvents, t_session *s)
{
	t_event *e;
//  	int smallestTime = INT_MAX;
	int i;

	int smallestTime = INT_MAX;
	int largestTime  = INT_MIN;
	
	if (ListNumItems(listOfEvents) == 0) {
		if (s) {
			s->smallestTime = 0;
			s->largestTime  = 0;
			s->dSmallestTime_us = 0.0;
			s->dLargestTime_us = 0.0;
		}
		return 0;
	}
	
	for (i = 1; i <= ListNumItems(listOfEvents); i++) {
		ListGetItem (listOfEvents, &e, i);
		if (!e->alwaysOn) {
			if (e->time < smallestTime) smallestTime = e->time;
			if (e->time+e->duration > largestTime) largestTime = e->time+e->duration;			
		}
	}


	if (s) {
		s->smallestTime = smallestTime;
		s->largestTime  = largestTime ;
		s->dSmallestTime_us = s->smallestTime / (1.0 * VAL_us);
		s->dLargestTime_us  = s->largestTime / (1.0 * VAL_us);
	}
	return smallestTime / (1.0 * VAL_us);
}
*/



int CVICALLBACK EVENTS_insertCompare (void *item1, void *item2)
{
	t_event *e1, *e2;
	
	e1 = *( (t_event **) item1);
	e2 = *( (t_event **) item2);
	
	if (e1->time < e2->time) return -1;
	if (e1->time > e2->time) return 1;
	if (e1->duration < e2->duration) return -1;
	if (e1->duration > e2->duration) return 1;
	if (e1->DIG_channel < e2->DIG_channel) return -1;
	if (e1->DIG_channel > e2->DIG_channel) return 1;
	if (e1->AO_channel < e2->AO_channel) return -1;
	if (e1->AO_channel > e2->AO_channel) return 1;
	if (e1->alwaysOn > e2->alwaysOn) return -1;
	if (e1->alwaysOn < e2->alwaysOn) return 1;
	return 0;
}


// add a new digital pulse to the list of events

t_event *EVENTS_insertDIGPulse (ListType lEvents, char* atomStr, int channel, 
						       double time_us, double duration_us, int putStrings,
						       const char *format, ...)
{
//	unsigned deltaT;
	t_event *e;
	char *helpStr;
	va_list arg;

	if (putStrings) {
		helpStr = getTmpString();
	
		va_start( arg, format );
	    vsprintf(helpStr, format, arg  );
	    va_end( arg );
	}

//	deltaT = get_timeUnits (s->sequence->DIO_timeBase) * s->sequence->DIO_patternInterval;

//	e = EVENT_new (s);
	e = (t_event *) malloc (sizeof (t_event));
	EVENT_init (e);
	
	e->time     = getIntTime (time_us);
	e->alwaysOn = (duration_us == ALWAYS_ON);
	e->duration = getIntTime (duration_us);
	if (putStrings) {
		strcpy(e->atomStr , atomStr);
		strncpy (e->name, helpStr, MAX_EVENTNAME_LEN);
	}
	e->DIG_channel  = channel;
	ListInsertInOrder (lEvents, &e, (void*) EVENTS_insertCompare);

	//	ListQuickSort (s->lEvents, (void*) EVENTS_insertCompare);

	
	return e;
}




t_event *EVENTS_insertAOPulse (ListType lEvents, char* atomStr, 
						  int AOchannel, 
						  int waveform, 
						  double constVoltage,
						  double time_us, 
						  double duration_us, 
						  const char *format, ...)
{
	int deltaT;
	unsigned sub;
	t_event *e;
	char *helpStr;
	va_list arg;

	helpStr = getTmpString();
	
	va_start( arg, format );
    vsprintf(helpStr, format, arg  );
    va_end( arg );

//	if (AOchannel == CH_D7) Breakpoint(); 
	if (AOchannel < N_DAC_CHANNELS) {
		deltaT = CREATESEQ_deltaT_AO ();
	}
	else {
		switch (AOchannel) {
			case A_CH_GPIB_KILLER:
			case A_CH_GPIB_KILLER+1:
				deltaT = TIMEBASE_LECROY_KILLER;
				break;
			default:
				deltaT = 1;
		}
	}
		

//    e = EVENT_new (s);
	e = (t_event *) malloc (sizeof (t_event));
	EVENT_init (e);

	strcpy(e->atomStr, atomStr);
	e->time = RoundRealToNearestInteger (time_us * VAL_us);
	sub = (e->time % deltaT);
	e->time -= sub;
	e->alwaysOn = (duration_us == ALWAYS_ON);
	e->duration = duration_us * VAL_us;
	sub = (e->duration % deltaT);
	e->duration -= sub;
	strncpy (e->name, helpStr, MAX_EVENTNAME_LEN);
	e->AO_channel = AOchannel;
	e->constVoltage = constVoltage;
	e->waveform   = waveform;
	ListInsertInOrder (lEvents, &e, (void*) EVENTS_insertCompare);
	
	return e;
}







enum {  
	EVENTS_COL_NR,
	EVENTS_COL_NAME,
	EVENTS_COL_ATOM,
	EVENTS_COL_TIME,
	EVENTS_COL_DURATION,
	EVENTS_COL_CHANNEL,
	EVENTS_COL_VOLTAGE_WFM,
	EVENTS_COL_CHANNEL_NAME,
	
	EVENTS_COL_CONFLICTS,
	
	N_EVENTS_COL
};




void EVENTS_insertTreeItem (int panel, int ctrl, t_session *s, int eventNr)
{
	char *help;
	int newItem;
	t_event *e;
	t_waveform *wfm;
	t_sequence *seq;

	e = EVENT_ptr (s, eventNr);
	if (e == NULL) return;
	help = getTmpString();
	seq = s->sequence;

	// -----------------------------
	//      display nr
	// -----------------------------
	sprintf (help, "  %d", eventNr);
	newItem = eventNr-1;
//	InsertTreeItem (panel, ctrl, VAL_SIBLING, 0,
//							  VAL_LAST, help, NULL, NULL, 0);
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_NR,
						  ATTR_LABEL_TEXT, help);
//	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_NAME,
//						  ATTR_LABEL_JUSTIFY,
//						  VAL_CENTER_LEFT_JUSTIFIED);
	
	// -----------------------------
	//      display name
	// -----------------------------
	sprintf (help, "  %s", e->name);
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_NAME,
						  ATTR_LABEL_TEXT, e->name);
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_NAME,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_LEFT_JUSTIFIED);
	// -----------------------------
	//      display atom number
	// -----------------------------
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_ATOM,
						  ATTR_LABEL_TEXT, e->atomStr);
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_ATOM,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	
	// -----------------------------
	//      display time
	// -----------------------------
	sprintf (help, "%03.1f", ((double) e->time) * 0.05);
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_TIME,
						  ATTR_LABEL_TEXT, help);
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_TIME,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display duration
	// -----------------------------
	sprintf (help, "%03.1f", ((double) e->duration) * 0.05);
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_DURATION,
						  ATTR_LABEL_TEXT, help);
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_DURATION,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display channel
	// -----------------------------
	if (e->DIG_channel >= 0) {
		SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CHANNEL,
							  ATTR_LABEL_TEXT, str_ChannelNames (e->DIG_channel));
	}
	else if (e->AO_channel >= 0) {
		SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CHANNEL,
							  ATTR_LABEL_TEXT, str_AnalogChannelNames (e->AO_channel));
	}
	else {  
		SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CHANNEL,
							  ATTR_LABEL_TEXT, "");
	}
	
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CHANNEL,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
						  
						  
	// -----------------------------
	//      display channel name
	// -----------------------------
	if (e->DIG_channel >= 0) {
		if ((seq != NULL) && (seq->DIO_channelNames[e->DIG_channel] != NULL)) {
			SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CHANNEL_NAME,
								  ATTR_LABEL_TEXT, seq->DIO_channelNames[e->DIG_channel]);
		}
	}
	else if (e->AO_channel >= 0) {
		if ((seq != NULL) && (seq->AO_channelNames[e->AO_channel] != NULL)) {
			SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CHANNEL_NAME,
								  ATTR_LABEL_TEXT, seq->AO_channelNames[e->AO_channel]);
			if (e->waveform != 0) {
				if (e->waveform == WFM_ID_CONSTVOLTAGE) {
					sprintf (help, "%1.3f V", e->constVoltage);
					SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_VOLTAGE_WFM,
										  ATTR_LABEL_TEXT, help );
				}				
				else  {
					wfm = WFM_ptr (seq, e->waveform);
					if (wfm!= NULL) SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_VOLTAGE_WFM,
											  ATTR_LABEL_TEXT, wfm->name);
				}
			}
		}
		
	}
	else {
		SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CHANNEL_NAME,
							  ATTR_LABEL_TEXT, "");
	}
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CHANNEL_NAME,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
/*
	// --------------------------------------
	//      display waveform (as child item)
	// --------------------------------------
	if (e->AO_channel >= 0) {
		wfm = WFM_ptr(seq, e->waveform);
		if (wfm != NULL) {
			sprintf (help, "waveform = %d (%s)", e->waveform, wfm->name);
			InsertTreeItem (panel, ctrl, VAL_CHILD, newItem,
					    VAL_LAST, help, NULL, NULL, 0);
		}
	}
*/	
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CONFLICTS,
						  ATTR_LABEL_TEXT, e->conflicts ? e->conflicts : "");
	SetTreeCellAttribute (panel, ctrl, newItem, EVENTS_COL_CONFLICTS,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panel, ctrl, newItem,
						  EVENTS_COL_CONFLICTS, ATTR_LABEL_COLOR,
						  VAL_RED);
}



void EVENTS_resizePanel (int panel)
{
	int height, width;
	
	height = panelHeight (panel);
	width = panelWidth (panel);
	if (width < 100) width = 100;
	if (height < 100) height = 100;
	SetPanelSize (panel, height, width);
	
	SetCtrlAttribute (panel, EVENTS_TREE, ATTR_HEIGHT,
					  height - ctrlHeight (panel, EVENTS_COMMANDBUTTON_Done) - 20);
	SetCtrlAttribute (panel, EVENTS_TREE, ATTR_WIDTH, width);
	
	SetCtrlAttribute (panel, EVENTS_COMMANDBUTTON_Done, ATTR_TOP,
					  ctrlBottom(panel, EVENTS_TREE)+10);
	SetCtrlAttribute (panel, EVENTS_COMMANDBUTTON_Update, ATTR_TOP,
					  ctrlBottom(panel, EVENTS_TREE)+10);
	
	SetCtrlAttribute (panel, EVENTS_COMMANDBUTTON_Done, ATTR_LEFT,
					  width - ctrlWidth (panel, EVENTS_COMMANDBUTTON_Done)- 10);
	
	SetCtrlAttribute (panel, EVENTS_COMMANDBUTTON_Update, ATTR_LEFT,
					  ctrlLeft (panel, EVENTS_COMMANDBUTTON_Done)
					  - ctrlWidth (panel, EVENTS_COMMANDBUTTON_Update) - 10 );
}




/* To perform the comparison you can, if you chose, 
  obtain the labels of the two cells using 
  GetTreeCellAttribute and ATTR_LABEL_TEXT, 
  or of any other cells you chose to use as secondary 
  sort keys. 
  Return -1 if item1 is less than item2, 1 
  if item1 is greater than item2, and 0 
  if item1 and item2 are equivalent.
*/


int CVICALLBACK compareTxtDouble (int panelHandle, int controlID, 
	int item1, int item2, void *callbackData)
{
	char str1[30], str2[30];
	int column;
	double d1, d2;
	
	column = (int)callbackData;
	d1 = 0.0;
	d2 = 0.0;
	str1[0] = 0;
	str2[0] = 0;
	GetTreeCellAttribute (panelHandle, controlID, item1, column,
						  ATTR_LABEL_TEXT, str1);
	GetTreeCellAttribute (panelHandle, controlID, item2, column,
						  ATTR_LABEL_TEXT, str2);
	d1 = strtod (str1, NULL);
	d2 = strtod (str2, NULL);
	if (d1 < d2) return -1;
	if (d1 > d2) return 1;
	return 0;
}


int CVICALLBACK compareTxt (int panelHandle, int controlID, 
	int item1, int item2, void *callbackData)
{
	char str1[30], str2[30];
	int result;
	
	str1[0] = 0;
	str2[0] = 0;
	GetTreeCellAttribute (panelHandle, controlID, item1, (int)callbackData,
						  ATTR_LABEL_TEXT, str1);
	GetTreeCellAttribute (panelHandle, controlID, item2, (int)callbackData,
						  ATTR_LABEL_TEXT, str2);
	result = strcmp (str1, str2);	
	if (result != 0) return result;
	return compareTxtDouble (panelHandle, controlID, item1, item2, (void*)EVENTS_COL_TIME);
}



void EVENTS_initTree (int panel, int ctrl)
{
	int i;
	int nColumns;
	
	GetNumTreeColumns (panel, ctrl, &nColumns);
	for (i = 0; i < nColumns-1; i++) {
		DeleteTreeColumn (panel, ctrl, -1);
	}
	
	// create new tree columns
	SetCtrlAttribute (panel, ctrl,
					  ATTR_COLUMN_LABELS_VISIBLE, 1);
	for (i = 1; i < N_EVENTS_COL; i++) 
		InsertTreeColumn (panel, ctrl, -1, "");

	// set attributes for columns
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_NR,
							ATTR_COLUMN_WIDTH, 30);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_NR, 
							ATTR_LABEL_TEXT, "nr.");

	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_NAME,
							ATTR_COLUMN_WIDTH, 150);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_NAME, 
							ATTR_LABEL_TEXT, "name");

	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_ATOM,
							ATTR_COLUMN_WIDTH, 70);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_ATOM, 
							ATTR_LABEL_TEXT, "atom");

	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_TIME,
							ATTR_COLUMN_WIDTH, 90);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_TIME,
							ATTR_LABEL_JUSTIFY,
							VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_TIME, 
							ATTR_LABEL_TEXT, "time [�s]");

	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_DURATION,
							ATTR_COLUMN_WIDTH, 90);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_DURATION, 
							ATTR_LABEL_TEXT, "duration [�s]");

	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_CHANNEL,
							ATTR_COLUMN_WIDTH, 60);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_CHANNEL, 
							ATTR_LABEL_TEXT, "channel");

	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_VOLTAGE_WFM,
							ATTR_COLUMN_WIDTH, 60);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_VOLTAGE_WFM, 
							ATTR_LABEL_TEXT, "voltage/wfm");

	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_CHANNEL_NAME,
							ATTR_COLUMN_WIDTH, 100);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_CHANNEL_NAME, 
							ATTR_LABEL_TEXT, "channel name");
	
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_CONFLICTS,
							ATTR_COLUMN_WIDTH, 180);
	SetTreeColumnAttribute (panel, ctrl, EVENTS_COL_CONFLICTS, 
							ATTR_LABEL_TEXT, "conflicts");
}

void EVENTS_displayPanel (t_session *s) 
{
	int i;
	
	if (panelEvents == -1) {
		panelEvents = LoadPanel (0, SESSIONMANAGER_uirFile, EVENTS);
		if (panelEvents <= 0) return;
		EVENTS_initTree (panelEvents, EVENTS_TREE);
	}
	
	setNumTreeItems(panelEvents, EVENTS_TREE, ListNumItems (s->lEvents));
//	DeleteListItem (panelEvents, EVENTS_TREE, 0, -1);

	// insert events
	for (i = 1; i <= ListNumItems (s->lEvents); i++) {
		EVENTS_insertTreeItem (panelEvents, EVENTS_TREE, s, i);
	}
		
//	SortTreeItems (panelEvents, EVENTS_TREE, 0, EVENTS_COL_TIME, 0, 0,
//				   (void*)compareTxtDouble, (void*)EVENTS_COL_TIME);
		
	EVENTS_resizePanel (panelEvents);
	DisplayPanel (panelEvents);
}



int CVICALLBACK EVENT_done (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			HidePanel (panelEvents);
			break;
	}
	return 0;
}


int CVICALLBACK EVENT_panelCallback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_GOT_FOCUS:
			break;
		case EVENT_LOST_FOCUS:
			break;
		case EVENT_CLOSE:
			break;
		case EVENT_PANEL_SIZE:
			EVENTS_resizePanel (panel);
			break;
	}
	return 0;
}





int CVICALLBACK EVENTS_treeClicked (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	static int sortOrder = 1;
	static int lastColumn = -1;
	int column;
	int area;
	
//	DebugPrintf ("%s\n", eventStr (event, eventData1, eventData2));
	switch (event) {
		case EVENT_COMMIT:
			
			break;
		case EVENT_LEFT_CLICK:
            GetIndexFromPoint (panel, control,
                               MakePoint (eventData2, eventData1), NULL, &area, &column);
            if (VAL_COLUMN_LABEL_AREA == area) {
				if (column == lastColumn) sortOrder= !sortOrder;
				lastColumn = column;
				switch (column) {
					case EVENTS_COL_NR:
					case EVENTS_COL_TIME:
					case EVENTS_COL_DURATION:
						SortTreeItems (panel, control, 0, column, sortOrder, 0,
									   (void*)compareTxtDouble, (void*)column);
						break;
					default:
						SortTreeItems (panel, control, 0, column, sortOrder, 0,
									   (void*)compareTxt, (void*)column);
				}
			}
			break;
	}
	return 0;
}



int EVENTS_checkForConflicts (t_session *s, int putStrings,  int showError, char **errorStr, int progressDialog)
{
	t_event *e1, *e2;
	int i;
	char *help;
	int nConflicts;
	int firstCall;
	char *error = NULL;
	int n;

	help = getTmpString();
	if (errorStr != NULL) *errorStr = "";
	e1 = EVENT_ptr (s, 1);
	nConflicts = 0;
	n = ListNumItems (s->lEvents);
	for (i = 2; i <= n; i++) {
		ListGetItem (s->lEvents, &e2, i);
		if ((e1->AO_channel == e2->AO_channel) 
		    && (e1->DIG_channel == e2->DIG_channel) 
		    && (e2->time >= e1->time) 
		    && (e2->time <= e1->time+e1->duration)
		    && (e1->duration != 0)
		    && (e2->duration != 0)) {
			// conflict
			if (putStrings) {
				if (e1->conflicts == NULL) sprintf (help, "overlaps with event nr %d", i);
				else sprintf (help, "%s, %d", e1->conflicts, i);
				e1->conflicts = strnewcopy (e1->conflicts, help);
				if (e2->conflicts == NULL) sprintf (help, "overlaps with event nr %d", i-1);
				else sprintf (help, "%s, %d", e1->conflicts, i-1);
				e2->conflicts = strnewcopy (e2->conflicts, help);
			}
			if (error == NULL) {
				error = getTmpString();
				sprintf (error, "Could not generate sequence.\n\nEvent '%s' overlaps with event '%s'.", e1->name, e2->name);
				if (errorStr != NULL) *errorStr = error;
			}
			nConflicts++;
			if (nConflicts > MAX_CONFLICTS_IN_EVENT_LIST) i = n;
		}
		e1 = e2;
		if (progressDialog && (i % 100 == 0)) {
			if (UpdateProgressDialog (progressDialog, 50+50 * i / n, 1)) return -1;
		}
	}

	if (showError && (nConflicts > 0)) {
		switch (GenericMessagePopup ("Error", error, "Show all events", "Abort",
									 "", 0, 0, 0, VAL_GENERIC_POPUP_BTN1,
									 VAL_GENERIC_POPUP_BTN1,
									 VAL_GENERIC_POPUP_BTN2)) {
			case VAL_GENERIC_POPUP_BTN1:
				EVENTS_displayPanel (s); 
				break;
		}
	}
	
	return (nConflicts > 0) ? -1 : 0;
	
	
}




int EVENTS_checkTimesOfEvents (t_session *s, int showError, char **errorMsg, int progressDialog)
{
	
	t_event *e;
	t_event *errEvent = NULL;
	char *errStr, *help;
	int i;
	int maxTime, minTime;
	int time, duration;
	int n;
	int errorVariablePulse = 0;
	int nConflicts;

	errStr = getTmpString();
	if (errorMsg != NULL) *errorMsg = "";
	maxTime = RoundRealToNearestInteger (s->curveEnd_us * VAL_us) + DURATION_GATE_PULSE;
	minTime = RoundRealToNearestInteger (s->curveStart_us * VAL_us);
	n = ListNumItems(s->lEvents);

	nConflicts = 0;
	for (i = 1; i <= n; i++) {
		ListGetItem (s->lEvents, &e, i);
		if (!e->alwaysOn) {
			time = e->time  + e->duration;
			if ((time > maxTime) || (e->time < minTime)) {
				errStr[0] = 0;
				if (e->conflicts != 0) sprintf (errStr, "%s, ", e->conflicts);
				strcat (errStr, "time exceeds cuvre duration");
				e->conflicts = strnewcopy (e->conflicts, errStr);
				if (errEvent == NULL) errEvent = e;
				nConflicts ++;
				if (nConflicts > MAX_CONFLICTS_IN_EVENT_LIST) i = n;
			}
			else {
				// check if variable pulse exceeds duration
				time     = e->time     + (s->nSweepPoints-1) * e->timeIncrement;
				duration = e->duration + (s->nSweepPoints-1) * e->durationIncrement;
				if (duration < 0) duration = 0;
				if ((time+duration > maxTime) || (time < minTime)) {
					errStr[0] = 0;
					if (e->conflicts != 0) sprintf (errStr, "%s, ", e->conflicts);
					strcat (errStr, "variable pulse exceeds cuvre duration");
					e->conflicts = strnewcopy (e->conflicts, errStr);
					if (errEvent == NULL) {
						errEvent = e;
						errorVariablePulse = 1;
					}
					if (nConflicts > MAX_CONFLICTS_IN_EVENT_LIST) i = n;
				}
				
			}
		}			
		if (progressDialog && (i % 100 == 0)) {
			if (UpdateProgressDialog (progressDialog, 50 * i / n, 1)) return -1;
		}
	}	
	if (errEvent) {
		help = getTmpString();
		if (errorVariablePulse) strcpy (help, "Variable pulse exceeds curve duration.");
		else sprintf (help, "Time of event '%s' exceeds curve duration.\n\n"
					   "Event time is from %2.1f �s to %2.1f �s.\nCurve duration is from %2.1f �s to %2.1f �s.\n",
						errEvent->name,
						((double) (errEvent->time)) * 0.05,		
						((double) (errEvent->time + errEvent->duration)) * 0.05,
						s->curveStart_us,
						s->curveEnd_us);	
		if (errorMsg != NULL) *errorMsg = help;
		if (showError) {
			switch (GenericMessagePopup ("Error", help, "Show all events", "Abort",
										 "", 0, 0, 0, VAL_GENERIC_POPUP_BTN1,
										 VAL_GENERIC_POPUP_BTN1,
										 VAL_GENERIC_POPUP_BTN2)) {
				case VAL_GENERIC_POPUP_BTN1:
					EVENTS_displayPanel (s); 
					break;
			}
		}
		return -1;
				
	}

	return 0;
}




int CVICALLBACK EVENTS_callback_update (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			MENU_displayEvents (0, 0, 0, 0);
			break;
	}
	return 0;
}



void DEBUG_printDigitalBlocks (t_sequence *seq)
{
	int i;
	t_digitalBlock *b;
	
	printf ("\n");
	for (i = 1; i <= ListNumItems (seq->lDigitalBlocks); i++) {
		b = DIGITALBLOCK_ptr (seq, i);
		printf ("%02d: t=%8d %s\n", i, b->duration, b->blockName);
	}
}


	
