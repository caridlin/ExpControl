#include <ansi_c.h>
#include <utility.h>
#include <userint.h>
#include "UIR_SessionManager.h"

#include "regs.h"
#include "spcerr.h"
#include "tools.h"
//#include "INCLUDES_SESSIONMANAGER.h"
//#include "GPIB_DRIVER_LeCroy.h"

#define MI6021_MAX_VOLTAGE 3.0
#define MI6021_MAX_DIGITAL 8192 
#define MI6021_MIN_DIGITAL -8191 
#define MI6021_OFFSET      0.0


//************************************************************************************************* 
//  			STRUCT _BOARD_INFO											       *****
//********************************************************************************************************************** 

#define LOAD_DLL					1
#define UNLOAD_DLL  				0
#define MAX_BRDS    				32 

struct _BOARD_INFO
{
	int hDrv;
	int lBoardType;
	int lSerialNumber;
	int lMaxMemsize;
	int lMaxSamplerate;
	int lMaxFrequency;
	int lMaxChannels;
	int lMod;
	int lChPerMod;
	int lChEnable;
	int lBytesPerSample;
};


// ----- define the Spectrum driver functions -----
typedef short (SPCINITPCIBOARDS) (short* pnCount, short* pnPCIVersion);
typedef short (SPCINITBOARD)     (short nNr, short nTyp);
typedef short (SPCSETPARAM)      (short nNr, int lReg, int lValue);
typedef short (SPCGETPARAM)      (short nNr, int lReg, int* plValue);
typedef short (SPCSETDATA)       (short nNr, short nCh, int lStart, int lLen, void* pvData);
typedef short (SPCGETDATA)       (short nNr, short nCh, int lStart, int lLen, void* pvData);

// ----- global function adresses to acess the Spectrum driver -----
SPCINITPCIBOARDS* SpcInitPCIBoards;
SPCINITBOARD*     SpcInitBoard;
SPCSETPARAM*      SpcSetParam;
SPCGETPARAM*      SpcGetParam;
SPCSETDATA*       SpcSetData;
SPCGETDATA*       SpcGetData;



static struct _BOARD_INFO stBoardInfo;


//**********************************************************************************************************************
//***** FunctionCall : lLinkSpectrumDrv (lDrvCmd, lDrvId)											   			   *****														
//*****																											   *****
//***** ReturnCode   : lDriverID : spectrum.lib loaded 															   *****
//*****						  -1 : spectrum.lib not found														   *****
//*****						  -2 : 
//*****				   		   0 : spectrum.lib unloaded 								 			               *****
//*****																										       *****
//***** Description  : This function loads or unloads the driver functions from the spectrum.lib.			   	   *****
//*****				   To load the spectrum.lib set lDrvCmd to LOAD_DLL. The second parameter is don�t care.	   *****
//*****				   If the spectrum.lib could be loaded, the function returns the driver id, otherwise the      *****
//*****				   return value is -1.																		   *****
//*****				   To unload the spectrum.lib set lDrvCmd to UNLOAD_DLL and lDrvId to the driver id		       *****
//*****				   of the spectrum.lib.															  			   *****
//**********************************************************************************************************************

int lLinkSpectrumDrv (int lDrvCmd, int lDrvId)
{
	int lDriverId, lStatus;


	switch (lDrvCmd)
	{
		case LOAD_DLL   : // ----- load the driver entries from the DLL -----
						  lDriverId = LoadExternalModule ("spectrum.lib");
//						  lDriverId = LoadExternalModule ("..\\c_header\\spectrum.lib");
						  if (lDriverId < 0)
							  return -1;	// spectrum.lib not found 
							
						  // ----- Load functions from DLL -----
						  SpcInitPCIBoards = (SPCINITPCIBOARDS*) GetExternalModuleAddr (lDriverId, "SpcInitPCIBoards", &lStatus);
						  if (SpcInitPCIBoards == NULL) return -2;	

						  SpcInitBoard =     (SPCINITBOARD*)     GetExternalModuleAddr (lDriverId, "SpcInitBoard", &lStatus);
						  if (SpcInitPCIBoards == NULL) return -2;	
						  	
						  SpcSetParam =      (SPCSETPARAM*)      GetExternalModuleAddr (lDriverId, "SpcSetParam", &lStatus);
						  if (SpcInitPCIBoards == NULL) return -2;	
						  	
						  SpcGetParam =      (SPCGETPARAM*)      GetExternalModuleAddr (lDriverId, "SpcGetParam", &lStatus);
						  if (SpcInitPCIBoards == NULL) return -2;	
						  	
						  SpcSetData =       (SPCSETDATA*)       GetExternalModuleAddr (lDriverId, "SpcSetData", &lStatus);
						  if (SpcInitPCIBoards == NULL) return -2;	
						  	
						  SpcGetData =       (SPCGETDATA*)       GetExternalModuleAddr (lDriverId, "SpcGetData", &lStatus);
						  if (SpcInitPCIBoards == NULL) return -2;	
						  	
						  return lDriverId;
						  
						  break;
						
		case UNLOAD_DLL : // ----- free the driver dll -----
						  UnloadExternalModule (lDrvId);
						  
						  break;
	}
	
	return 0;
} 


//**********************************************************************************************************************
//***** FunctionCall : stInitBoard (hDrv)																		   *****
//*****																									   		   *****
//***** ReturnCode	 : stBoardInfo		 																		   *****
//*****																											   *****
//***** Description  : This function fills and returns the struct stBoardInfo with all information about the   	   *****
//*****				   board with the handle hDrv.													   			   *****
//**********************************************************************************************************************

struct _BOARD_INFO stInitBoard (int hDrv)
{	  
	stBoardInfo.hDrv = hDrv;
	
	SpcGetParam (hDrv, SPC_PCITYP, 		      &stBoardInfo.lBoardType);
	SpcGetParam (hDrv, SPC_PCISERIALNO,    &stBoardInfo.lSerialNumber);
	SpcGetParam (hDrv, SPC_PCIMEMSIZE, 	     &stBoardInfo.lMaxMemsize);
	SpcGetParam (hDrv, SPC_PCISAMPLERATE, &stBoardInfo.lMaxSamplerate);
	
	switch (stBoardInfo.lBoardType)
	{
		// ----- 60er boards -----
		case TYP_MI6030:
		case TYP_MC6030:
		case TYP_MX6030:
			 	stBoardInfo.lMaxChannels 	= 		 1; // number of channels
				stBoardInfo.lMod			= 		 1; // number of modules
				stBoardInfo.lChPerMod		= 		 1; // number of channels per modul
				stBoardInfo.lBytesPerSample = 		 2; // 14 bit board
				stBoardInfo.lChEnable       = 		 1; //  1 channel enable (0001)
				stBoardInfo.lMaxFrequency   = 10000000; // max. frequency 10 MHz 
				break;
		
		case TYP_MI6011:
		case TYP_MC6011:
		case TYP_MX6011:
				stBoardInfo.lMaxChannels	= 		2; // number of channels
				stBoardInfo.lMod			= 		1; // number of modules
				stBoardInfo.lChPerMod		= 		2; // number of channels per modul
				stBoardInfo.lBytesPerSample = 		2; // 14 bit board
				stBoardInfo.lChEnable       = 		3; //  2 channels enable (0011)
				stBoardInfo.lMaxFrequency   = 1500000; // max. frequency 1.5 MHz  
				break;
		
		case TYP_MI6021:
		case TYP_MI6033:
		
		case TYP_MC6021:
		case TYP_MC6033:
		
		case TYP_MX6021:
		case TYP_MX6033:
				stBoardInfo.lMaxChannels	= 		2; // number of channels
				stBoardInfo.lMod			= 		1; // number of modules
				stBoardInfo.lChPerMod		= 		2; // number of channels per modul
				stBoardInfo.lBytesPerSample = 		2; // 14 bit board
				stBoardInfo.lChEnable       = 		3; //  2 channels enable (0011)
				stBoardInfo.lMaxFrequency   = 5000000; // max. frequency 5 MHz 
				break;
			
		case TYP_MI6031:
		case TYP_MC6031:
				stBoardInfo.lMaxChannels	= 		 2; // number of channels
				stBoardInfo.lMod			= 		 2; // number of modules
				stBoardInfo.lChPerMod		= 		 1; // number of channels per modul
				stBoardInfo.lBytesPerSample = 		 2; // 14 bit board
				stBoardInfo.lChEnable       = 		 3; //  2 channels enable (0011)
				stBoardInfo.lMaxFrequency   = 10000000; // max. frequency 10 MHz 
				break;
		
		case TYP_MI6012:
		case TYP_MC6012:
				stBoardInfo.lMaxChannels	=  		4; // number of channels
				stBoardInfo.lMod			=  		2; // number of modules
				stBoardInfo.lChPerMod		=  	    2; // number of channels per modul
				stBoardInfo.lBytesPerSample = 	    2; // 14 bit board
				stBoardInfo.lChEnable       = 	   15; //  4 channels enable (1111)
				stBoardInfo.lMaxFrequency   = 1500000; // max. frequency 1.5 MHz 
				break;
				
		case TYP_MI6022:
		case TYP_MI6034:
		
		case TYP_MC6022:
		case TYP_MC6034:
				stBoardInfo.lMaxChannels	=  		4; // number of channels
				stBoardInfo.lMod			=  		2; // number of modules
				stBoardInfo.lChPerMod		=  		2; // number of channels per modul
				stBoardInfo.lBytesPerSample =  		2; // 14 bit board
				stBoardInfo.lChEnable       = 	   15; //  4 channels enable (1111)
				stBoardInfo.lMaxFrequency   = 5000000; // max. frequency 5 MHz
				break;
		
	
		// -----61er boards -----
		case TYP_MI6110:
		case TYP_MC6110:
		case TYP_MX6110:
				stBoardInfo.lMaxChannels	= 		 2; // number of channels
				stBoardInfo.lMod			= 		 1; // number of modules
				stBoardInfo.lChPerMod		= 		 2; // number of channels per modul
				stBoardInfo.lBytesPerSample = 		 1; // 8 bit board
				stBoardInfo.lChEnable       = 		 3; // 2 channels enable (0011) 
				stBoardInfo.lMaxFrequency   = 10000000; // max. frequency 10 MHz 
				break;
			
		case TYP_MI6111:
		case TYP_MC6111:
				stBoardInfo.lMaxChannels	=  		 4; // number of channels
				stBoardInfo.lMod			=  		 2; // number of modules
				stBoardInfo.lChPerMod		=  		 2; // number of channels per modul
				stBoardInfo.lBytesPerSample =  	     1; // 8 bit board
				stBoardInfo.lChEnable       = 		15; // 4 channels enable (1111)
				stBoardInfo.lMaxFrequency   = 10000000; // max. frequency 10 MHz 
				break;
		
	}
	
	// ----- get max samplerate, if all channels are enabled -----
	SpcSetParam (hDrv, SPC_CHENABLE,    stBoardInfo.lChEnable);
	SpcSetParam (hDrv, SPC_SAMPLERATE,  stBoardInfo.lMaxSamplerate); 
	SpcGetParam (hDrv, SPC_SAMPLERATE, &stBoardInfo.lMaxSamplerate); 
	
	return stBoardInfo;
}


//**********************************************************************************************************************
//***** FunctionCall : lSearch4Boards (lMI6X_BrdType, lMI6X_SN, lMI6X_hDrv) 									   *****
//*****												  													   		   *****
//***** ReturnCode   : lMI6XFound						   			   											   *****
//*****																											   *****
//***** Description  : This function seeks for all spectrum boards in the system. If a MI60xx or a MI61xx          *****
//*****				   board is found, the board type, serial number and handle will be stored in the		       *****
//*****				   corresponding refered address. The return value is the number of the counted MI60xx 		   *****
//*****				   and MI61xx boards.																		   *****
//**********************************************************************************************************************

int lSearch4Boards(int lMI6X_BrdType[], int lMI6X_SN[], int lMI6X_hDrv[])
{
	short nCount, nVersion;
	int lBrdType[MAX_BRDS];
	int lSN[MAX_BRDS];
	int lMI6XFound = 0;
	int i;
	
	// ----- get number of spectrum boards in the system -----
	SpcInitPCIBoards (&nCount, &nVersion);
	
	for(i=0;(i < MAX_BRDS) && (i < nCount);i++)
	{
		SpcGetParam(i, SPC_PCITYP, &lBrdType[i]); 
		SpcGetParam(i, SPC_PCISERIALNR, &lSN[i]);
		
		if (((lBrdType[i] & 0xffff) > 0x6000) && ((lBrdType[i] & 0xffff) < 0x6200))
		{
			// ----- found MI60xx or MI61xx board -----
			lMI6X_BrdType[lMI6XFound] = lBrdType[i]; // store board type 
			lMI6X_SN[lMI6XFound]      = lSN[i];		 // store serial number
			lMI6X_hDrv[lMI6XFound]    = i;			 // store handle
			lMI6XFound++;							 // increase the number of founded MI60xx or MI61xx boards
		}
	}
	
	return lMI6XFound;
}



//**********************************************************************************************************************
//***** FunctionCall : lGetBoardHandle (&hDrv) 														 			   *****
//*****																											   *****
//*****	ReturnCode   : 0 : board not found 																	       *****
//*****				   1 : board found 																		       *****
//*****																											   *****
//***** Description	 : This function seeks for a MI60xx or MI61xx board and writes the handle to the refered	   *****
//*****				   address of hDrv.																			   *****
//**********************************************************************************************************************

int lGetBoardHandle (int *hDrv)
{
	int lBrdType[MAX_BRDS];
	int lSN[MAX_BRDS];
	int lDrv[MAX_BRDS];
	int lBrdCount;
	char szTmp[100];   
	int i;
	
	// ----- seek for spectrum boards and store information of all founded MI60xx and MI61xx boards -----
	lBrdCount = lSearch4Boards (lBrdType, lSN, lDrv);  
	
	switch (lBrdCount)
	{
		case 0  : // ----- no 60xx or 61xx board found -----
				  return 0;
				
				  break;
				  
		case 1  : // ----- one board found ----- 
				  *hDrv = lDrv[0]; 
				  return 1;
		
				  break;
				  
		default : // ----- more than one board found -----
		
/*				  // ----- display all founded MI60xx and MI61xx boards, user has to select the board to use -----
				  DisplayPanel (brd_selectHandle); 
				  for(i=0;i<lBrdCount;i++)
				  {
				  	switch (lBrdType[i] & TYP_SERIESMASK)
				  	{
				  	case TYP_MISERIES: 
				  		sprintf(szTmp, "MI.%X                SN:%05ld", lBrdType[i] & TYP_VERSIONMASK, lSN[i]);
				  		break;
				  		
				  	case TYP_MXSERIES:                                                                            				  		
				  		sprintf(szTmp, "MX.%X                SN:%05ld", lBrdType[i] & TYP_VERSIONMASK, lSN[i]);     				  		
				  		break;                                                                                    				  		

				  	case TYP_MCSERIES:                                                                            				  		
				  		sprintf(szTmp, "MC.%X                SN:%05ld", lBrdType[i] & TYP_VERSIONMASK, lSN[i]);     				  		
				  		break;                                                                                    				  		
				  	}
				 	InsertListItem (brd_selectHandle, BRD_SELECT_BOARDLIST, -1, szTmp,0); 	 
				  }
				  
				  // ----- poll until board is selected -----
				  while (lHandleIndex == -1)
				  {
				  	ProcessSystemEvents();
				  }
				  
				  *hDrv = lDrv[lHandleIndex];
				  HidePanel (brd_selectHandle);
*/				  
				  return 1;
				  
				  break;
	}
	
	return 0;
}		



char *DRIVER_MI6021_errorStr (int errorCode) 
{
	switch (errorCode) {
		case ERR_OK				 : return "";
		case ERR_INIT            : return "Initialisation error";
		case ERR_NR              : return "Board number out of range";
		case ERR_TYP             : return "Unknown board Typ";
		case ERR_FNCNOTSUPPORTED : return "This function is not supported by the hardware";
		case ERR_BRDREMAP        : return "The Board Index Remap table is wrong";
		case ERR_KERNELVERSION   : return "The kernel version and the dll version are mismatching";
		case ERR_HWDRVVERSION    : return "The driver version doesn't match the minimum requirements of the board";
		case ERR_ADRRANGE        : return "The address range is disabled (fatal error)";
		case ERR_INVALIDHANDLE   : return "Handle not valid";
		case ERR_BOARDNOTFOUND   : return "Card mit given name hasn't been found";
		case ERR_LASTERR         : return "Old Error waiting to be read";
		case ERR_ABORT           : return "Abort of wait function";
		case ERR_BOARDLOCKED     : return "Board acess already locked by another process. it's not possible to acess one board through multiple processes";
   					 
		case ERR_REG             : return "unknown Register for this Board";
		case ERR_VALUE           : return "Not a possible value in this state";
		case ERR_FEATURE         : return "Feature of the board not installed";
		case ERR_SEQUENCE        : return "Channel sequence not allowed";
		case ERR_READABORT       : return "Read not allowed after abort";
		case ERR_NOACCESS        : return "Access to this register denied";
		case ERR_POWERDOWN       : return "not allowed in Powerdown mode";
		case ERR_TIMEOUT         : return "timeout occured while waiting for interrupt";
		case ERR_CALLTYPE        : return "call type (int32 mux) is not allowed for this register";
		case ERR_EXCEEDSINT32    : return "return value is int32 but software register exceeds the 32 bit integer range -> use 2x32 or 64";
		case ERR_NOWRITEALLOWED  : return "register cannot be written, read only";
		case ERR_SETUP           : return "the setup isn't valid";
		case ERR_CHANNEL         : return "Wrong number of Channel to be read out";
		case ERR_NOTIFYSIZE      : return "Notify block size isn't valid";
		case ERR_RUNNING         : return "Board is running, changes not allowed";
		case ERR_ADJUST          : return "Auto Adjust has an error";
		case ERR_PRETRIGGERLEN   : return "pretrigger length exceeds allowed values";
		case ERR_DIRMISMATCH     : return "direction of card and memory transfer mismatch";
		case ERR_POSTEXCDSEGMENT : return "posttrigger exceeds segment size in multiple recording mode";
		case ERR_SEGMENTINMEM    : return "memsize is not a multiple of segmentsize, last segment hasn't full length";
		case ERR_MULTIPLEPW      : return "multiple pulsewidth counters used but card only supports one at the time";
		case ERR_NOCHANNELPWOR   : return "channel pulsewidth can't be OR'd";
						  
		case ERR_NOPCI           : return "No PCI bus found";
		case ERR_PCIVERSION      : return "Wrong PCI bus version";
		case ERR_PCINOBOARDS     : return "No Spectrum PCI boards found";
		case ERR_PCICHECKSUM     : return "Checksum error on PCI board";
		case ERR_DMALOCKED       : return "DMA buffer in use, try later";
		case ERR_MEMALLOC        : return "Memory Allocation error";
		case ERR_EEPROMLOAD      : return "EEProm load error, timeout occured";
		case ERR_CARDNOSUPPORT   : return "no support for that card in the library";
						 
		case ERR_FIFOBUFOVERRUN  : return "Buffer overrun in FIFO mode";
		case ERR_FIFOHWOVERRUN   : return "Hardware buffer overrun in FIFO mode";
		case ERR_FIFOFINISHED    : return "FIFO transfer hs been finished. Number of buffers has been transferred";
		case ERR_FIFOSETUP       : return "FIFO setup not possible, transfer rate to high (max 250 MB/s)";

		case ERR_TIMESTAMP_SYNC  : return "Synchronisation to ref clock failed";
		case ERR_STARHUB         : return "Autorouting of Starhub failed";
	
		case ERR_INTERNAL_ERROR  : return "Internal hardware error detected, please check for update";
		default: return "";
	}
}

void DRIVER_MI6021_displayError (int error)
{
	MessagePopupf ("Driver Error", "Driver error %d for board MI.6021\n\n%s.",
				   error, DRIVER_MI6021_errorStr(error));		
}





int DRIVER_MI6021_init (void)
{
    
    int lDriverId;
    int lReturnCode;
    int hDrv = 0;
    
	// ----- load spectrum.lib -----
	lDriverId = lLinkSpectrumDrv (LOAD_DLL, 0);
	if (lDriverId < 0) 
	{
		switch (lDriverId)
		{
			case -1 : //MessagePopup ("SPEasyGenerator","spectrum.lib not found");
				      return -1;
					  break;
					  
			case -2 : //MessagePopup ("SPEasyGenerator","Unable to load spectrum.dll"); 
	  				  return -2;
					  break;
		}
		
		return -1;
	}
	// ----- get handle of MI60xx or MI61xx -----
	lReturnCode = lGetBoardHandle(&hDrv);
	
	switch (lReturnCode)
	{
		case 0 : // ----- no 60xx or 61xx board found -----
				 MessagePopup ("Generator board not found", "There is no 60xx or 61xx board installed.");		
				 return -1;
				 break;
				 
		case 1 : // ----- 60xx or 61xx board found -----
				 stBoardInfo = stInitBoard(hDrv);
				 break;
	}

	return 0;
}


