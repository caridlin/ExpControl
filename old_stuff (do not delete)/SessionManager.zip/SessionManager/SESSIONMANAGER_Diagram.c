#include <userint.h>
#include "UIR_SessionManager.h"

#include "INCLUDES_SESSIONMANAGER.h"
#include "GPIB_DRIVER_LeCroy.h"

#define DIAGRAM_onTrajectory 0
#define N_ZOOM_STEPS 10

#define FONT_PI_2 "FONT_PI_2"
#define STRING_PI_OVER_2 "p/2"
#define STRING_PI "p"

typedef struct {
	double DEFAULT_yMin;
	double DEFAULT_yMax;
	double xFrom;
	double xTo;
	double yFrom;
	double yTo;
	int autoscale;
//	dRect lastZoomRegion;
	dRect zoomRegion;
	double cursorX1;
	double cursorX2;
	double cursorY1;
	double cursorY2;
	int showPulses;
	int placePulses;
	int killer[2];
	int sweepPoint;
	int velocityUncertainty;
	ListType lZooms;
	ListType lPicts;
} t_diag;



t_diag* diag=NULL;
int panelDiagram 	   = -1;
int	menuDiagram 	   = -1;
int panelDiagramError  = -1;
int panelDiagramPreview= -1;
int DIAG_PRINT_GRAPH   = -1;;

void DIAGRAM_switchAutoscale(void);
int DIAGRAM_displayError (char *errStr);


void DIAG_init (t_diag* diag) 
{
	t_atomConfig *ac;
	ac = activeSession()->atomConfig; 
	diag->DEFAULT_yMin = ac->position[POS_LASER1]  - 10; 
	diag->DEFAULT_yMax = ac->position[POS_DETECTOR2]  + 10;
	diag->showPulses = 1;
	diag->placePulses = 0;
	diag->autoscale = 1;
	diag->killer[0] = 0;
	diag->killer[1] = 0;
	diag->xFrom = 0;
	diag->xTo = 0;
	diag->yFrom = 0;
	diag->yTo = 0;
//	zoomRegion;
	diag->cursorX1 = 0;
	diag->cursorX2 = 0;
	diag->cursorY1 = 0;
	diag->cursorY2 = 0;
	diag->sweepPoint = 1;
	diag->velocityUncertainty=0;
	diag->lZooms = ListCreate (sizeof (dRect*));
	diag->lPicts = ListCreate (sizeof (int)); 
}


void DIAGRAM_resizePanel (void)
{
	int height, width;
	
	height = panelHeight (panelDiagram);
	width = panelWidth (panelDiagram);
	if (width < 850) width = 850;
	if (height < 150) height = 150;
	SetPanelSize (panelDiagram, height, width);
	
	SetCtrlAttribute (panelDiagram, DIAGRAM_GRAPH, ATTR_HEIGHT,
					  height - ctrlHeight (panelDiagram, DIAGRAM_COMMANDBUTTON_done) - 60);
	SetCtrlAttribute (panelDiagram, DIAGRAM_GRAPH, ATTR_WIDTH, width);
	
	// button "Done"
	SetCtrlAttribute (panelDiagram, DIAGRAM_COMMANDBUTTON_done, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+10);
	SetCtrlAttribute (panelDiagram, DIAGRAM_COMMANDBUTTON_done, ATTR_LEFT,
					  width - ctrlWidth (panelDiagram, DIAGRAM_COMMANDBUTTON_done)- 10);

//button "print"	
	SetCtrlAttribute (panelDiagram, DIAGRAM_COMMANDBUTTON_print, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+ctrlHeight (panelDiagram, DIAGRAM_COMMANDBUTTON_done)+15);
	SetCtrlAttribute (panelDiagram, DIAGRAM_COMMANDBUTTON_print, ATTR_LEFT,
					  width - ctrlWidth (panelDiagram, DIAGRAM_COMMANDBUTTON_done)- 10);  

	// button "Update"
	SetCtrlAttribute (panelDiagram, DIAGRAM_COMMANDBUTTON_update, ATTR_TOP,
					  ctrlTop(panelDiagram, DIAGRAM_COMMANDBUTTON_done));
	SetCtrlAttribute (panelDiagram, DIAGRAM_COMMANDBUTTON_update, ATTR_LEFT,
					  ctrlLeft (panelDiagram, DIAGRAM_COMMANDBUTTON_done)
					  - ctrlWidth (panelDiagram, DIAGRAM_COMMANDBUTTON_update)- 10);

	//button "xMin"
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_xMin, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+5+15);
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_xMin, ATTR_LEFT,
					   65); 
	//button "xMax"	
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_xMax, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+5+15);
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_xMax, ATTR_LEFT,
					   115+ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_xMax)); 
	
	
	//button "yMax"	
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_yMax, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+ctrlHeight (panelDiagram, DIAGRAM_NUMERIC_yMax)+5+15);
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_yMax, ATTR_LEFT,
					   115+ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_yMax)); 
	//button "yMin"	
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_yMin, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+ctrlHeight (panelDiagram, DIAGRAM_NUMERIC_yMin)+5+15);
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_yMin, ATTR_LEFT,
					   65); 

	//button "autoscale"	
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale, ATTR_TOP,ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+2*ctrlHeight (panelDiagram, DIAGRAM_RADIOBUTTON_pulses)+2*25);
					  //ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+/*ctrlHeight (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale)*/+5);
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale, ATTR_LEFT, 75);
					   //120+2*ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_xMax)); 
	//button "show pulses"	
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_pulses, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+5);
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_pulses, ATTR_LEFT,
					   240+2*ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_xMax)+ctrlWidth (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale)); 
					   
	//button "show text"	
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_showText, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+ctrlHeight (panelDiagram, DIAGRAM_RADIOBUTTON_pulses)+25);
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_showText, ATTR_LEFT,
					   240+2*ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_xMax)+ctrlWidth (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale));/*+ctrlWidth (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale)*/ 

	
	//button "place pulse"
//	SetCtrlAttribute (panelDiagram, DIAGRAM_BINARYSWITCH_place, ATTR_TOP,
//					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+ctrlHeight (panelDiagram, DIAGRAM_RADIOBUTTON_pulses)+25);
//	SetCtrlAttribute (panelDiagram, DIAGRAM_BINARYSWITCH_place, ATTR_LEFT,
//					   240+2*ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_xMax));

	//button "killer 1" 
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_killer1, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+5);
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_killer1, ATTR_LEFT,
					   390+2*ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_xMax));
	//button "killer 2" 
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_killer2, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+ctrlHeight (panelDiagram, DIAGRAM_RADIOBUTTON_pulses)+25);
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_killer2, ATTR_LEFT,
					  390+2*ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_xMax));
	
	//button "sweep Point" 
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_sweepPoint, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+ctrlHeight (panelDiagram, DIAGRAM_RADIOBUTTON_pulses)+6+ctrlHeight(panelDiagram, DIAGRAM_NUMERIC_xMax));
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_sweepPoint, ATTR_LEFT,
					  145+2*ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_xMax));
	
	
		//button "velocity uncertainty"	
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_velocity, ATTR_TOP,
					  ctrlBottom(panelDiagram, DIAGRAM_GRAPH)+2*ctrlHeight (panelDiagram, DIAGRAM_RADIOBUTTON_pulses)+2*25);
	SetCtrlAttribute (panelDiagram, DIAGRAM_RADIOBUTTON_velocity, ATTR_LEFT,
					   240+2*ctrlWidth (panelDiagram, DIAGRAM_NUMERIC_xMax)+ctrlWidth (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale));
//	
	DIAGRAM_plot(activeSession());
	RefreshGraph (panelDiagram, DIAGRAM_GRAPH);
}


void DIAGRAM_updateDiagBoundingBox(void) {
	int mode;
	GetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
						 VAL_BOTTOM_XAXIS, &mode, &diag->xFrom, &diag->xTo);
	GetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
						 VAL_LEFT_YAXIS, &mode, &diag->yFrom, &diag->yTo);
}


void DIAGRAM_setAxisScalingAccordingToDiag(void) {
	SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
								VAL_BOTTOM_XAXIS, VAL_MANUAL,diag->xFrom,diag->xTo);
	SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
								VAL_LEFT_YAXIS, VAL_MANUAL,diag->yFrom,diag->yTo);
}


/*
void DIAGRAM_setAxisScaling(void) 
{
	int autoScale;
	t_session* s;      
	s=activeSession();
 	GetCtrlVal (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale , &autoScale);
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_yMin,
					  ATTR_DIMMED, autoScale);
	SetCtrlAttribute(panelDiagram,DIAGRAM_NUMERIC_yMax,ATTR_DIMMED,autoScale);
	SetCtrlAttribute(panelDiagram,DIAGRAM_NUMERIC_xMin,ATTR_DIMMED,autoScale);
	SetCtrlAttribute(panelDiagram,DIAGRAM_NUMERIC_xMax,ATTR_DIMMED,autoScale);
	switch(autoScale)  {
		case 1:
		   	SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
								VAL_BOTTOM_XAXIS, VAL_MANUAL,s->curveStart_us,s->curveEnd_us);
			SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
								VAL_LEFT_YAXIS, VAL_AUTOSCALE,NULL,NULL);
			break;
	default :
			SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
								VAL_BOTTOM_XAXIS, VAL_MANUAL,NULL,NULL);
			SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
								VAL_LEFT_YAXIS, VAL_MANUAL,NULL,NULL);
	}
	DIAGRAM_updateDiagBoundingBox();
 } */

/*void DIAGRAM_disableAutoscale(void) {
	SetCtrlVal (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale , 0);
	DIAGRAM_setAxisScaling();
}   */
/*SetCtrlAttribute (panelDiagram, DIAGRAM_GRAPH,
				  ATTR_GRAPH_BGCOLOR, VAL_TRANSPARENT);   */
				  
				  
void DIAGRAM_initPanel (void)
{   
	int panelDummy;
	if (panelDiagram == -1) {
		panelDiagram = LoadPanel (0, SESSIONMANAGER_uirFile, DIAGRAM);
		//
		panelDiagramPreview = LoadPanel (0, SESSIONMANAGER_uirFile, DIAG_PRINT);
		SetPanelPos (panelDiagramPreview, 20, 20);
		
		
		//
		panelDummy = LoadPanel (0, SESSIONMANAGER_uirFile, DIAG_MENU);
		menuDiagram = GetPanelMenuBar (panelDummy);
		CreateMetaFont (FONT_PI_2, "Symbol", 17, 0, 0, 0, 0);
		panelDiagramError  = LoadPanel (panelDiagram, SESSIONMANAGER_uirFile, DIAG_ERR);
		SetPanelPos (panelDiagramError, 20, 20);
	}
	if (diag == NULL) {
		diag = (t_diag *) malloc (sizeof(t_diag)); 
		DIAG_init (diag);
		SetCtrlAttribute (panelDiagram, DIAGRAM_GRAPH,
					  ATTR_REFRESH_GRAPH, 0);
	}
	//SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
	//					VAL_RIGHT_YAXIS, VAL_AUTOSCALE,NULL,NULL);
	DIAGRAM_resizePanel ();
}


void DIAGRAM_updateNumericBoxesValues(void) {
	SetCtrlVal (panelDiagram, DIAGRAM_NUMERIC_xMin, diag->xFrom);
	SetCtrlVal (panelDiagram, DIAGRAM_NUMERIC_xMax, diag->xTo);
	SetCtrlVal (panelDiagram, DIAGRAM_NUMERIC_yMin, diag->yFrom);
	SetCtrlVal (panelDiagram, DIAGRAM_NUMERIC_yMax, diag->yTo);
}


/*void DIAGRAM_SetNumericBoxes(int panel,int control) {
	int mode;
	double xMin,xMax,yMin,yMax;
	GetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
						VAL_BOTTOM_XAXIS, &mode, &xMin, &xMax);
	GetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
						VAL_LEFT_YAXIS, &mode, &yMin, &yMax);
	SetCtrlVal(panelDiagram, DIAGRAM_NUMERIC_xMin,xMin );
	SetCtrlVal(panelDiagram, DIAGRAM_NUMERIC_xMax,xMax );
	SetCtrlVal(panelDiagram, DIAGRAM_NUMERIC_yMin,yMin );
	SetCtrlVal(panelDiagram, DIAGRAM_NUMERIC_yMax,yMax );  
}   */

void DIAGRAM_setBoundsToSweepPoints(void) {
	t_session* s;
	s=activeSession();
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_sweepPoint,
					  ATTR_MAX_VALUE,s->nSweepPoints);
}

void DIAGRAM_displayPanel (t_session *s) 
{
	DIAGRAM_initPanel ();
	DIAGRAM_setBoundsToSweepPoints();
//	DIAGRAM_setAxisScaling();
	DIAGRAM_displayError (0);
    if(diag->autoscale) {
    	diag->xFrom = activeSession()->curveStart_us;
		diag->xTo =   activeSession()->curveEnd_us;
		diag->yFrom = diag->DEFAULT_yMin;
		diag->yTo =  diag->DEFAULT_yMax;
		DIAGRAM_updateNumericBoxesValues();
		}
	DIAGRAM_setAxisScalingAccordingToDiag();
    DIAGRAM_plot (s);
   // DIAGRAM_SetNumericBoxes(panelDiagram,DIAGRAM_GRAPH);	
	DisplayPanel (panelDiagram);
	RefreshGraph(panelDiagram,DIAGRAM_GRAPH); 
}



int CVICALLBACK DIAGRAM_panelCallback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	
	switch (event) {
		case EVENT_GOT_FOCUS:
			break;
		case EVENT_LOST_FOCUS:
			break;
		case EVENT_CLOSE:
			break;
		case EVENT_PANEL_SIZE:
			DIAGRAM_resizePanel ();
			break;
	}
	return 0;
}







int CVICALLBACK DIAGRAM_callback_done (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			HidePanel (panelDiagram);
			break;
		}
	return 0;
}

int CVICALLBACK DIAGRAM_callback_update (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			DIAGRAM_displayPanel (activeSession());
			break;
		}
	return 0;
}


#define DIAM_DET1 0.5 
#define DIAM_DET2 0.7
#define DIAM_LASER1 0.7
#define DIAM_RAMSEY 2.0



enum {
	DIAGRAM_EVENT_STYLE_NONE = 0,
	DIAGRAM_EVENT_STYLE_DIAMOND,
	DIAGRAM_EVENT_STYLE_PI_SUR_2,
	DIAGRAM_EVENT_STYLE_PI,
	DIAGRAM_EVENT_STYLE_PI_SUR_2_DIAMOND,
	DIAGRAM_EVENT_STYLE_PI_DIAMOND,
	
	N_EVENT_STYLES
};


const char *DIAGRAM_eventStyleStr (int eventStyle)
{
	switch (eventStyle) {
		case DIAGRAM_EVENT_STYLE_NONE: return "none";
		case DIAGRAM_EVENT_STYLE_DIAMOND: return "diamond";
		case DIAGRAM_EVENT_STYLE_PI_SUR_2: return "pi/2 pulse";
		case DIAGRAM_EVENT_STYLE_PI_SUR_2_DIAMOND: return "pi/2 pulse cavity";
		case DIAGRAM_EVENT_STYLE_PI: return "pi pulse"; 
		case DIAGRAM_EVENT_STYLE_PI_DIAMOND: return "pi pulse cavity";
	}
	return "";
}


void DIAGRAM_fillEventStylesToRing (int panel, int ctrl)
{
	int i;
	ClearListCtrl (panel, ctrl);
	for (i = 0; i < N_EVENT_STYLES; i++) {
		InsertListItem (panel, ctrl, -1, DIAGRAM_eventStyleStr (i), i);
	}
}

void DIAGRAM_plotTxt (double x, double y, const char *string, const char *font, int color)
{
	int height, width;
	double dHeight, dWidth;
	
	GetTextDisplaySize (string, FONT_PI_2, &height, &width);
	dHeight = 1.0*height / (1.0 * ctrlHeight (panelDiagram, DIAGRAM_GRAPH)) * (diag->yTo-diag->yFrom);
	dWidth  = 1.0*width / (1.0 * ctrlWidth (panelDiagram, DIAGRAM_GRAPH)) * (diag->xTo-diag->xFrom);
	PlotText (panelDiagram, DIAGRAM_GRAPH, x-dWidth/2, y-dHeight/2, string, font, color,
			  VAL_TRANSPARENT);
			  
	
}	 

void DIAGRAM_plotCircle(double x,double y,char* word) 
{	
	int pict1,pict2;
	int height, width,heightChar, widthChar;
	double dHeight, dWidth,rayonX,rayonY,dHeightChar, dWidthChar;
	
	GetTextDisplaySize (word, FONT_PI_2, &height, &width);
	dHeight= 1.0*height / (1.0 * ctrlHeight (panelDiagram, DIAGRAM_GRAPH)) * (diag->yTo-diag->yFrom);
	dWidth  = 1.0*width / (1.0 * ctrlWidth (panelDiagram, DIAGRAM_GRAPH)) * (diag->xTo-diag->xFrom);

	GetTextDisplaySize ("p", FONT_PI_2, &heightChar, &widthChar);
	dHeightChar =1.0*heightChar / (1.0 * ctrlHeight (panelDiagram, DIAGRAM_GRAPH)) * (diag->yTo-diag->yFrom);
	dWidthChar = 1.0*widthChar / (1.0 * ctrlWidth (panelDiagram, DIAGRAM_GRAPH)) * (diag->xTo-diag->xFrom);  
				 
	if(heightChar>widthChar)  {
		rayonX = 1.9*dWidthChar;
		rayonY = dHeightChar*widthChar/heightChar*rayonX/dWidthChar;
		}
	else{
		rayonY = 1.9*dHeightChar;
		rayonX = dWidthChar*heightChar/widthChar*rayonY/dHeightChar;
		}
	pict1=PlotOval (panelDiagram, DIAGRAM_GRAPH, x-rayonX, y-rayonY,
			  x+rayonX, y+rayonY, VAL_RED, VAL_RED);
	pict2=PlotText (panelDiagram, DIAGRAM_GRAPH, x-dWidth/2, y-dHeight/2, word, FONT_PI_2, VAL_WHITE,
			  VAL_TRANSPARENT);
	ListInsertItem (diag->lPicts, &pict1, END_OF_LIST);
	ListInsertItem (diag->lPicts, &pict2, END_OF_LIST); 
	//DIAGRAM_plotTxt (x,y,"p/2",FONT_PI_2,VAL_BLUE);
	
}

void DIAGRAM_plotLosange(double x,double y,char* word) 
{	
	int pict1,pict2;
	int height, width,heightChar, widthChar;
	double dHeight, dWidth,rayonX,rayonY,dHeightChar, dWidthChar;

//	int height, width;
//	double dHeight, dWidth,rayonX,rayonY;
	double cornerX[4];
	double cornerY[4];
	
	GetTextDisplaySize (word, FONT_PI_2, &height, &width);
	dHeight = 1.0*height / (1.0 * ctrlHeight (panelDiagram, DIAGRAM_GRAPH)) * (diag->yTo-diag->yFrom);
	dWidth  = 1.0*width / (1.0 * ctrlWidth (panelDiagram, DIAGRAM_GRAPH)) * (diag->xTo-diag->xFrom);

	GetTextDisplaySize ("p", FONT_PI_2, &heightChar, &widthChar);
	dHeightChar =1.0*heightChar / (1.0 * ctrlHeight (panelDiagram, DIAGRAM_GRAPH)) * (diag->yTo-diag->yFrom);
	dWidthChar = 1.0*widthChar / (1.0 * ctrlWidth (panelDiagram, DIAGRAM_GRAPH)) * (diag->xTo-diag->xFrom);  

	if(heightChar>widthChar)  {
		rayonX = 1.9*dWidthChar;
		rayonY = dHeightChar*widthChar/heightChar*rayonX/dWidthChar;
		}
	else{
		rayonY = 1.9*dHeight;
		rayonX = dWidthChar*heightChar/widthChar*rayonY/dHeightChar;
		}
	
	cornerX[0] = x-rayonX;
	cornerY[0] = y;
	cornerX[1] = x;
	cornerY[1] = y+rayonY;
	cornerX[2] = x+rayonX;
	cornerY[2] = y;
	cornerX[3] = x;
	cornerY[3] = y-rayonY;
	pict1=PlotPolygon (panelDiagram, DIAGRAM_GRAPH, cornerX, cornerY, 4,
				 VAL_DOUBLE, VAL_DOUBLE, VAL_RED, VAL_RED);
	pict2=PlotText (panelDiagram, DIAGRAM_GRAPH, x-dWidth/2, y-dHeight/2, word, FONT_PI_2, VAL_WHITE,
			  VAL_TRANSPARENT);
	ListInsertItem (diag->lPicts, &pict1, END_OF_LIST);
	ListInsertItem (diag->lPicts, &pict2, END_OF_LIST); 
	//DIAGRAM_plotTxt (x,y,"p/2",FONT_PI_2,VAL_BLUE);
	
}


void DIAGRAM_plotEvent (t_session *s, t_atom *a, t_atomEvent* ae, double delay,int showPulses)  
{
	double lineXFrom,lineYFrom,lineXTo,lineYTo;
	double pulseStart,pulseDuration; 
	double heightLosange,widthLosange,centerX,centerY,height,width,xGain,graphHeight,graphWidth;
	int top,left,bottom,right,diamond,width_pi_sur_2,height_pi_sur_2,line;
	double tableX[5];
	double tableY[5];
	double xTotal,yTotal;
	char fileName[40];
	int mode;
	double xEvent,yEvent;
	char word[10];
	int n; 
	
	t_atomConfig *ac;
	ac = s->atomConfig; 
	if(!ae->active) return;
	n = ae->pulseStartVary ? diag->sweepPoint-1 : 0;
	pulseStart = delay+ae->pulseStartFirst +  n* ae->pulseStartIncrement+a->time[ae->pulseStartReference];
	pulseDuration = ae->pulseDurationFirst+ n * ae->pulseDurationIncrement;
	if(pulseStart<diag->xFrom) { 
		lineXFrom = diag->xFrom;
		lineYFrom = a->velocity*(diag->xFrom-delay)/1000;
		}
	else {
		lineXFrom = pulseStart;
		lineYFrom = a->velocity*(pulseStart-delay)/1000;
		}
	if(pulseStart+pulseDuration>diag->xTo) { 
		lineXTo = diag->xTo;
		lineYTo = a->velocity*(diag->xTo-delay)/1000;
		}
	else {
		lineXTo = pulseStart+pulseDuration;
		lineYTo = a->velocity*(pulseStart+pulseDuration-delay)/1000;
		}
	line = PlotLine (panelDiagram, DIAGRAM_GRAPH, lineXFrom,
					 lineYFrom, lineXTo, lineYTo, VAL_RED);
					
	SetPlotAttribute (panelDiagram, DIAGRAM_GRAPH, line,
					  ATTR_PLOT_THICKNESS, 3);
	
	if(showPulses) {
					centerX = pulseStart + pulseDuration/2; 
	
					switch(diag->placePulses) {
						case DIAGRAM_onTrajectory:
							 centerY = a->velocity*(centerX-delay)/1000;
							 //centerY = a->velocity*(ae->pulseStartFirst+a->time[ae->pulseStartReference])/1000;
						break;
						default :
							 centerY = ac->position[ATOMS_EVENTS_positionOfChannel(ae->digitalChannel)];
					} 
	

				//centerX = delay+ae->pulseStartFirst+a->time[ae->pulseStartReference];
					//centerY = ac->position[ATOMS_EVENTS_positionOfChannel(ae->digitalChannel)];
					//centerY = a->velocity*(ae->pulseStartFirst+a->time[ae->pulseStartReference])/1000;
	
				//	GetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH, VAL_BOTTOM_XAXIS,&mode ,&xMin ,&xMax);
				//	GetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH, VAL_LEFT_YAXIS,&mode ,&yMin ,&yMax); 
					xTotal = diag->xTo-diag->xFrom;
					yTotal = diag->yTo-diag->yFrom;
					graphWidth = ctrlWidth (panelDiagram, DIAGRAM_GRAPH);
					graphHeight = ctrlHeight (panelDiagram, DIAGRAM_GRAPH);
					if(panelHeight (panelDiagram)<panelWidth(panelDiagram)) {
						heightLosange = yTotal/10;
						widthLosange  = heightLosange * xTotal/yTotal*graphHeight/graphWidth;
						width_pi_sur_2 = widthLosange;
						height_pi_sur_2 = heightLosange;
						}
					else {
						widthLosange  =  xTotal/10;
						heightLosange =  widthLosange * yTotal/xTotal*graphWidth/graphHeight;
						width_pi_sur_2 = widthLosange;
						height_pi_sur_2 = heightLosange;
					}
					switch(ae->eventStyle) {
		
							 case DIAGRAM_EVENT_STYLE_NONE:
							 	break;
							 case DIAGRAM_EVENT_STYLE_DIAMOND :
				
								tableX[0]=centerX-widthLosange/2;
								tableX[1]=centerX;
								tableX[2]=centerX+widthLosange/2;
								tableX[3]=centerX;
								tableX[4]=tableX[0];
	
								tableY[0]=centerY;
								tableY[1]=centerY+heightLosange/2;
								tableY[2]=centerY;
								tableY[3]=centerY-heightLosange/2;
								tableY[4]=tableY[0]; 
	
								diamond = PlotXY (panelDiagram,
										DIAGRAM_GRAPH,
										tableX, tableY,
		  								5,
		  								VAL_DOUBLE,
		  								VAL_DOUBLE, VAL_FAT_LINE, VAL_BOLD_X,
		  								VAL_SOLID, 1, VAL_MAGENTA);
	
								/*diamond*/ListInsertItem(diag->lPicts, &diamond ,END_OF_LIST);
							
								break;
							case DIAGRAM_EVENT_STYLE_PI_SUR_2:
								//PlotBitmap (panelDiagram, DIAGRAM_GRAPH, centerX-width_pi_sur_2/2, centerY-height_pi_sur_2/2,
								//			width_pi_sur_2, height_pi_sur_2,"pisur2.bmp");
								DIAGRAM_plotCircle (centerX,centerY,STRING_PI_OVER_2);
								break;
							case DIAGRAM_EVENT_STYLE_PI:
								DIAGRAM_plotCircle (centerX,centerY,STRING_PI);
								break;
							case DIAGRAM_EVENT_STYLE_PI_SUR_2_DIAMOND:
								DIAGRAM_plotLosange (centerX,centerY,STRING_PI_OVER_2);
								break;
							case DIAGRAM_EVENT_STYLE_PI_DIAMOND:
								DIAGRAM_plotLosange (centerX,centerY,STRING_PI);
								break;
					}
	}
	
}

int ordered(double a,double b,double c) {
	if(b<a)
		return 0;
	if(c<b)
		return 0;
	return 1;
}

double minimum(double* tab,int n,int* min) {
	double m;
	int i;
	if(n==0) return -1;
	m=tab[0];
	*min = 0;
	for(i=1;i<n;i++) {
		if(tab[i]<m) {
			m=tab[i];
			*min = i;
			}
	}
	return m;
}

double DIAGRAM_maximum(double* tab,int n,int* max) {
	double m;
	int i;
	if(n==0) return -1;
	m=tab[0];
	*max=0;
	for(i=1;i<n;i++) {
		if(tab[i]>m) {
			m=tab[i];
			*max = i;
			}
	}
	return m;
}


double intersectionY(double X1,double Y1,double X2,double Y2,double Y) {
	return X1+(Y-Y1)/(Y2-Y1) * (X2-X1);
}

int remainder(int a,int b) {
	return a-(a/b)*b;
}

void DIAGRAM_plotTriangle(double* cornerX,double* cornerY) {
	double X[4];
	double Y[4];
	double maxi;
	int min,max,max2,k,nSummit,u;
	k=0;
	nSummit=0;
	if(minimum(cornerY,3,&min)<diag->yFrom) {
		u =(min+1)%3; 
	  	X[2] = intersectionY(cornerX[min],cornerY[min],cornerX[(min+1)%3],cornerY[(min+1)%3],diag->yFrom);
	  	Y[2] = diag->yFrom;
	  	nSummit++;
	  	X[3] = intersectionY(cornerX[min],cornerY[min],cornerX[(min+2)%3],cornerY[(min+2)%3],diag->yFrom);
	  	Y[3] = diag->yFrom;
		nSummit++;
		}
	else {
		X[2] = cornerX[min];
		Y[2] = cornerY[min];
		nSummit++;
		}
	maxi = DIAGRAM_maximum(cornerY,3,&max);
	for(k=0;k<3;k++)
		if(k != max && k != min) 
			max2=k;
	if(maxi>diag->yTo) {
		X[0] = intersectionY(cornerX[max2],cornerY[max2],cornerX[min],cornerY[min],diag->yTo);
		Y[0] = diag->yTo;
		nSummit++;
		X[1] = intersectionY(cornerX[max],cornerY[max],cornerX[min],cornerY[min],diag->yTo);
		Y[1] = diag->yTo;
		nSummit++;
		}
	else {
		X[1] = cornerX[max];
		Y[1] = cornerY[max];
		nSummit++;
		X[0] = cornerX[max2];
		Y[0] = cornerY[max2];
		nSummit++;
		}
		
	  	
		PlotPolygon (panelDiagram, DIAGRAM_GRAPH, X, Y, nSummit,            
	  				 VAL_DOUBLE, VAL_DOUBLE, VAL_GREEN, VAL_GREEN);               
}                                                                         


void DIAGRAM_plotAtom (t_session *s, t_atom *a, double delay)
{
	t_atomConfig *ac;
	t_atomEvent *ae;
	t_atom* b;
	int i,nombre,m;
	double timeFastest,timeSlowest;
	double velocityFastest,velocitySlowest,velocityFastestDoppler,velocitySlowestDoppler;
	double timeFastestDoppler,timeSlowestDoppler,velocityEcho,velocityEchoSlowest,velocityEchoFastest;
	double timeEchoFastest,timeEchoSlowest;
	double cornerX[4];
	double cornerY[4];
	
	double timeExitFastest,timeExitSlowest,timeEntranceFastest,timeEntranceSlowest;
		
	ac = s->atomConfig;
	if(!diag->velocityUncertainty) {
		PlotLine (panelDiagram, DIAGRAM_GRAPH, delay+a->time[POS_REPUMPER],
				  ac->position[POS_REPUMPER], delay+a->time[POS_DETECTOR2],
				  ac->position[POS_DETECTOR2], VAL_GREEN);
				  
/*		PlotLine (panelDiagram, DIAGRAM_GRAPH, 
				  delay+ATOM_time(a,diag->yFrom),
				  diag->yFrom,
				  delay+ATOM_time(a,diag->yTo),
				  diag->yTo, 
				  VAL_GREEN);*/
				}
	else
		 {
		velocityFastest = a->velocity + a->velocitySpread;
		velocitySlowest = a->velocity - a->velocitySpread;
		
		velocityFastestDoppler = a->velocity + a->velocitySpreadDoppler; 
		velocitySlowestDoppler = a->velocity - a->velocitySpreadDoppler;
		
		timeFastest = a->time[POS_LASER1]+delay+(ac->position[POS_DETECTOR2]-ac->position[POS_LASER1])/velocityFastest*1000;
		timeSlowest = a->time[POS_LASER1]+delay+(ac->position[POS_DETECTOR2]-ac->position[POS_LASER1])/velocitySlowest*1000;

/*		timeExitFastest = delay+(diag->yTo-ac->position[POS_LASER1])/velocityFastest*1000; 
		timeExitSlowest = delay+(diag->yTo-ac->position[POS_LASER1])/velocitySlowest*1000; 
		timeEntranceFastest = delay+(diag->yFrom-ac->position[POS_LASER1])/velocityFastest*1000;  
		timeEntranceSlowest = delay+(diag->yFrom-ac->position[POS_LASER1])/velocitySlowest*1000;    */
		
		timeFastestDoppler = a->time[POS_REPUMPER]+delay+(ac->position[POS_LASER1]-ac->position[POS_REPUMPER])/velocityFastestDoppler*1000;
		timeSlowestDoppler = a->time[POS_REPUMPER]+delay+(ac->position[POS_LASER1]-ac->position[POS_REPUMPER])/velocitySlowestDoppler*1000;

//		timeExitFastestDoppler = a->time[POS_REPUMPER]+delay+(ac->position[POS_LASER1]-ac->position[POS_REPUMPER])/velocityFastestDoppler*1000;	
//		timeExitSlowestDoppler = a->time[POS_REPUMPER]+delay+(ac->position[POS_LASER1]-ac->position[POS_REPUMPER])/velocitySlowestDoppler*1000;
	
		
	
	
/*		if(ac->position[POS_LASER1]<diag->yFrom) {
			cornerX[0] = timeExitFastest;
			cornerY[0] = diag->yTo;
			cornerX[1] = timeExitSlowest;
			cornerY[1] = diag->yTo;
			cornerX[2] = a->time[POS_LASER1]+delay;
			cornerY[2] = ac->position[POS_LASER1];
			PlotPolygon (panelDiagram, DIAGRAM_GRAPH, cornerX, cornerY, 3,
						 VAL_DOUBLE, VAL_DOUBLE, VAL_GREEN, VAL_GREEN);
			}
		else {
				cornerX[0] = timeExitFastest;                                  
				cornerY[0] = diag->yTo;                                        
				cornerX[1] = timeExitSlowest;                                  
				cornerY[1] = diag->yTo;                                        
				cornerX[2] = timeEntranceSlowest+delay;                        
				cornerY[2] = diag->yFrom;
				cornerX[3] = timeEntranceFastest+delay;       
				cornerY[3] = diag->yFrom;       
				
				PlotPolygon (panelDiagram, DIAGRAM_GRAPH, cornerX, cornerY, 4, 
							 VAL_DOUBLE, VAL_DOUBLE, VAL_GREEN, VAL_GREEN);    
			}
	
		
		PlotPolygon (panelDiagram, DIAGRAM_GRAPH, cornerX, cornerY, 3,
					 VAL_DOUBLE, VAL_DOUBLE, VAL_GREEN, VAL_GREEN);
													*/
		cornerX[0] = timeFastest;
		cornerY[0] = ac->position[POS_DETECTOR2];
		cornerX[1] = timeSlowest;
		cornerY[1] = ac->position[POS_DETECTOR2];
		cornerX[2] = a->time[POS_LASER1]+delay;
		cornerY[2] = ac->position[POS_LASER1];
		DIAGRAM_plotTriangle(cornerX,cornerY);
		
		cornerX[0] = timeFastestDoppler;
		cornerY[0] = ac->position[POS_LASER1];
		cornerX[1] = timeSlowestDoppler;
		cornerY[1] = ac->position[POS_LASER1];
		cornerX[2] = a->time[POS_REPUMPER]+delay;
		cornerY[2] = ac->position[POS_REPUMPER];
		DIAGRAM_plotTriangle(cornerX,cornerY);		
//////////////////////////////////////////////
//echos
//////////////////////////////////////////////
		for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
			b = ATOM_ptr (s, i);
			if (b->active) {
					ATOMS_calculateTimesForAtom (s, b);
					if(b->hasMultiples==0)	
						nombre=1;
					else 
						nombre = b->nMultiples;
					for(m=0;m<nombre;m++)
						 if(ordered(timeFastestDoppler,b->delay*m+b->time[POS_LASER1],timeSlowestDoppler))
						 	{
						 		if(a!=b || delay!=m*b->delay)
							 		{
							 		velocityEcho = 1000*(ac->position[POS_LASER1]-ac->position[POS_REPUMPER])/(b->time[POS_LASER1]+b->delay*m-a->time[POS_REPUMPER]-delay);
							 		velocityEchoFastest =  velocityEcho + (b->velocitySpread)*velocityEcho/b->velocity;
							 		velocityEchoSlowest =  velocityEcho - (b->velocitySpread)*velocityEcho/b->velocity;
							 		timeEchoFastest = m*b->delay+(ac->position[POS_DETECTOR2]-ac->position[POS_LASER1])/velocityEchoFastest*1000;
									timeEchoSlowest = m*b->delay+(ac->position[POS_DETECTOR2]-ac->position[POS_LASER1])/velocityEchoSlowest*1000;
							 		cornerX[0] = timeEchoFastest;
									cornerY[0] = ac->position[POS_DETECTOR2];
									cornerX[1] = timeEchoSlowest;
									cornerY[1] = ac->position[POS_DETECTOR2];
									cornerX[2] = b->time[POS_LASER1]+b->delay*m;
									cornerY[2] = ac->position[POS_LASER1];
									PlotPolygon (panelDiagram, DIAGRAM_GRAPH, cornerX, cornerY, 3,
												 VAL_DOUBLE, VAL_DOUBLE, VAL_CYAN, VAL_CYAN);
							 		}
						 	}
						
				}
			}
		 }
	//if(diag->showPulses)
		for(i=1;i<=ListNumItems(a->lAtomEvents);i++) {
				ae=ATOMEVENT_ptr(a,i);
				DIAGRAM_plotEvent(s,a,ae,delay,diag->showPulses);
				
		}
}



void DIAGRAM_plotAtoms (void) 
{
    t_session* s=activeSession();
    t_atom * a;
    int i,nombre,m,pict;
  	for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
		a = ATOM_ptr (s, i);
		if (a->active) {
			ATOMS_calculateTimesForAtom (s, a);  		
			if(a->hasMultiples==0)	
				nombre=1;
			else 
				nombre = a->nMultiples;
			for(m=0;m<nombre;m++)
				DIAGRAM_plotAtom (s, a, m*(a->delay) );
		}
	}
	for (i = 1; i <= ListNumItems (diag->lPicts); i++) {
			ListGetItem (diag->lPicts, &pict, i);
			SetPlotAttribute (panelDiagram, DIAGRAM_GRAPH, pict,
							  ATTR_PLOT_ZPLANE_POSITION, 0);
	}
		
}


void DIAGRAM_plotPositions (t_session *s)
{
	t_atomConfig *ac;
	int plot;
	
	ac = s->atomConfig;
//	PlotRectangle (panelDiagram, DIAGRAM_GRAPH, s->dSmallestTime,
//				   s->, d->largestTime, , VAL_RED, VAL_RED);
	PlotLine (panelDiagram, DIAGRAM_GRAPH, s->curveStart_us, 0,
			  s->curveStart_us, ac->position[POS_DETECTOR2]+10,
			  VAL_TRANSPARENT);

	plot = PlotRectangle (panelDiagram, DIAGRAM_GRAPH, 
				   s->curveStart_us,
				   ac->position[POS_DETECTOR1] - DIAM_DET1/2, 
				   s->curveEnd_us, 
				   ac->position[POS_DETECTOR1] + DIAM_DET1/2, 
				   VAL_DK_GRAY, VAL_DK_GRAY);
	// Plot detector 2
	PlotRectangle (panelDiagram, DIAGRAM_GRAPH, s->curveStart_us,
				   ac->position[POS_DETECTOR2] - DIAM_DET2/2,
				   s->curveEnd_us,
				   ac->position[POS_DETECTOR2] + DIAM_DET2/2,
				   VAL_DK_GRAY, VAL_DK_GRAY);

	// Plot RamseyZone1
	PlotRectangle (panelDiagram, DIAGRAM_GRAPH, s->curveStart_us,
				   ac->position[POS_RAMSEY1] - DIAM_RAMSEY/2,
				   s->curveEnd_us,
				   ac->position[POS_RAMSEY1] + DIAM_RAMSEY/2,
				   VAL_GRAY, VAL_GRAY);   
	
	if(ac->position[POS_RAMSEY2]!=POSITION_UNASSIGNED) {								
	PlotRectangle (panelDiagram, DIAGRAM_GRAPH, s->curveStart_us,
				   ac->position[POS_RAMSEY2] - DIAM_RAMSEY/2,
				   s->curveEnd_us,
				   ac->position[POS_RAMSEY2] + DIAM_RAMSEY/2,
				   VAL_GRAY, VAL_GRAY);  
				   }
		 
	PlotRectangle (panelDiagram, DIAGRAM_GRAPH, s->curveStart_us,
				   ac->position[POS_RAMSEY3] - DIAM_RAMSEY/2,
				   s->curveEnd_us,
				   ac->position[POS_RAMSEY3] + DIAM_RAMSEY/2,
				   VAL_GRAY, VAL_GRAY);
				   
	PlotRectangle (panelDiagram, DIAGRAM_GRAPH, s->curveStart_us,
				   ac->position[POS_START_CAVITY1],
				   s->curveEnd_us,
				   ac->position[POS_END_CAVITY1],
				   VAL_LT_GRAY,VAL_LT_GRAY );	   

	PlotRectangle (panelDiagram, DIAGRAM_GRAPH, s->curveStart_us,
				   ac->position[POS_START_CAVITY2], s->curveEnd_us,
				   ac->position[POS_END_CAVITY2], VAL_LT_GRAY,
				   VAL_LT_GRAY);
											 
	PlotRectangle (panelDiagram, DIAGRAM_GRAPH, s->curveStart_us,
				   ac->position[POS_LASER1] - DIAM_LASER1/2,
				   s->curveEnd_us,
				   ac->position[POS_LASER1] + DIAM_LASER1/2,
				   VAL_OFFWHITE, VAL_OFFWHITE);

	
}

/*
void convertAOoutputToVoltages (t_digitizeParameters *p, double *points, int nPoints,double * min,double * max)
{
	int i;
	if (p == NULL) return;

	for (i = 0; i < nPoints; i++) DigitalToAnalog (
	
/*	*min=+1000;
	*max=-1000;
	for (i = 0; i < nPoints; i++) {
         points[i] = (double) p->maxVoltage * points[i] / (double) p->maxDigital;
         if(points[i]>*max)
         	*max = points[i];
         if(points[i]<*min)
         	*min = points[i];
    }

}
*/			

  // t_digitizeParameters *p;
  


int DIAGRAM_displayError (char *errStr)
{
	int ok;
	
	ok = (errStr == NULL) || (errStr[0] == 0);
	
	SetPanelAttribute (panelDiagramError, ATTR_VISIBLE, !ok);
	if (ok) return 0;
	ClearListCtrl (panelDiagramError, DIAG_ERR_TEXTBOX_error);
	InsertTextBoxLine (panelDiagramError, DIAG_ERR_TEXTBOX_error, -1, errStr);
	DisplayPanel (panelDiagramError);
	return -1;
}


int DIAGRAM_plotKiller(t_session* s, int cavity) {
	int curveKiller;
	int couleur,j,cav,dataIndex,nPoints,i;
	double* pointListX,*pointListY;
//	double min,max;
	int error;
	int oldTransmitKiller;
	
	t_sequence *seq;
	t_outputData *outData;
  	t_digitizeParameters *p;
  	unsigned __int64 absoluteTime;
	
	DIAGRAM_displayError (0);

	if(cavity==0) couleur = VAL_YELLOW;
	else couleur =VAL_MAGENTA;

	if (config == NULL) {
		config = (t_config *) malloc (sizeof (t_config));
		CONFIG_init (config);
		config->ignorePresenceOfGpibLeCroyDevices = 1;
	}

	oldTransmitKiller = s->transmitKillerCurves;
	s->transmitKillerCurves = 1;
	error = SESSIONMANAGER_createSequence (s, "", 0);
	s->transmitKillerCurves = oldTransmitKiller;
	
	if (error != 0) return DIAGRAM_displayError ( CREATESEQ_getErrorStr() );
	
	seq = s->sequence;
	seq->repetition = diag->sweepPoint-1;
	if (OUTPUTDATA_calculate (seq, 1) != 0) {
		return DIAGRAM_displayError ( "Can't compute output data");
	}
	outData = seq->outData;

    dataIndex = MAX_AO_DEVICES * 8 + (GPIB_ADDRESS_KILLER-1) * 2 + cavity;
    nPoints = 2*outData->numAOValues[dataIndex];

    
    pointListX = (double *) malloc (sizeof (double) * nPoints);
    pointListY = (double *) malloc (sizeof (double) * nPoints);

	absoluteTime = 0;
	p = digitizeParameters_LeCroyLW120 (0, TIMEBASE_LECROY_KILLER);
	for (i = 0; i < nPoints/2; i++) {
		pointListX[2*i] = ((double) (ui64toDouble (absoluteTime) * VAL_FLOAT_MIN_us)) + s->curveStart_us;
		pointListY[2*i] =  DigitalToAnalog (outData->AO_Values[dataIndex][i], p);
		pointListY[2*i+1] = pointListY[2*i]; 
		absoluteTime += outData->AO_ValueDuration[dataIndex][i];
		pointListX[2*i+1] =  ((double) (ui64toDouble (absoluteTime) * VAL_FLOAT_MIN_us)) + s->curveStart_us;
	}
     
	
	curveKiller=PlotXY (panelDiagram, DIAGRAM_GRAPH, pointListX, pointListY,
			nPoints, VAL_DOUBLE, VAL_DOUBLE, VAL_THIN_LINE,
			VAL_EMPTY_SQUARE, VAL_SOLID, 1, couleur);
	SetPlotAttribute (panelDiagram, DIAGRAM_GRAPH, curveKiller,
					  ATTR_PLOT_YAXIS, VAL_RIGHT_YAXIS);
	SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
						VAL_RIGHT_YAXIS, VAL_MANUAL, -10.5, 10.5);
	free (pointListX);
	free (pointListY);
	return 0;		
}

void DIAGRAM_plot (t_session *s)
{
	int i;
	
	DeleteGraphPlot (panelDiagram, DIAGRAM_GRAPH, -1,
					 VAL_DELAYED_DRAW);
	if (ListNumItems(s->lAtoms) == 0) return;
	DIAGRAM_plotPositions(s);
//	RefreshGraph(panelDiagram, DIAGRAM_GRAPH);
	DIAGRAM_plotAtoms();
	for(i=0;i<N_CAVITIES;i++)
		if(diag->killer[i]) 
			DIAGRAM_plotKiller(s,i);
}


void DIAGRAM_copyRect(dRect *r1,const dRect* r2) {
	memcpy (r1, r2, sizeof (dRect));
}


dRect *DIAGRAM_recallZoomRegion (void)
{
	static dRect oldZoomRegion;
	dRect *item;
	
	if (ListNumItems (diag->lZooms) == 0) return NULL;
	
	ListRemoveItem (diag->lZooms, &item, ListNumItems (diag->lZooms) );
	DIAGRAM_copyRect (&oldZoomRegion, item);  
	free (item);

	return &oldZoomRegion;	
}



void DIAGRAM_storeZoomRegion (dRect *zoomRegion)
{
	dRect *newZoomRegion;
	
	newZoomRegion = (dRect *) malloc (sizeof (dRect));
	DIAGRAM_copyRect(newZoomRegion, zoomRegion);
	ListInsertItem (diag->lZooms, &newZoomRegion, END_OF_LIST);
}



void DIAGRAM_setZoomRegionAccordingToCursors(void) {
	double X1,X2,Y1,Y2;
	X1 = diag->cursorX1;
	X2 = diag->cursorX2;
	Y1 = diag->cursorY1;
	Y2 = diag->cursorY2;
	//backup zoomRegion in lastZoomRegion first
//	DIAGRAM_storeZoomRegion (&diag->zoomRegion);
	//then write new values
	if(X1<=X2)  {
		diag->zoomRegion.xFrom = X1;
	 	diag->zoomRegion.xTo = X2;
	 	}
	 	else
	 	{
		diag->zoomRegion.xFrom = X2;
	 	diag->zoomRegion.xTo = X1;
	 	}
	if(Y1<=Y2)  { 
		diag->zoomRegion.yFrom = Y1;
		diag->zoomRegion.yTo = Y2;
		}
		else
		{
		diag->zoomRegion.yFrom = Y2;
		diag->zoomRegion.yTo = Y1;
		}
}


void DIAGRAM_getCurrentAxis (dRect *axis)
{
	axis->xFrom=diag->xFrom;
	axis->xTo=diag->xTo;
	axis->yFrom=diag->yFrom;
	axis->yTo=diag->yTo;
}


void DIAGRAM_loadAxisBoundsFromDiag(void) {
	SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
						VAL_BOTTOM_XAXIS, VAL_MANUAL, diag->xFrom,
						diag->xTo);
	SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
						VAL_LEFT_YAXIS, VAL_MANUAL, diag->yFrom,
						diag->yTo);
}



void DIAGRAM_saveCursorsPositionsInDiag () {
	GetGraphCursor(panelDiagram,DIAGRAM_GRAPH,1,&diag->cursorX1,&diag->cursorY1);
	GetGraphCursor(panelDiagram,DIAGRAM_GRAPH,2,&diag->cursorX2,&diag->cursorY2);
}
double saturate(double a, double b, double c) {
	if(b>c) return c;
	if(b<a) return a;
	else return b;
}

void DIAGRAM_restoreCursorsPositions () {
	SetGraphCursor(panelDiagram,DIAGRAM_GRAPH,1,saturate(diag->xFrom,diag->cursorX1,diag->xTo),saturate(diag->yFrom,diag->cursorY1,diag->yTo));
	SetGraphCursor(panelDiagram,DIAGRAM_GRAPH,2,saturate(diag->xFrom,diag->cursorX2,diag->xTo),saturate(diag->yFrom,diag->cursorY2,diag->yTo)); 
}



void DIAGRAM_zoomOnRect (dRect *target) {
	int i;
	dRect r = {0,0,0,0};
	dRect current = {0,0,0,0};
	
	if (target == NULL) return;
	
	DIAGRAM_getCurrentAxis(&current);
	for(i=0;i<N_ZOOM_STEPS;i++) {
		diag->xFrom = current.xFrom + (target->xFrom - current.xFrom) * (1.0*i)/(N_ZOOM_STEPS-1);
		diag->xTo   = current.xTo   + (target->xTo   - current.xTo  ) * (1.0*i)/(N_ZOOM_STEPS-1);
		diag->yFrom = current.yFrom + (target->yFrom - current.yFrom) * (1.0*i)/(N_ZOOM_STEPS-1);
		diag->yTo   = current.yTo   + (target->yTo   - current.yTo  ) * (1.0*i)/(N_ZOOM_STEPS-1);
		DIAGRAM_loadAxisBoundsFromDiag ();
		DIAGRAM_restoreCursorsPositions ();
		RefreshGraph (panelDiagram, DIAGRAM_GRAPH);
		//DIAGRAM_displayPanel(activeSession());
		Delay (0.05);
	//	 
	}
//	DIAGRAM_restoreCursorsPositions ();
	DIAGRAM_displayPanel(activeSession());
/*	
	SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
						VAL_BOTTOM_XAXIS, VAL_MANUAL,
						diag->zoomRegion.xFrom, diag->zoomRegion.xTo);
	SetAxisScalingMode (panelDiagram, DIAGRAM_GRAPH,
						VAL_LEFT_YAXIS, VAL_MANUAL,
						diag->zoomRegion.yFrom, diag->zoomRegion.yTo);
	DIAGRAM_displayPanel(activeSession());	   */
	}

dRect* DIAGRAM_activeBoundingBox(void) {
	static dRect bb={0,0,0,0};
	bb.xFrom = diag->xFrom;
	bb.yFrom = diag->yFrom;
	bb.xTo = diag->xTo;
	bb.yTo=diag->yTo;
	return &bb;
}

/*
int isEqual(dRect* r1,dRect* r2) {
	if(r1->xFrom!=r2->xFrom)
		return 0;
	if(r1->yFrom!=r2->yFrom)
		return 0;
	if(r1->xTo!=r2->xTo)
		return 0;
	if(r1->yTo!=r2->yTo)
		return 0;
	return 1;
}
*/		  
		  
int DIAGRAM_RunPopupMenu (int panelDiagram,int top,
						  int left) {
	int choice;
	
	SetMenuBarAttribute (menuDiagram, DIAGMENU_DMENU_BACK, ATTR_DIMMED,
						 ListNumItems(diag->lZooms) == 0);
	choice = RunPopupMenu (menuDiagram, DIAGMENU_DMENU, panelDiagram,
						   top, left, 0, 0, 0, 0);
	switch (choice) {
		case DIAGMENU_DMENU_ZOOM:
		//	DIAGRAM_disableAutoscale();
		//	GetGraphCursor (panelDiagram, DIAGRAM_GRAPH, 1, &X1, &Y1);
		//	GetGraphCursor (panelDiagram, DIAGRAM_GRAPH, 2, &X2, &Y2);
			DIAGRAM_saveCursorsPositionsInDiag ();   
			DIAGRAM_setZoomRegionAccordingToCursors();
			
			if(!dRect_isEqual( DIAGRAM_activeBoundingBox(), &diag->zoomRegion)) {
				DIAGRAM_storeZoomRegion ( DIAGRAM_activeBoundingBox());
//				DIAGRAM_copyRect(&(diag->lastZoomRegion),DIAGRAM_activeBoundingBox());
				if (diag->autoscale)
					DIAGRAM_switchAutoscale ();
				DIAGRAM_zoomOnRect( &diag->zoomRegion);
				DIAGRAM_updateNumericBoxesValues();
				}
			break;
		case DIAGMENU_DMENU_BACK:
			//DIAGRAM_disableAutoscale();
			DIAGRAM_zoomOnRect( DIAGRAM_recallZoomRegion () );
			DIAGRAM_updateNumericBoxesValues();
			break;
	}	
	return 0;					  
}


int CVICALLBACK DIAGRAM_callback_graph (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int choice;
	switch (event)
		{
		case EVENT_VAL_CHANGED:
			//w = GRAPH_getWindowFromPanelHandle (panelDiagram, DIAGRAM_GRAP
			break;
		case EVENT_RIGHT_CLICK:
			DIAGRAM_RunPopupMenu (panelDiagram, eventData1,
						  eventData2);
			break;
		}
	return 0;
}


void DIAGRAM_autoScaleDiag(void) {
	
	t_session* s;
	s=activeSession();
	
	diag->xFrom = s->curveStart_us;
	diag->xTo   = s->curveEnd_us	  ;
	diag->yFrom = diag->DEFAULT_yMin;
	diag->yTo   = diag->DEFAULT_yMax;
}

void DIAGRAM_updateButtonAutoScale(void) {
	SetCtrlVal (panelDiagram, DIAGRAM_RADIOBUTTON_autoScale,
				diag->autoscale);
}

void DIAGRAM_switchAutoscale(void) {
	diag->autoscale = !diag->autoscale;
	DIAGRAM_updateButtonAutoScale();
	
	if(diag->autoscale) {
		DIAGRAM_autoScaleDiag();
		DIAGRAM_loadAxisBoundsFromDiag();
		DIAGRAM_updateNumericBoxesValues();
		}
	SetCtrlAttribute (panelDiagram, DIAGRAM_NUMERIC_yMin,
					  ATTR_DIMMED, diag->autoscale);
	SetCtrlAttribute(panelDiagram,DIAGRAM_NUMERIC_yMax,ATTR_DIMMED,diag->autoscale);
	SetCtrlAttribute(panelDiagram,DIAGRAM_NUMERIC_xMin,ATTR_DIMMED,diag->autoscale);
	SetCtrlAttribute(panelDiagram,DIAGRAM_NUMERIC_xMax,ATTR_DIMMED,diag->autoscale);
}



int CVICALLBACK DIAGRAM_callback_parameterChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
	double xMin,xMax,yMin,yMax;
	switch (event)
		{
		case EVENT_COMMIT:
			switch(control)   {
				case DIAGRAM_RADIOBUTTON_autoScale:
					//DIAGRAM_setAxisScaling();
					DIAGRAM_switchAutoscale();
					DIAGRAM_plot(activeSession()); 
					RefreshGraph(panelDiagram,DIAGRAM_GRAPH);
					//DIAGRAM_updateDiagBoundingBox();
					break;
				case DIAGRAM_RADIOBUTTON_pulses:
					diag->showPulses=!diag->showPulses;
					DIAGRAM_plot(activeSession());
					RefreshGraph(panelDiagram,DIAGRAM_GRAPH); 
					break; 
				/*case DIAGRAM_BINARYSWITCH_place:
					diag->placePulses=!diag->placePulses;
					break;  */
				case DIAGRAM_RADIOBUTTON_killer1:
					diag->killer[0]=!diag->killer[0];
					DIAGRAM_plot(activeSession());
					RefreshGraph(panelDiagram,DIAGRAM_GRAPH);
					break;
				case DIAGRAM_RADIOBUTTON_killer2:
					diag->killer[1]=!diag->killer[1];
					DIAGRAM_plot(activeSession());
					RefreshGraph(panelDiagram,DIAGRAM_GRAPH);
					break;
				case DIAGRAM_NUMERIC_xMax :	
				case DIAGRAM_NUMERIC_xMin :
				case DIAGRAM_NUMERIC_yMin :
				case DIAGRAM_NUMERIC_yMax :
					GetCtrlVal (panelDiagram, DIAGRAM_NUMERIC_xMin, &diag->xFrom);
					GetCtrlVal (panelDiagram, DIAGRAM_NUMERIC_xMax, &diag->xTo);
					GetCtrlVal (panelDiagram, DIAGRAM_NUMERIC_yMin, &diag->yFrom);
					GetCtrlVal (panelDiagram, DIAGRAM_NUMERIC_yMax, &diag->yTo);
					DIAGRAM_loadAxisBoundsFromDiag();
					DIAGRAM_plot(activeSession());
					RefreshGraph(panelDiagram,DIAGRAM_GRAPH);
					break;
				case DIAGRAM_NUMERIC_sweepPoint :
					DIAGRAM_setBoundsToSweepPoints();
					GetCtrlVal (panelDiagram, DIAGRAM_NUMERIC_sweepPoint, &diag->sweepPoint);
					DIAGRAM_plot(activeSession());
					RefreshGraph(panelDiagram,DIAGRAM_GRAPH);
					break;
				case DIAGRAM_RADIOBUTTON_velocity :
					diag->velocityUncertainty = !diag->velocityUncertainty;
					DIAGRAM_plot(activeSession());
					RefreshGraph(panelDiagram,DIAGRAM_GRAPH);
					break;
				}	
		 	break;
	} 
	return 0;
}


int CVICALLBACK DIAGRAM_PRINT_panelCallback  (int panel, int event,void *callbackData,
		int eventData1, int eventData2) {

	switch (event)
		{
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			SetPanelAttribute (panelDiagramPreview, ATTR_VISIBLE, 0);
			break;
		}
	return 0;	
		
}

int CVICALLBACK DIAGRAM_ERR_callback_panel (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			
			break;
		}
	return 0;
}

int CVICALLBACK DIAGRAM_ERR_callback_close (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			HidePanel (panelDiagramError);   
			break;
		}
	return 0;
}

void DIAGRAM_makeLittleChangesBeforePrinting(void) {
	int width,height;
	SetCtrlAttribute (panelDiagramPreview, DIAG_PRINT_GRAPH,
					  ATTR_NUM_CURSORS, 0);
	SetCtrlAttribute (panelDiagramPreview, DIAG_PRINT_GRAPH,
					  ATTR_PLOT_BGCOLOR, VAL_WHITE);
	GetCtrlAttribute (panelDiagramPreview, DIAG_PRINT_GRAPH,
					  ATTR_WIDTH, &width);
	GetCtrlAttribute (panelDiagramPreview, DIAG_PRINT_GRAPH,
					  ATTR_HEIGHT, &height);
	SetPanelAttribute (panelDiagramPreview, ATTR_WIDTH, width);
	SetPanelAttribute (panelDiagramPreview, ATTR_HEIGHT, height+45);
	SetCtrlAttribute (panelDiagramPreview, DIAG_PRINT_GRAPH,
					  ATTR_LEFT, 0);
	SetCtrlAttribute (panelDiagramPreview, DIAG_PRINT_GRAPH,
					  ATTR_TOP, 0);
	//button print
	SetCtrlAttribute (panelDiagramPreview,
					  DIAG_PRINT_COMMANDBUTTON_abort, ATTR_TOP,
					  ctrlBottom(panelDiagramPreview, DIAG_PRINT_GRAPH)+5);
	SetCtrlAttribute (panelDiagramPreview,
					  DIAG_PRINT_COMMANDBUTTON_abort, ATTR_LEFT,
					  width-ctrlWidth(panelDiagramPreview,DIAG_PRINT_COMMANDBUTTON_abort)-5);
	//button confirm
	SetCtrlAttribute (panelDiagramPreview,
					  DIAG_PRINT_COMMANDBUTTON_confirm, ATTR_TOP,
					  ctrlBottom(panelDiagramPreview, DIAG_PRINT_GRAPH)+5);    
	SetCtrlAttribute (panelDiagramPreview,
					  DIAG_PRINT_COMMANDBUTTON_confirm, ATTR_LEFT,
					  width-ctrlWidth(panelDiagramPreview,DIAG_PRINT_COMMANDBUTTON_abort)
					  -ctrlWidth(panelDiagramPreview,DIAG_PRINT_COMMANDBUTTON_confirm)-10);	
}

int CVICALLBACK COMMANDBUTTON_print_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	
	switch (event)
		{
		case EVENT_COMMIT:
		//	PrintPanel (panelDiagram, "", 1, VAL_FULL_PANEL, 1);
			//PrintCtrl (panelDiagram, DIAGRAM_GRAPH, "", 1, 0);
		//	SetPanelAttribute (panelDiagramPreview, ATTR_VISIBLE, 1);
		//	SetPanelSize (panelDiagramPreview, 300, 300);
			DiscardCtrl (panelDiagramPreview, DIAG_PRINT_GRAPH);
			DIAG_PRINT_GRAPH = DuplicateCtrl (panelDiagram, DIAGRAM_GRAPH,
											  panelDiagramPreview,
											  "preview", 0, 0);
			DIAGRAM_makeLittleChangesBeforePrinting();
			DisplayPanel (panelDiagramPreview);
			break;
		}
	return 0;
}

int CVICALLBACK COMMANDBUTTON_abort_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			SetPanelAttribute (panelDiagramPreview, ATTR_VISIBLE, 0);
			break;
		}
	return 0;
}

int CVICALLBACK COMMANDBUTTON_confirm_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			PrintCtrl (panelDiagramPreview, DIAG_PRINT_GRAPH, "", 1, 1);
			break;
		}
	return 0;
}
