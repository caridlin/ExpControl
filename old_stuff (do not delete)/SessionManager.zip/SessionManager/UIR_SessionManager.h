/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2006. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  ATOMS                           1       /* callback function: ATOMS_CALLBACK_panel */
#define  ATOMS_NUMERIC_number            2       /* callback function: Atom_ParameterChanged */
#define  ATOMS_RADIOBUTTON_active        3       /* callback function: Atom_ParameterChanged */
#define  ATOMS_STRING_name               4       /* callback function: Atom_ParameterChanged */
#define  ATOMS_BTN_newAtom               5       /* callback function: ATOMS_BTN_New */
#define  ATOMS_BTN_importAtom            6       /* callback function: ATOMS_BTN_import */
#define  ATOMS_BTN_duplicateAtom         7       /* callback function: ATOMS_BTN_duplicate */
#define  ATOMS_BTN_deleteAtom            8       /* callback function: ATOMS_BTN_delete */
#define  ATOMS_NUMERIC_total             9       /* callback function: Atom_ParameterChanged */
#define  ATOMS_TABLE                     10      /* callback function: ATOMS_TABLE_edited */
#define  ATOMS_CANVAS                    11
#define  ATOMS_COMMANDBT_changeRef       12      /* callback function: ATOMS_TIMEREF_change */
#define  ATOMS_BUTTON_createName         13      /* callback function: ATOMS_BTN_createName */
#define  ATOMS_CHECKBOX_multiple         14      /* callback function: Atom_ParameterChanged */
#define  ATOMS_NUMERIC_multiplicity      15      /* callback function: Atom_ParameterChanged */
#define  ATOMS_NUMERIC_delai             16      /* callback function: Atom_ParameterChanged */
#define  ATOMS_TEXTMSG_us                17

#define  ATOMS_CAV                       2
#define  ATOMS_CAV_GRAPH                 2
#define  ATOMS_CAV_NUMERIC_startCavity   3       /* callback function: Atom_ParameterChanged */
#define  ATOMS_CAV_NUMERIC_centerCavity  4       /* callback function: Atom_ParameterChanged */
#define  ATOMS_CAV_NUMERIC_endCavity     5       /* callback function: Atom_ParameterChanged */
#define  ATOMS_CAV_TEXTMSG               6
#define  ATOMS_CAV_RING_referencePos     7       /* callback function: ATOMS_CAVITY_parameterChanged */
#define  ATOMS_CAV_TEXTMSG_invalid       8
#define  ATOMS_CAV_NUMERIC_killerStart   9       /* callback function: ATOMS_CAVITY_parameterChanged */
#define  ATOMS_CAV_BTN_editKiller        10      /* callback function: ATOMS_CAVITY_editKiller */
#define  ATOMS_CAV_BTN_importParameters  11      /* callback function: ATOMS_CAVITY_importKillerParameters */
#define  ATOMS_CAV_TEXTMSG_10            12
#define  ATOMS_CAV_TEXTMSG_9             13
#define  ATOMS_CAV_TEXTMSG_8             14
#define  ATOMS_CAV_NUMERIC_defaultV      15
#define  ATOMS_CAV_NUMERIC_defaultDet    16
#define  ATOMS_CAV_TEXTMSG_defaultDet    17
#define  ATOMS_CAV_TEXTMSG_default1      18
#define  ATOMS_CAV_TEXTMSG_default2      19
#define  ATOMS_CAV_RADIOBUTTON_active    20      /* callback function: ATOMS_CAVITY_parameterChanged */
#define  ATOMS_CAV_TEXTMSG_2             21

#define  ATOMS_CIRC                      3
#define  ATOMS_CIRC_NUMERIC_time52d      2       /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_NUMERIC_timeLaserOP  3       /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_NUMERIC_timeLaser2   4       /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_NUMERIC_timeLaser1   5       /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_TEXTMSG_us2_4        6
#define  ATOMS_CIRC_TEXTMSG_us2_5        7
#define  ATOMS_CIRC_TEXTMSG_time3        8
#define  ATOMS_CIRC_TEXTMSG_us2_3        9
#define  ATOMS_CIRC_TEXTMSG_time2        10
#define  ATOMS_CIRC_NUMERIC_durationOP   11      /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_NUMERIC_duration52d  12      /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_TEXTMSG_duration3    13
#define  ATOMS_CIRC_TEXTMSG_us2_2        14
#define  ATOMS_CIRC_NUMERIC_durationL2   15      /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_TEXTMSG_us2_6        16
#define  ATOMS_CIRC_TEXTMSG_duration2    17
#define  ATOMS_CIRC_TEXTMSG_17           18
#define  ATOMS_CIRC_RADIOBUTTON_alwaysOn3 19     /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_NUMERIC_durationL1   20      /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_TEXTMSG_16           21
#define  ATOMS_CIRC_TEXTMSG_19           22
#define  ATOMS_CIRC_TEXTMSG_us2          23
#define  ATOMS_CIRC_RADIOBUTTON_alwaysOn2 24     /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_NUMERIC_trigCircRamp 25      /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_NUMERIC_trigRFcirc   26      /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_TEXTMSG_52d          27
#define  ATOMS_CIRC_TEXTMSG_18           28
#define  ATOMS_CIRC_TEXTMSG              29
#define  ATOMS_CIRC_RADIOBUTTON_always   30      /* callback function: Atom_ParameterChanged */
#define  ATOMS_CIRC_DECORATION           31
#define  ATOMS_CIRC_TEXTMSG_20           32
#define  ATOMS_CIRC_DECORATION_2         33
#define  ATOMS_CIRC_DECORATION_3         34
#define  ATOMS_CIRC_DECORATION_4         35
#define  ATOMS_CIRC_DECORATION_5         36

#define  ATOMS_DET                       4
#define  ATOMS_DET_RING_detectionParams  2       /* callback function: ATOMS_DETECTOR_parameterChanged */
#define  ATOMS_DET_RING_voltDet2         3       /* callback function: Atom_ParameterChanged */
#define  ATOMS_DET_CHECKBOX_detectAtom   4       /* callback function: Atom_ParameterChanged */
#define  ATOMS_DET_COMMANDBUTTON_edit    5       /* callback function: DETECTION_callback_edit */
#define  ATOMS_DET_RING_referencePos     6       /* callback function: Atom_ParameterChanged */
#define  ATOMS_DET_NUMERIC_time          7       /* callback function: Atom_ParameterChanged */
#define  ATOMS_DET_TEXTMSG_setVoltage    8
#define  ATOMS_DET_DECORATION            9
#define  ATOMS_DET_CHECKBOX_useDetTransf 10      /* callback function: ATOMS_DETECTOR_parameterChanged */
#define  ATOMS_DET_DECORATION_2          11
#define  ATOMS_DET_CHECKBOX_setDetLevel  12      /* callback function: ATOMS_DETECTOR_parameterChanged */
#define  ATOMS_DET_TEXTMSG               13

#define  ATOMS_EVTS                      5
#define  ATOMS_EVTS_RADIOBUTTON_active   2       /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_STRING_name          3       /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_RINGSLIDE_deviceType 4       /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_RING_digitalChannel  5       /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_RING_analogChannel   6       /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_TEXTMSG_pluseStart   7
#define  ATOMS_EVTS_NUMERIC_start        8       /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_RING_referencePos    9       /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_CHECKBOX_varyStart   10      /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_NUMERIC_startIncr    11      /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_NUMERIC_nPoints      12      /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_NUMERIC_durationFirst 13     /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_CHECKBOX_varyDuration 14     /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_NUMERIC_durationIncr 15      /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_NUMERIC_voltageFirst 16      /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_CHECKBOX_varyVoltage 17      /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_NUMERIC_voltageIncr  18      /* callback function: ATOMS_EVENTS_parameterChanged */
#define  ATOMS_EVTS_LISTBOX_events       19      /* callback function: ATOMS_EVENTS_listboxClicked */
#define  ATOMS_EVTS_BTN_newEvent         20      /* callback function: ATOMS_EVENTS_newEvent */
#define  ATOMS_EVTS_BTN_deleteEvent      21      /* callback function: ATOMS_EVENTS_deleteEvent */
#define  ATOMS_EVTS_BTN_importEvent      22      /* callback function: ATOMS_EVENTS_importEvent */
#define  ATOMS_EVTS_NUMERIC_voltageLast  23
#define  ATOMS_EVTS_NUMERIC_durationLast 24
#define  ATOMS_EVTS_NUMERIC_timeLast     25
#define  ATOMS_EVTS_TEXTMSG_voltage      26
#define  ATOMS_EVTS_TEXTMSG_pulseDuration 27
#define  ATOMS_EVTS_TEXTMSG_incr3        28
#define  ATOMS_EVTS_TEXTMSG_incr2        29
#define  ATOMS_EVTS_TEXTMSG_voltageLast  30
#define  ATOMS_EVTS_TEXTMSG_durationLast 31
#define  ATOMS_EVTS_TEXTMSG_timeLast     32
#define  ATOMS_EVTS_TEXTMSG_incr1        33
#define  ATOMS_EVTS_TEXTMSG_alwaysOn     34
#define  ATOMS_EVTS_TEXTMSG_alwaysOff    35
#define  ATOMS_EVTS_RING_eventStyle      36      /* callback function: ATOMS_EVENTS_parameterChanged */

#define  ATOMS_STAT                      6
#define  ATOMS_STAT_RING_state           2       /* callback function: Atom_ParameterChanged */
#define  ATOMS_STAT_NUMERIC_purifStart_g 3       /* callback function: Atom_ParameterChanged */
#define  ATOMS_STAT_NUMERIC_purifDur_g   4       /* callback function: Atom_ParameterChanged */
#define  ATOMS_STAT_NUMERIC_purifStart_e 5       /* callback function: Atom_ParameterChanged */
#define  ATOMS_STAT_NUMERIC_purifDur_e   6       /* callback function: Atom_ParameterChanged */
#define  ATOMS_STAT_NUMERIC_purifStart_a 7       /* callback function: Atom_ParameterChanged */
#define  ATOMS_STAT_TEXTMSG_start_e      8
#define  ATOMS_STAT_TEXTMSG_dur_e        9
#define  ATOMS_STAT_TEXTMSG_start_g      10
#define  ATOMS_STAT_TEXTMSG_13           11
#define  ATOMS_STAT_TEXTMSG_dur_g        12
#define  ATOMS_STAT_TEXTMSG_time3        13
#define  ATOMS_STAT_TEXTMSG              14
#define  ATOMS_STAT_TEXTMSG_14           15

#define  ATOMS_VEL                       7
#define  ATOMS_VEL_BTN_velocitySelection 2       /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_TEXTMSG_ms            3
#define  ATOMS_VEL_RING_frequencyAll     4       /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_RING_powerAll         5       /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_RING_frequency        6       /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_RING_power            7       /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_RING_referencePos     8       /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_TEXTMSG_duration_2    9
#define  ATOMS_VEL_TEXTMSG_depumper2     10
#define  ATOMS_VEL_NUMERIC_durationDep   11      /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_TEXTMSG_duration      12
#define  ATOMS_VEL_TEXTMSG_repumper      13
#define  ATOMS_VEL_NUMERIC_durationRep   14      /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_NUMERIC_depStart      15      /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_TEXTMSG_time1         16
#define  ATOMS_VEL_NUMERIC_timeRep       17      /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_TEXTMSG_calcTime      18
#define  ATOMS_VEL_NUMERIC_repStart      19      /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_RADIOBUTTON_always    20      /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_NUMERIC_spread        21      /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_NUMERIC_velocity      22      /* callback function: Atom_ParameterChanged */
#define  ATOMS_VEL_TEXTMSG_display_2     23
#define  ATOMS_VEL_TEXTMSG_display       24
#define  ATOMS_VEL_TEXTMSG_4             25
#define  ATOMS_VEL_TEXTMSG_ms_3          26
#define  ATOMS_VEL_TEXTMSG_ms_2          27
#define  ATOMS_VEL_TEXTMSG_2             28
#define  ATOMS_VEL_TEXTMSG_3             29
#define  ATOMS_VEL_TEXTMSG_repumper2     30
#define  ATOMS_VEL_TEXTMSG_calcTime_2    31
#define  ATOMS_VEL_TEXTMSG_depumper      32
#define  ATOMS_VEL_NUMERIC_spreadDoppler 33      /* callback function: Atom_ParameterChanged */

#define  AXIS                            8
#define  AXIS_STRING_xLabel              2
#define  AXIS_NUMERIC_xFrom              3       /* callback function: GRAPH_displayParametersChanged */
#define  AXIS_NUMERIC_xTo                4       /* callback function: GRAPH_displayParametersChanged */
#define  AXIS_CHECKBOX_xFromAuto         5       /* callback function: GRAPH_displayParametersChanged */
#define  AXIS_CHECKBOX_xToAuto           6       /* callback function: GRAPH_displayParametersChanged */
#define  AXIS_STRING_yLabel              7
#define  AXIS_NUMERIC_yFrom              8       /* callback function: GRAPH_displayParametersChanged */
#define  AXIS_NUMERIC_yTo                9       /* callback function: GRAPH_displayParametersChanged */
#define  AXIS_CHECKBOX_yFromAuto         10      /* callback function: GRAPH_displayParametersChanged */
#define  AXIS_CHECKBOX_yToAuto           11      /* callback function: GRAPH_displayParametersChanged */
#define  AXIS_TEXTMSG_3                  12
#define  AXIS_TEXTMSG_4                  13
#define  AXIS_TEXTMSG                    14
#define  AXIS_TEXTMSG_2                  15
#define  AXIS_RINGSLIDE_showCounts       16      /* callback function: GRAPH_displayParametersChanged */

#define  CIRC                            9

#define  CKILLER                         10

#define  CONFpos                         11
#define  CONFpos_NUMERIC_dummy           2       /* callback function: SCONFIG_editDistances */
#define  CONFpos_TEXTMSG                 3
#define  CONFpos_RING_reference          4       /* callback function: SCONFIG_referenceChanged */
#define  CONFpos_COMMANDBUTTON_pos2R     5       /* callback function: SCONFIG_setPositionsRamsey_CB */
#define  CONFpos_COMMANDBUTTON_pos3R     6       /* callback function: SCONFIG_setPositionsRamsey_CB */
#define  CONFpos_TEXTMSG_setPositions    7

#define  CONFrf                          12
#define  CONFrf_NUMERIC_rf1              2       /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rf1_v            3       /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rf2              4       /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rf2_v            5       /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rf3              6       /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rf3_v            7       /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rf4              8       /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rf4_v            9       /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rfPower1         10      /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rfPower2         11      /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rfPower3         12      /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_NUMERIC_rfPower4         13      /* callback function: SCONFIG_rfParametersEdited */
#define  CONFrf_TEXTMSG_MHz              14
#define  CONFrf_TEXTMSG_2                15
#define  CONFrf_TEXTMSG_MHz_2            16
#define  CONFrf_TEXTMSG_MHz_3            17
#define  CONFrf_TEXTMSG_MHz_4            18
#define  CONFrf_TEXTMSG                  19
#define  CONFrf_TEXTMSG_4                20
#define  CONFrf_TEXTMSG_5                21
#define  CONFrf_TEXTMSG_6                22
#define  CONFrf_TEXTMSG_7                23

#define  CORR_AT                         13
#define  CORR_AT_RING_level2             2       /* callback function: PLOTITEM_edit */
#define  CORR_AT_RING_level1             3       /* callback function: PLOTITEM_edit */
#define  CORR_AT_RING_atom               4       /* callback function: PLOTITEM_edit */
#define  CORR_AT_NUMERIC_multiple        5       /* callback function: PLOTITEM_edit */

#define  COUNTS                          14      /* callback function: COUNTS_panelCallback */
#define  COUNTS_TREE                     2

#define  CURSORS                         15
#define  CURSORS_NUMERIC_cursorDeltaY    2
#define  CURSORS_NUMERIC_cursorDeltaX    3
#define  CURSORS_NUMERIC_cursorY2        4
#define  CURSORS_NUMERIC_cursorX2        5
#define  CURSORS_NUMERIC_cursorY1        6
#define  CURSORS_NUMERIC_cursorX1        7
#define  CURSORS_TEXTMSG_difference      8
#define  CURSORS_NUMERIC_nCursors        9       /* callback function: GRAPH_displayParametersChanged */
#define  CURSORS_TEXTMSG_Cursor1         10
#define  CURSORS_TEXTMSG_Cursor2         11
#define  CURSORS_TEXTMSG_delta1          12
#define  CURSORS_TEXTMSG_delta2          13

#define  CURVE2D                         16      /* callback function: CURVE2D_callbackPanel */
#define  CURVE2D_GRAPH                   2       /* callback function: GRAPH_graph2D_callback */
#define  CURVE2D_BUTTON_interpolate2D    3       /* callback function: CURVE2D_showPartsOfExperiment_CB */
#define  CURVE2D_RADIOBUTTON_showParts   4       /* callback function: CURVE2D_showPartsOfExperiment_CB */

#define  CURVES                          17      /* callback function: CURVES_panelCallback */
#define  CURVES_TREE                     2       /* callback function: CURVES_callback_Tree */
#define  CURVES_CANVAS                   3
#define  CURVES_COMMANDBUTTON_close      4       /* callback function: CURVES_callback_Close */
#define  CURVES_STRING_curve             5
#define  CURVES_NUMERIC_nCurves          6
#define  CURVES_NUMERIC_curve            7       /* callback function: CURVES_callback_curveNrChanged */
#define  CURVES_STRING_window            8
#define  CURVES_TEXTMSG_point            9
#define  CURVES_STRING_value             10

#define  CUSTOM1                         18      /* callback function: CUSTOM1_panel_callback */
#define  CUSTOM1_TEXTBOX                 2
#define  CUSTOM1_COMMANDBUTTON_abort     3       /* callback function: CUSTOM1_abort_callback */
#define  CUSTOM1_COMMANDBUTTON           4       /* callback function: CUSTOM1_startEvaluation_callback */

#define  CUSTOM2                         19      /* callback function: CUSTOM1_panel_callback */
#define  CUSTOM2_TEXTBOX                 2
#define  CUSTOM2_COMMANDBUTTON_abort     3       /* callback function: CUSTOM2_abortEvaluation_callback */
#define  CUSTOM2_COMMANDBUTTON           4       /* callback function: CUSTOM2_startEvaluation_callback */
#define  CUSTOM2_GRAPH4                  5
#define  CUSTOM2_GRAPH3                  6
#define  CUSTOM2_GRAPH1                  7
#define  CUSTOM2_NUMERIC_minCounts       8       /* callback function: CUSTOM2_nCurve_callback */
#define  CUSTOM2_NUMERIC_windowSize      9       /* callback function: CUSTOM2_nCurve_callback */
#define  CUSTOM2_NUMERIC_nCurve          10      /* callback function: CUSTOM2_nCurve_callback */
#define  CUSTOM2_RING_dataSet            11      /* callback function: CUSTOM2_nCurve_callback */
#define  CUSTOM2_TEXTMSG                 12

#define  DETECTORS                       20
#define  DETECTORS_TABLE_levelNames      2       /* callback function: DETECTORS_changeLevels */
#define  DETECTORS_NUMERIC_nLevels       3       /* callback function: DETECTORS_changeLevels */
#define  DETECTORS_BTN_newParameters     4       /* callback function: DETECTORS_new */
#define  DETECTORS_BTN_deleteParameters  5       /* callback function: DETECTORS_delete */
#define  DETECTORS_BTN_importParameters  6       /* callback function: DETECTORS_import */
#define  DETECTORS_RING_referencePos_2   7       /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_RING_referencePos     8       /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_NUMERIC_triggerRamp   9       /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_STRING_name           10      /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_TEXTMSG_ramp2         11
#define  DETECTORS_NUMERIC_rampStart     12      /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_NUMERIC_rampStop      13      /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_NUMERIC_rampDuration  14      /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_NUMERIC_timeStart     15      /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_NUMERIC_timeEnd       16      /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_TEXTMSG_ramp          17
#define  DETECTORS_TEXTMSG_start1        18
#define  DETECTORS_TEXTMSG_stop1         19
#define  DETECTORS_TEXTMSG_start4        20
#define  DETECTORS_TEXTMSG_end4          21
#define  DETECTORS_TEXTMSG_dur1          22
#define  DETECTORS_RADIOBUTTON_det2      23      /* callback function: DETECTORS_detectorChanged */
#define  DETECTORS_TEXTMSG_roof          24
#define  DETECTORS_RADIOBUTTON_det1      25      /* callback function: DETECTORS_detectorChanged */
#define  DETECTORS_TEXTMSG_flat          26
#define  DETECTORS_TABLE_windows         27      /* callback function: DETECTORS_parameterChanged */
#define  DETECTORS_DECORATION_3          28
#define  DETECTORS_TEXTMSG               29
#define  DETECTORS_TEXTMSG_warning1a     30
#define  DETECTORS_DECORATION_7          31
#define  DETECTORS_TREE_parameterSets    32      /* callback function: DETECTORS_listboxClicked */
#define  DETECTORS_COMMANDBUTTON_done    33      /* callback function: DETECTION_callback_done */
#define  DETECTORS_TEXTMSG_warning2      34

#define  DIAG_ERR                        21      /* callback function: DIAGRAM_ERR_callback_panel */
#define  DIAG_ERR_TEXTBOX_error          2
#define  DIAG_ERR_COMMANDBUTTON_close    3       /* callback function: DIAGRAM_ERR_callback_close */

#define  DIAG_MENU                       22

#define  DIAG_PRINT                      23      /* callback function: DIAGRAM_PRINT_panelCallback */
#define  DIAG_PRINT_COMMANDBUTTON_confirm 2      /* callback function: COMMANDBUTTON_confirm_callback */
#define  DIAG_PRINT_COMMANDBUTTON_abort  3       /* callback function: COMMANDBUTTON_abort_callback */

#define  DIAGRAM                         24      /* callback function: DIAGRAM_panelCallback */
#define  DIAGRAM_COMMANDBUTTON_update    2       /* callback function: DIAGRAM_callback_update */
#define  DIAGRAM_COMMANDBUTTON_done      3       /* callback function: DIAGRAM_callback_done */
#define  DIAGRAM_GRAPH                   4       /* callback function: DIAGRAM_callback_graph */
#define  DIAGRAM_NUMERIC_xMax            5       /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_NUMERIC_xMin            6       /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_NUMERIC_yMin            7       /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_NUMERIC_yMax            8       /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_RADIOBUTTON_autoScale   9       /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_RADIOBUTTON_pulses      10      /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_RADIOBUTTON_showText    11      /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_RADIOBUTTON_killer1     12      /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_RADIOBUTTON_killer2     13      /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_NUMERIC_sweepPoint      14      /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_RADIOBUTTON_velocity    15      /* callback function: DIAGRAM_callback_parameterChanged */
#define  DIAGRAM_COMMANDBUTTON_print     16      /* callback function: COMMANDBUTTON_print_callback */

#define  DIR                             25
#define  DIR_TREE                        2

#define  ERRPANEL                        26
#define  ERRPANEL_COMMANDBUTTON_done     2       /* callback function: ERROR_callback_done */
#define  ERRPANEL_TEXTBOX                3

#define  EVENTS                          27      /* callback function: EVENT_panelCallback */
#define  EVENTS_COMMANDBUTTON_Update     2       /* callback function: EVENTS_callback_update */
#define  EVENTS_COMMANDBUTTON_Done       3       /* callback function: EVENT_done */
#define  EVENTS_TREE                     4       /* callback function: EVENTS_treeClicked */

#define  FCRITERION                      28
#define  FCRITERION_DECORATION           2
#define  FCRITERION_RING1                3       /* callback function: FILTER_ParameterEdited */
#define  FCRITERION_RING2                4       /* callback function: FILTER_ParameterEdited */
#define  FCRITERION_RINGSLIDE_logic      5       /* callback function: FILTER_ParameterEdited */
#define  FCRITERION_NUMERIC_minCounts    6       /* callback function: FILTER_ParameterEdited */
#define  FCRITERION_NUMERIC_maxCounts    7       /* callback function: FILTER_ParameterEdited */
#define  FCRITERION_NUMERIC_detector     8       /* callback function: FILTER_ParameterEdited */
#define  FCRITERION_RADIOBUTTON_active   9       /* callback function: FILTER_ParameterEdited */
#define  FCRITERION_RADIOBUTTON_and      10      /* callback function: FILTER_ParameterEdited */
#define  FCRITERION_RADIOBUTTON_hasTo    11      /* callback function: FILTER_ParameterEdited */
#define  FCRITERION_TEXTMSG_N            12
#define  FCRITERION_STRING_editList      13
#define  FCRITERION_COMMANDBUTTON_edit   14      /* callback function: FILTER_editListTimeIntervals_CB */

#define  FILTERS                         29
#define  FILTERS_BTN_deleteFilter        2       /* callback function: FILTER_deleteFilter_CB */
#define  FILTERS_BTN_newFilter           3       /* callback function: FILTER_newFilter_CB */
#define  FILTERS_STRING_name             4       /* callback function: FILTER_ParameterEdited */
#define  FILTERS_LISTBOX_filters         5       /* callback function: FILTERS_listboxCLicked */
#define  FILTERS_NUMERIC_nCriteria       6       /* callback function: FILTER_ParameterEdited */
#define  FILTERS_STRING_usedByPlotitem   7
#define  FILTERS_COMMANDBUTTON_listTI    8       /* callback function: FILTER_displayListOfTimeIntervals_CB */
#define  FILTERS_COMMANDBUTTON_calcAll   9       /* callback function: PLOTITEM_calculateAll_CB */
#define  FILTERS_RING_otherDataFilter    10      /* callback function: FILTER_ParameterEdited */

#define  GRAPH                           30      /* callback function: GRAPH_panelCallback */
#define  GRAPH_NUMERICSLIDE_number       2
#define  GRAPH_GRAPH                     3       /* callback function: GRAPH_graphCallback */
#define  GRAPH_LISTBOX_statusLine        4
#define  GRAPH_RUN                       5

#define  IMPORT_AT                       31
#define  IMPORT_AT_COMMANDBUTTON_abort   2       /* callback function: ATOMS_importAtoms_Done */
#define  IMPORT_AT_COMMANDBUTTON_done    3       /* callback function: ATOMS_importAtoms_Done */
#define  IMPORT_AT_LISTBOX_names         4

#define  IMPORT_DET                      32
#define  IMPORT_DET_COMMANDBUTTON_abort  2       /* callback function: SCONFIG_DETECTIONPAR_importButton */
#define  IMPORT_DET_COMMANDBUTTON_done   3       /* callback function: SCONFIG_DETECTIONPAR_importButton */
#define  IMPORT_DET_LISTBOX_names        4

#define  IMPORT_KIL                      33
#define  IMPORT_KIL_GRAPH                2
#define  IMPORT_KIL_COMMANDBUTTON_abort  3       /* callback function: ATOMS_CAVITY_importKillerParameters_Done */
#define  IMPORT_KIL_COMMANDBUTTON_done   4       /* callback function: ATOMS_CAVITY_importKillerParameters_Done */
#define  IMPORT_KIL_LISTBOX_names        5       /* callback function: ATOMS_CAVITY_importKillerParameters_selected */
#define  IMPORT_KIL_TEXTMSG_invalid      6

#define  KILLER                          34
#define  KILLER_GRAPH                    2
#define  KILLER_TABLE_points             3       /* callback function: ATOMS_KILLER_callback_table */
#define  KILLER_COMMANDBUTTON_done       4       /* callback function: ATOMS_KILLER_done */
#define  KILLER_COMMANDBUTTON_abort      5       /* callback function: ATOMS_KILLER_done */
#define  KILLER_NUMERIC_repetition       6       /* callback function: POINTS_processEvents_CB */
#define  KILLER_TEXTMSG_invalid          7
#define  KILLER_GRAPH_leCroy             8
#define  KILLER_NUMERIC_C                9
#define  KILLER_NUMERIC_A                10
#define  KILLER_NUMERIC_B                11
#define  KILLER_TEXTMSG_transferFct      12
#define  KILLER_NUMERIC_cavity           13
#define  KILLER_DECORATION               14
#define  KILLER_TEXTBOX_transferFunct    15

#define  MENUCURVE2                      35

#define  MENUCURVES                      36

#define  MENUGRA2D                       37

#define  MENUGRAPH                       38

#define  MINIRUN                         39
#define  MINIRUN_NUMERIC_run             2
#define  MINIRUN_NUMERIC_repetition      3

#define  MoreInterv                      40
#define  MoreInterv_COMPLEMENTARYINTERVAL 2      /* callback function: FILTER_ParameterEdited */
#define  MoreInterv_RING2_9              3       /* callback function: FILTER_ParameterEdited */
#define  MoreInterv_RADIOBUTTON_and_4    4       /* callback function: FILTER_ParameterEdited */
#define  MoreInterv_RING2_7              5       /* callback function: FILTER_ParameterEdited */
#define  MoreInterv_RADIOBUTTON_and_3    6       /* callback function: FILTER_ParameterEdited */
#define  MoreInterv_RING2_5              7       /* callback function: FILTER_ParameterEdited */
#define  MoreInterv_RADIOBUTTON_and_2    8       /* callback function: FILTER_ParameterEdited */
#define  MoreInterv_RING2_2              9       /* callback function: FILTER_ParameterEdited */
#define  MoreInterv_RADIOBUTTON_and      10      /* callback function: FILTER_ParameterEdited */
#define  MoreInterv_COMMANDBUTTON_close  11      /* callback function: panelMore_close_callback */

#define  OUTPUTS                         41
#define  OUTPUTS_STRING_name             2
#define  OUTPUTS_RADIOBUTTON_active      3       /* callback function: OUTPUTS_valueChanged_callback */
#define  OUTPUTS_BINARYSWITCH_onOff      4       /* callback function: OUTPUTS_valueChanged_callback */
#define  OUTPUTS_COMMANDBUTTON_done      5       /* callback function: OUTPUT_DIRECT_done_CB */
#define  OUTPUTS_TEXTMSG_DIGITAL         6
#define  OUTPUTS_DECORATION              7
#define  OUTPUTS_COMMANDBUTTON_manual    8       /* callback function: OUTPUTS_manuallyOperate_CB */

#define  PLOT_ARR                        42
#define  PLOT_ARR_NUMERIC_binStartTime   2       /* callback function: PLOTITEM_edit */
#define  PLOT_ARR_NUMERIC_binsize        3       /* callback function: PLOTITEM_edit */
#define  PLOT_ARR_TEXTMSG_endTime        4
#define  PLOT_ARR_TEXTMSG_times          5
#define  PLOT_ARR_NUMERIC_binEndTime     6       /* callback function: PLOTITEM_edit */
#define  PLOT_ARR_NUMERIC_nBins          7
#define  PLOT_ARR_RADIOBUTTON_auto       8       /* callback function: PLOTITEM_edit */
#define  PLOT_ARR_TEXTMSG_times2         9
#define  PLOT_ARR_TEXTMSG_arrTimes       10
#define  PLOT_ARR_TEXTMSG_startTime      11
#define  PLOT_ARR_DECORATION             12
#define  PLOT_ARR_TEXTMSG_binsize        13

#define  PLOT_CORR                       43
#define  PLOT_CORR_NUMERIC_nCorrAtoms    2       /* callback function: PLOTITEM_edit */
#define  PLOT_CORR_TEXTMSG_atom_2        3
#define  PLOT_CORR_TEXTMSG_atom          4
#define  PLOT_CORR_TEXTMSG_3             5
#define  PLOT_CORR_TEXTMSG_2             6
#define  PLOT_CORR_BUTTON_createFilters  7       /* callback function: PLOTITEM_createDataFilters_CB */

#define  PLOT_DISPL                      44
#define  PLOT_DISPL_RADIOBUTTON_setName  2       /* callback function: PLOTITEM_edit */
#define  PLOT_DISPL_RING_plotStyleCurrent 3      /* callback function: PLOTITEM_edit */
#define  PLOT_DISPL_RING_plotColorCurrent 4      /* callback function: PLOTITEM_edit */
#define  PLOT_DISPL_RING_plotStyle       5       /* callback function: PLOTITEM_edit */
#define  PLOT_DISPL_RING_plotColor       6       /* callback function: PLOTITEM_edit */
#define  PLOT_DISPL_TEXTMSG_3            7
#define  PLOT_DISPL_TEXTMSG_5            8
#define  PLOT_DISPL_DECORATION_5         9
#define  PLOT_DISPL_DECORATION_6         10
#define  PLOT_DISPL_COLORNUM_current     11
#define  PLOT_DISPL_COLORNUM             12
#define  PLOT_DISPL_TEXTMSG_6            13
#define  PLOT_DISPL_TEXTMSG_4            14
#define  PLOT_DISPL_STRING_windowName    15      /* callback function: PLOTITEM_edit */

#define  PLOT_MULT                       45
#define  PLOT_MULT_NUMERIC_nBinAtoms     2       /* callback function: PLOTITEM_edit */
#define  PLOT_MULT_RING_dataFilter       3       /* callback function: PLOTITEM_edit */
#define  PLOT_MULT_CHECKBOX_sumAllRuns   4       /* callback function: PLOTITEM_edit */

#define  PLOT_SAVE                       46
#define  PLOT_SAVE_RADIOBUTTON_saveTxt   2       /* callback function: PLOTITEM_edit */
#define  PLOT_SAVE_RADIOBUTTON_saveCurve 3       /* callback function: PLOTITEM_edit */
#define  PLOT_SAVE_TEXTMSG               4
#define  PLOT_SAVE_TEXTMSG_2             5
#define  PLOT_SAVE_RADIOBUTTON_keep      6       /* callback function: PLOTITEM_edit */
#define  PLOT_SAVE_DECORATION            7
#define  PLOT_SAVE_DECORATION_2          8

#define  PLOT_VEL                        47
#define  PLOT_VEL_NUMERIC_timeMultiply   2       /* callback function: PLOTITEM_edit */
#define  PLOT_VEL_NUMERIC_velocityStart  3       /* callback function: PLOTITEM_edit */
#define  PLOT_VEL_NUMERIC_velocityEnd    4       /* callback function: PLOTITEM_edit */
#define  PLOT_VEL_NUMERIC_velocityNPts   5       /* callback function: PLOTITEM_edit */
#define  PLOT_VEL_TEXTMSG_ms             6
#define  PLOT_VEL_DECORATION_2           7
#define  PLOT_VEL_DECORATION             8
#define  PLOT_VEL_TEXTMSG_ms_2           9
#define  PLOT_VEL_RADIOBUTTON_showParts  10      /* callback function: PLOTITEM_edit */
#define  PLOT_VEL_RADIOBUTTON_showPos    11      /* callback function: PLOTITEM_edit */
#define  PLOT_VEL_TEXTMSG_multiply       12

#define  PLOTITEMS                       48
#define  PLOTITEMS_RING_level1           2       /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_BUTTON_intManually    3       /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_BUTTON_showTransfer   4       /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_RING_timeInterval1_d2 5       /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_RING_timeInterval1_d1 6       /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_STRING_timeInterval1  7
#define  PLOTITEMS_DECORATION            8
#define  PLOTITEMS_RING_atom             9       /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_BTN_import            10      /* callback function: PLOTITEM_callback_import */
#define  PLOTITEMS_STRING_name           11      /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_BTN_new               12      /* callback function: PLOTITEM_callback_new */
#define  PLOTITEMS_TREE                  13      /* callback function: PLOTITEM_callback_listBox */
#define  PLOTITEMS_BTN_delete            14      /* callback function: PLOTITEM_callback_delete */
#define  PLOTITEMS_RINGSLIDE_type        15      /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_NUMERIC_multiple      16      /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_NUMERIC_detector      17      /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_TEXTBOX_error         18
#define  PLOTITEMS_RADIOBUTTON_2D        19      /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_CANVAS                20
#define  PLOTITEMS_COMMANDBUTTON_down    21      /* callback function: PLOTITEM_callback_moveDown */
#define  PLOTITEMS_COMMANDBUTTON_up      22      /* callback function: PLOTITEM_callback_moveUp */
#define  PLOTITEMS_RING_dataFilter       23      /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_RING_plotItemTransf2  24      /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_RING_plotItemTransf1  25      /* callback function: PLOTITEM_edit */
#define  PLOTITEMS_DECORATION_2          26
#define  PLOTITEMS_COMMANDBUTTON_calcA_3 27      /* callback function: PLOTITEM_calculateAll_CB */
#define  PLOTITEMS_COMMANDBUTTON_calcA_2 28      /* callback function: PLOTITEM_calculateAll_CB */
#define  PLOTITEMS_COMMANDBUTTON_calcAll 29      /* callback function: PLOTITEM_calculateAll_CB */

#define  PLOTRANGES                      49
#define  PLOTRANGES_LISTBOX              2       /* callback function: PLOTITEM_selectRangeListbox_CB */
#define  PLOTRANGES_COMMANDBUTTON_abort  3       /* callback function: PLOTITEM_selectAbort_CB */
#define  PLOTRANGES_TEXTMSG              4
#define  PLOTRANGES_COMMANDBUTTON_close  5       /* callback function: PLOTITEM_selectDone_CB */
#define  PLOTRANGES_TEXTMSG_velocity     6
#define  PLOTRANGES_TEXTMSG_2            7
#define  PLOTRANGES_TEXTMSG_3            8

#define  PRINT                           50      /* callback function: PRINT_panel_callback */
#define  PRINT_STRING_title              2
#define  PRINT_COMMANDBUTTON_print       3       /* callback function: PRINT_callback_print */
#define  PRINT_COMMANDBUTTON_abort       4       /* callback function: PRINT_callback_abort */
#define  PRINT_TEXTBOX_comment           5
#define  PRINT_TEXTMSG_date              6
#define  PRINT_TEXTMSG_title             7

#define  PTABLEMENU                      51

#define  RENAME_CUR                      52
#define  RENAME_CUR_STRING_name          2
#define  RENAME_CUR_COMMANDBUTTON_abort  3       /* callback function: panelCallbackRemovePopup */
#define  RENAME_CUR_COMMANDBUTTON_close  4       /* callback function: RENAMECURVES_callback */
#define  RENAME_CUR_TEXTMSG              5
#define  RENAME_CUR_TEXTMSG_name         6

#define  RUN                             53      /* callback function: RUN_panelCallback */
#define  RUN_RING_transferLevel2         2       /* callback function: RUN_parametersEdited */
#define  RUN_RING_transferLevel1         3       /* callback function: RUN_parametersEdited */
#define  RUN_RINGSLIDE_killerCh          4       /* callback function: RUN_parametersEdited */
#define  RUN_RINGSLIDE_acqMode           5       /* callback function: RUN_parametersEdited */
#define  RUN_RING_transferAtom           6       /* callback function: RUN_parametersEdited */
#define  RUN_COMMANDBUTTON_edit          7       /* callback function: DETECTION_callback_edit */
#define  RUN_NUMERIC_curveStart          8       /* callback function: RUN_parametersEdited */
#define  RUN_NUMERIC_curveEnd            9       /* callback function: RUN_parametersEdited */
#define  RUN_TEXTMSG_end                 10
#define  RUN_CANVAS                      11
#define  RUN_TEXTMSG_start               12
#define  RUN_TEXTMSG_totalSweepDur       13
#define  RUN_TEXTBOX_protocol            14
#define  RUN_TREE_timeIntervals          15
#define  RUN_RADIOBUTTON_testData        16      /* callback function: RUN_parametersEdited */
#define  RUN_RADIOBUTTON_saveTimes       17      /* callback function: RUN_parametersEdited */
#define  RUN_TEXTBOX_errTimes            18
#define  RUN_RADIOBUTTON_CTR7            19      /* callback function: RUN_parametersEdited */
#define  RUN_RADIOBUTTON_CTR6            20      /* callback function: RUN_parametersEdited */
#define  RUN_RADIOBUTTON_CTR1            21      /* callback function: RUN_parametersEdited */
#define  RUN_RADIOBUTTON_CTR0            22      /* callback function: RUN_parametersEdited */
#define  RUN_TEXTMSG_counters            23
#define  RUN_TEXTMSG                     24
#define  RUN_TEXTMSG_2                   25
#define  RUN_TEXTMSG_3                   26
#define  RUN_TEXTMSG_4                   27
#define  RUN_DECORATION                  28
#define  RUN_TEXTMSG_times_2             29
#define  RUN_TEXTMSG_times               30
#define  RUN_DECORATION_4                31
#define  RUN_DECORATION_3                32
#define  RUN_RADIOBUTTON_transfer        33      /* callback function: RUN_parametersEdited */
#define  RUN_TEXTMSG_transfDet2          34

#define  RUN_DIG                         54
#define  RUN_DIG_TEXTMSG_2               2
#define  RUN_DIG_NUMERIC_nAveragesDone   3
#define  RUN_DIG_RING_channel            4       /* callback function: DIG_parameterChanged */
#define  RUN_DIG_NUMERIC_nAverages       5       /* callback function: RUN_parametersEdited */
#define  RUN_DIG_NUMERIC_from            6       /* callback function: DIG_parameterChanged */
#define  RUN_DIG_BTN_startAveraging      7       /* callback function: BTN_startAveraging */
#define  RUN_DIG_TEXTMSG_5               8
#define  RUN_DIG_TEXTMSG_3               9
#define  RUN_DIG_NUMERIC_stepsize        10
#define  RUN_DIG_NUMERIC_to              11      /* callback function: DIG_parameterChanged */
#define  RUN_DIG_NUMERIC_nCopies         12      /* callback function: DIG_parameterChanged */
#define  RUN_DIG_NUMERIC_nSteps          13      /* callback function: DIG_parameterChanged */
#define  RUN_DIG_TEXTMSG_4               14
#define  RUN_DIG_DECORATION              15
#define  RUN_DIG_STRING_windowName       16      /* callback function: DIG_parameterChanged */

#define  RUN_RESUME                      55
#define  RUN_RESUME_NUMERIC_failedcurves 2
#define  RUN_RESUME_COMMANDBUTTON        3
#define  RUN_RESUME_COMMANDBUTTON_resume 4       /* callback function: SESSIONMANAGER_resumeRun */
#define  RUN_RESUME_NUMERIC_nRun_R       5
#define  RUN_RESUME_NUMERIC_nRepetition_R 6
#define  RUN_RESUME_TEXTMSG_resumeAt     7

#define  RUN_SAVE                        56
#define  RUN_SAVE_TEXTBOX_comments       2       /* callback function: RUN_SAVE_parametersEdited */
#define  RUN_SAVE_BTN_browseMasterSeq_2  3       /* callback function: BTN_browseDataDirectory */
#define  RUN_SAVE_STRING_dataPathToday   4
#define  RUN_SAVE_STRING_dataPath        5

#define  RUN_STD                         57
#define  RUN_STD_LISTBOX_sweeps          2       /* callback function: RUN_parametersEdited */
#define  RUN_STD_NUMERIC_nRuns           3       /* callback function: RUN_parametersEdited */
#define  RUN_STD_NUMERIC_nSweepPoints    4       /* callback function: RUN_parametersEdited */
#define  RUN_STD_NUMERIC_nCurves         5       /* callback function: RUN_parametersEdited */

#define  RUNS                            58      /* callback function: RUNS_panelCallback */
#define  RUNS_TREE                       2       /* callback function: RUNS_tree_CB */
#define  RUNS_COMMANDBUTTON_quit         3       /* callback function: RUNS_quit_CB */

#define  RUNS_DUMMY                      59

#define  SAVING                          60
#define  SAVING_TEXTBOX                  2

#define  SCONFIG                         61
#define  SCONFIG_CANVAS_tabCtrl          2
#define  SCONFIG_BUTTON_restoreDefault   3       /* callback function: BTN_SCONFIG_restoreDefault */
#define  SCONFIG_BUTTON_setAsDefault     4       /* callback function: BTN_SCONFIG_setAsDefault */
#define  SCONFIG_BUTTON_applyChanges     5       /* callback function: BTN_SCONFIG_Done */

#define  SIGNALS                         62
#define  SIGNALS_TEXTBOX                 2

#define  SMAN                            63      /* callback function: SESSIONMANAGER_panelCallback */
#define  SMAN_BUTTON_start               2       /* callback function: SESSIONMANAGER_startRun */
#define  SMAN_NUMERIC_repetition         3
#define  SMAN_CANVAS_tabCtrl             4       /* callback function: SMAIN_TabClicked */
#define  SMAN_STRING_status              5
#define  SMAN_TREE_sessions              6       /* callback function: SESSION_listClicked */
#define  SMAN_BTN_saveRunData            7       /* callback function: RUN_parametersEdited */
#define  SMAN_TEXTMSG_readOnly           8
#define  SMAN_NUMERIC_run                9
#define  SMAN_NUMERIC_currentRun         10
#define  SMAN_NUMERIC_nextRun            11
#define  SMAN_TEXTMSG_sessionName        12
#define  SMAN_TEXTMSG_startNr            13
#define  SMAN_BUTTON_deleteLast          14      /* callback function: RUN_deleteLastRunData */
#define  SMAN_BUTTON_saveLast            15      /* callback function: RUN_saveLastRunData */
#define  SMAN_DECORATION_2               16
#define  SMAN_NUMERIC_memoryUsage        17      /* callback function: SESSIONMANAGER_memoryClicked_CB */
#define  SMAN_TIMER                      18      /* callback function: SESSINMANAGER_updateMemoryTimer_CB */
#define  SMAN_NUMERIC_updatePoints       19      /* callback function: SESSIONMANAGER_updatePointsChanged_CB */
#define  SMAN_TEXTMSG_MB                 20
#define  SMAN_TEXTMSG                    21
#define  SMAN_COMMANDBUTTON_bottom       22      /* callback function: SESSION_moveInList_CB */
#define  SMAN_COMMANDBUTTON_down         23      /* callback function: SESSION_moveInList_CB */
#define  SMAN_COMMANDBUTTON_up           24      /* callback function: SESSION_moveInList_CB */
#define  SMAN_COMMANDBUTTON_top          25      /* callback function: SESSION_moveInList_CB */

#define  START                           64
#define  START_TEXTMSG_TITLE             2
#define  START_TEXTMSG_DEBUG             3
#define  START_STRING_status             4
#define  START_TEXTMSG_2                 5

#define  STATISTICS                      65
#define  STATISTICS_NUMERIC_to           2
#define  STATISTICS_NUMERIC_xFrom        3
#define  STATISTICS_NUMERIC_nPoints      4
#define  STATISTICS_NUMERIC_sum_3        5
#define  STATISTICS_NUMERIC_sum_2        6
#define  STATISTICS_NUMERIC_sum_5        7
#define  STATISTICS_NUMERIC_min          8
#define  STATISTICS_NUMERIC_sum          9
#define  STATISTICS_RADIOBUTTON_all      10

#define  SWEEP                           66

#define  SWEEP_a                         67
#define  SWEEP_a_CHECKBOX_freqSweep      2       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_a_CHECKBOX_activate       3       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_a_RING_channel            4       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_a_NUMERIC_from            5       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_a_NUMERIC_stepSize        6       /* callback function: SWEEP_ANALOG_stepChanged */
#define  SWEEP_a_NUMERIC_to              7       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_a_TEXTMSG_from            8
#define  SWEEP_a_TEXTMSG_stepSize        9
#define  SWEEP_a_TEXTMSG_to              10
#define  SWEEP_a_DECORATION              11
#define  SWEEP_a_NUMERIC_nPoints         12      /* callback function: SWEEP_ANALOG_stepChanged */

#define  SWEEP_p                         68
#define  SWEEP_p_CHECKBOX_sweep          2       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_p_CHECKBOX_activate       3       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_p_RING_device             4       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_p_NUMERIC_from            5       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_p_NUMERIC_stepSize        6       /* callback function: SWEEP_ANALOG_stepChanged */
#define  SWEEP_p_NUMERIC_to              7       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_p_TEXTMSG_mA              8
#define  SWEEP_p_TEXTMSG_from            9
#define  SWEEP_p_TEXTMSG_stepSize        10
#define  SWEEP_p_TEXTMSG_to              11
#define  SWEEP_p_NUMERIC_nPoints         12      /* callback function: SWEEP_ANALOG_stepChanged */
#define  SWEEP_p_NUMERIC_current         13      /* callback function: SWEEP_parameterChanged */
#define  SWEEP_p_DECORATION              14
#define  SWEEP_p_NUMERIC_devChannel      15      /* callback function: SWEEP_parameterChanged */

#define  SWEEP_s                         69
#define  SWEEP_s_CHECKBOX_freqSweep      2       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_s_CHECKBOX_activate       3       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_s_RING_device             4       /* callback function: SWEEP_parameterChanged */
#define  SWEEP_s_NUMERIC_from            5       /* callback function: SWEEP_frequencyChanged */
#define  SWEEP_s_NUMERIC_to              6       /* callback function: SWEEP_frequencyChanged */
#define  SWEEP_s_NUMERIC_center          7       /* callback function: SWEEP_frequencyChanged */
#define  SWEEP_s_TEXTMSG_dBm             8
#define  SWEEP_s_NUMERIC_stepsize        9       /* callback function: SWEEP_GPIB_stepChanged */
#define  SWEEP_s_NUMERIC_span            10      /* callback function: SWEEP_frequencyChanged */
#define  SWEEP_s_TEXTMSG_stepsize        11
#define  SWEEP_s_TEXTMSG_center          12
#define  SWEEP_s_TEXTMSG_span            13
#define  SWEEP_s_TEXTMSG_from            14
#define  SWEEP_s_TEXTMSG_to              15
#define  SWEEP_s_NUMERIC_nPoints         16      /* callback function: SWEEP_GPIB_stepChanged */
#define  SWEEP_s_NUMERIC_harmonic        17      /* callback function: SWEEP_parameterChanged */
#define  SWEEP_s_NUMERIC_outputPower     18      /* callback function: SWEEP_parameterChanged */
#define  SWEEP_s_RADIOBUTTON_pulse       19      /* callback function: SWEEP_parameterChanged */
#define  SWEEP_s_RADIOBUTTON_RFon        20      /* callback function: SWEEP_parameterChanged */
#define  SWEEP_s_DECORATION              21
#define  SWEEP_s_TEXTMSG_mode            22

#define  SWEEP_sub                       70
#define  SWEEP_sub_TEXTMSG_type          2
#define  SWEEP_sub_DECORATION            3
#define  SWEEP_sub_NUMERIC_nSweeps       4       /* callback function: SWEEP_nSweepsChanged_callback */

#define  TABLECOL                        71
#define  TABLECOL_TREE_all               2
#define  TABLECOL_TREE_displayed         3       /* callback function: ATOMS_TABLE_COL_callback_tree */
#define  TABLECOL_COMMANDBUTTON_abort    4       /* callback function: ATOMS_TABLE_COL_callback_abort */
#define  TABLECOL_COMMANDBUTTON_done     5       /* callback function: ATOMS_TABLE_COL_callback_done */
#define  TABLECOL_COMMANDBUTTON_recal_2  6       /* callback function: ATOMS_TABLE_COL_callback_recallDefault */
#define  TABLECOL_COMMANDBUTTON_set_5    7       /* callback function: ATOMS_TABLE_COL_callback_setAsDefault */
#define  TABLECOL_STRING_name            8       /* callback function: ATOMS_TABLE_COL_callback_name */
#define  TABLECOL_BUTTON_arrorwRight     9       /* callback function: ATOMS_TABLE_COL_callback_arrowRight */
#define  TABLECOL_BUTTON_arrowLeft       10      /* callback function: ATOMS_TABLE_COL_callback_arrowLeft */
#define  TABLECOL_NUMERIC_nConfig        11      /* callback function: ATOMS_TABLE_COL_callback_nrChanged */

#define  TFKILLER                        72
#define  TFKILLER_TEXTMSG_cavity         2
#define  TFKILLER_NUMERIC_C              3       /* callback function: SCONFIG_KILLER_parametersEdited_CB */
#define  TFKILLER_NUMERIC_A              4       /* callback function: SCONFIG_KILLER_parametersEdited_CB */
#define  TFKILLER_NUMERIC_B              5       /* callback function: SCONFIG_KILLER_parametersEdited_CB */
#define  TFKILLER_TEXTMSG_transferFct_3  6
#define  TFKILLER_TEXTMSG_transferFct    7
#define  TFKILLER_NUMERIC_defaultV       8       /* callback function: SCONFIG_KILLER_parametersEdited_CB */
#define  TFKILLER_NUMERIC_defaultDet     9       /* callback function: SCONFIG_KILLER_parametersEdited_CB */
#define  TFKILLER_GRAPH                  10
#define  TFKILLER_RING_transferFunction  11      /* callback function: SCONFIG_KILLER_parametersEdited_CB */
#define  TFKILLER_TEXTMSG                12
#define  TFKILLER_DECORATION             13
#define  TFKILLER_TEXTBOX                14
#define  TFKILLER_BINARYSWITCH_defaultV  15      /* callback function: SCONFIG_KILLER_parametersEdited_CB */

#define  TIMEINT                         73      /* callback function: TIMEINTERVALS_panel_CB */
#define  TIMEINT_COMMANDBUTTON_close     2       /* callback function: TIMEINTERVALS_close_CB */

#define  TIMEREF                         74
#define  TIMEREF_TEXTMSG_2               2
#define  TIMEREF_RING_referenceAtom      3
#define  TIMEREF_RING_referencePos       4
#define  TIMEREF_COMMANDBUTTON_apply     5       /* callback function: ATOMS_TIMEREF_done */
#define  TIMEREF_COMMANDBUTTON_abort     6       /* callback function: TOOLS_CALLBACK_Abort */
#define  TIMEREF_COMMANDBUTTON_done      7       /* callback function: ATOMS_TIMEREF_done */


     /* Menu Bars, Menus, and Menu Items: */

#define  CURVESMENU                      1
#define  CURVESMENU_FILE                 2
#define  CURVESMENU_FILE_LOAD            3       /* callback function: CURVES_MENUBAR_loadCurve */
#define  CURVESMENU_FILE_SAVE            4       /* callback function: CURVES_MENUBAR_saveCurve */
#define  CURVESMENU_FILE_SEPARATOR       5
#define  CURVESMENU_FILE_EXPORT          6       /* callback function: CURVES_MENUBAR_exportCurve */
#define  CURVESMENU_FILE_IMPORT          7       /* callback function: CURVES_MENUBAR_import */
#define  CURVESMENU_FILE_SEPARATOR_2     8
#define  CURVESMENU_FILE_QUIT_SMANAGER   9       /* callback function: SMAIN_MENU_Quit */
#define  CURVESMENU_SPECIAL              10
#define  CURVESMENU_SPECIAL_START        11      /* callback function: CURVES_MENUBAR_startRun */
#define  CURVESMENU_SPECIAL_SEPARATOR_3  12
#define  CURVESMENU_SPECIAL_CUSTOM1      13      /* callback function: CURVES_MENUBAR_custom1 */
#define  CURVESMENU_SPECIAL_CUSTOM2      14      /* callback function: CURVES_MENUBAR_custom2 */
#define  CURVESMENU_WINDOW               15
#define  CURVESMENU_WINDOW_REMOVE_ALL    16      /* callback function: CURVES_MENUBAR_removeAllWindows */

#define  DIAGMENU                        2
#define  DIAGMENU_DMENU                  2
#define  DIAGMENU_DMENU_ZOOM             3
#define  DIAGMENU_DMENU_BACK             4

#define  GRAPH2D                         3
#define  GRAPH2D_MENU                    2
#define  GRAPH2D_MENU_PRINT              3

#define  GRAPHMENU                       4
#define  GRAPHMENU_GRAPH                 2
#define  GRAPHMENU_GRAPH_CURSORS         3
#define  GRAPHMENU_GRAPH_CURSORS_SUBMENU 4
#define  GRAPHMENU_GRAPH_CURSORS_CURSORS0 5
#define  GRAPHMENU_GRAPH_CURSORS_CURSORS1 6
#define  GRAPHMENU_GRAPH_CURSORS_CURSORS2 7
#define  GRAPHMENU_GRAPH_SEPARATOR_3     8
#define  GRAPHMENU_GRAPH_FREQ            9
#define  GRAPHMENU_GRAPH_FREQ_SUBMENU    10
#define  GRAPHMENU_GRAPH_FREQ_C1         11
#define  GRAPHMENU_GRAPH_FREQ_C1_SUBMENU 12
#define  GRAPHMENU_GRAPH_FREQ_C1_DUMMY   13
#define  GRAPHMENU_GRAPH_FREQ_C2         14
#define  GRAPHMENU_GRAPH_FREQ_C2_SUBMENU 15
#define  GRAPHMENU_GRAPH_FREQ_C2_DUMMY   16
#define  GRAPHMENU_GRAPH_FREQ_DIFF       17
#define  GRAPHMENU_GRAPH_FREQ_DIFF_SUBMEN 18
#define  GRAPHMENU_GRAPH_FREQ_DIFF_DUMMY 19
#define  GRAPHMENU_GRAPH_SEPARATOR_4     20
#define  GRAPHMENU_GRAPH_ZOOM            21
#define  GRAPHMENU_GRAPH_UNZOOM          22
#define  GRAPHMENU_GRAPH_SEPARATOR_5     23
#define  GRAPHMENU_GRAPH_KEEP            24
#define  GRAPHMENU_GRAPH_SEPARATOR       25
#define  GRAPHMENU_GRAPH_DISPLAY         26
#define  GRAPHMENU_GRAPH_SEPARATOR_2     27
#define  GRAPHMENU_GRAPH_PRINT           28

#define  MAINMENU                        5
#define  MAINMENU_FILE                   2
#define  MAINMENU_FILE_NEW               3       /* callback function: MENU_newSession */
#define  MAINMENU_FILE_LOAD              4       /* callback function: MENU_loadSession */
#define  MAINMENU_FILE_SEPARATOR_5       5
#define  MAINMENU_FILE_SAVE              6       /* callback function: MENU_saveSession */
#define  MAINMENU_FILE_SAVEAS            7       /* callback function: MENU_saveSessionAs */
#define  MAINMENU_FILE_SAVE_COPY_AS      8       /* callback function: MENU_saveSessionCopyAs */
#define  MAINMENU_FILE_SEPARATOR_6       9
#define  MAINMENU_FILE_CLOSE             10      /* callback function: MENU_closeSession */
#define  MAINMENU_FILE_CLOSE_ALL         11      /* callback function: MENU_closeAllSessions */
#define  MAINMENU_FILE_SEPARATOR         12
#define  MAINMENU_FILE_CREATE_PATH       13      /* callback function: MENU_createDataPath */
#define  MAINMENU_FILE_SEPARATOR_9       14
#define  MAINMENU_FILE_SAVE_SCR          15      /* callback function: MENU_saveSourceCode */
#define  MAINMENU_FILE_SAVE_EXP          16      /* callback function: MENU_saveProgram */
#define  MAINMENU_FILE_SEPARATOR_7       17
#define  MAINMENU_FILE_QUIT              18      /* callback function: SMAIN_MENU_Quit */
#define  MAINMENU_SPECIAL                19
#define  MAINMENU_SPECIAL_DETECTION      20      /* callback function: MENU_detection */
#define  MAINMENU_SPECIAL_SEPARATOR_10   21
#define  MAINMENU_SPECIAL_FILTERS        22      /* callback function: MENU_filters */
#define  MAINMENU_SPECIAL_SEPARATOR_2    23
#define  MAINMENU_SPECIAL_DIAGRAM        24      /* callback function: MENU_diagram */
#define  MAINMENU_SPECIAL_SEPARATOR_11   25
#define  MAINMENU_SPECIAL_DIGITALLINES   26      /* callback function: MENU_digitalOutputs */
#define  MAINMENU_SPECIAL_SEPARATOR_3    27
#define  MAINMENU_SPECIAL_CREATESEQ      28      /* callback function: MENU_createSequence */
#define  MAINMENU_SPECIAL_DISPLAYEVENTS  29      /* callback function: MENU_displayEvents */
#define  MAINMENU_SPECIAL_SEPARATOR_8    30
#define  MAINMENU_SPECIAL_STARTEXPCONTROL 31     /* callback function: MENU_startExperimentControl */
#define  MAINMENU_SPECIAL_QUITEXPCONTROL 32      /* callback function: MENU_quitExperimentControl */
#define  MAINMENU_RESULTS                33
#define  MAINMENU_RESULTS_CURVES         34      /* callback function: MENU_curves */
#define  MAINMENU_RESULTS_DISPLAYCOUNTS  35      /* callback function: MENU_displayCounts */
#define  MAINMENU_RESULTS_SEPARATOR_4    36
#define  MAINMENU_RESULTS_RUNS           37      /* callback function: MENU_runs */

#define  MCURVES                         6
#define  MCURVES_TREE                    2
#define  MCURVES_TREE_KEEP               3
#define  MCURVES_TREE_RENAME             4
#define  MCURVES_TREE_DELETE             5
#define  MCURVES_TREE_STYLE              6
#define  MCURVES_TREE_COLOR              7

#define  MCURVES2                        7
#define  MCURVES2_TREE                   2
#define  MCURVES2_TREE_REMOVE_WINDOW     3
#define  MCURVES2_TREE_DELETE_ALL_CURVES 4

#define  MENURUNS                        8
#define  MENURUNS_TREE                   2
#define  MENURUNS_TREE_DISPLAYPLOTITEM   3
#define  MENURUNS_TREE_DISPLAYPLOTITEM_SU 4
#define  MENURUNS_TREE_DISPLAYPLOTITEM_P1 5
#define  MENURUNS_TREE_SEPARATOR_4       6
#define  MENURUNS_TREE_DISPLAYCOUNTS     7
#define  MENURUNS_TREE_SEPARATOR         8
#define  MENURUNS_TREE_DISPLAYSESSION    9
#define  MENURUNS_TREE_SEPARATOR_2       10
#define  MENURUNS_TREE_DISPLAYCURVES     11
#define  MENURUNS_TREE_SEPARATOR_3       12
#define  MENURUNS_TREE_REMOVE            13

#define  RUNSMENU                        9
#define  RUNSMENU_FILE                   2
#define  RUNSMENU_FILE_LOAD              3       /* callback function: MENU_loadRun */
#define  RUNSMENU_FILE_SEPARATOR         4
#define  RUNSMENU_FILE_Quit              5       /* callback function: MENU_quitRun */
#define  RUNSMENU_FILE_QUITSMANAGER      6       /* callback function: SMAIN_MENU_Quit */
#define  RUNSMENU_FILTERS                7
#define  RUNSMENU_FILTERS_EDITFILTERS    8

#define  TABLEMENU                       10
#define  TABLEMENU_1                     2
#define  TABLEMENU_1_SETVALUE            3
#define  TABLEMENU_1_SETCONFIG           4
#define  TABLEMENU_1_SETCONFIG_SUBMENU   5
#define  TABLEMENU_1_SETCONFIG_CONFIG1   6
#define  TABLEMENU_1_SETCONFIG_CONFIG2   7
#define  TABLEMENU_1_SETCONFIG_CONFIG3   8
#define  TABLEMENU_1_SETCONFIG_SEPARATOR 9
#define  TABLEMENU_1_SETCONFIG_EDITCONFIG 10


     /* Callback Prototypes: */ 

int  CVICALLBACK Atom_ParameterChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_BTN_createName(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_BTN_delete(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_BTN_duplicate(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_BTN_import(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_BTN_New(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_CALLBACK_panel(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_CAVITY_editKiller(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_CAVITY_importKillerParameters(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_CAVITY_importKillerParameters_Done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_CAVITY_importKillerParameters_selected(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_CAVITY_parameterChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_DETECTOR_parameterChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_EVENTS_deleteEvent(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_EVENTS_importEvent(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_EVENTS_listboxClicked(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_EVENTS_newEvent(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_EVENTS_parameterChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_importAtoms_Done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_KILLER_callback_table(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_KILLER_done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_COL_callback_abort(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_COL_callback_arrowLeft(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_COL_callback_arrowRight(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_COL_callback_done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_COL_callback_name(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_COL_callback_nrChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_COL_callback_recallDefault(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_COL_callback_setAsDefault(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_COL_callback_tree(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TABLE_edited(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TIMEREF_change(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ATOMS_TIMEREF_done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK BTN_browseDataDirectory(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK BTN_SCONFIG_Done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK BTN_SCONFIG_restoreDefault(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK BTN_SCONFIG_setAsDefault(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK BTN_startAveraging(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK COMMANDBUTTON_abort_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK COMMANDBUTTON_confirm_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK COMMANDBUTTON_print_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK COUNTS_panelCallback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CURVE2D_callbackPanel(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CURVE2D_showPartsOfExperiment_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CURVES_callback_Close(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CURVES_callback_curveNrChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CURVES_callback_Tree(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK CURVES_MENUBAR_custom1(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK CURVES_MENUBAR_custom2(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK CURVES_MENUBAR_exportCurve(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK CURVES_MENUBAR_import(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK CURVES_MENUBAR_loadCurve(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK CURVES_MENUBAR_removeAllWindows(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK CURVES_MENUBAR_saveCurve(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK CURVES_MENUBAR_startRun(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK CURVES_panelCallback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CUSTOM1_abort_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CUSTOM1_panel_callback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CUSTOM1_startEvaluation_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CUSTOM2_abortEvaluation_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CUSTOM2_nCurve_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK CUSTOM2_startEvaluation_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DETECTION_callback_done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DETECTION_callback_edit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DETECTORS_changeLevels(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DETECTORS_delete(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DETECTORS_detectorChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DETECTORS_import(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DETECTORS_listboxClicked(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DETECTORS_new(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DETECTORS_parameterChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DIAGRAM_callback_done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DIAGRAM_callback_graph(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DIAGRAM_callback_parameterChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DIAGRAM_callback_update(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DIAGRAM_ERR_callback_close(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DIAGRAM_ERR_callback_panel(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DIAGRAM_panelCallback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DIAGRAM_PRINT_panelCallback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK DIG_parameterChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK ERROR_callback_done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EVENT_done(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EVENT_panelCallback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EVENTS_callback_update(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK EVENTS_treeClicked(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK FILTER_deleteFilter_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK FILTER_displayListOfTimeIntervals_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK FILTER_editListTimeIntervals_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK FILTER_newFilter_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK FILTER_ParameterEdited(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK FILTERS_listboxCLicked(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK GRAPH_displayParametersChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK GRAPH_graph2D_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK GRAPH_graphCallback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK GRAPH_panelCallback(int panel, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK MENU_closeAllSessions(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_closeSession(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_createDataPath(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_createSequence(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_curves(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_detection(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_diagram(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_digitalOutputs(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_displayCounts(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_displayEvents(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_filters(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_loadRun(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_loadSession(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_newSession(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_quitExperimentControl(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_quitRun(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_runs(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_saveProgram(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_saveSession(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_saveSessionAs(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_saveSessionCopyAs(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_saveSourceCode(int menubar, int menuItem, void *callbackData, int panel);
void CVICALLBACK MENU_startExperimentControl(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK OUTPUT_DIRECT_done_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OUTPUTS_manuallyOperate_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OUTPUTS_valueChanged_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK panelCallbackRemovePopup(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK panelMore_close_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_calculateAll_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_callback_delete(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_callback_import(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_callback_listBox(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_callback_moveDown(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_callback_moveUp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_callback_new(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_createDataFilters_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_edit(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_selectAbort_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_selectDone_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PLOTITEM_selectRangeListbox_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK POINTS_processEvents_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PRINT_callback_abort(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PRINT_callback_print(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK PRINT_panel_callback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RENAMECURVES_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RUN_deleteLastRunData(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RUN_panelCallback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RUN_parametersEdited(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RUN_SAVE_parametersEdited(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RUN_saveLastRunData(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RUNS_panelCallback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RUNS_quit_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK RUNS_tree_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SCONFIG_DETECTIONPAR_importButton(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SCONFIG_editDistances(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SCONFIG_KILLER_parametersEdited_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SCONFIG_referenceChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SCONFIG_rfParametersEdited(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SCONFIG_setPositionsRamsey_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SESSINMANAGER_updateMemoryTimer_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SESSION_listClicked(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SESSION_moveInList_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SESSIONMANAGER_memoryClicked_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SESSIONMANAGER_panelCallback(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SESSIONMANAGER_resumeRun(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SESSIONMANAGER_startRun(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SESSIONMANAGER_updatePointsChanged_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
void CVICALLBACK SMAIN_MENU_Quit(int menubar, int menuItem, void *callbackData, int panel);
int  CVICALLBACK SMAIN_TabClicked(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SWEEP_ANALOG_stepChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SWEEP_frequencyChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SWEEP_GPIB_stepChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SWEEP_nSweepsChanged_callback(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SWEEP_parameterChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TIMEINTERVALS_close_CB(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TIMEINTERVALS_panel_CB(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK TOOLS_CALLBACK_Abort(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
