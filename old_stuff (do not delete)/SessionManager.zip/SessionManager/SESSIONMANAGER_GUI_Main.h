#if !defined (SESSIONMANAGER_GUI_MAIN)
#define SESSIONMANAGER_GUI_MAIN

#include "SESSIONMANAGER/SESSIONMANAGER_DataStructure.h"






t_session *activeSession (void);

void SESSIONMANAGER_discardPanel (void);

int SESSIONMANAGER_initPanel (int outPanel, int outCtrl);

int SESSIONMANAGER_init (int outPanel, int outCtrl);

int SESSIONMANAGER_quit (void);
int SESSIONMANAGER_saveSession (t_session *s);
int SESSIONMANAGER_saveAs (t_session *s);



//void SESSIONMANAGER_displayList (void);
void SESSIONMANAGER_displayList (int changeFirstLine);


void SESSIONMANAGER_setFilenameToTitle (const char *filename, int changes);


void SESSIONMANAGER_parseTCPString (char *buffer, unsigned long bufferSize);

void SESSION_appendToList (t_session *s);
void SESSION_setChanges (t_session *s, int changes);
int SESSION_close (int nr);
void SESSION_displayActive (void);
int SESSION_getNrFromPtr (t_session *s);
void SESSION_setAsActive (int nr);

int nSessions (void);




void SESSIONMANAGER_displayActiveTreeItem (void);


void SESSIONMANAGER_dimControls (t_session *s, int dimmed);

void ERROR_showMessagef (const char *format, ...);		  

void SESSIONMANAGER_displayMemoryInfo (void);


#endif
