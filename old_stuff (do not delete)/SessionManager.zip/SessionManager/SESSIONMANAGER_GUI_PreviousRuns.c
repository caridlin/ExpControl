#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"


int panelRuns = -1;
int menuRunsTree = -1;
//const int treeCtrl[N_DETECTORS] = {COUNTS_TREE, COUNTS_TREE_2};


#define RUNS_TREELEVEL_DATE 0
#define RUNS_TREELEVEL_RUN  1



#define RUNS_LOAD_OLD_DATA_DEBUG 1


//============================================================
//
//   DISPLAY COUNTS
//
//============================================================


enum {  
	COUNTS_COL_NAME,
//	COUNTS_COL_RUN,
//	COUNTS_COL_REP,
//	COUNTS_COL_CURVE,
	
	N_COUNTS_COL
};




void COUNTS_initTree (t_run *r, int panel, int ctrl, int nPlotItemsCalculated)
{
	int i;
	int nColumns[N_DETECTORS];

	char help[200];
	int det;
	t_timeInterval *t;
	t_session *s;
	int nCalculated;
	t_plotItem *p, *pTransfer1, *pTransfer2 ;
	t_filter *f;
	int nColTotal;
	int col;
	
	s = r->session;
	
	SetCtrlAttribute (panel, ctrl, ATTR_COLUMN_LABELS_HEIGHT, 70);
	
	// create new tree columns
	SetCtrlAttribute (panel, ctrl,
					  ATTR_COLUMN_LABELS_VISIBLE, 1);

	nColTotal = 0;
	for (det = 0; det < N_DETECTORS; det++) {
		nColumns[det] =  ListNumItems (r->lTimeIntervals[det]);
		nColTotal+= nColumns[det];
	}
	setNumTreeColumns (panel, ctrl, N_COUNTS_COL + nColTotal+ nPlotItemsCalculated);

	// set attributes for columns
	SetTreeColumnAttribute (panel, ctrl, COUNTS_COL_NAME,
							ATTR_COLUMN_WIDTH, 180);
	SetTreeColumnAttribute (panel, ctrl, COUNTS_COL_NAME, 
							ATTR_LABEL_TEXT, "name");

/*	SetTreeColumnAttribute (panel, ctrl, COUNTS_COL_RUN,
							ATTR_COLUMN_WIDTH, 50);
	SetTreeColumnAttribute (panel, ctrl, COUNTS_COL_RUN, 
							ATTR_LABEL_TEXT, "run");

	SetTreeColumnAttribute (panel, ctrl, COUNTS_COL_REP,
							ATTR_COLUMN_WIDTH, 50);
	SetTreeColumnAttribute (panel, ctrl, COUNTS_COL_REP, 
							ATTR_LABEL_TEXT, "rep.");

	SetTreeColumnAttribute (panel, ctrl, COUNTS_COL_CURVE,
							ATTR_COLUMN_WIDTH, 50);
	SetTreeColumnAttribute (panel, ctrl, COUNTS_COL_CURVE, 
							ATTR_LABEL_TEXT, "curve");
*/
	col = 0;
	for (det = 0; det < N_DETECTORS; det++) {
		for (i = 0; i < nColumns[det]; i++) {
			SetTreeColumnAttribute (panel, ctrl, N_COUNTS_COL + col,
								ATTR_COLUMN_WIDTH, 50);
			SetTreeColumnAttribute (panel, ctrl, N_COUNTS_COL + col,
									ATTR_LABEL_JUSTIFY, 50);
			SetTreeColumnAttribute (panel, ctrl, N_COUNTS_COL + col,
							  ATTR_LABEL_WRAP_MODE, VAL_WORD_WRAP);
							
			t = TIMEINTERVAL_ptrList (r->lTimeIntervals[det], i+1);
			if (t == NULL) strcpy (help, intToStr (i));
			else sprintf (help, "det %d\n(I=%s)\n%s", det+1, t->idStr,
						  levelStr (s, t->levelNr));
			SetTreeColumnAttribute (panel, ctrl, N_COUNTS_COL  + col, 
									ATTR_LABEL_TEXT, help);
			col++;
		}
	}
	if (r->session == NULL) return;
	// add columns "plotItems"
	nCalculated = 0;
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		p = PLOTITEM_ptr (s, i);
		PLOTITEM_calculateTimeIntervals (s, p);
		if (p->hasTableColumn) {
			SetTreeColumnAttribute (panel, ctrl, N_COUNTS_COL + nCalculated + nColTotal,
								ATTR_COLUMN_WIDTH, 50);
			SetTreeColumnAttribute (panel, ctrl, N_COUNTS_COL + nCalculated + nColTotal,
									ATTR_LABEL_JUSTIFY, 50);
			SetTreeColumnAttribute (panel, ctrl, N_COUNTS_COL + nCalculated + nColTotal,
							  ATTR_LABEL_WRAP_MODE, VAL_WORD_WRAP);
			help[0] = 0;
			if (p->transfer) {
				pTransfer1 = PLOTITEM_ptr (s, p->plotItemTransfer1);
				pTransfer2 = PLOTITEM_ptr (s, p->plotItemTransfer2);
				if ((pTransfer1 != NULL) && (pTransfer2 != NULL)) {
					sprintf (help, "PI %s\nTRANSFER\n%s->%s", 
							p->name, pTransfer1->name, pTransfer2->name);
				}
			
			
			}
			else 
			if (p->dataFilterID == 0) {
				t = TIMEINTERVAL_ptrList (r->lTimeIntervals[p->detector], p->interval[p->detector]);
				if (t != NULL) sprintf (help, "PI %s\n(I=%s)\n%s", p->name, t->idStr,
										levelStr(s, t->levelNr));
			}
			else {
				f = FILTER_ptr (s, p->dataFilterID);
				if (f != NULL) sprintf (help, "PI %s\n(det=%d)\\n(F=%s)\n(I=%s)", p->name, p->detector+1, f->name, t->idStr);
			}
			SetTreeColumnAttribute (panel, ctrl, N_COUNTS_COL  + nCalculated + nColTotal, 
									ATTR_LABEL_TEXT, help);
			nCalculated++;
		}
		
	}
}




int COUNTS_insertCurve (int panel, int ctrl, int beforeItem, t_run *r,
					     t_counterData **data, int *nColumns, int curveNr)
{
	unsigned dataStart;
	int i;
	char help[50];
	t_plotItem *p;
	t_filterResults *fr;
	int nCalculated;
	t_session *s;
	int counts;
	int curveItem;
	int col;
	int det;
	t_counterData *dataR;
	
	sprintf (help, "curve %d", curveNr);
	
	GetTreeItem (panel, ctrl, VAL_SIBLING, beforeItem, beforeItem,
				 VAL_NEXT, 0, &curveItem);
	if (curveItem < 0) {
		curveItem = InsertTreeItem (panel, ctrl, VAL_SIBLING,
									beforeItem, VAL_NEXT, help, NULL,
									NULL, curveNr);
	}	
	
	col = 0;
	for (det = 0; det < N_DETECTORS; det++) {
		dataStart = curveNr * nColumns[det]  + 1;
		for (i = 0; i < nColumns[det]; i++) {
			if (data[det]!= NULL) {
				if (dataStart + i < data[det]->nCounts) {
					setTreeCellTxt (panel, ctrl, curveItem, N_COUNTS_COL + col,
										intToStr (data[det]->counts[dataStart+i]));
				}
			}
			col++;								
		}
	}
	
	nCalculated = 0;
	for (i = 1; i <= ListNumItems (r->session->lPlotItems); i++) {
		p = PLOTITEM_ptr (r->session, i);
		if (p->hasDataCalculated) {
			dataR = data[p->detector];
			if (p->dataFilterID == 0) counts = dataR->counts[dataStart+p->interval[dataR->detector]-1];
			else {
				fr = &dataR->filterResults[i-1];
				if (fr == NULL) counts = -1;
				else if (fr->countsArray == NULL) counts = -1;
				else if (curveNr < fr->nSteps) counts = fr->countsArray[curveNr];
				else counts = -1;
			}
			setTreeCellTxt (panel, ctrl, curveItem, N_COUNTS_COL + col + nCalculated,
							counts < 0 ? "" : intToStr (counts));
		}
		if (p->hasTableColumn) nCalculated++;
	}
	return curveItem;
}	




int COUNTS_displayTreeItem (int panel, int ctrl, t_run *r, 
							 t_counterData **data,  int *nColumns,

							 int displayPanel, int *nCurvesDisplayed, 
							 
							 int maxCurvesToDisplay,
							 unsigned __int64 *sumArray64, unsigned *nSummedArray, int arrSize 
							 )
{
	
	int runItem, repItem, avgItem, sumItem, filterItem, curveItem;
	char help[50];
	int i;
	int error;
	int n;
	double sum, sum2;
	double err;
	unsigned __int64 sumI64;
	unsigned nSummed = 0;
	t_filterResults *fr1, *fr2;
	double avg;
	int nCalculated;
	t_plotItem *p;
	int new = 0;
	int nTotalColumns;
	t_counterData *dataD, *dataP;
	int col;
	int det;
	int k;
	nTotalColumns = 0;		
	dataD = NULL;
	for (det = 0; det < N_DETECTORS; det++) {
		if (data[det] != NULL) {
			nTotalColumns += nColumns[det];
			if (dataD == NULL) dataD = data[det];
		}
	}


	for (k = 0; k < arrSize; k++) {
		sumArray64[k] = 0;
		nSummedArray[k] = 0;
	}

	// -----------------------------
	//    get item showing "Run x"
	// ----------------------------
	if (dataD == NULL) return -1;
	error = GetTreeItemFromValue (panel, ctrl,
						  VAL_SIBLING, 0, VAL_FIRST,
						  VAL_NEXT_PLUS_SELF, 0, &runItem,
						  dataD->run);
	if ((runItem < 0) || (error < 0)) {
		sprintf (help, "run %d", dataD->run);
		runItem = InsertTreeItem (panel, ctrl, VAL_SIBLING, 0,
								  VAL_LAST, help, NULL, NULL,
								  dataD->run);
	}
	// -----------------------------------
	//    get item showing "Repetition x"
	// -----------------------------------
	GetTreeItemFromValue (panel, ctrl, VAL_CHILD, runItem,
						  VAL_FIRST, VAL_NEXT_PLUS_SELF, 0,
						  &repItem, dataD->repetition);
	if (repItem < 0) {
		sprintf (help, "repetiton %d", dataD->repetition);
		repItem = InsertTreeItem (panel, ctrl, VAL_CHILD,
								  runItem, VAL_LAST, help, NULL, NULL,
								  dataD->repetition);
		new = 1;
		// insert item "AVERAGE"
		avgItem = InsertTreeItem (panel, ctrl, VAL_CHILD,
								  repItem, VAL_LAST, "AVERAGE", NULL, NULL,
								  -1);
		// insert item "SUM"
		sumItem = InsertTreeItem (panel, ctrl, VAL_CHILD,
								  repItem, VAL_LAST, "SUM", NULL, NULL,
								  -1);
		filterItem = InsertTreeItem (panel, ctrl, VAL_CHILD,
								  repItem, VAL_LAST, "NFILTERED", NULL, NULL,
								  -1);
	}
	else {
		avgItem = repItem+1;
		sumItem = avgItem+1;
		filterItem = sumItem+1;
/*		GetTreeItem (panel, ctrl, VAL_CHILD, repItem, repItem,
					 VAL_NEXT_PLUS_SELF, 0, &avgItem);
		GetTreeItem (panel, ctrl, VAL_SIBLING, avgItem, avgItem,
					 VAL_NEXT, 0, &sumItem);
		GetTreeItem (panel, ctrl, VAL_SIBLING, sumItem, sumItem,
					 VAL_NEXT, 0, &filterItem);
*/	}
	// calculate averages
	col = 0;
	for (det = 0; det < N_DETECTORS; det++) {
		for (i = 0; i < nColumns[det]; i++) {
			sum = COUNTERDATA_sumInterval (data[det], i+1, &sumI64, &nSummed);
			if (col < arrSize) {
				sumArray64[col] = sumI64;
				nSummedArray[col] = nSummed;
			}
			
			if (nSummed > 0) {
				sprintf (help, "%1.3f", sum / nSummed);
				setTreeCellTxtColor (panel, ctrl, repItem, N_COUNTS_COL + col,
							         help, VAL_BLUE);
				setTreeCellTxtColor (panel, ctrl, avgItem, N_COUNTS_COL + col,
							         help, VAL_BLUE);
			}
			if (data[det] != NULL) {
				// display sum:
				
				setTreeCellTxtColor (panel, ctrl, sumItem, N_COUNTS_COL + col,
							         intToStr (sum), VAL_GREEN);
				setTreeCellTxtColor (panel, ctrl, filterItem, N_COUNTS_COL + col,
									 intToStr (nSummed), VAL_ORANGE);
			}
			col++;
		}
	}
//	return;
	nCalculated = 0;
	for (i = 1; i <= ListNumItems (r->session->lPlotItems); i++) {
		p = PLOTITEM_ptr (r->session, i);
		sum = -1;
		avg = -1;
		n = -1;
		err = -1;
		if (p->hasDataCalculated) {
			fr1 = &p->filterResultsCurrent;
			if (fr1 != NULL) {
				sum = ui64toDouble (fr1->sum);
				avg = fr1->average;
				n = fr1->nSummedDatasets;
				if (col < arrSize) {
					sumArray64[col] = fr1->sum;
					nSummedArray[col] = n;
				}
			}
		}
		else if (p->transfer && (p->type == PLOT_TYPE_NCOUNTS)) {		  
			PLOTITEM_calculateTransfer_NCOUNTS (r, p, &avg, &err, 0, 0);
		}
		if (p->hasTableColumn) {
			sprintf (help, "%1.3f", avg);
			setTreeCellTxtColor (panel, ctrl, repItem, N_COUNTS_COL + col ,
							avg < 0 ? "" : help, VAL_BLUE);
			setTreeCellTxtColor (panel, ctrl, avgItem, N_COUNTS_COL + col ,
							avg < 0 ? "" : help, VAL_BLUE);
			setTreeCellTxtColor (panel, ctrl, sumItem, N_COUNTS_COL + col ,
							sum < 0 ? "" : intToStr(sum), VAL_GREEN);
			setTreeCellTxtColor (panel, ctrl, filterItem, N_COUNTS_COL + col,
							n < 0 ? "" : intToStr (n), VAL_ORANGE);
			nCalculated++;
			col++;
		}
	}
		
//	if (data->nTimeIntervals == 0) return;
	// -----------------------------------
	//    insert all curves
	// -----------------------------------
	if (*nCurvesDisplayed < maxCurvesToDisplay) {
		n = dataD->nCounts / dataD->nTimeIntervals;
		curveItem = filterItem;
		if (new) SetTreeItemAttribute (panel, ctrl, repItem, ATTR_COLLAPSED, 1);
		for (i = 0; i < n; i++) {
			if (*nCurvesDisplayed < maxCurvesToDisplay) {
				curveItem = COUNTS_insertCurve (panel, ctrl, curveItem, r, data, nColumns, i);
				*nCurvesDisplayed = *nCurvesDisplayed + 1;
			}
		}
	}
	if (new) SetTreeItemAttribute (panel, ctrl, repItem, ATTR_COLLAPSED, 1);
	if (displayPanel) DisplayPanel (panel);
	return runItem;
}




void COUNTS_insertResultsRepetition (int panel, int ctrl, int allItem,  
							  t_run *r, int repetition,
							 unsigned __int64 *sumArray64, unsigned *nSummed, int arrSize ) 
{
	int avgItem, sumItem, filterItem, repItem, errItem;
	int i;
	double sum, avg, dN;
	double err;
	char help[40];
	t_filterResults rSum;
	int col;
	t_plotItem *p;
	int n;
	t_filterResults *fr1;
	
/*		sprintf (help, "repetiton %d", dataD->repetition);
		repItem = InsertTreeItem (panel, ctrl, VAL_CHILD,
								  runItem, VAL_LAST, help, NULL, NULL,
								  dataD->repetition);
		new = 1;
*/		// insert item "AVERAGE"


	err = -1;
	sprintf (help, "repetiton %d", repetition);
	repItem = InsertTreeItem (panel, ctrl, VAL_CHILD,
							  allItem, VAL_LAST, help, NULL, NULL,
							  repetition);
	errItem = InsertTreeItem (panel, ctrl, VAL_CHILD,
							  repItem, VAL_LAST, "ERROR", NULL, NULL,
							  -1);

	avgItem = InsertTreeItem (panel, ctrl, VAL_SIBLING, errItem,
							  VAL_LAST, "AVERAGE", NULL, NULL, -1);
							  
	// insert item "SUM"
	sumItem = InsertTreeItem (panel, ctrl, VAL_SIBLING, avgItem,
							  VAL_LAST, "SUM", NULL, NULL, -1);
	filterItem = InsertTreeItem (panel, ctrl, VAL_SIBLING, sumItem,
							  VAL_LAST, "NFILTERED", NULL, NULL, -1);
	for (i = 0; i < arrSize; i++) {
		sum = ui64toDouble (sumArray64[i]);
		if (nSummed[i] > 0) {
			sprintf (help, "%1.4f", sum / nSummed[i]);
			setTreeCellTxtColor (panel, ctrl, repItem, N_COUNTS_COL + i,
						         help, VAL_BLUE);
			setTreeCellTxtColor (panel, ctrl, avgItem, N_COUNTS_COL + i,
						         help, VAL_BLUE);
			setTreeCellTxtColor (panel, ctrl, filterItem, N_COUNTS_COL + i,
							 intToStr (nSummed[i]), VAL_ORANGE);
			sprintf (help, "�%1.3f", err);
			setTreeCellTxtColor (panel, ctrl, errItem, N_COUNTS_COL + i ,
							err < 0 ? "" : help, VAL_LT_BLUE);
							 
		}
		// display sum:
		setTreeCellTxtColor (panel, ctrl, sumItem, N_COUNTS_COL +i,
					         intToStr (sum), VAL_GREEN);
     
	}

	col = arrSize;
	for (i = 1; i <= ListNumItems (r->session->lPlotItems); i++) {
		p = PLOTITEM_ptr (r->session, i);
		sum = -1;
		avg = -1;
		n = -1;
		err = -1;
		if (p->hasDataCalculated) {
			fr1 = &p->filterResultsAll;
			if (fr1 != NULL) {
				sum = ui64toDouble (fr1->sum);
				avg = fr1->average;
				n = fr1->nSummedDatasets;
				dN = n;
				err = sqrt (sum) / dN;
			}
		}
		else if (p->transfer && (p->type == PLOT_TYPE_NCOUNTS)) {		  
			PLOTITEM_calculateTransfer_NCOUNTS (r, p, 0, 0, &avg, &err);
		}
		if (p->hasTableColumn) {
			sprintf (help, "%1.3f", avg);
			setTreeCellTxtColor (panel, ctrl, repItem, N_COUNTS_COL + col ,
							avg < 0 ? "" : help, VAL_BLUE);
			setTreeCellTxtColor (panel, ctrl, avgItem, N_COUNTS_COL + col ,
							avg < 0 ? "" : help, VAL_BLUE);
			setTreeCellTxtColor (panel, ctrl, sumItem, N_COUNTS_COL + col ,
							sum < 0 ? "" : intToStr(sum), VAL_GREEN);
			setTreeCellTxtColor (panel, ctrl, filterItem, N_COUNTS_COL + col,
							n < 0 ? "" : intToStr (n), VAL_ORANGE);
			sprintf (help, "�%1.3f", err);
			setTreeCellTxtColor (panel, ctrl, errItem, N_COUNTS_COL + col ,
							err < 0 ? "" : help, VAL_LT_BLUE);
							
			col++;
		}
	}
	
	SetTreeItemAttribute (panel, ctrl, repItem, ATTR_COLLAPSED, 1);
	
}

#define MAX_CURVES_TO_DISPLAY 20000


int RUN_getNPlotItemsType (t_run *r, int *nCalculated, int type)
{
	int i;
	int nPlotItems;
	t_plotItem *p;
	int counter, dataSet;
	t_counterData *data;
	int typeOk;
	
	if (r == NULL) return -1;
	if (r->session == NULL) nPlotItems = 0;
	else nPlotItems = ListNumItems (r->session->lPlotItems);
	*nCalculated = 0;
	
	for (i = 1; i <= nPlotItems; i++) {
		p = PLOTITEM_ptr (r->session, i);
		p->hasDataCalculated = 0;
		p->hasTableColumn = 0;
		typeOk = (type == PLOT_TYPE_NONE) || (p->type == type);
		if (p->active && typeOk) {
			p->hasDataCalculated = !p->transfer;
			p->hasTableColumn = (p->hasDataCalculated || p->transfer);
			if (p->hasTableColumn) (*nCalculated)++;
		}
	}
	return 0;
	
}

void COUNTS_displayRun (t_run *r)
{
	int i;
	t_counterData *data[N_DETECTORS];
	int nColumns[N_DETECTORS];
	int ctr;
	int detector;
	unsigned totalIterations, done;
	int progressDialog = 0;
	int nPlotItemsCalculated;
	int nCurvesDisplayed;
	int nCurves;
	int ctr1, ctr2, nDATA;
	int run, repetition, index;
	int arrSize;
	int k;

	unsigned __int64 *currentSumArray, *sumArray;
	unsigned *currentNSummedArray, *nSummedArray;
	
	int runItem, allItem;


	if (r == NULL) return;

	currentSumArray = NULL;
	sumArray = NULL;
	currentNSummedArray = NULL;
	nSummedArray = NULL;
	totalIterations = 0;
	done = 0;
	arrSize = 0;
	for (detector = 0; detector < N_DETECTORS; detector++) {
		ctr = COUNTERS_NCOUNTS[detector];
		totalIterations += r->nData[ctr];
		nColumns[detector] = ListNumItems (r->lTimeIntervals[detector]);
		arrSize += nColumns[detector];
	}
	totalIterations *= r->nCopiesPerRepetition;
	nCurvesDisplayed = 0;
	
	if (totalIterations > 5000) {
		progressDialog = CreateProgressDialog ("Generating list of counts",
										 extractFilename (r->filenameRun), 1,
										 VAL_NO_MARKERS,
										 "Stop");
	}
	FILTERS_setKeepResults (r->session, 1);
//	RUN_calculateAllPlotItemsForAllData (r, &nPlotItemsCalculated, PLOT_TYPE_NCOUNTS);
	RUN_getNPlotItemsType (r, &nPlotItemsCalculated, PLOT_TYPE_NCOUNTS);
	COUNTS_initPanel (0, r, nPlotItemsCalculated);
	arrSize += nPlotItemsCalculated;

	
//		ClearListCtrl (r->panelCounts, treeCtrl[detector]);
//		ProcessDrawEvents();
//	ctr = COUNTERS_NCOUNTS[detector];
	ctr1 = COUNTERS_NCOUNTS[0];
	ctr2 = COUNTERS_NCOUNTS[1];
//	nDATA = max(r->nData[ctr1], r->nData[ctr2]);

	currentSumArray = (unsigned __int64 *) malloc (arrSize * sizeof ( unsigned __int64));
	currentNSummedArray = (unsigned *) malloc (arrSize * sizeof ( unsigned ));
//	totalSumArray = (unsigned __int64 *) malloc (arrSize * sizeof ( unsigned __int64));
//	totalNSummedArray = (unsigned *) malloc (arrSize * sizeof ( unsigned ));
	sumArray = (unsigned __int64 *) malloc (arrSize * sizeof ( unsigned __int64));
	nSummedArray = (unsigned *) malloc (arrSize * sizeof ( unsigned )); 	

	i = 0;
	allItem = InsertTreeItem (r->panelCounts, COUNTS_TREE, VAL_SIBLING, 0,
							  VAL_NEXT, "all Runs", NULL, NULL, -1);
	
	
	for (repetition = 0; repetition < r->nRepetitionsPerRun; repetition++) {
		for (k = 0; k < arrSize; k++) {
			sumArray[k] = 0;
			nSummedArray[k] = 0;
		}
//		if (repetition == 11) Breakpoint();
		for (run = 0; run < r->nRuns; run++) {
			if (progressDialog && (i % 200 == 0)) {
				if (UpdateProgressDialog (progressDialog, (100*r->nCopiesPerRepetition*(done+i))/totalIterations, 1)) 
					goto STOPPED;
			}
			
			for (detector = 0; detector < N_DETECTORS; detector++) {
				ctr = COUNTERS_NCOUNTS[detector];
				data[detector] = NULL;
				if (r->data[ctr] != NULL) {
					index = RUN_datasetIndex(r, run, repetition);
					data[detector] = r->data[ctr][index];
					if (data[detector] != NULL) {
						data[detector]->nTimeIntervals = ListNumItems (r->lTimeIntervals[detector]);
					}
				}
				if (data[detector] != NULL) RUN_calculateAllPlotItems (r, data[detector], repetition, detector, 0);
			}
			i++;
			runItem = COUNTS_displayTreeItem (r->panelCounts, COUNTS_TREE, r, data, nColumns,
									0, &nCurvesDisplayed, MAX_CURVES_TO_DISPLAY,
							 		currentSumArray, currentNSummedArray, arrSize );
							 		
			for (k = 0; k < arrSize; k++) {
				sumArray[k] += currentSumArray[k];	
				nSummedArray[k] += currentNSummedArray[k];	
			}
		}
		SetTreeItemAttribute (r->panelCounts, COUNTS_TREE, runItem, ATTR_COLLAPSED, 1);

		for (detector = 0; detector < N_DETECTORS; detector++) {
			if (data[detector]!= NULL) RUN_calculateAllPlotItems (r, data[detector], repetition, detector, 1);
		}
		
		COUNTS_insertResultsRepetition (r->panelCounts, COUNTS_TREE, allItem, r, repetition,
					 		             sumArray, nSummedArray, nColumns[0] +nColumns[1]);
	}

	done += i;


STOPPED:
	if (progressDialog) DiscardProgressDialog (progressDialog);
	
	free (currentSumArray);
	free (currentNSummedArray);
	free (sumArray);
	free (nSummedArray);

	return;
}




void COUNTS_resizePanel (int panel)
{
	setCtrlBoundingRect (panel, COUNTS_TREE, 	
					 	 0, 0, panelHeight (panel), panelWidth (panel));

}


void COUNTS_initPanel (int parentPanel, t_run *r, int nPlotItemsCalculated)
{
	char titleStr[500];
	int detector;
	
	if (r->panelCounts == -1) {
		r->panelCounts = 
			LoadPanel (parentPanel, SESSIONMANAGER_uirFile, COUNTS);
		sprintf (titleStr, "Counts %04d - %s (%s %s)", r->startNr, extractFilename (r->filenameRun),
				 r->dateStr, r->timeStr);
		SetPanelAttribute (r->panelCounts, ATTR_TITLE, titleStr);
		ClearListCtrl (r->panelCounts, COUNTS_TREE);
	}
	COUNTS_initTree (r, r->panelCounts, COUNTS_TREE, nPlotItemsCalculated);
//	COUNTS_initTree (r, r->panelCounts, COUNTS_TREE_2, nPlotItemsCalculated);
	COUNTS_resizePanel (r->panelCounts);
}



void COUNTS_closePanel (int panel)
{
	RUNS_deleteAllReferencesToPanel (panel, activeRunPtr());
	
//	ClearListCtrl (panel, COUNTS_TREE);
//	ClearListCtrl (panel, COUNTS_TREE_2);
//	DiscardCtrl (panel, COUNTS_TREE);
//	DiscardCtrl (panel, COUNTS_TREE_2);
	DiscardPanel (panel);
}


int CVICALLBACK COUNTS_panelCallback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_GOT_FOCUS:
			break;
		case EVENT_LOST_FOCUS:
			break;
		case EVENT_CLOSE:
			COUNTS_closePanel (panel);
			break;
		case EVENT_DISCARD:
			COUNTS_closePanel (panel);
			break;
		case EVENT_PANEL_SIZE:
			COUNTS_resizePanel (panel);
			break;
	}
	return 0;
}




//============================================================
//
//   RUNS
//
//============================================================





enum {  
	RUNS_COL_NAME,
	RUNS_COL_TIME,
	RUNS_COL_SWEEP,
	RUNS_COL_SWEEP_NPOINTS,
	RUNS_COL_NCOPIES,
	RUNS_COL_NRUNS,
						  
	RUNS_COL_NDATASETS,
	RUNS_COL_COMMENT,
	
	N_RUNS_COL
};



void RUNS_debugLoadRun (void)
{

//	RUNS_loadAndDisplay ("D:\\temp\\DATA\\2006\\March\\22\\0031_R3 det1 scanfreq\\R3 det1 scanfreq.run");
//	RUNS_loadAndDisplay ("D:\\temp\\DATA\\2006\\March\\22\\0019_franges_r2_r3\\franges_r2_r3.run");
}



void RUNS_initTree (int panel, int ctrl)
{
	setNumTreeColumns (panel, ctrl, N_RUNS_COL);


	// set attributes for columns
	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_NAME,
							ATTR_COLUMN_WIDTH, 200);
	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_NAME, 
							ATTR_LABEL_TEXT, "name");

	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_TIME,
							ATTR_COLUMN_WIDTH, 50);
	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_TIME, 
							ATTR_LABEL_TEXT, "time");

	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_SWEEP,
							ATTR_COLUMN_WIDTH, 100);
	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_SWEEP, 
							ATTR_LABEL_TEXT, "sweep");

	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_SWEEP_NPOINTS,
							ATTR_COLUMN_WIDTH, 50);
	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_SWEEP_NPOINTS, 
							ATTR_LABEL_TEXT, "points");

	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_NCOPIES,
							ATTR_COLUMN_WIDTH, 50);
	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_NCOPIES, 
							ATTR_LABEL_TEXT, "copies");

	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_NRUNS,
							ATTR_COLUMN_WIDTH, 50);
	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_NRUNS, 
							ATTR_LABEL_TEXT, "runs");

	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_NDATASETS,
							ATTR_COLUMN_WIDTH, 50);
	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_NDATASETS, 
							ATTR_LABEL_TEXT, "nData");

	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_COMMENT,
							ATTR_COLUMN_WIDTH, 200);
	SetTreeColumnAttribute (panel, ctrl, RUNS_COL_COMMENT, 
							ATTR_LABEL_TEXT, "comment");
							

}


void RUNS_displayPanel (void)
{
	if (panelRuns == -1) RUNS_initPanel();
	DisplayPanel (panelRuns);	
}


void RUNS_resizePanel (void)
{
	int width, height;
	
	width = panelWidth (panelRuns);
	if (width < 100) width =  100;
	height = panelHeight (panelRuns) - panelMenuHeight (panelRuns) ;
	if (height < 50) height = 50;
//	SetPanelSize (panelRuns, height, width);
	SetCtrlAttribute (panelRuns, RUNS_TREE, ATTR_WIDTH, 
					  width);
	SetCtrlAttribute (panelRuns, RUNS_TREE, ATTR_HEIGHT, 
					  height);
	SetCtrlAttribute (panelRuns, RUNS_TREE, ATTR_LEFT, 
					  0);
}


int RUNS_initPanel (void) 
{
	static int panelRunsDummy = -1;
	
	if (panelRuns == -1) {
		panelRuns = LoadPanel (0, SESSIONMANAGER_uirFile, RUNS);
		SetCtrlAttribute (panelRuns, RUNS_TREE,
						  ATTR_ZPLANE_POSITION, 0);
		RUNS_initTree (panelRuns, RUNS_TREE);
		SetPanelSize (panelRuns, 300, 800);
		RUNS_resizePanel ();
		SetPanelPos (panelRuns, 40, 10);
		if (panelRunsDummy == -1) panelRunsDummy = LoadPanel (0, SESSIONMANAGER_uirFile, RUNS_DUMMY);         
		menuRunsTree = GetPanelMenuBar (panelRunsDummy);
		SetCtrlAttribute (panelRuns, RUNS_TREE, ATTR_ENABLE_POPUP_MENU, 0);
		RUNS_debugLoadRun ();
	}
//	DisplayPanel (panelRuns);
	return panelRuns;
}


t_run *RUNS_getFromIndex (int item)
{
	unsigned pointer;

	if (item < 0) return NULL;
	
	GetValueFromIndex (panelRuns, RUNS_TREE, item, &pointer);
	return (t_run *) pointer;
}



void *RUNS_deleteAllReferencesToCurve (t_graph *g, t_curve *c)      
{
	t_run *r;
	int item;

	item = VAL_FIRST;
	GetTreeItem (panelRuns, RUNS_TREE, VAL_ALL, 0,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		r = RUNS_getFromIndex (item);
		if ((r != NULL) && (r->session != NULL)) PLOTITEM_deleteReferenceToCurve (r->session, g, c);
		GetTreeItem (panelRuns, RUNS_TREE, VAL_ALL, 0,
					 item, VAL_NEXT, 0, &item);
	}
	return NULL;
}


void RUNS_deleteAllReferencesToPanel (int panel, t_run *activeR)      
{
	t_run *r;
	int item;

	if (panel < 0) return;
	item = VAL_FIRST;
	GetTreeItem (panelRuns, RUNS_TREE, VAL_ALL, 0,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		r = RUNS_getFromIndex (item);
		if (r != NULL) {
			if (r->panelCounts == panel) r->panelCounts = -1;
		}
		GetTreeItem (panelRuns, RUNS_TREE, VAL_ALL, 0, item, VAL_NEXT,
					 0, &item);
	}
	if (activeR != NULL) {
		if (activeR->panelCounts == panel) activeR->panelCounts = -1;
	}
}


void RUNS_displayTreeItem (t_run *r)
{
	int dateItem, runItem;
	char *help;
	
	help = getTmpString();
	
	GetTreeItemFromTag (panelRuns, RUNS_TREE, r->dateStr, &dateItem);
	if (dateItem < 0) {
		dateItem = InsertTreeItem (panelRuns, RUNS_TREE, VAL_SIBLING, 0,
						           VAL_LAST, r->dateStr, r->dateStr, NULL, 0);
	}

	// -----------------------------
	//      display name
	// -----------------------------
	
	sprintf (help, "%04d_%s", r->startNr, extractFilename(r->filenameRun));
	runItem = InsertTreeItem (panelRuns, RUNS_TREE, 
							  VAL_CHILD, dateItem, VAL_LAST,
							  help, NULL, NULL, (unsigned) r);
	// -----------------------------
	//      time 
	// -----------------------------
	SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_TIME,
						  ATTR_LABEL_TEXT, r->timeStr);
	SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_TIME,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_TIME,
						  ATTR_LABEL_COLOR, VAL_LT_GRAY);
	// -----------------------------
	//      sweep
	// -----------------------------
	if (r->sweep != NULL) {
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_SWEEP,
							  ATTR_LABEL_TEXT, r->sweep->name);
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_SWEEP, 
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_LEFT_JUSTIFIED);
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_SWEEP_NPOINTS,
							  ATTR_LABEL_TEXT, intToStr(r->nRepetitionsPerRun));
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_SWEEP_NPOINTS,
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_CENTER_JUSTIFIED);
	}

	// -----------------------------
	//      n Copies, n Runs 
	// -----------------------------
	SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_NCOPIES,
						  ATTR_LABEL_TEXT, intToStr (r->nCopiesPerRepetition));
	SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_NCOPIES,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_NRUNS,
						  ATTR_LABEL_TEXT, intToStr (r->nRuns));
	SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_NRUNS,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_NDATASETS,
						  ATTR_LABEL_TEXT, intToStr (r->nData[0]));
						  
	SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_NDATASETS,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);

	// --------------------------------
	//      comment
	// --------------------------------
	if (r->session == NULL) {
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_COMMENT,
						  ATTR_LABEL_TEXT, "ERROR: no session loaded");
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem,
							  RUNS_COL_COMMENT, ATTR_LABEL_COLOR,
							  VAL_RED);
	}
	else {
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_COMMENT,
							  ATTR_LABEL_TEXT, r->session->comments);
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_COMMENT,
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_CENTER_JUSTIFIED);
	}

/*	if (r->session != NULL) {
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_SESSION,
							  ATTR_LABEL_TEXT, extractFilename(r->session->filename));
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, RUNS_COL_SESSION,
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_CENTER_JUSTIFIED);
		SetTreeCellAttribute (panelRuns, RUNS_TREE, runItem, 
							  RUNS_COL_SESSION,
							  ATTR_LABEL_COLOR, VAL_LT_GRAY);
	}
*/
}


void RUNS_loadAndDisplay (const char *filename)
{
    t_run *r;
    int i;

	SetWaitCursor (1);
	
    r = RUN_load (filename, fileSize (filename) > 1000000);  
	SetWaitCursor (0);
    
    if (r == NULL) return;
    
    if (r->session == NULL) return;
    r->session->loadedWithRunData = 1;
    r->session->run = r;
    RUNS_displayTreeItem (r);
}


void CVICALLBACK MENU_loadRun (int menuBar, int menuItem, void *callbackData,
		int panel)
{
    char filename[MAX_PATHNAME_LEN];

/*    if (FileSelectPopup (smanagerConfig->dataPathToday, RUN_fileSuffix, RUN_fileSuffix,
						 "Load run", VAL_LOAD_BUTTON, 0, 1, 1, 0,
						 filename) > 0) {
*/    
	if (FileSelectPopup (smanagerConfig->dataPathToday, "*_run.zip",
						 "*.zip; *.run", "Load run", VAL_LOAD_BUTTON,
						 0, 1, 1, 0, filename) > 0) {
		strcpy (smanagerConfig->dataPathToday, extractDir (filename));
		RUNS_loadAndDisplay (filename);
    }
	
}

void RUNS_discardRun (t_run **r)
{
	int sessionNr;
	int index;

	if (*r == NULL) return;

	(*r)->freeSession = 1;
	// removeSession if displayed
	sessionNr = SESSION_getNrFromPtr ((*r)->session);
	if (sessionNr > 0) {
		SESSION_close (sessionNr);
		(*r)->session = NULL;
	}
	
	DiscardPanel ((*r)->panelCounts);

	index = -1;
	GetIndexFromValue (panelRuns, RUNS_TREE, &index, (int) (*r));
	if (index >= 0) DeleteListItem (panelRuns, RUNS_TREE, index, 1);
	
//	RUNS_deleteAllReferences (*g, NULL);

	RUN_free (*r);
	free (*r);
	*r = NULL;
}



void RUNS_discardAll (void)
{
	t_run *r;
	int item;
	
	item = VAL_LAST;
	GetTreeItem (panelRuns, RUNS_TREE, VAL_ALL, 0, item,
				 VAL_PREV_PLUS_SELF, 0, &item);
	while (item >= 0) {
		r = RUNS_getFromIndex (item);
		GetTreeItem (panelRuns, RUNS_TREE, VAL_ALL, 0, item,
					 VAL_PREV, 0, &item);
		RUNS_discardRun (&r);
//		GRAPH_discard();
	}
}



void RUNS_hideAllCountWindows (void)
{
	t_run *r;
	int item;
	
	item = VAL_LAST;
	GetTreeItem (panelRuns, RUNS_TREE, VAL_ALL, 0, item,
				 VAL_PREV_PLUS_SELF, 0, &item);
	while (item >= 0) {
		r = RUNS_getFromIndex (item);
		GetTreeItem (panelRuns, RUNS_TREE, VAL_ALL, 0, item,
					 VAL_PREV, 0, &item);
		if ((r != NULL) && (r->panelCounts > 0)) HidePanel (r->panelCounts);
	}
}


void RUNS_hidePanel (void)
{
	RUNS_hideAllCountWindows ();
	if (panelRuns > 0) HidePanel (panelRuns);
}


void RUNS_quit (void)
{
	// free all old runData
	
	RUNS_hideAllCountWindows ();
	RUNS_discardAll ();	
	DiscardPanel (panelRuns);
	panelRuns = -1;
}


void CVICALLBACK MENU_quitRun (int menuBar, int menuItem, void *callbackData,
		int panel)
{	
	RUNS_quit ();
}


int CVICALLBACK RUNS_panelCallback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_GOT_FOCUS:
			break;
		case EVENT_LOST_FOCUS:
			break;
		case EVENT_CLOSE:
			break;
		case EVENT_PANEL_SIZE:
			RUNS_resizePanel();
			break;
	}
	return 0;
}

int CVICALLBACK RUNS_quit_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			if (ConfirmPopup ("Quit", "Do you really want to quit the display of previous runs?") == 0) return 0;
			RUNS_quit ();
			break;
	}
	return 0;
}



//int GRAPH_getSelectionFromTree (t_graph **w, t_curve **c, int *selected, int *clicked2D, int *clickedCurrent)


int RUNS_getSelectionFromTree (t_run **r, int *selected)
{

	int index = -1;
	int level = -10;
	
	*r = NULL;
	if (selected != NULL) *selected = 0;
	
	// no curve item selected
	GetActiveTreeItem (panelRuns, RUNS_TREE, &index);
	if (index == -1) return -1;
	
	if (selected != NULL) {
		GetTreeItemAttribute (panelRuns, RUNS_TREE, index, ATTR_MARK_STATE, selected);
	}

	GetTreeItemLevel (panelRuns, RUNS_TREE, index, &level);
//	GetValueFromIndex (panelRuns, RUNS_TREE, index, &value);
	switch (level) {
		case RUNS_TREELEVEL_DATE:
			
			break;
		case RUNS_TREELEVEL_RUN:
			GetCtrlVal (panelRuns, RUNS_TREE, r);
			return 1;
	}	

	return 0;
}


void RUNS_treeMenu_insertPlotItems (t_run *r)
{
	t_session *s;
	int i;
	int ok;
	t_plotItem *p;
	char help[200];
	
	
	EmptyMenu (menuRunsTree, MENURUNS_TREE_DISPLAYPLOTITEM_SU);

	if (r == NULL) return;
	s = r->session;
	if (s == NULL) return;
	
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
		sprintf (help, "%s (%s)", p->name, PLOTITEM_typeStr (p));
		ok = NewMenuItem (menuRunsTree, MENURUNS_TREE_DISPLAYPLOTITEM_SU,
					 help, -1, 0, 0, (void*) i);
		
	}
	
}


int CVICALLBACK RUNS_tree_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int item;
	t_run *r;
	void *plotItemIndex;
	
	switch (event) {
		case EVENT_RIGHT_CLICK:
            RUNS_getSelectionFromTree (&r, 0);
			if (r == NULL) return 0;
			RUNS_treeMenu_insertPlotItems (r);
            item = RunPopupMenu (menuRunsTree, MENURUNS_TREE, panel, 
                eventData1, eventData2, 0,0,0,0);
            switch (item) {
           		case MENURUNS_TREE_DISPLAYCOUNTS:
           		    COUNTS_displayRun (r);
           		    DisplayPanel (r->panelCounts);
           			break;
           		case MENURUNS_TREE_DISPLAYSESSION:
			        if (r->session != NULL) {
				        SESSION_appendToList (r->session);
					    SESSION_setAsActive (nSessions());
				    	SESSIONMANAGER_displayList (1);  
				    }
           			break;
           		case MENURUNS_TREE_DISPLAYCURVES:
           			break;
           		case MENURUNS_TREE_REMOVE:
					RUNS_discardRun (&r);
           			break;
           		default:
           		    // MENURUNS_TREE_DISPLAYPLOTITEM:
					GetMenuBarAttribute (menuRunsTree, item, ATTR_CALLBACK_DATA, &plotItemIndex);
					RUN_generatePlotFromOldData (r, (int) plotItemIndex);
           			break;
           		  
			}
	}
	return 0;
}



