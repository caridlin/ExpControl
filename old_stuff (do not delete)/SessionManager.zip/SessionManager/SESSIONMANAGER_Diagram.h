#if !defined (SESSIOMANAGER_DIAGRAM)
#define SESSIOMANAGER_DIAGRAM


//void DIAG_init (t_diag *d);

//t_diag* new_t_diag();

void DIAGRAM_displayPanel (t_session *s);

void DIAGRAM_fillEventStylesToRing (int panel, int ctrl);




#endif

