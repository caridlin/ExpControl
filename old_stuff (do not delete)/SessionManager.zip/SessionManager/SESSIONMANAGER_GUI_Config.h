#if !defined (SESSIOMANAGER_GUI_CONFIG)
#define SESSIOMANAGER_GUI_CONFIG



int SCONFIG_initPanel (void);
void SCONFIG_discardPanel (void);


void SCONFIG_POSITIONS_initPanel (t_session *s);


void SCONFIG_POSITIONS_initRingReference (int panel, int control);

void SCONFIG_setRfParameters (t_atomConfig *c);
void SCONFIG_getRfParameters (t_atomConfig *c);

void SCONFIG_getPositions (t_atomConfig *c);
void SCONFIG_setPositions (t_atomConfig *c);

void SCONFIG_KILLER_setValues (t_session *s, int cavityNr);

void SCONFIG_KILLER_setDefaultVoltages (int panel, int ctrlDefaultV, int ctrlDefaultDetuning, 
										t_session *s, int cavity);

/*
void SCONFIG_SEQGEN_initPanel (t_smanagerConfig *c);
void SCONFIG_SEQGEN_getParameters (t_session *s, t_smanagerConfig *c);
void SCONFIG_SEQGEN_setParameters (t_session *s, t_smanagerConfig *c);
*/
/*
void SCONFIG_ACQUISITION_initPanel (void);
void SCONFIG_ACQUISITION_getParameters (t_session *s);
void SCONFIG_ACQUISITION_setParameters (t_session *s);
 */




#endif
