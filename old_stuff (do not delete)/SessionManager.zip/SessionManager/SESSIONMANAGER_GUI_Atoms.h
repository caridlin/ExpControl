#if !defined (SESSIOMANAGER_GUI_ATOMS)
#define SESSIOMANAGER_GUI_ATOMS


void setCtrlMode (int panel, int control, int hot, int reference);

int subPanelCirc (void);
int subPanelVelocity (void);
int subPanelEvents (void);
int subPanelCavity (int i);
int subPanelState (void);
int subPanelDetection (void);

t_atom *activeAtom (void);

//void ATOM_GetAtomAndNCopyFromInt(int rawNumber,int* atomNr,int* NCopy);
int ATOMS_initPanel (void);
void ATOMS_displayAtomParameters (t_session *s, t_atom *a);
void ATOMS_displayAllValues (t_session *s);
//void ATOMS_initRings (t_session *s);
void ATOMS_fillAtomNamesToRing (int panel, int control, t_session *s, int addNone, int checkForCrossRefs);

void ATOMS_fillLevelsToRing (int panel, int control, t_session *s, int showVoltages);

//void ATOMS_fillLevelsToRing (int panel, int control, t_session *s);

void ATOMS_calculateAllTimes (t_session *s);
double ATOMS_getSmallestTime (t_session *s, int atomNr);
double ATOMS_getSmallestTimeAll (t_session *s);
void ATOMS_calculateTimesForAtom (t_session *s, t_atom *a);


		 


void ATOMS_TABLE_displayAtom (int row, char *atomLabel, t_atom *a, t_session *s);
void ATOMS_TABLE_displayActiveAtom (t_session *s);
//void ATOMS_TABLE_updateAllAtoms (int panel, int table, t_session *s);
void ATOMS_TABLE_displayAllAtoms (t_session *s);

void ATOMS_TABLE_init (t_session *s);
void ATOMS_TABLE_displayColors (int panel, int table, t_session *s);
int ATOMS_TABLE_getRowFromAtomNr (int panel, int table, t_session *s, int atomNr);
int ATOMS_TABLE_columnFromDataFieldID (t_session *s, int dataFieldID);
void CVICALLBACK ATOMS_TABLE_menuItemSelected (int panelHandle, int controlID,
                              int menuItemID, void *callbackData);


								 

void ATOMS_CAVITY_initPanel (int panel);
void ATOMS_CAVITY_setValues (t_session *s, t_atom *a, int cavityNr);
void ATOMS_CAVITY_displayKillerPoints (t_atom *a, int cavityNr);



void ATOMS_EVENTS_initPanel (void);
void ATOMS_EVENTS_displayAll (t_session *s, t_atom *a);
int ATOMS_EVENTS_positionOfChannel(int channel);

void ATOMS_DETECTOR_initPanel (t_session *s);

void ATOMS_VELOCITY_initPanel (t_session *s);


void ATOMS_KILLER_initPanel (void);


void ATOMS_KILLER_makeTransferFunction  (t_transferFunction *f, 
									     double par1, double par2, double par3);

//void ATOMS_KILLER_makeTransferFunction  (t_transferFunction *f, 
//									     double par1, double par2, double par3);

void ATOMS_KILLER_setTransferFunctionInv (int panel, int ctrl, t_session *s, int cavity);

									     


void DIAGRAM_displayPanel (t_session *s) ;
void DIAGRAM_plot (t_session *s);


#endif
