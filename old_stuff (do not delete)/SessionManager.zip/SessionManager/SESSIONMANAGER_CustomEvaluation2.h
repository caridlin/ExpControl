#if !defined (SESSIOMANAGER_CUSTOM2)
#define SESSIOMANAGER_CUSTOM2

void CUSTOM2_startEvaluation (void);



#endif
