#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"



extern int panelSMain;

int panelCurves = -1;
int panelAxis = -1;
int panelStatistics= -1;
int panelCursors = -1;
int panelRenameCurve = -1;
int panelPrint = -1;
int graphPanelPrint = -1;

#define N_CUSTOM_EVALUATIONPANELS 2

int panelCustomEvaluation[N_CUSTOM_EVALUATIONPANELS];     

int panelIDcustom[N_CUSTOM_EVALUATIONPANELS] = {
	CUSTOM1,
	CUSTOM2
};

// if graph contains > 101 points, the error bars are not displayed
int NPointsSuppressErrorBars = 101;

#define PLOT_BAR_METAFONT 			  "PLOT_BAR_METAFONT"
#define PLOT_BAR_METAFONT_ORIGIN     VAL_APP_META_FONT
#define PLOT_BAR_METAFONT_POINTSIZE  18
#define PLOT_BAR_METAFONT_BOLD       0



#define TREELEVEL_PLOTWINDOWS 0
#define TREELEVEL_CURVES      1  
#define TREELEVEL_SUB         2  // 2D plots + current curve

#define TREE_VALUE_2D         -1
#define TREE_VALUE_CURRENT 	  -2

#define COLOR_CURSOR1 VAL_BLUE
#define COLOR_CURSOR2 VAL_RED
#define COLOR_DIFFERENCE VAL_DK_GREEN
// delete
// rename
// change display mode (BAR, POINT, LINE)
// move to front
// move to back
// change color


// ---------------------------------------------------
//        definition of colors + names
// ---------------------------------------------------

#define N_CURVE_COLORS 12
const char COLOR_NAME_AUTO[] = "auto select";
const char STYLE_NAME_AUTO[] = "auto select";

int CURVE_colors[N_CURVE_COLORS] = { 
	   VAL_BLACK,
	   VAL_RED, 
	   VAL_GREEN,
	   VAL_BLUE, 
	   VAL_CYAN,                     
	   
	   VAL_MAGENTA,
	   VAL_ORANGE,
	   VAL_DK_RED,
	   VAL_DK_BLUE,                     
	   VAL_DK_CYAN,
	   VAL_LT_GRAY,
	   VAL_DK_GREEN
	};



#define N_CURVE_COLORS_DIG 9
int CURVE_colors_DIG[N_CURVE_COLORS_DIG] = { 
	   VAL_DK_GREEN,
	   VAL_BLUE, 
	   VAL_CYAN,                     
	   VAL_MAGENTA,
	   VAL_DK_RED,
	   
	   VAL_DK_BLUE,                     
	   VAL_DK_CYAN,
	   VAL_LT_GRAY,
	   VAL_BLACK
	};





char *CURVE_colorNames[N_CURVE_COLORS] = {
	"black",
	"red",
	"green",
	"blue",
	"cyan",   
	
	"magenta",
	"orange",
	"dark red",
	"dark blue",
	"dark cyan",
	"gray",
	"darl green"
};


int MENUCURVES_colorItems[N_CURVE_COLORS];


// ---------------------------------------------------
//        definition of curve styles + names
// ---------------------------------------------------

#define N_CURVE_STYLES 5

//#define CURVE_STYLE_BAR       0
//#define CURVE_STYLE_THIN_LINE 1
//#define CURVE_STYLE_FAT_LINE  2
//#define CURVE_STYLE_POINTS    3
//#define CURVE_STYLE_CONNECTED_POINTS    4


int CURVE_styles[N_CURVE_STYLES] = { 
	VAL_VERTICAL_BAR,
	VAL_THIN_LINE, 
	VAL_FAT_LINE,  
    VAL_SCATTER,    
    VAL_CONNECTED_POINTS
};

char *CURVE_styleNames[N_CURVE_STYLES] = {
	"bar",
	"thin line",
	"fat line",
	"points",
	"connected points"
};

int MENUCURVES_styleItems[N_CURVE_STYLES];


enum {  
	CURVES_COL_NAME,
	CURVES_COL_STARTNR,
	CURVES_COL_TIME,
	CURVES_COL_DATE,
	CURVES_COL_AVG,
	CURVES_COL_INFO,

	N_CURVES_COL
};


int menuCurves = -1;
int menuCurves2 = -1;
int menuGraph  = -1;
int menuGraph2D  = -1;
//int *menuCurves_Items = NULL;

void SWEEP_setValues (t_sweep *s, int nPoints);


#define SetCtrlValDouble_MAX_STD 100000
void setCtrlValDouble (int panel, int ctrl, double val)
{
	if (val < SetCtrlValDouble_MAX_STD) 
		SetCtrlAttribute (panel, ctrl, ATTR_FORMAT,
						  VAL_FLOATING_PT_FORMAT);
	else
		SetCtrlAttribute (panel, ctrl, ATTR_FORMAT,
						  VAL_SCIENTIFIC_FORMAT);
						 
	SetCtrlVal (panel, ctrl, val);
}


char *concatLabelAndUnits (const char *label, const char *units) 
{
	char *help;
	
	help = getTmpString ();
	strcpy (help, label);
	if (units[0] != 0) {
		strcat (help, " (");
		strcat (help, units);
		strcat (help, ")");
	}
	return help;
}

/*
void setTime (int panel, int ctrl, unsigned __int64 uLtime, int sign)
{              
    SetCtrlVal (panel, ctrl, ulToTime(uLtime)*sign);
    
    if ((uLtime % VAL_ms) == 0)
        SetCtrlAttribute (panel, ctrl, ATTR_PRECISION, 1);
    else
    if ((uLtime % VAL_us) == 0)
        SetCtrlAttribute (panel, ctrl, ATTR_PRECISION, 3);
    else
    	SetCtrlAttribute (panel, ctrl, ATTR_PRECISION, 5); 
}
*/


int PLOT_colorNr (int color)
{
	int i;
	
	for (i = 0; i < N_CURVE_COLORS; i++) {
		if (CURVE_colors[i] == color) return i;
	}
	return -1;
}


int PLOT_colorNr_DIG (int color)
{
	int i;
	
	for (i = 0; i < N_CURVE_COLORS_DIG; i++) {
		if (CURVE_colors_DIG[i] == color) return i;
	}
	return -1;
}


int CURVE_getMatchingColor (int color)
{
	switch (color) {
		case VAL_BLACK    : return VAL_WHITE;
		case VAL_RED      : return VAL_ORANGE;
	    case VAL_GREEN    : return VAL_DK_GREEN;
	    case VAL_BLUE     : return VAL_DK_BLUE;
	    case VAL_CYAN     : return VAL_MAGENTA;                     
		case VAL_MAGENTA  : return VAL_CYAN;
	    case VAL_ORANGE   : return VAL_RED;
	    case VAL_DK_RED   : return VAL_DK_CYAN; 
	    case VAL_DK_BLUE  : return VAL_BLUE;                     
	    case VAL_DK_CYAN  : return VAL_DK_RED;
	    case VAL_WHITE     : return VAL_BLACK;
	    case VAL_DK_GREEN : return VAL_GREEN;
	    default: return VAL_BLACK;
	}
}



void CURVE_sumAllDatasets (t_curve *c, int index)
{
	int i;
	double sum;
	int nValues;
	
	nValues = 0;
	sum = 0;
	for (i = 0; i < c->nCurvesWritten; i++) {
		if (c->yValues[i][index] != NO_VALUE) {
			sum += c->yValues[i][index];
			nValues ++;
		}
	}
	if (nValues > 0) {
		c->yValuesAveraged[index] = sum / nValues;
		c->yErrPosAveraged[index] = sqrt (c->yValuesAveraged[index]);
	}
}




void CURVE_getWeightedMeanOfAllDatasets (t_curve *c, int index)
{
	int i;
	double sigmaSQR;
	double sigmaSQRsum;
	double weightedSum;
	int nValues;
	
	// given are values x[i] with errors sigma[i], i = 1 ... n
	// routine calculates weighted sum WS and its error sigmaWS
	
	// 				  NORM = SUM(1/sigma[i]^2, i=1..n) 
	//                 WS = SUM(x[i]/sigma[i]^2, i=1..n) / NORM
	// 		1 / sigmaWS^2 = SUM(1/sigma[i]^2, i=1..n) / n
	nValues = 0;
	weightedSum = 0;
	sigmaSQRsum = 0;
	
	
	for (i = 0; i < c->nCurvesWritten; i++) {
		if (c->yValues[i][index] != NO_VALUE) {
			sigmaSQR = c->yErrPos[i][index] * c->yErrPos[i][index];
			if (sigmaSQR != 0.0) {
				nValues++;
				weightedSum += c->yValues[i][index] / sigmaSQR;
				sigmaSQRsum += 1 / sigmaSQR;
			}
			
		}
	}
//	if (nValues == 0) {
//		if (c->nCurvesWritten && 
//	}
	if (nValues > 0) {
		c->yValuesAveraged[index] = weightedSum / sigmaSQRsum;
		c->yErrPosAveraged[index] = 1 / (sigmaSQRsum / nValues);
	}
}


int CURVE_colorAuto (t_curve *curve)
{
	int colorUsed[N_CURVE_COLORS];
	int graphItem, item;
	int i;
	int min;
	t_curve *c;
	
	for (i = 0; i < N_CURVE_COLORS; i++) colorUsed[i] = 0;

	// check which colors are used
	CURVE_getTreeItemNr (NULL, curve, &graphItem, NULL, NULL, NULL);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		if (curve != c) {
			i = PLOT_colorNr (c->plotColor);
			if (i >= 0) colorUsed[i]++;
		}
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_NEXT, 0, &item);
	}
	
	min = 0;
	for (i = 0; i < N_CURVE_COLORS; i++) {
		if (colorUsed[i] == 0) return CURVE_colors[i];
		if (colorUsed[i] < colorUsed[min]) min = i;
	}
			
	return CURVE_colors[min];
}



int CURVE_colorAuto_DIG (t_curve *curve)
{
	int colorUsed[N_CURVE_COLORS_DIG];
	int graphItem, item;
	int i;
	int min;
	t_curve *c;
	
	for (i = 0; i < N_CURVE_COLORS_DIG; i++) colorUsed[i] = 0;

	// check which colors are used
	CURVE_getTreeItemNr (NULL, curve, &graphItem, NULL, NULL, NULL);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		if (curve != c) {
			i = PLOT_colorNr_DIG (c->plotColor);
			if (i >= 0) colorUsed[i]++;
		}
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_NEXT, 0, &item);
	}
	
	min = 0;
	for (i = 0; i < N_CURVE_COLORS_DIG; i++) {
		if (colorUsed[i] == 0) return CURVE_colors_DIG[i];
		if (colorUsed[i] < colorUsed[min]) min = i;
	}
			
	return CURVE_colors_DIG[min];
}



void CURVE_setStyle (t_curve *c, t_plotItem *p, int evenRepetition) 
{
	c->plotStyle = p->plotStyle;
	c->lineStyle =  VAL_SOLID;
	switch (p->plotStyle) {
		case VAL_VERTICAL_BAR:
			c->plotStyle = VAL_VERTICAL_BAR_ERROR;
			break;
		case VAL_THIN_LINE:
			c->pointStyle = VAL_SOLID_DIAMOND;
			break;
		case VAL_FAT_LINE:
			c->pointStyle  = VAL_NO_POINT;
			break;
		case VAL_SCATTER:
			c->pointStyle = VAL_SOLID_DIAMOND;
			break;
		case VAL_CONNECTED_POINTS:
			c->pointStyle = VAL_SOLID_DIAMOND;
			break;
		default:
			c->plotStyle =  VAL_CONNECTED_POINTS;
			c->pointStyle = VAL_SOLID_DIAMOND;
	}

	c->plotStyleCurrent = p->plotStyleCurrent;
	c->lineStyleCurrent  = VAL_DOT;
	switch (p->plotStyleCurrent) {
		case VAL_STYLE_AUTO:
			c->plotStyleCurrent  = VAL_THIN_LINE;
			c->pointStyleCurrent = VAL_SOLID_DIAMOND;
			break;
		case VAL_VERTICAL_BAR:
			c->plotStyleCurrent = VAL_VERTICAL_BAR_ERROR;
			break;
		case VAL_THIN_LINE:
			c->pointStyleCurrent  = VAL_SOLID_DIAMOND;
			break;
		case VAL_FAT_LINE:
			c->pointStyleCurrent  = VAL_NO_POINT;
			break;
		case VAL_SCATTER:
			c->pointStyleCurrent  = VAL_SOLID_DIAMOND;
			break;
		case VAL_CONNECTED_POINTS:
			c->pointStyleCurrent  = VAL_SOLID_DIAMOND;
			break;
		default:
			c->plotStyleCurrent =  VAL_CONNECTED_POINTS;
			c->pointStyleCurrent = VAL_SOLID_DIAMOND;
	}
	// ----------------------------
	//           set color
	// ----------------------------
	if (p->plotColor == VAL_COLOR_AUTO) {
		c->plotColor = CURVE_colorAuto (c);
	}
	else c->plotColor = p->plotColor;

	if (p->plotColorCurrent == VAL_COLOR_AUTO) {
		c->plotColorCurrent = CURVE_getMatchingColor (c->plotColor);
	}
	else c->plotColorCurrent = p->plotColorCurrent;
	
}


/*
void CURVE_setStyleCurrent (t_curve *c, t_plotItem *p, int evenRepetition) 
{
/*
#define VAL_SOLID                       0L
#define VAL_DASH                        1L
#define VAL_DOT                         2L
#define VAL_DASH_DOT                    3L
#define VAL_DASH_DOT_DOT                4L

	c->plotStyle = p->plotStyleCurrent;
	c->lineStyle =  VAL_SOLID;
	switch (p->plotStyleCurrent) {
		case VAL_VERTICAL_BAR:
			c->plotStyle = VAL_VERTICAL_BAR_ERROR;
			break;
		case VAL_THIN_LINE:
			c->pointStyle = VAL_SOLID_DIAMOND;
			c->lineStyle  = VAL_DASH_DOT;
			break;
		case VAL_FAT_LINE:
			c->pointStyle  = VAL_NO_POINT;
			c->lineStyle  = VAL_DASH_DOT;
			break;
		case VAL_SCATTER:
			c->pointStyle = VAL_SOLID_DIAMOND;
			break;
		case VAL_CONNECTED_POINTS:
			c->pointStyle = VAL_SOLID_DIAMOND;
			break;
		default:
			c->plotStyle =  VAL_CONNECTED_POINTS;
			c->pointStyle = VAL_SOLID_DIAMOND;
	}
	// ----------------------------
	//           set color
	// ----------------------------
	if (p->plotColorCurrent == VAL_COLOR_AUTO) {
		// debug: more intelligent determination of color
		c->plotColor = CURVE_colorAuto (c);
/*
		switch (evenRepetition) {
			case 0: 
				c->plotColor = CURVE_DEFAULT_COLOR_G;
				break;
			case 1:
				c->plotColor = CURVE_DEFAULT_COLOR_E;
				break;
			default:
				c->plotColor = colorAuto (c);

//		}
	}
	else c->plotColor = p->plotColor;
}
	*/


void CURVE_colorNamesToRing (int panel, int ctrl) 
{
	int i;
	int color;
	
	DeleteListItem (panel, ctrl, 0, -1);
	InsertListItem (panel, ctrl, -1, COLOR_NAME_AUTO, VAL_COLOR_AUTO);
	for (i = 0; i < N_CURVE_COLORS; i++) {
		InsertListItem (panel, ctrl, -1, CURVE_colorNames[i], CURVE_colors[i]);
	}
}


void CURVE_styleNamesToRing (int panel, int ctrl) 
{
	int i;
	int color;
	
	DeleteListItem (panel, ctrl, 0, -1);
	InsertListItem (panel, ctrl, -1, STYLE_NAME_AUTO, VAL_STYLE_AUTO);
	for (i = 0; i < N_CURVE_STYLES; i++) {
		InsertListItem (panel, ctrl, -1, CURVE_styleNames[i], CURVE_styles[i]);
	}
}



/*
int plotColor (int i)
{

//	if ((i < 0) || (i >= N_GRAPH_COLORS)) i = 0;
	return CURVE_colors[i % N_CURVE_COLORS];
	

}

*/

t_curve *CURVE_getFromIndex (int item)
{
	unsigned pointer;
	
	if (item < 0) return NULL;
	GetValueFromIndex (panelCurves, CURVES_TREE, item, &pointer);
	return (t_curve *) pointer;
}
		
			
t_graph *GRAPH_getFromIndex (int item)
{
	unsigned pointer;
	
	if (item < 0) return NULL;
	GetValueFromIndex (panelCurves, CURVES_TREE, item, &pointer);
	return (t_graph *) pointer;
}


void CURVE_setTime (t_curve *c)
{
	time_t t;
	
	if (c == NULL) return;
	time(&t);
	getDateAndTime (c->dateStr, c->timeStr);
}
					



void CURVE_init (t_curve *c)
{
	int i;
	
	c->name[0] = 0;
    c->title[0] = 0;
    c->plotType = -1;
    c->startNr = -1;
	c->xLabel[0] = 0;
	c->xLabel2[0] = 0;
	c->yLabel[0] = 0;
	c->yLabel2[0] = 0;
	c->xUnits[0] = 0;
	c->xUnits2[0] = 0;
	c->yUnits[0] = 0;
	c->yUnits2[0] = 0;
	c->yAsciiFileColumnLabel[0] = 0;
	c->xAsciiFileColumnLabel[0] = 0;
	c->xAsciiFileColumnLabel2[0] = 0;
	c->yAsciiFileColumnLabel2[0] = 0;
	c->xDigits = 9;
	c->xShowSecondAxis = 0;
	c->yShowSecondAxis = 0;
	c->xAxis2Multiply = 1;
	c->yAxis2Multiply = 1;

	c->yDigits = 6;
	c->yDigits2 = 6;
	c->info[0] = 0;
	c->dateStr[0] = 0;
	c->timeStr[0] = 0;
	c->divideAveraged = 1;
	c->averagedOnTop = 0;
	
	c->visible = 1;
	c->visible2D = 1;
	c->active = 0;
	CURVE_setTime (c);
	c->panelGraph = -1;
	c->keep = 0;
	
	c->newCurve = 1;
	c->nPlotHandlesAveraged = 0;
	c->plotHandlesAveraged = NULL;	
	c->nPlotHandlesCurrent = 0;
	c->plotHandlesCurrent = NULL;	
	
	c->nValues = 0;
	c->nValuesVisibleAvg = -1;
	c->xValues = NULL;
	
	c->yValuesAveraged = NULL;
	c->yAverages = NULL;
	c->hasErrorBars = 0;
	c->hasErrorBarsCurrent = 0;
	c->yErrPosAveraged = NULL;
	c->yErrNegAveraged = NULL;
	
	c->nCurves = 0;
	c->showCurrentCurve = 0;
	c->currentCurve = 0;
	c->nValues = NULL;
	c->nCurvesWritten = NULL;
	c->yValuesVisible = NULL;
	c->yValuesArrSize = NULL;
	c->yValues = NULL;
	c->yErrPos = NULL; 
	c->yErrNeg = NULL;
	
	c->maxYValue = 0.0;
	c->minYValue = 0.0;
	c->maxXValue = 0.0;
	c->minXValue = 0.0;
	c->sumYValues = 0.0;
	c->nAveraged = 0;

	c->plotStyle  = VAL_FAT_LINE;
	c->plotColor  = VAL_BLACK;
	c->pointStyle = VAL_EMPTY_SQUARE;
	c->lineStyle  = VAL_SOLID;
	c->plotNumbers = 0;
	
	c->plotStyleCurrent  = VAL_THIN_LINE;
	c->plotColorCurrent  = VAL_RED;
	c->pointStyleCurrent = VAL_EMPTY_SQUARE;
	c->lineStyleCurrent  = VAL_SOLID;
	
	
	c->nValues2D = 0;
	c->n2Dcurves = 0;
	c->values2D  = NULL;
	c->panel2DPlot = -1;
	c->plotHandle2D = -1;
	c->interpolate2D = 0;
	
/*	c->xFrom2D = 0;
	c->xTo2D   = 1.0;
	c->yFrom2D = 0;
	c->yTo2D   = 1.0;
	c->yLabel2D[0] = 0;
*/	c->xLabel2D[0] = 0;
	c->xUnits2D[0] = 0;
	c->panelPos2D = MakeRect (40,20,300,400);
	c->panelPos = MakeRect (-1,-1,-1,-1);
	
/*	c->showRightAxis2D = 0;
	c->rightAxis2DScalingFactor = 1;
	c->yRightLabel2D[0] = 0;
	c->yRightUnits2D[0]  = 0;
*/
	c->activeCurve2D = 0;
	c->xValues2D = NULL;
	c->colors2D = NULL;
	c->nColors2D = 0;
	c->averages2D = NULL;
	c->error2D = 0;
	c->plotItem = NULL;
	c->markerPoint = -1;
	
	c->xFrom = NO_VALUE;
	c->xTo   = NO_VALUE;
	
	c->componentsVisible = 1;
	c->nComponentsPositions = 0;
	for (i = 0; i < CURVES_MAX_POSITIONS; i++) {
		c->componentsPositions[i] = 0.0;
		c->componentsNames[i][0] = 0;
		c->componentsColors[i] = VAL_DK_GREEN;
	}
	c->autoScaleCurrentCurve = 0;

}


void CURVE_freeRun (t_curve *c)
{
	int i;
	
	for (i = 0; i < c->nCurves; i++) {
		free (c->yValues[i]);
		free (c->yErrPos[i]);
		free (c->yErrNeg[i]);
	}
	free (c->yValuesArrSize);
	free (c->yValuesVisible);
	free (c->yValues);
	free (c->yErrPos);
	free (c->yErrNeg);
	c->yValuesArrSize = NULL;
	c->yValuesVisible = NULL;
	c->yValues = NULL;
	c->yErrPos = NULL;
	c->yErrNeg = NULL;
}


void CURVE_free (t_curve *c)
{
	free (c->xValues);
	free (c->yValuesAveraged);
	free (c->yErrPosAveraged);
	free (c->yErrNegAveraged);
	c->nValues = 0;
	c->nValuesVisibleAvg = -1;
	c->nCurvesWritten = 0;
	c->xValues = NULL;
	c->yValuesAveraged = NULL;
	c->yErrPosAveraged = NULL;
	c->yErrNegAveraged = NULL;
	c->hasErrorBars = 0;
	c->hasErrorBarsCurrent = 0;
	
	free (c->yAverages);
	c->yAverages = NULL;
	
	free (c->plotHandlesAveraged);
	c->nPlotHandlesAveraged = 0;
	c->plotHandlesAveraged = NULL;	

	free (c->plotHandlesCurrent);
	c->nPlotHandlesCurrent = 0;
	c->plotHandlesCurrent = NULL;	

	
	
	// free 2D values
	DiscardPanel (c->panel2DPlot);
	c->panel2DPlot = -1;
	free (c->values2D);
	c->values2D  = NULL;
	c->nValues2D = 0;
	free (c->xValues2D);
	c->xValues2D  = NULL;
	c->n2Dcurves = 0;
	free (c->colors2D);
	c->colors2D = 0;
	c->nColors2D = 0;
	free (c->averages2D);
	c->averages2D = NULL;
	CURVE_freeRun (c);
}

/*
t_curve *CURVE_ptr (t_graph *w, int nr)
{
	t_curve *c = NULL;
	
	if (w == NULL) return NULL;
	if ((nr <= 0) || (nr > ListNumItems (w->listOfCurves))) return NULL;
	ListGetItem (w->listOfCurves, &c, nr);
	return c;
}
*/
/*
int CURVE_getNrFromName (t_graph *w, const char *name)
{
	t_curve *c;
	int i;
	
	for (i = 1; i <= ListNumItems (w->listOfCurves); i++) {
		c = CURVE_ptr (w, i);
		if (strcmp (c->name, name) == 0) return i;
	}
	return 0;
}
*/


t_curve *CURVE_getPtrFromName (t_graph *w, const char *name, int checkKeepState)
{
	t_curve *c;
	int graphItem;
	int item;
	
	CURVE_getTreeItemNr (w, NULL, &graphItem, NULL, NULL, NULL);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		if (strcmp (c->name, name) == 0) {
			if (!checkKeepState) return c;
			if (!c->keep || c->active) return c;
		}
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_NEXT, 0, &item);
	}
	return NULL;
}


/*
int CURVE_hasPlotHandles (t_curve *c)
{
	if (c->nPlotHandlesAveraged   c->nPlotHandlesCurrent);
}
*/


void CURVE_displayCross (t_graph *w, t_curve *c, int display)
{
	if (display) {
		c->plotHandlesAveraged[1] = PlotPoint (w->panelHandle,
											   GRAPH_GRAPH,
											   c->xValues[c->markerPoint],
											   c->yValuesAveraged[c->markerPoint],
											   VAL_BOLD_X, VAL_YELLOW);
	}
	else { if (c->plotHandlesAveraged[1] > 0) 
		DeleteGraphPlot (w->panelHandle, GRAPH_GRAPH,
		   			     c->plotHandlesAveraged[1], VAL_DELAYED_DRAW);
		c->plotHandlesAveraged[1] = -1;
	}
}


void CURVE_removePlot (t_graph *w, t_curve *c, int delayedDraw)
{
	int i;
	
	// delete averaged plot
	for (i = 0; i < c->nPlotHandlesAveraged; i++) {
		if (c->plotHandlesAveraged[i] > 0) {
			DeleteGraphPlot (w->panelHandle, GRAPH_GRAPH, c->plotHandlesAveraged[i],
							 delayedDraw ? VAL_DELAYED_DRAW : VAL_IMMEDIATE_DRAW);
			c->plotHandlesAveraged[i] = -1;
		}
	}
	// delete current plot
	for (i = 0; i < c->nPlotHandlesCurrent; i++) {
		if (c->plotHandlesCurrent[i] > 0) {
			DeleteGraphPlot (w->panelHandle, GRAPH_GRAPH, c->plotHandlesCurrent[i],
							 delayedDraw ? VAL_DELAYED_DRAW : VAL_IMMEDIATE_DRAW);
			c->plotHandlesCurrent[i] = -1;
		}
	}

}



void GRAPH_deleteAllReferences (t_graph *g, t_curve *c)
{
	int k;
	t_session *s;
	
	if (c == NULL) return;
	
	// check all in sessions
	for (k = 1; k <= ListNumItems (smanagerConfig->listOfSessions); k++) {
		s = SESSION_ptr (k);
		PLOTITEM_deleteReferenceToCurve (s, g, c);
	}
	RUNS_deleteAllReferencesToCurve (g, c);
}



int CURVE_delete (t_graph *w, t_curve *c)
{

	int plotItem;
	int curveItem;
	int curve2DItem;
	int currentCurveItem;
	
	if (c == NULL) return -1;
	if (w == NULL) w = GRAPH_getFromCurve (c);
	if (w == NULL) return -1;

	if (w->panelHandle >= 0) {
		SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_REFRESH_GRAPH, 0);
		CURVE_getTreeItemNr (w, c, &plotItem, &curveItem, &curve2DItem, &currentCurveItem);
		CURVE_removePlot (w, c, 1);
		DeleteListItem (panelCurves, CURVES_TREE, curve2DItem, 1);
		DeleteListItem (panelCurves, CURVES_TREE, currentCurveItem, 1);
		DeleteListItem (panelCurves, CURVES_TREE, curveItem, 1);
	}	
	if (c == w->sliderCurve) w->sliderCurve = NULL;
	
	GRAPH_deleteAllReferences (NULL, c);
	CURVE_free (c);
	free (c);
	return 0;
}



// ---------------------------------
//    allocate memory for 2D curve
// ---------------------------------	
void CURVE2D_allocateMemory (t_curve *c, int nShots, int n2Dcurves)
{

	if (n2Dcurves != 0) {
/*		if (nShots * n2Dcurves > MAX_VALUES_PLOT2D) {
			if (c->panel2DPlot > 0) {
				DiscardPanel (c->panel2DPlot);
				c->panel2DPlot = -1;
			}
			if (!c->error2D) {
				MessagePopupf ("Error: Too many points", "Function 'CURVE2D_allocateMemory()' in file "
							   "'SESSIONMANAGER_PLOT.c' failed.\n\n"
							   "Too many points for 2D curve '%s'.\n\n"
							   "Your curve needs %d * %d = %d points\n"
							   "but maximally allowed are %d (constant 'MAX_VALUES_PLOT2D').",
							   c->name,
							   nShots, n2Dcurves, nShots * n2Dcurves, MAX_VALUES_PLOT2D);
				c->error2D  = 1;
			}							  
			n2Dcurves = 0;
			nShots    = 0;
		}

		else c->error2D = 0;
*/		
		if (c->panel2DPlot > 0) DeleteGraphPlot (c->panel2DPlot, CURVE2D_GRAPH, -1, VAL_DELAYED_DRAW);
		
		if (c->n2Dcurves != n2Dcurves) {
			c->n2Dcurves = n2Dcurves;
			free (c->averages2D);
			free (c->xValues2D);
			c->averages2D = (int *) malloc (sizeof (int) * c->n2Dcurves);
			c->xValues2D = (double *) malloc (sizeof (double) * c->n2Dcurves);
		}
		if (c->nValues2D != nShots * n2Dcurves) {
			c->nValues2D = nShots * n2Dcurves;
			free (c->values2D);
			c->values2D = (double *) malloc (sizeof (double) * c->nValues2D);
		}
		CURVE2D_resetValues(c);
		memset (c->xValues2D, 0, sizeof(double) * c->n2Dcurves);
	}
}



void CURVE_allocateMemoryForOneCurve (t_curve *c, int curveNr, int nValues)
{
	int i;
	
	if (curveNr >= c->nCurves) return;
	
	if (c->yValuesArrSize[curveNr] != nValues) {
		free (c->yValues[curveNr]);
		free (c->yErrPos[curveNr]);
		free (c->yErrNeg[curveNr]);
		c->yValuesArrSize[curveNr] = nValues;
		c->yValues[curveNr] = (double *) malloc (sizeof (double) * nValues);
		for (i = 0; i < nValues; i++) c->yValues[curveNr][i] = NO_VALUE;
		if (c->hasErrorBarsCurrent) {
			c->yErrPos[curveNr] = (double *) malloc (sizeof (double) * nValues);
			for (i = 0; i < nValues; i++) c->yErrPos[curveNr][i] = NO_VALUE;
		//	c->yErrNegRun[curveNr] = (double **) calloc (sizeof (double *), c->nRuns);
		}   
	}
}



void CURVE_allocateMemoryRun (t_curve *c, int nCurves)
{
	if (nCurves != c->nCurves) CURVE_freeRun (c);
	c->nCurves = nCurves;
	c->yValuesArrSize = (unsigned *) calloc (sizeof (unsigned), c->nCurves);
	c->yValuesVisible = (unsigned *) calloc (sizeof (unsigned), c->nCurves);
	c->yValues = (double **) calloc (sizeof (double *), c->nCurves);
	c->yErrPos = (double **) calloc (sizeof (double *), c->nCurves);
	c->yErrNeg = (double **) calloc (sizeof (double *), c->nCurves);
}


void CURVE_setXValues (t_curve *c, int doFill)
{
	int i;
	
	if ((c->xValues != NULL) && !doFill) return;
    // first call allocate memory

	if (c->xValues == NULL) {
	    c->xValues = (double *) malloc (sizeof (double) * c->nValues);
	}
	if (c->xFrom == NO_VALUE) {
		// reset everything to zero
		memset (c->xValues, 0, sizeof(double) * c->nValues);
		return;
	}
	if (c->nValues == 1) {
		c->xValues[0] = c->xFrom;
		return;
	}
	for (i = 0; i < c->nValues; i++) {
		c->xValues[i] = i * (c->xTo - c->xFrom) / (c->nValues - 1) + c->xFrom;
	}
}



void CURVE_allocateMemory (t_curve *c, int nShots)
{
	unsigned nBlocks, nBytes;
	// ---------------------------------
	//    allocate memory for curve
	// ---------------------------------	
//	if (c->panel2DPlot > 0) DeleteGraphPlot (c->panel2DPlot, CURVE2D_GRAPH, -1, VAL_DELAYED_DRAW);
	
	if (c->nValues != nShots) {
		c->nValues = nShots;
		free (c->xValues);
		free (c->yValuesAveraged);
		free (c->yAverages);
		free (c->yErrPosAveraged);
		c->xValues = NULL;//(double *) malloc (sizeof (double) * c->nValues);
		c->yValuesAveraged = (double *) malloc (sizeof (double) * c->nValues);
		c->yAverages = (int *) malloc (sizeof (int) * c->nValues);
		c->yErrPosAveraged = (double *) malloc (sizeof (double) * c->nValues);

	}
//	CURVE_setXValues (c);	
	memset (c->yValuesAveraged, 0, sizeof(double) * c->nValues);
	memset (c->yAverages, 0, sizeof(int) * c->nValues);
	memset (c->yErrPosAveraged, 0, sizeof(double) * c->nValues);
	
//	CVIDynamicMemoryInfo ("Info", &nBlocks, &nBytes,
//						  DYNAMIC_MEMORY_SHOW_ALLOCATED_MEMORY_SUMMARY);
}

	


t_curve *CURVE_new ()
{
	 t_curve *c;
	 
	 c = (t_curve *) malloc (sizeof(t_curve));
	 CURVE_init (c);
	 
	 return c;
}


t_curve *CURVE_create (t_graph *w, const char *name, int nPoints, int n2Dcurves)
{
	t_curve *c;
	int oldNValues;
	
	c = CURVE_getPtrFromName (w, name, 1);
	// create new curve
	// if 'keepCurve' flag is set and this is 
	// not the active curve
//	if ((c != NULL) && c->keep && !c->active) c = NULL;
	
	if (c == NULL) {
		c = CURVE_new ();	
		strcpy (c->name, name);
		CURVE_displayTreeItem (w, c, 1);
		strcpy (c->xLabel, w->xLabel);
		strcpy (c->yLabel, w->yLabel);
		strcpy (c->xUnits, w->xUnits);
		strcpy (c->yUnits, w->yUnits);
		strcpy (c->xAsciiFileColumnLabel, w->xAsciiFileColumnLabel);
		strcpy (c->yAsciiFileColumnLabel, w->yAsciiFileColumnLabel);
	}
	oldNValues = c->nValues;
	if (nPoints != c->nValues) {
		CURVE_removePlot (w, c, 1);
		CURVE_allocateMemory (c, nPoints);
		c->newCurve = 1;
	}
	c->panelGraph = w->panelHandle;

	if ((nPoints != oldNValues) || (n2Dcurves != c->n2Dcurves))	{
		CURVE2D_allocateMemory (c, nPoints, n2Dcurves);
	}

	return c;
}



int CURVE_average (t_graph *w, t_curve *c, int *nAveragesToDo)
{
	t_curve *cAverage = NULL;
	char name[MAX_PLOTNAME_LEN+10];
	int i;
	double add;
	int newCurve = 0;

	CURVE_setXValues (c, 0);	

	if (*nAveragesToDo < 0) {
		strcpy (name, c->name);
		strcat (name, "_AVG");
		cAverage = CURVE_create (w, name, c->nValues, 0);
		// new curve created
		if (c->nAveraged == 0) {
			cAverage->plotStyle = VAL_FAT_LINE;
			cAverage->lineStyle = VAL_DASH;
			for (i = 0; i < cAverage->nValues; i++) {
				cAverage->xValues[i] = c->xValues[i];
				cAverage->yValuesAveraged[i] = 0;
			}
		}
		newCurve = 1;
		cAverage->nAveraged = 0;
	}
	*nAveragesToDo = abs(*nAveragesToDo);

	if (*nAveragesToDo > 0) {
		if (cAverage == NULL) {
			strcpy (name, c->name);
			strcat (name, "_AVG");
			cAverage = CURVE_getPtrFromName (w, name, 1);
		}
		if (cAverage != NULL) {// DEBUGGED 21/12/04
			for (i = 0; i < cAverage->nValues; i++) {
	//			cAverage->xValues[i] = SWEEP_value2 (r->sweep, c->nValues, i);
				if (cAverage->nAveraged == 0) add = 0;
				else add = cAverage->yValuesAveraged[i] * cAverage->nAveraged;
				cAverage->yValuesAveraged[i] = (add + c->yValuesAveraged[i]) / (cAverage->nAveraged + 1);
			}
			cAverage->nAveraged ++;
			(*nAveragesToDo) --;
			cAverage->plotColor = (*nAveragesToDo == 0) ? VAL_DK_GREEN :  VAL_GREEN ;
			CURVE_getMinMax (cAverage);
		}
	}
	
	if (newCurve) GRAPH_setWindowParameters (w, NULL);

	return newCurve;
}





int CURVE_loadTxt (const char *filename, t_curve **returnCurve)
{
	int file;
	#define MAX_LINE 200
	t_curve *c;
	char line[MAX_LINE];
	int i;
	double values[2];
	int error;
	
	*returnCurve = NULL;
	DisableBreakOnLibraryErrors ();
	file = OpenFile (filename, VAL_READ_ONLY, VAL_OPEN_AS_IS,
					 VAL_ASCII);
	if (file < 0) return displayFileError (filename);

	c = CURVE_new ();
	i = 0;
	error = 0;
	c->nValues = 10;
	CURVE_allocateMemory (c, c->nValues*2);
	CURVE_setXValues (c, 0);	
	DisableBreakOnLibraryErrors ();   
	error = ReadLine(file, line, MAX_LINE-1);
	while (error >= 0) {
		error = ReadLine(file, line, MAX_LINE-1);
		if (error > 0) {
			values[0] = 0;
			values[1] = 0;
			if ((Scan (line, "%s>%*f[x]", 2, values)) > 0) {
//			if (sscanf (line, "%f\t%f", &x, &y) == 2) {
				if (i >= c->nValues) CURVE_allocateMemory (c, c->nValues*2);
				c->xValues[i] = values[0];
				c->yValuesAveraged[i] = values[1];
				i++;
			}
			else error = -1;
		}
	}
	CloseFile (file);
	if (i == 0) {
		CURVE_free (c);
		return 0;
	}
	c->nValues = i;
	*returnCurve = c;  
	
	strncpy (c->name, extractFilename (filename), MAX_PLOTNAME_LEN);
	c->name[MAX_PLOTNAME_LEN-1] = 0;

	getDateAndTimeFromFile (filename, c->dateStr, c->timeStr);
	
	return 0;

ERROR:
	CloseFile (file);
	displayFileError (filename);
	return -1;
}



void CURVE_saveTxt_appendValue (char *string, t_curve *c, double **arr, 
								int nCurve, int index)
{
	double value;
	char help[50];
	int nValues;
	
	if (arr == NULL) value = NO_VALUE;
	else if (arr[nCurve] == NULL) value = NO_VALUE;
	else {
		if (c->yValuesVisible != NULL) nValues = c->yValuesVisible[nCurve];
		else nValues = c->yValuesArrSize[nCurve];
		if (index < nValues) value = arr[nCurve][index];
		else value = NO_VALUE;
	}
	
	strcpy (help, "\t");
	if (value != NO_VALUE) strcpy (help+1, doubleToStr (value));
	strcat (string, help);
}


int CURVE_saveTxt (const char *filename, t_curve *c, t_graph *w)
{
	char s[200];
	int file;
	int i, k;
	#define MAX_COL_LABEL_LEN 10  // maximum length of column label = 10
								  // (given by ORIGIN)

	if (c == NULL) return -1;
	CURVE_setXValues (c, 0);	
	if (c->n2Dcurves > 0) return CURVE2D_saveTxt (filename, c, w);
	
	file = OpenFile (filename, VAL_WRITE_ONLY, VAL_TRUNCATE,
					 VAL_ASCII);
	if (file < 0) return displayFileError (filename);

	// ------------------------------------	
	//       create column labels
	// ------------------------------------	
	if ((c->xAsciiFileColumnLabel[0] == 0) && (w != NULL)) strcpy (s, w->xAsciiFileColumnLabel);
	else strcpy (s, c->xAsciiFileColumnLabel);
	strCharChange (s, ' ', '_');
	writeString (file, s);

	// insert label for averaged curve
	strcpy (s, "\t");
	if ((c->yAsciiFileColumnLabel[0] == 0) && (w != NULL)) {
		if (w->yAsciiFileColumnLabel[0] == 0) strcat (s, "S");
		else strcat (s, w->yAsciiFileColumnLabel);
	}
	else strcat (s, c->yAsciiFileColumnLabel);

	// make sure that label is <= MAX_COL_LABEL_LEN
	s[MAX_COL_LABEL_LEN+1-N_STARTNR_DIGITS] = 0;
	strcat (s, intToStr0 (N_STARTNR_DIGITS, c->startNr));
	if (c->hasErrorBars) {
		strcat (s, "\terr");
		if (c->yErrNegAveraged != NULL) strcat (s, "Pos\terrNeg");
	}		
	strCharChange (s, ' ', '_');
	writeString (file, s);
	
	// insert label for curves of all runs
	if (c->nCurvesWritten > 1) {
		for (i = 0; i < c->nCurvesWritten; i++) {
			// insert label for averaged curve
			sprintf (s, "\tRUN%d", i);
			writeString (file, s);
			if (c->hasErrorBarsCurrent) {
				if (c->yErrNegAveraged == NULL) sprintf (s, "\terr%d", i);
				else sprintf  (s, "\terrPos%d\terrNeg%d", i, i);
				writeString (file, s);
			}		
		}
	}
	
	// write line feed
	s[0] = 0;
	WriteLine (file, s, -1);
	

	// ------------------------------------	
	//       write values
	// ------------------------------------	
	for (i = 0; i < c->nValuesVisibleAvg; i++) {
		strcpy (s, doubleToStr (c->xValues[i]));
//		sprintf (line, "%2.12f", c->xValues[i]); 
//		strcpy (line, strDouble (c->xValues[i]));
		strcat (s, "\t");
		strcat (s, doubleToStr (c->yValuesAveraged[i]));
		
		if (c->hasErrorBars) {
			strcat (s, "\t");
			strcat (s, doubleToStr (c->yErrPosAveraged[i]));
			if (c->yErrNegAveraged != NULL) {
				strcat (s, "\t");
				strcat (s, doubleToStr (c->yErrNegAveraged[i]));
			}
		}		
		
		writeString (file, s);
		
		// write results of previous runs
		if (c->nCurvesWritten > 1) {
			for (k = 0; k < c->nCurvesWritten; k++) {
				s[0] = 0;
				CURVE_saveTxt_appendValue (s, c, c->yValues, k, i);
				
				// add errors
				if (c->hasErrorBarsCurrent) {
					CURVE_saveTxt_appendValue (s, c, c->yErrPos, k, i);
					if (c->yErrNegAveraged != NULL) {
						CURVE_saveTxt_appendValue (s, c, c->yErrNeg, k, i);
					}
				}	
				writeString (file, s);
			}
		}

		// write line feed
		s[0] = 0;
		WriteLine (file, s, -1);
	}
	CloseFile (file);
	return 0;
}






void CURVE_getMinMax (t_curve *c)
{
	int i, n;
	
	if (c == NULL) return;
	if (c->nValues == 0) return;
	
	c->maxYValue = -DBL_MAX;
	c->minYValue = DBL_MAX;
	c->maxXValue = -DBL_MAX;
	c->minXValue = DBL_MAX;
//	c->sumYValues = 0.0;
	for (i = 0; i < c->nValues; i++) {
		if (c->yValuesAveraged != NULL) {
			if (c->yValuesAveraged[i] > c->maxYValue) c->maxYValue = c->yValuesAveraged[i];
			if (c->yValuesAveraged[i] < c->minYValue) c->minYValue = c->yValuesAveraged[i];
//			c->sumYValuesAveraged += c->yValuesAveraged[i];
		}
		
	}
	if (c->xFrom != NO_VALUE) {
		if (c->xFrom < c->minXValue) c->minXValue = c->xFrom;
		if (c->xTo < c->minXValue) c->minXValue = c->xTo;
		if (c->xFrom > c->maxXValue) c->maxXValue = c->xFrom;
		if (c->xTo > c->maxXValue) c->maxXValue = c->xTo;
//		
//		c->maxXValue = c->xTo;
//		
	}
	else {
		if (c->xValues != NULL) {
			for (i = 0; i < c->nValues; i++) {
				if (c->xValues[i] > c->maxXValue) c->maxXValue = c->xValues[i];
				if (c->xValues[i] < c->minXValue) c->minXValue = c->xValues[i];
			}
		}
		else {
			c->minXValue = 0;
			c->maxXValue = 0;
		}
	}

	// check curve of current run
	n = c->currentCurve;
	if (c->autoScaleCurrentCurve && (c->yValues != NULL) && (c->yValues[n] != NULL)) {
		for (i = 0; i < c->yValuesVisible[n]; i++) {
			if (c->yValues[n][i] != NO_VALUE) {
				if (c->yValues[n][i] > c->maxYValue) c->maxYValue = c->yValues[n][i];
				if (c->yValues[n][i] < c->minYValue) c->minYValue = c->yValues[n][i];
			}
//			else Breakpoint();
			
		}
	}
}
	

/*	
int CURVE_nr (t_graph *w, t_curve *c)
{
	return ListFindItem (w->listOfCurves, &c, FRONT_OF_LIST, 0);
}
*/


void CURVE_createPlotHandles (int **plotHandles, int *nPlotHandles, int n)
{
	int i;
	int *newHandles;
	
	if (*nPlotHandles <  n) {
	    newHandles = (int *) malloc (n * sizeof(int));
	    memcpy (newHandles, *plotHandles, sizeof(int)* (*nPlotHandles));
		free (*plotHandles);
		*plotHandles = newHandles;
	    // fill new handles with "-1"
	    for (i = *nPlotHandles; i < n; i++) (*plotHandles)[i] = -1;
	    *nPlotHandles = n; 
	}
}




void CURVE_plotErrorBars_Avg (t_graph *w, t_curve *c, int handleStart)
{
	double errPos, errNeg;
	int i;
	int nValues;
	
	if (!c->hasErrorBars) return;
	if (c->nValues > NPointsSuppressErrorBars) 
		return;
    if (c->nValuesVisibleAvg < 0) nValues = c->nValues;
    else nValues = c->nValuesVisibleAvg;
	
	CURVE_createPlotHandles (&(c->plotHandlesAveraged), &c->nPlotHandlesAveraged, handleStart + c->nValues);
	errPos = 0;
	for (i = 0; i < nValues; i++) {
		if (c->yErrPosAveraged != NULL) errPos = fabs(c->yErrPosAveraged[i]);
		if (c->yErrNegAveraged != NULL) errNeg = fabs(c->yErrNegAveraged[i]);
		else errNeg = errPos;
		if (errPos != 0) {
			c->plotHandlesAveraged[i+handleStart] = PlotLine (w->panelHandle, GRAPH_GRAPH,
										   	   c->xValues[i], c->yValuesAveraged[i]+errPos, 
										   	   c->xValues[i], c->yValuesAveraged[i]-errNeg, 
										   	   c->plotColor);
			SetPlotAttribute (w->panelHandle, GRAPH_GRAPH, c->plotHandlesAveraged[i+handleStart], ATTR_PLOT_LG_VISIBLE, 0); 										   	   
		}
	}
}


void CURVE_plotErrorBars_Current (t_graph *w, t_curve *c, int n, int handleStart)
{
	double errPos, errNeg;
	int i;
	int nValues;
	
	if (!c->hasErrorBarsCurrent) return;
	if (c->nValues > NPointsSuppressErrorBars) 
		return;
    nValues = c->yValuesVisible[n];
	CURVE_createPlotHandles (&(c->plotHandlesCurrent), &c->nPlotHandlesCurrent, handleStart + nValues);
	errPos = 0;
	for (i = 0; i < nValues; i++) {
		if (c->yErrPos[n] != NULL) errPos = fabs(c->yErrPos[n][i]);
		if (c->yErrNeg[n] != NULL) errNeg = fabs(c->yErrNeg[n][i]);
		else errNeg = errPos;
		if (errPos != 0) {
			c->plotHandlesCurrent[i+handleStart] = PlotLine (w->panelHandle, GRAPH_GRAPH,
										   	   c->xValues[i], c->yValues[n][i]+errPos, 
										   	   c->xValues[i], c->yValues[n][i]-errNeg, 
										   	   c->plotColorCurrent);
			SetPlotAttribute (w->panelHandle, GRAPH_GRAPH, c->plotHandlesCurrent[i+handleStart], ATTR_PLOT_LG_VISIBLE, 0); 										   	   
		}
	}
}





void CURVE_plotBars (t_graph *w, t_curve *c)  
{
	double widthL = 0;
	double widthR = 0;
	int i;
	double errPos, errNeg;
	int nValues;
	char help[50];
	int handleMultiply;
	static int metafontCreated = 0;
	
	
	// do not show ErrorBars if nValues > NPointsSuppressErrorBars
	
	if (c->plotNumbers) handleMultiply = 3;
	else handleMultiply = 2;
	CURVE_createPlotHandles (&c->plotHandlesAveraged, &c->nPlotHandlesAveraged, c->nValues * handleMultiply + 1);    
	errPos = 0;
//	DisplayPanel (w->panelHandle);
    if (c->nValuesVisibleAvg < 0) nValues = c->nValues;
    else nValues = c->nValuesVisibleAvg;

	
	for (i = 0; i < nValues; i++) {
		if (i != c->nValues-1) widthR = (c->xValues[i+1] - c->xValues[i]) / (2.05);
		else widthR = c->xValues[0] * 0.1;
		if (i != 0) widthL = (c->xValues[i] - c->xValues[i-1]) / 2;
		else widthL = widthR;
		if (c->yErrPosAveraged != NULL) errPos = fabs(c->yErrPosAveraged[i]);
		if (c->yErrNegAveraged != NULL) errNeg = fabs(c->yErrNegAveraged[i]);
		else errNeg = errPos;
		if ((c->yValuesAveraged[i] != 0) || (errPos != 0)) {
			c->plotHandlesAveraged[i] = PlotRectangle (w->panelHandle, GRAPH_GRAPH,
											   c->xValues[i]-widthL, 0,
											   c->xValues[i]+widthR,
											   c->yValuesAveraged[i], c->plotColor,
											   VAL_OFFWHITE);
			SetPlotAttribute (w->panelHandle, GRAPH_GRAPH,
							  c->plotHandlesAveraged[i], ATTR_PLOT_THICKNESS, 2);
		}
		if (errPos != 0) {
			c->plotHandlesAveraged[i+c->nValues] = PlotLine (w->panelHandle, GRAPH_GRAPH,
										   	   c->xValues[i], c->yValuesAveraged[i]+errPos, 
										   	   c->xValues[i], c->yValuesAveraged[i]-errNeg, 
										   	   c->plotColor);
		}
		if (c->plotNumbers) {
			if (c->yErrPosAveraged == NULL) 
				sprintf (help, "%1.4f",c->yValuesAveraged[i]);
			else if (c->yErrNegAveraged == NULL) 
				sprintf  (help, "%1.4f�%1.4f",c->yValuesAveraged[i], fabs(c->yErrPosAveraged[i]));
			else sprintf  (help, "%1.4f+(%1.4f-%1.4f)",c->yValuesAveraged[i], fabs(c->yErrPosAveraged[i]),fabs(c->yErrNegAveraged[i]));
			if (!metafontCreated) {
				CreateMetaFont (PLOT_BAR_METAFONT, PLOT_BAR_METAFONT_ORIGIN, PLOT_BAR_METAFONT_POINTSIZE, PLOT_BAR_METAFONT_BOLD, 0,
								0, 0);
				metafontCreated = 1;
			}
			c->plotHandlesAveraged[i+2*c->nValues] = 
					  PlotText (w->panelHandle, GRAPH_GRAPH, 
					  			c->xValues[i]*1.01, 
					  			c->yValuesAveraged[i], help, PLOT_BAR_METAFONT,
								c->plotColor, VAL_TRANSPARENT);
		}
	}
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH,
					  ATTR_REFRESH_GRAPH, 1);
	RefreshGraph(w->panelHandle, GRAPH_GRAPH);
}
		 




void CURVES_resizePanel (void)
{
	Rect bounds;
	int width, height;
	
	EasyTab_GetBounds (panelCurves, CURVES_CANVAS,
					   VAL_EASY_TAB_EXTERIOR_BOUNDS, &bounds);
	width = panelWidth (panelCurves);
	if (width < bounds.width + bounds.left + 100) width = + 100;
	height = panelHeight (panelCurves);
	if (height < bounds.top + bounds.height) height = bounds.top + bounds.height;
	SetCtrlAttribute (panelCurves, CURVES_TREE, ATTR_LEFT, 
					  bounds.left + bounds.width + 10);

	SetCtrlAttribute (panelCurves, CURVES_TREE, ATTR_WIDTH, 
					  panelWidth(panelCurves) - 
					  ctrlLeft (panelCurves, CURVES_TREE));
	SetCtrlAttribute (panelCurves, CURVES_TREE, ATTR_HEIGHT, 
					  panelHeight(panelCurves) - panelMenuHeight (panelCurves));
}



void CURVES_initTree (void)
{
	int panel = panelCurves;
	int ctrl =  CURVES_TREE;
	
	setNumTreeColumns (panel, ctrl, N_CURVES_COL);

	// set attributes for columns
	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_NAME,
							ATTR_COLUMN_WIDTH, 250);
	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_NAME, 
							ATTR_LABEL_TEXT, "name");

	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_STARTNR,
							ATTR_COLUMN_WIDTH, 50);
	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_STARTNR, 
							ATTR_LABEL_TEXT, "start nr");

	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_TIME,
							ATTR_COLUMN_WIDTH, 40);
	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_TIME, 
							ATTR_LABEL_TEXT, "time");

	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_DATE,
							ATTR_COLUMN_WIDTH, 70);
	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_DATE, 
							ATTR_LABEL_TEXT, "date");

	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_AVG,
							ATTR_COLUMN_WIDTH, 40);
	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_AVG, 
							ATTR_LABEL_TEXT, "avgs.");

	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_INFO,
							ATTR_COLUMN_WIDTH, 220);
	SetTreeColumnAttribute (panel, ctrl, CURVES_COL_INFO, 
							ATTR_LABEL_TEXT, "info");

//	SetTreeColumnAttribute (panel, ctrl, TIMEINTERVAL_COL_TIME_START,
//							ATTR_LABEL_JUSTIFY,
//							VAL_CENTER_CENTER_JUSTIFIED);
	
}


int CURVE_getTreeItemNr (t_graph *w, t_curve *c, int *plotItem, int *curveItem, 
					      int *curve2DItem, int *currentCurveItem)
{
	
	if (w == NULL) w = GRAPH_getFromCurve (c);  
	GetTreeItemFromValue (panelCurves, CURVES_TREE,
								  VAL_ALL, 0, VAL_FIRST,
								  VAL_NEXT_PLUS_SELF, 0, plotItem, (unsigned) w);
	if (*plotItem < 0) return -1;
	if ((curveItem == NULL) || (c == NULL)) return 0;
	GetTreeItemFromValue (panelCurves, CURVES_TREE,
								  VAL_CHILD, *plotItem, VAL_FIRST,
								  VAL_NEXT_PLUS_SELF, 0,
								  curveItem, (unsigned) c);
	if ((curve2DItem == NULL) || (c == NULL)) return 0;
	GetTreeItemFromValue (panelCurves, CURVES_TREE,
								  VAL_CHILD, *curveItem, VAL_FIRST,
								  VAL_NEXT_PLUS_SELF, 0,
								  curve2DItem, TREE_VALUE_2D);

	if ((currentCurveItem == NULL) || (c == NULL)) return 0;
	GetTreeItemFromValue (panelCurves, CURVES_TREE,
								  VAL_CHILD, *curveItem, VAL_FIRST,
								  VAL_NEXT_PLUS_SELF, 0,
								  currentCurveItem, TREE_VALUE_CURRENT);
	return 0;
}




void CURVE_displayTreeItem (t_graph *w, t_curve *c, int setMarkStates)
{
//	char *help;

	char help[10];
	int plotItem = -1;
	int curveItem = -1;
	int curve2DItem = -1;
	int currentCurveItem = -1;
	const char curveName2D[] = "2D graph";
	const char curveNameCurrent[] = "current curve";
	int collapsed;

//	help = getTmpString();
	if (CURVE_getTreeItemNr (w, c, &plotItem, &curveItem, &curve2DItem, &currentCurveItem) < 0) return;

	// -----------------------------
	//      display name
	// -----------------------------
	if (curveItem < 0) {
		// 13/02 RUNTIME ERROR *c "under Array bounds???"
		curveItem = InsertTreeItem (panelCurves, CURVES_TREE,
									VAL_CHILD, plotItem, VAL_LAST,
									c->name, NULL, NULL, (unsigned) c);
		SetTreeItemAttribute (panelCurves, CURVES_TREE, curveItem,
							  ATTR_NO_EDIT_LABEL, 0);
	    setMarkStates = 1;							  
	}
	else {
		// -----------------------------
		//      display name
		// -----------------------------
		SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_NAME,
							  ATTR_LABEL_TEXT, c->name);
		SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_NAME,
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_CENTER_JUSTIFIED);
	}
    if (setMarkStates) {
		SetTreeItemAttribute (panelCurves, CURVES_TREE, curveItem,
							  ATTR_MARK_STATE, c->visible);
		SetTreeItemAttribute (panelCurves, CURVES_TREE, curveItem,
							  ATTR_COLLAPSED, !c->visible);
    }
	

	// ---------------------------------------
	//    insert tree item for current curve
	// ---------------------------------------	
	if ((currentCurveItem < 0) && (c->showCurrentCurve)) {
		currentCurveItem = InsertTreeItem (panelCurves, CURVES_TREE,
									  VAL_CHILD, curveItem, VAL_LAST,
									  curveNameCurrent, NULL, NULL,
									  TREE_VALUE_CURRENT);
		SetTreeItemAttribute (panelCurves, CURVES_TREE, currentCurveItem,
								  ATTR_MARK_STATE, c->showCurrentCurve);
	}
	
    if (setMarkStates) {
		collapsed = !c->showCurrentCurve && ((!c->visible2D || c->nValues2D == 0));
		SetTreeItemAttribute (panelCurves, CURVES_TREE, curveItem,
							  ATTR_COLLAPSED, collapsed);
		
    }
	
	if (currentCurveItem >= 0) {
		SetTreeCellAttribute (panelCurves, CURVES_TREE, currentCurveItem, CURVES_COL_NAME,
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_CENTER_JUSTIFIED);
		SetTreeItemAttribute (panelCurves, CURVES_TREE, currentCurveItem,
							  ATTR_MARK_TYPE, VAL_MARK_CHECK);
		SetTreeCellAttribute (panelCurves, CURVES_TREE,
							  currentCurveItem, CURVES_COL_NAME, ATTR_LABEL_COLOR,
							  c->plotColorCurrent == VAL_WHITE ? VAL_BLACK : c->plotColorCurrent);
		if (setMarkStates) {
			SetTreeItemAttribute (panelCurves, CURVES_TREE, currentCurveItem,
									  ATTR_MARK_STATE, c->showCurrentCurve);
//			SetTreeItemAttribute (panelCurves, CURVES_TREE, curveItem,
//								  ATTR_COLLAPSED, !c->showCurrentCurve);
//			SetTreeItemAttribute (panelCurves, CURVES_TREE, curveItem,
//								  ATTR_COLLAPSED, !c->visible);
 								  
		}
	}
	// ---------------------------------------
	//    insert tree item for 2D curve
	// ---------------------------------------	
	if ((c->panel2DPlot > 0) && (curve2DItem < 0)) {
		curve2DItem = InsertTreeItem (panelCurves, CURVES_TREE,
									  VAL_CHILD, curveItem, VAL_LAST,
									  curveName2D, NULL, NULL,
									  TREE_VALUE_2D);
	    SetTreeItemAttribute (panelCurves, CURVES_TREE,curve2DItem,
							  ATTR_MARK_STATE, c->visible2D);
	}
	
	if (curve2DItem >= 0) {
		// -----------------------------
		//      display name
		// -----------------------------
	    if (setMarkStates)  SetTreeItemAttribute (panelCurves, CURVES_TREE,curve2DItem,
									  ATTR_MARK_STATE, c->visible2D);
		
		SetTreeCellAttribute (panelCurves, CURVES_TREE, curve2DItem, CURVES_COL_NAME,
							  ATTR_LABEL_TEXT, curveName2D);
		SetTreeCellAttribute (panelCurves, CURVES_TREE, curve2DItem, CURVES_COL_NAME,
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_CENTER_JUSTIFIED);
		SetTreeItemAttribute (panelCurves, CURVES_TREE, curve2DItem,
							  ATTR_MARK_TYPE, VAL_MARK_CHECK);
		SetTreeCellAttribute (panelCurves, CURVES_TREE,
							  curve2DItem, CURVES_COL_NAME, ATTR_LABEL_COLOR,
							  c->plotColor);
							  
	}
	
	SetTreeItemAttribute (panelCurves, CURVES_TREE, curveItem,
						  ATTR_NO_EDIT_LABEL, 0);
	SetTreeItemAttribute (panelCurves, CURVES_TREE, VAL_ALL_OBJECTS,
						  ATTR_NO_EDIT_LABEL, 0);
	SetTreeItemAttribute (panelCurves, CURVES_TREE, curveItem,
						  ATTR_MARK_TYPE, VAL_MARK_CHECK);
	
	SetTreeCellAttribute (panelCurves, CURVES_TREE,
						  curveItem, CURVES_COL_NAME,
						  ATTR_LABEL_BOLD, c->active);
	SetTreeCellAttribute (panelCurves, CURVES_TREE,
						  curveItem, CURVES_COL_NAME, ATTR_LABEL_COLOR,
						  c->plotColor);
	// -----------------------------
	//      display start nr
	// -----------------------------
	if (c->startNr >= 0) sprintf (help, "%04d", c->startNr);
	else help[0] = 0;
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_STARTNR,
						  ATTR_LABEL_TEXT, help);
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_STARTNR,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display time + date
	// -----------------------------
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_TIME,
						  ATTR_LABEL_TEXT, c->timeStr);
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_TIME,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panelCurves, CURVES_TREE,
						  curveItem, CURVES_COL_TIME,
						  ATTR_LABEL_COLOR, VAL_LT_GRAY);
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_DATE,
						  ATTR_LABEL_TEXT, c->dateStr);
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_DATE,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_DATE,
						  ATTR_LABEL_COLOR, VAL_LT_GRAY);
	// --------------------------------
	//      display number of averages
	// --------------------------------
	
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_AVG,
						  ATTR_LABEL_TEXT, 
						  c->nAveraged == 0 ? "" : intToStr (c->nAveraged));
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_AVG,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// --------------------------------
	//      info
	// --------------------------------
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_INFO,
						  ATTR_LABEL_TEXT, c->info);
	SetTreeCellAttribute (panelCurves, CURVES_TREE, curveItem, CURVES_COL_INFO,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
						  
}


// ------------------------------------
//		  plot averaged curve
// ------------------------------------
void CURVE_displayAveragedCurve (t_graph *w, t_curve *c)
{
	int nValues;

    switch (c->plotStyle) {
    	case VAL_VERTICAL_BAR_ERROR: 
    		CURVE_plotBars (w, c);
    		break;
    	default:
		    CURVE_createPlotHandles (&c->plotHandlesAveraged, &c->nPlotHandlesAveraged, 2);
		    if (c->nValuesVisibleAvg < 0) nValues = c->nValues;
		    else nValues = c->nValuesVisibleAvg;
		    if (c->yValuesAveraged == NULL) break;
		    c->plotHandlesAveraged[0] = PlotXY (w->panelHandle, GRAPH_GRAPH, c->xValues, c->yValuesAveraged,
									nValues, VAL_DOUBLE, VAL_DOUBLE, c->plotStyle,
									c->pointStyle, c->lineStyle, 1, c->plotColor);
			SetPlotAttribute (w->panelHandle, GRAPH_GRAPH, 
						  	  c->plotHandlesAveraged[0], ATTR_PLOT_LG_VISIBLE, 1);
			CURVE_plotErrorBars_Avg (w, c, 2);										
			if ((c->active)) {// && (!c->showCurrentCurve)) {
				CURVE_displayCross (w, c, (c->markerPoint >= 0) && (c->markerPoint < nValues));
			}
			SetPlotAttribute (w->panelHandle, GRAPH_GRAPH, 
						  	  c->plotHandlesAveraged[1], ATTR_PLOT_LG_VISIBLE, 1);
	}

}


		
// ------------------------------------
//		  plot current curve
// ------------------------------------
void CURVE_displayCurrentCurve (t_graph *w, t_curve *c)
{
	int nValues;
	int n;

    if (c->showCurrentCurve) {
	    switch (c->plotStyleCurrent) {
	    	case VAL_VERTICAL_BAR_ERROR: 
//		    		CURVE_plotBars (w, c);
	    		break;
	    	default:
			    CURVE_createPlotHandles (&c->plotHandlesCurrent, &c->nPlotHandlesCurrent, 1);
			    n = c->currentCurve;
			    nValues = c->yValuesVisible[n];
			    if (n < c->nCurvesWritten) {
				    c->plotHandlesCurrent[0] = PlotXY (w->panelHandle, GRAPH_GRAPH, c->xValues, c->yValues[n],
											nValues, VAL_DOUBLE, VAL_DOUBLE, c->plotStyleCurrent,
											c->pointStyleCurrent, c->lineStyleCurrent, 1, c->plotColorCurrent);
					SetPlotAttribute (w->panelHandle, GRAPH_GRAPH, 
								  	  c->plotHandlesCurrent[0], ATTR_PLOT_LG_VISIBLE, 1);
					CURVE_plotErrorBars_Current (w, c, n, 1);										
				}
		}
	}
}
		

void CURVE_displayDefinitely (t_graph *w, t_curve *c)
{
	if (c->visible) {
		if (c->averagedOnTop) {
			CURVE_displayCurrentCurve (w, c);
			CURVE_displayAveragedCurve (w, c);
		}
		else {
			CURVE_displayAveragedCurve (w, c);
			CURVE_displayCurrentCurve (w, c);
		}		
	}
}



void CURVE_display (t_graph *w, t_curve *c, int refresh, int setMarkStates, int setTreeItem)
{
//	char *help, *help2;
	double sliderMax;
	int display;

	if (c == NULL) return;
	CURVE_setXValues (c, 0);	
	
	if (c->nValues == 0) return;

	if (w == NULL) w = GRAPH_getFromCurve (c);
	if (w == NULL) w = GRAPH_createFromCurveData (c);
	if (w == NULL) return;

	if (w->sliderCurve == c) {
	    // numeric slider
		sliderMax = pow10 ( ceil (log10 (w->yTo * c->nValues)));
		SetCtrlAttribute (w->panelHandle, GRAPH_NUMERICSLIDE_number,
					      ATTR_MAX_VALUE, sliderMax);
		SetCtrlVal (w->panelHandle, GRAPH_NUMERICSLIDE_number, c->sumYValues);
	}

	//!!	
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH,
					  ATTR_REFRESH_GRAPH, 0);

	// redisplay only active curves
	if (c->active) CURVE_removePlot (w, c, 1);
	
	if (c->visible) {
		if (c->averagedOnTop) {
			display = (c->nPlotHandlesCurrent == 0) || (c->plotHandlesCurrent[0] < 0);
			if (display || (c->active))  CURVE_displayCurrentCurve (w, c);
			display = (c->nPlotHandlesAveraged == 0) || (c->plotHandlesAveraged[0] < 0);
			if (display || (c->active))  CURVE_displayAveragedCurve (w, c);
		}
		else {
			display = (c->nPlotHandlesAveraged == 0) || (c->plotHandlesAveraged[0] < 0);
			if (display || (c->active))  CURVE_displayAveragedCurve (w, c);
			display = (c->nPlotHandlesCurrent == 0) || (c->plotHandlesCurrent[0] < 0);
			if (display || (c->active))  CURVE_displayCurrentCurve (w, c);
		}		
	}


	DisableBreakOnLibraryErrors();
	if (setTreeItem) CURVE_displayTreeItem (w, c, setMarkStates);
	if (refresh) RefreshGraph (w->panelHandle, GRAPH_GRAPH);
	

}




t_curve *CURVE2D_getFromPanelHandle (int panel)
{
	int item;
	int level;
	t_curve *c;
	
	if (panel < 0) return NULL;
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
				 VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		GetTreeItemLevel (panelCurves, CURVES_TREE, item, &level);
		if (level == TREELEVEL_CURVES) {
			c = CURVE_getFromIndex (item);
			if (c->panel2DPlot == panel) return c;
		}	
		GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
					 VAL_NEXT, 0, &item);
	}
	return NULL;
}



t_graph *GRAPH_createFromCurveData (t_curve *c)
{
	t_graph *w;
	
	if (c->title[0] == 0) strcpy (c->title, "???");

	w = GRAPH_getFromTitle (c->title, c->plotType);
	if (w != NULL) return w;
	
	w = GRAPH_newPlotWindow (0, c->title);
	strcpy (w->xLabel, c->xLabel);
	strcpy (w->yLabel, c->yLabel);
	strcpy (w->xUnits, c->xUnits);
	strcpy (w->yUnits, c->yUnits);
	w->plotType = c->plotType;
	return w;
}


void GRPAH_rememberCursorPositions (t_graph *w, int rememberPositions)
{
	static double x[MAX_CURSORS];
	static double y[MAX_CURSORS];
	int i;

	if (rememberPositions) {
		for (i = 0; i < w->nCursors; i++) {
			GetGraphCursor (w->panelHandle, GRAPH_GRAPH, i+1, &x[i], &y[i]);
		}	
	}
	else {
		for (i = 0; i < w->nCursors; i++) {
			SetGraphCursor (w->panelHandle, GRAPH_GRAPH, i+1, x[i], y[i]);
		}
	}
}


void GRAPH_resizePanel (t_graph *w)
{
	int width;
	int height;
	int sliderHeight;
	int statusHeight;
	int top;
	
	if (w == NULL) return;
		
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_LEFT, 0);

	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_TOP, panelMenuHeight(w->panelHandle));
	
	
	
//	minimumWidth  = ctrlLeft   (w->panelHandle, GRAPH_GRAPH) + 300;
	width = panelWidth (w->panelHandle);
/*	if (width < minimumWidth) {
		width = minimumWidth;
		SetPanelAttribute (w->panelHandle, ATTR_WIDTH, width);
	}
*/	
//	minimumHeight = ctrlBottom (w->panelHandle, GRAPH_CANVAS);
	height = panelHeight (w->panelHandle);
/*	if (height < minimumHeight) {
		height = minimumHeight;
		SetPanelAttribute (w->panelHandle, ATTR_HEIGHT, height);
	}
*/	
	// set graph size
	SetCtrlAttribute (w->panelHandle, GRAPH_NUMERICSLIDE_number, ATTR_VISIBLE,
					  w->showSlider_number);
	sliderHeight = w->showSlider_number ? ctrlHeight (w->panelHandle, GRAPH_NUMERICSLIDE_number) : 0;
	
	SetCtrlAttribute (w->panelHandle, GRAPH_LISTBOX_statusLine, ATTR_VISIBLE,
					  w->showStatusLine);
	statusHeight = w->showStatusLine ? ctrlHeight (w->panelHandle, GRAPH_LISTBOX_statusLine) : 0;
	
	GRPAH_rememberCursorPositions (w, 1);

	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_WIDTH,
					  width - ctrlLeft (w->panelHandle, GRAPH_GRAPH));
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_HEIGHT,
					 height - ctrlTop (w->panelHandle, GRAPH_GRAPH) - sliderHeight - statusHeight);

	if (w->showSlider_number) { 
		SetCtrlAttribute (w->panelHandle, GRAPH_NUMERICSLIDE_number, ATTR_TOP,
						  ctrlBottom (w->panelHandle, GRAPH_GRAPH));
		GetCtrlAttribute (w->panelHandle, GRAPH_NUMERICSLIDE_number,
						  ATTR_DIG_DISP_WIDTH, &width);
		SetCtrlAttribute (w->panelHandle, GRAPH_NUMERICSLIDE_number, ATTR_WIDTH,
						  panelWidth (w->panelHandle) - width);
	}
	
	top = ctrlBottom (w->panelHandle, GRAPH_GRAPH) + sliderHeight+1;
	
	if (w->showStatusLine) { 
		SetCtrlAttribute (w->panelHandle, GRAPH_LISTBOX_statusLine, ATTR_TOP,
						  top);
		SetCtrlAttribute (w->panelHandle, GRAPH_LISTBOX_statusLine, ATTR_LEFT,
						  0);
		SetCtrlAttribute (w->panelHandle, GRAPH_LISTBOX_statusLine, ATTR_WIDTH,
						  panelWidth (w->panelHandle));
	}
	GRPAH_rememberCursorPositions (w, 0);
	
	
}



void GRAPH_init (t_graph *w)
{
	w->plotType = 0;
	w->showSlider_number = 0;
	w->sliderCurve = NULL;
	w->visible = 1;
	w->showStatusLine = 0;
	w->newGraph = 1;
	w->usedByActiveSession = 0;
//	w->alwaysVisible = 0;
	

	strcpy (w->panelTitle, "Results");

	w->xLabel[0] = 0;
	w->xAsciiFileColumnLabel[0] = 0;
	w->xUnits[0] = 0;
	w->xDigits = 9;
	w->xFrom = 0;
	w->xTo   = 0;
	w->xIncrement = 1;
	w->xFromAutoscale = 1;
	w->xToAutoscale = 1;
	w->xShowSecondAxis = 0;
	w->xAxis2Multiply = 1.0;
	w->xLabel2[0] = 0;
	w->xAsciiFileColumnLabel2[0]= 0;
	w->xUnits2[0] = 0;
	
	
	w->yLabel[0] = 0;
	w->yAsciiFileColumnLabel[0] = 0;
	w->yUnits[0] = 0;
	w->yDigits = 6;
	w->yFrom = 0;
	w->yTo   = 0;
	w->yIncrement = 1;
	w->yFromAutoscale = 0;
	w->yToAutoscale   = 1;
	w->yShowSecondAxis = 0;
	w->yAxis2Multiply = 1.0;
	w->yLabel2[0] = 0;
	w->yAsciiFileColumnLabel2[0]= 0;
	w->yUnits2[0] = 0;

	w->maxYValue = 0;
	w->minYValue = 0;
	w->maxXValue = 0;
	w->minXValue = 0;
	
	w->panelHandle = -1;
	w->graphFullSize = 0;
	w->defaultPos = PANEL_POS_TOP_LEFT;
	
	w->nCursors = 0;
	w->displayed = 0;
	
	w->canShowCounts = 0;
	w->showCounts = 0;
	
	w->wasZoomed = 0;
}

void GRAPH_free (t_graph *w)
{

}




/*
void GRAPH_freeCurvesInPlotWindow (t_graph *w)
{
	int i;
	t_curve *c;
	
	if (w == NULL) return;
	
	// free contents of plotWindow

	for (i = 1; i <= ListNumItems (w->listOfCurves); i++) {
		ListRemoveItem (w->listOfCurves, &c, END_OF_LIST);
		CURVE_free (c);
		free (c);
	}
	ListDispose (w->listOfCurves);
	w->listOfCurves = NULL;
}
*/


void AXIS_initPanel (t_graph *w)
{
}



void GRAPH_STAT_initPanel (t_graph *w)
{
}


void GRAPH_CURS_initPanel (t_graph *w)
{
}



int GRAPH_initPanel (t_graph *w, int parentPanel)
{

	w->panelHandle = LoadPanel (parentPanel, SESSIONMANAGER_uirFile, GRAPH);

	SetPanelAttribute (w->panelHandle, ATTR_TITLE, w->panelTitle);
	SetCtrlAttribute (w->panelHandle, GRAPH_NUMERICSLIDE_number,
					  ATTR_FILL_COLOR, VAL_YELLOW);
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH,
					  ATTR_PLOT_BGCOLOR, GRAPH_BACKGOUND_COLOR);
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_GRID_COLOR,
					  GRAPH_GRID_COLOR);
					  
	
	return 0;
}



void systemErrChk (int error)
{
	if (error != 0) {
		MessagePopup ("Error", GetGeneralErrorString (error));
	}
}



//
// up = 1, down = 0;
// 
void GRAPH_positionPanel (t_graph *g, Rect r)//(int panel, int pos)
{
	int twoScreens;
	Rect screen;
	int titlebarThickness = 20;
	int frameThickness    = 5;
	int top, left, width, height;
	
	if (g == NULL) return;
	if (g->panelHandle < 0) return;

	twoScreens = (GetMonitorAttribute (2, ATTR_WIDTH, &screen.width) >= 0);
	
	if ((r.width > 0) && (r.height > 0)) {
		if ((!twoScreens) && (r.left > screenWidth()-20)) {
			r.left = 5;
			r.top = 5;
		}
		SetPanelPos (g->panelHandle, r.top, r.left);
		SetPanelSize (g->panelHandle, r.height, r.width);
		GRAPH_resizePanel (g);
		return;
	}

	
	if (twoScreens) {
		//DisplayPanel (w->panelHandle);
		
		GetMonitorAttribute (2, ATTR_TOP,  &screen.top);
		GetMonitorAttribute (2, ATTR_LEFT, &screen.left);		 
		GetMonitorAttribute (2, ATTR_HEIGHT, &screen.height);

		top    = titlebarThickness +  frameThickness;
		left   = screen.left + frameThickness;
		height =  screen.height - titlebarThickness - 2 * frameThickness;
		width  =  screen.width - 2 * frameThickness;

		switch (g->defaultPos) {
			case PANEL_POS_FULLSIZE:
				SetPanelSize (g->panelHandle, height, width);
				SetPanelPos (g->panelHandle, top, left);
				break;
			case PANEL_POS_TOP_LEFT:
				SetPanelSize (g->panelHandle, height/2, width/2);
				SetPanelPos (g->panelHandle, top, left);
				break;
			case PANEL_POS_TOP_RIGHT:
				SetPanelSize (g->panelHandle, height/2, width/2);
				SetPanelPos (g->panelHandle, top, left+width/2);
				break;
			case PANEL_POS_BOTTOM_LEFT:
				SetPanelSize (g->panelHandle, height/2, width/2);
				SetPanelPos (g->panelHandle, top+height/2, left);
				break;
			case PANEL_POS_BOTTOM_RIGHT:
				SetPanelSize (g->panelHandle, height/2, width/2);
				SetPanelPos (g->panelHandle, top+height/2, left+width/2);
				break;
			default:
				SetPanelPos (g->panelHandle, 10, 20);
		}
	}
}




t_graph *GRAPH_newPlotWindow (int parentPanel, const char *title)
{
	t_graph *w;
	t_graph *prev = NULL;
//	int nextMonitor = 0;
	int titleHeight;
	int fullSize = 0;
	int nPlots;
	int newItem, prevItem;
	

//	if (parentPanel == 0) parentPanel = panelResults;
	
	w = (t_graph *) malloc (sizeof (t_graph));

	GRAPH_init (w);
	strcpy (w->panelTitle, title);
	GRAPH_initPanel (w, parentPanel);
	newItem = InsertTreeItem (panelCurves, CURVES_TREE,
	   			    VAL_SIBLING, 0, VAL_LAST, w->panelTitle, NULL,
					NULL, (unsigned) w);
	SetTreeItemAttribute (panelCurves, CURVES_TREE, newItem,
						  ATTR_LABEL_COLOR, w->visible ? VAL_BLACK : VAL_LT_GRAY);
					
//	if (GRAPHPAREMETERS_placeWindow (s, w->panelHandle)) 
//		GRAPH_positionPanel (w->panelHandle, pos);

	SetTreeItemAttribute (panelCurves, CURVES_TREE, newItem, ATTR_NO_EDIT_LABEL, 0);
//	SetTreeItemAttribute (panelCurves, CURVES_TREE, newItem,
//						  ATTR_MARK_TYPE, VAL_MARK_NONE);
	SetTreeItemAttribute (panelCurves, CURVES_TREE, newItem,
						  ATTR_MARK_STATE, w->visible);
	SetTreeItemAttribute (panelCurves, CURVES_TREE, newItem,
						  ATTR_LABEL_POINT_SIZE, 17);

	SetTreeItemAttribute (panelCurves, CURVES_TREE, newItem,
						  ATTR_LABEL_BOLD, 1);
	DisplayPanel (panelCurves);
	GRAPH_resizePanel (w);
	
//	DisplayPanel (w->panelHandle);
	
	return w;	
}



int GRAPH_getSelectionFromTree (t_graph **w, t_curve **c, int *selected, int *clicked2D, int *clickedCurrent)
{

	int level, value;
	int index, parentIndex;
	
	*w = NULL;
	if (c != NULL) *c = NULL;
	if (selected != NULL) *selected = 0;
	
	// no curve item selected

	GetActiveTreeItem (panelCurves, CURVES_TREE, &index);
	if (index == -1) return -1;
	
	if (selected != NULL) {
		GetTreeItemAttribute (panelCurves, CURVES_TREE, index, ATTR_MARK_STATE, selected);
	}

	GetTreeItemLevel (panelCurves, CURVES_TREE, index, &level);
	GetValueFromIndex (panelCurves, CURVES_TREE, index, &value);
	if (clicked2D != NULL) *clicked2D = ((level == TREELEVEL_SUB) && (value == TREE_VALUE_2D));
	if (clickedCurrent != NULL) *clickedCurrent = ((level == TREELEVEL_SUB) && (value == TREE_VALUE_CURRENT));
	if (level == TREELEVEL_PLOTWINDOWS) {
		GetCtrlVal (panelCurves, CURVES_TREE, w);
		return 1;
	}	

	// 2D graph clicked
	if (level == TREELEVEL_SUB) {
		GetTreeItemParent (panelCurves, CURVES_TREE, index, &index);
	}
	
	GetTreeItemParent (panelCurves, CURVES_TREE, index, &parentIndex);
	*w = GRAPH_getFromIndex (parentIndex);
	if (c != NULL) *c = CURVE_getFromIndex (index);

	return 0;
}



t_graph *GRAPH_getWindowFromPanelHandle (int panelHandle, int *index)
{
	t_graph *g;
	int item;
	
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
				 VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		g = GRAPH_getFromIndex (item);
		if (g->panelHandle == panelHandle) {
			if (index != NULL) *index = item;
			return g;
		}
		GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, item, item,
					 VAL_NEXT, 0, &item);
	}
	if (index != NULL) *index = item;
	return NULL;
}






t_graph *GRAPH_getFromTitle (const char *strTitle,
									   int plotType)
{
	t_graph *g;
	int item;
	
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
				 VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		g = GRAPH_getFromIndex (item);
		if (plotType >= 0) {
			if (g->plotType == plotType) {
				if (strcmp (g->panelTitle, strTitle) == 0) return g;
			}
		}
		else {
			if (strcmp (g->panelTitle, strTitle) == 0) return g;
		}
		GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
					 VAL_NEXT, 0, &item);
	}
	return NULL;
}





void GRAPH_discard (t_graph **g)
{
	t_curve *c;
	int graphItem;
	int item;

	if (*g == NULL) return;
	
	CURVE_getTreeItemNr (*g, NULL, &graphItem, NULL, NULL, NULL);
	item = VAL_LAST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_PREV_PLUS_SELF, 0, &item);
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_PREV, 0, &item);
		CURVE_delete (*g, c);
	}
	DiscardPanel ((*g)->panelHandle);
	DeleteListItem (panelCurves, CURVES_TREE, graphItem, 1);
	GRAPH_deleteAllReferences (*g, NULL);
	GRAPH_free (*g);
	free (*g);
	*g = NULL;
}




void GRAPH_discardAll (void)
{
	t_graph *g;
	int item;
	
	item = VAL_LAST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
				 VAL_PREV_PLUS_SELF, 0, &item);
	while (item >= 0) {
		g = GRAPH_getFromIndex (item);
		GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
					 VAL_PREV, 0, &item);
		GRAPH_discard (&g);
	}
}


void GRAPH_setAllDisplayed (int displayed)
{
	t_graph *g;
	int item;
	
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
				 VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		g = GRAPH_getFromIndex (item);
		if (g != NULL) g->displayed = displayed;
		GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
					 VAL_NEXT, 0, &item);
	}
}



void GRAPH_RemoveReferenceToPlotItem (void *plotItem)
{
	t_graph *g;
	int item;
	int level;
	t_curve *c = NULL;
	
	if (panelCurves < 0) return;
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
				 VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		GetTreeItemLevel (panelCurves, CURVES_TREE, item, &level);
		if (level == TREELEVEL_CURVES) {
			c = CURVE_getFromIndex (item);
			if (c->plotItem == plotItem) c->plotItem = NULL;
		}	
		GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
					 VAL_NEXT, 0, &item);
	}
}




void GRAPH_removeCurveWithName (t_graph *w, char *name)
{
	t_curve *c;
	c = CURVE_getPtrFromName (w, name, 0);
	CURVE_delete (w, c);
}


void GRAPH_applyWindowParametersToGraph (t_graph *w)
{
	if (w == NULL) return;
	
	// x - axis

	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH,
					  ATTR_XLOOSE_FIT_AUTOSCALING, 
					  0);
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, 
					  ATTR_XNAME, concatLabelAndUnits(w->xLabel, w->xUnits));
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_XDIVISIONS,
					  VAL_AUTO);

	
	// y - axis
	
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH,
					  ATTR_YLOOSE_FIT_AUTOSCALING, 
					  0);

	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_YNAME,
					  concatLabelAndUnits(w->yLabel, w->yUnits));
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_YNAME,
					  concatLabelAndUnits(w->yLabel, w->yUnits));
	
	if (w->xShowSecondAxis) {
		SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_ACTIVE_XAXIS,
						  VAL_TOP_XAXIS);
		SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_XLABEL_VISIBLE,
						  1);
		SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH,
						  ATTR_XLOOSE_FIT_AUTOSCALING, 
						  0);
		SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, 
					  	  ATTR_XNAME, concatLabelAndUnits(w->xLabel2, w->xUnits2));
		SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_XDIVISIONS,
						  VAL_AUTO);
		SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH, ATTR_ACTIVE_XAXIS,
						  VAL_BOTTOM_XAXIS);
	}
    
	if (w->xTo > w->xFrom) {
		SetAxisScalingMode (w->panelHandle, GRAPH_GRAPH,
							VAL_BOTTOM_XAXIS,
							VAL_MANUAL,
							w->xFrom, w->xTo);
		if (w->xShowSecondAxis) {
			SetAxisScalingMode (w->panelHandle, GRAPH_GRAPH,
								VAL_TOP_XAXIS,
								VAL_MANUAL,
								w->xFrom * w->xAxis2Multiply, w->xTo * w->xAxis2Multiply);
		}
	}
	if (w->yTo > w->yFrom) {
		SetAxisScalingMode (w->panelHandle, GRAPH_GRAPH, VAL_LEFT_YAXIS,
						VAL_MANUAL,
						w->yFrom, w->yTo);
	}
}



void AXIS_setParameters (t_graph *w)
{
	int panelInactive;
	int activeCtrl;
	
	panelInactive = (GetActivePanel () != panelAxis);
	activeCtrl  = GetActiveCtrl (panelAxis);
	
	// ---------------------	
	//     set axis labels and titles
	// ---------------------
	SetCtrlVal (panelAxis, AXIS_STRING_xLabel, w->xLabel);
	SetCtrlVal (panelAxis, AXIS_STRING_yLabel, w->yLabel);
	// ---------------------	
	//     set xFrom
	// ---------------------
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_xFrom,
					  ATTR_CTRL_MODE,
					  w->xFromAutoscale ? VAL_INDICATOR : VAL_HOT);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_xFrom,
					  ATTR_TEXT_BGCOLOR,
					  w->xFromAutoscale ? VAL_MED_GRAY : VAL_WHITE);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_xFrom,
					  ATTR_INCR_VALUE, w->xIncrement);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_xFrom,
					  ATTR_MAX_VALUE, w->xTo);
	SetCtrlVal (panelAxis, AXIS_CHECKBOX_xFromAuto, w->xFromAutoscale);
	if (panelInactive || (activeCtrl != AXIS_NUMERIC_xFrom) || w->xFromAutoscale) {
		setCtrlValDouble (panelAxis, AXIS_NUMERIC_xFrom, w->xFrom);
	}
	// ---------------------	
	//     set xTo
	// ---------------------
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_xTo,
					  ATTR_CTRL_MODE,
					  w->xToAutoscale ? VAL_INDICATOR : VAL_HOT);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_xTo,
					  ATTR_TEXT_BGCOLOR,
					  w->xToAutoscale ? VAL_MED_GRAY : VAL_WHITE);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_xTo,
					  ATTR_INCR_VALUE, w->xIncrement);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_xTo,
					  ATTR_MIN_VALUE, w->xFrom);
	SetCtrlVal (panelAxis, AXIS_CHECKBOX_xToAuto, w->xToAutoscale);
	if (panelInactive || (activeCtrl != AXIS_NUMERIC_xTo) || w->xToAutoscale) {
		setCtrlValDouble (panelAxis, AXIS_NUMERIC_xTo, w->xTo);
	}
	// ---------------------	
	//     set yFrom
	// ---------------------
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_yFrom,
					  ATTR_CTRL_MODE,
					  w->yFromAutoscale ? VAL_INDICATOR : VAL_HOT);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_yFrom,
					  ATTR_TEXT_BGCOLOR,
					  w->yFromAutoscale ? VAL_MED_GRAY : VAL_WHITE);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_yFrom,
					  ATTR_INCR_VALUE, w->yIncrement);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_yFrom,
					  ATTR_MAX_VALUE, w->yTo);
	SetCtrlVal (panelAxis, AXIS_CHECKBOX_yFromAuto, w->yFromAutoscale);
	if (panelInactive || (activeCtrl != AXIS_NUMERIC_yFrom) || w->yFromAutoscale) {
		setCtrlValDouble (panelAxis, AXIS_NUMERIC_yFrom, w->yFrom);
	}
				  
	// ---------------------	
	//     set yTo
	// ---------------------
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_yTo,
					  ATTR_CTRL_MODE,
					  w->yToAutoscale ? VAL_INDICATOR : VAL_HOT);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_yTo,
					  ATTR_TEXT_BGCOLOR,
					  w->yToAutoscale ? VAL_MED_GRAY : VAL_WHITE);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_yTo,
					  ATTR_INCR_VALUE, w->yIncrement);
	SetCtrlAttribute (panelAxis, AXIS_NUMERIC_yTo,
					  ATTR_MIN_VALUE, w->yFrom);
	SetCtrlVal (panelAxis, AXIS_CHECKBOX_yToAuto,   w->yToAutoscale);

	if (panelInactive || (activeCtrl != AXIS_NUMERIC_yTo) || w->yToAutoscale) {
		setCtrlValDouble (panelAxis, AXIS_NUMERIC_yTo, w->yTo);
	}
	
	if (w->canShowCounts) 
		SetCtrlVal (panelAxis, AXIS_RINGSLIDE_showCounts, w->showCounts);
	SetCtrlAttribute (panelAxis, AXIS_RINGSLIDE_showCounts, ATTR_DIMMED, !w->canShowCounts);
	
	
}




void GRAPH_STAT_setParameters (t_graph *w, t_curve *c)
{	 
	if (c == NULL) return;
}



void GRAPH_setWindowParameters (t_graph *w, t_curve *c)
{
	int sliderVisible, plotVisible;
	t_graph *selWindow;
	t_curve *selCurve;
	int selected;
	char help[100];
	int itemNo;
	
	if (w == NULL) return;
	
	GetCtrlAttribute (w->panelHandle, GRAPH_NUMERICSLIDE_number,
					  ATTR_VISIBLE, &sliderVisible);
	if ((!sliderVisible) && (w->showSlider_number == 1)) {
		GRAPH_resizePanel (w);
	}

	if (w->visible) GRAPH_applyWindowParametersToGraph (w);
	
	GetPanelAttribute (w->panelHandle, ATTR_VISIBLE, &plotVisible); 
	if (plotVisible != w->visible) 
		SetPanelAttribute (w->panelHandle, ATTR_VISIBLE, w->visible); 
	
	CURVE_getTreeItemNr (w, c, &itemNo, 0, 0, 0);
	SetTreeItemAttribute (panelCurves, CURVES_TREE, itemNo, ATTR_MARK_STATE, w->visible);
	SetTreeItemAttribute (panelCurves, CURVES_TREE, itemNo,
						  ATTR_LABEL_COLOR, w->visible ? VAL_BLACK : VAL_LT_GRAY);
	
		

	GRAPH_getSelectionFromTree (&selWindow, &selCurve, &selected, NULL, NULL);
	if (selWindow == w) {
		// if current window selected
		// display axis parameters
		AXIS_setParameters (w);
		GRAPH_STAT_setParameters (w, c);
		CURSORS_setParameters (w);
	}
	SetCtrlVal (panelCurves, CURVES_STRING_window, w->panelTitle);

	SetCtrlAttribute (panelCurves, CURVES_STRING_curve, ATTR_VISIBLE,  c != NULL);
	if (c != NULL) SetCtrlVal (panelCurves, CURVES_STRING_curve,  c->name);
	
	SetAttributeForCtrls (panelCurves, ATTR_VISIBLE, (c != NULL) && (c->n2Dcurves > 0), 0,
						  CURVES_NUMERIC_curve, 
						  CURVES_NUMERIC_nCurves,
						  CURVES_TEXTMSG_point,
						  CURVES_STRING_value, 0);
	if ((c != NULL) && (c->n2Dcurves > 0)) {
		SetCtrlVal (panelCurves, CURVES_NUMERIC_nCurves, c->n2Dcurves);
		SetCtrlAttribute (panelCurves, CURVES_NUMERIC_curve, ATTR_MAX_VALUE, c->n2Dcurves);
		SetCtrlVal (panelCurves, CURVES_NUMERIC_curve,  c->activeCurve2D+1);
		sprintf (help, "%s %s", doubleToStr(c->xValues2D[c->activeCurve2D]), c->xUnits2D);
		SetCtrlVal (panelCurves, CURVES_STRING_value, help);
	}
//	SetPanelAttribute (w->panelHandle, ATTR_TITLE, w->panelTitle);
}



void AXIS_getParameters (t_graph *w)
{
	// x axis
	GetCtrlVal (panelAxis, AXIS_CHECKBOX_xFromAuto, &w->xFromAutoscale);
	GetCtrlVal (panelAxis, AXIS_CHECKBOX_xToAuto, &w->xToAutoscale);
	GetCtrlVal (panelAxis, AXIS_NUMERIC_xFrom, 	  &w->xFrom);
	GetCtrlVal (panelAxis, AXIS_NUMERIC_xTo, 		  &w->xTo);
//	if (w->xTo <= w->xFrom) w->xTo = w->xFrom + w->xIncrement;

	GetCtrlVal (panelAxis, AXIS_CHECKBOX_yFromAuto, &w->yFromAutoscale);
	GetCtrlVal (panelAxis, AXIS_CHECKBOX_yToAuto,   &w->yToAutoscale);
	GetCtrlVal (panelAxis, AXIS_NUMERIC_yFrom, 	   &w->yFrom);
	GetCtrlVal (panelAxis, AXIS_NUMERIC_yTo, 	   &w->yTo);
//	if (w->yTo <= w->yFrom) w->yTo = w->yFrom + w->yIncrement;
	if (w->canShowCounts) 
		GetCtrlVal (panelAxis, AXIS_RINGSLIDE_showCounts, &w->showCounts);
}


void CURSORS_getParameters (t_graph *w)
{
	GetCtrlVal (panelCursors, CURSORS_NUMERIC_nCursors, &w->nCursors);
}


void CURSORS_displayCoordinates (t_graph *w)
{

	double x1, y1;
	double x2, y2;
	char help[400];
	char statusLine[400];
	

	if (w == NULL) return;
	if (w->nCursors >= 1) {
		SetCursorAttribute (w->panelHandle, GRAPH_GRAPH, 1,
							ATTR_CURSOR_COLOR, COLOR_CURSOR1);
		GetGraphCursor (w->panelHandle, GRAPH_GRAPH, 1, &x1, &y1);
		SetCtrlVal (panelCursors, CURSORS_NUMERIC_cursorX1, x1);
		SetCtrlVal (panelCursors, CURSORS_NUMERIC_cursorY1, y1);
		if (w->showStatusLine) {
			sprintf (statusLine, "cursor1=( %s, %s )", 
			doubleToStrDCUF(x1, w->xDigits, w->xUnits, COLOR_CURSOR1), 
			doubleToStrDCUF (y1, w->yDigits, w->yUnits, COLOR_CURSOR1));
		}			
	}

	if (w->nCursors >= 2) {
		SetCursorAttribute (w->panelHandle, GRAPH_GRAPH, 2,
							ATTR_CURSOR_COLOR, COLOR_CURSOR2);
		GetGraphCursor (w->panelHandle, GRAPH_GRAPH, 2, &x2, &y2);
		SetCtrlVal (panelCursors, CURSORS_NUMERIC_cursorX2, x2);
		SetCtrlVal (panelCursors, CURSORS_NUMERIC_cursorY2, y2);
		SetCtrlVal (panelCursors, CURSORS_NUMERIC_cursorDeltaX, x2 - x1);
		SetCtrlVal (panelCursors, CURSORS_NUMERIC_cursorDeltaY, y2 - y1);
		if (w->showStatusLine) {
			sprintf (help, ", cursor2=( %s, %s), diff=( %s, %s )", 
					 doubleToStrDCUF (x2, w->xDigits, w->xUnits, COLOR_CURSOR2), 
					 doubleToStrDCUF (y2, w->yDigits, w->yUnits, COLOR_CURSOR2),
					 doubleToStrDCUFI (x2-x1, w->xDigits, w->xUnits, COLOR_DIFFERENCE), 
					 doubleToStrDCUF (y2-y1, w->yDigits, w->yUnits, COLOR_DIFFERENCE));
			strcat (statusLine, help); 
		}			
	}
	if ((w->showStatusLine) && (w->nCursors >= 1)) 
		ReplaceListItem (w->panelHandle, GRAPH_LISTBOX_statusLine,  0, statusLine, 0);
}


void CURSORS_setParameters (t_graph *w)
{
	int old;
	int oldNCursors;
	
	SetCtrlVal (panelCursors, CURSORS_NUMERIC_nCursors, w->nCursors);
	
	SetAttributeForCtrls (panelCursors, ATTR_DIMMED, w->nCursors < 1, 0,
					      CURSORS_TEXTMSG_Cursor1,
					      CURSORS_NUMERIC_cursorX1,
					      CURSORS_NUMERIC_cursorY1,
						  0);
	SetAttributeForCtrls (panelCursors, ATTR_DIMMED, w->nCursors < 2, 0,
					      CURSORS_TEXTMSG_Cursor2,
					      CURSORS_NUMERIC_cursorX2,
					      CURSORS_NUMERIC_cursorY2,
					      CURSORS_TEXTMSG_difference,
					      CURSORS_TEXTMSG_delta1,
					      CURSORS_TEXTMSG_delta2,
					      CURSORS_NUMERIC_cursorDeltaX,
					      CURSORS_NUMERIC_cursorDeltaY,
						  0);
	if (w->panelHandle == 0) return;
	
	GetCtrlAttribute (w->panelHandle, GRAPH_GRAPH,
					  ATTR_NUM_CURSORS, &oldNCursors);
	SetCtrlAttribute (w->panelHandle, GRAPH_GRAPH,
					  ATTR_NUM_CURSORS, w->nCursors);
	if ((oldNCursors < 1) && (w->nCursors >= 1)) {
		SetCtrlAttribute (w->panelHandle, GRAPH_LISTBOX_statusLine,
							ATTR_VISIBLE_LINES, 1);
		SetGraphCursor (w->panelHandle, GRAPH_GRAPH, 1, 
						w->xFrom+0.1*(w->xTo-w->xFrom), 
						w->yTo-0.1*(w->yTo-w->yFrom));
	}
	if ((oldNCursors < 2) && (w->nCursors == 2)) {
		SetGraphCursor (w->panelHandle, GRAPH_GRAPH, 2, 
						w->xTo-0.1*(w->xTo-w->xFrom), 
						w->yFrom+0.1*(w->yTo-w->yFrom));
	}
	
	old = w->showStatusLine;
	w->showStatusLine = (w->nCursors > 0);
	if (w->showStatusLine != old) GRAPH_resizePanel (w);
	
	CURSORS_displayCoordinates (w);
}


void GRAPH_getWindowParameters (t_graph *w)
{
	if (w == NULL) return;
	AXIS_getParameters (w);
	CURSORS_getParameters (w);
	CURSORS_setParameters (w);
}





/*

void GRAPH_deleteCurve (t_graph *w)
{
	int i;
	t_curve *c;
	
	if (w == NULL) return;
	
	for (i = 1; i <= ListNumItems (w->listOfCurves); i++) {
		ListGetItem (w->listOfCurves, &c, i);
		SetPlotAttribute (w->panelHandle, GRAPH_GRAPH, c->plotHandle,
						  ATTR_GRAPH_LG_VISIBLE, 0);
		DeleteGraphPlot (w->panelHandle, GRAPH_GRAPH, c->plotHandle,
						 VAL_IMMEDIATE_DRAW);
	}
	
}
*/

void GRAPH_displayAllCurves (t_graph *w, int setMarkStates, int setTreeItems)
{
	t_curve *c;
	int visible;
	int graphItem;
	int item;
	t_graph *wActive;
	
#ifdef MEASUREDURATION
	clock_t time;
	time = clock();
	printf ("----------------GRAPH_displayAllCurves---------\n");
#endif
	
	if (w == NULL) return;

	if (w->yToAutoscale || w->yFromAutoscale || w->xToAutoscale || w->xFromAutoscale) {
		GRAPH_autoScale (w);
	//	GRAPH_setWindowParameters (w, NULL);     
	}

	
	CURVE_getTreeItemNr (w, NULL, &graphItem, NULL, NULL, NULL);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		CURVE_display (w, c, 0, setMarkStates, setTreeItems);
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_NEXT, 0, &item);
#ifdef MEASUREDURATION
			printf ("t ('CURVE_display(%d,active=%d)') = %d ms\n", c->startNr, c->active,timeStop(time));
#endif

	}

	// check if active panel is the active one...
	GRAPH_getSelectionFromTree (&wActive, NULL, NULL, NULL, NULL);
	if (w->newGraph || (w == wActive)) GRAPH_setWindowParameters (w, NULL);
	else GRAPH_applyWindowParametersToGraph (w);  
	w->newGraph = 0;
//	GRAPH_applyWindowParametersToGraph (w);
	GetPanelAttribute (w->panelHandle, ATTR_VISIBLE, &visible);
// BUG: GENERAL PROTECTIOn FAULT ICI	
	RefreshGraph (w->panelHandle, GRAPH_GRAPH);

#ifdef MEASUREDURATION
			printf ("t ('RefreshGraph()') = %d ms\n", timeStop(time));
			printf ("----------------END-----------\n");
#endif
	
	if (!visible && w->visible) DisplayPanel (w->panelHandle);
}	
	
	
int GRAPH_hasActiveCurve (t_graph *w)
{
	t_curve *c;
	int visible;
	int graphItem;
	int item;
	t_graph *wActive;
	
	if (w == NULL) return 0;

	CURVE_getTreeItemNr (w, NULL, &graphItem, NULL, NULL, NULL);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		if (c->active) return 1;
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_NEXT, 0, &item);
	}
	return 0;
}	
	



void GRAPH_deleteAllNonActiveCurves (t_graph *w)
{
	t_curve *c;
	int graphItem;
	int item;
	t_graph *wActive;
	
	if (w == NULL) return ;

	CURVE_getTreeItemNr (w, NULL, &graphItem, 0,0,0);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		if (!c->active) CURVE_delete (w, c);     
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_NEXT, 0, &item);
	}
	GRAPH_displayAllCurves (w, 0, 1);
}	
	


void GRAPH_getMinMaxAllCurves (t_graph *w)
{

	t_curve *c = NULL;
	int firstItem = 1;
	int graphItem;
	int item;
	

	CURVE_getTreeItemNr (w, NULL, &graphItem, 0,0,0);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		if (c->visible) {
			if (firstItem) {
				w->maxYValue = -DBL_MAX;
				w->minYValue = DBL_MAX;
				w->maxXValue = -DBL_MAX;
				w->minXValue = DBL_MAX;
				firstItem = 0;
			}
			if (c->maxXValue > w->maxXValue) w->maxXValue = c->maxXValue;
			if (c->maxYValue > w->maxYValue) w->maxYValue = c->maxYValue;
			if (c->minXValue < w->minXValue) w->minXValue = c->minXValue;
			if (c->minYValue < w->minYValue) w->minYValue = c->minYValue;
		}
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_NEXT, 0, &item);
	}
	
	if (w->maxYValue == -DBL_MAX) w->maxYValue = 1.0;
	if (w->minYValue == DBL_MAX) w->minYValue = 0.0;
	if (w->maxXValue == -DBL_MAX) w->maxXValue = 1.0;
	if (w->minXValue == DBL_MAX) w->minXValue = 0.0;
	if ((w->minYValue == 0.0) && (w->maxYValue == 0.0)) w->maxYValue = 1.0;
}




int CVICALLBACK GRAPH_displayParametersChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_graph *w;
	t_curve *c;
	int checked;
	
	switch (event) {
		case EVENT_COMMIT:
			if (GRAPH_getSelectionFromTree (&w, &c, &checked, 0,0) >= 0) {
				if ((c != NULL) && (c->visible != checked)) {
//					c->visible = checked;
//					CURVE_display (w, c);
				}
     		}
     		if (w == NULL) return 0;
     		RefreshGraph (w->panelHandle, GRAPH_GRAPH);
//			w = GRAPH_getWindowFromPanelHandle (panel, 0);   
			GRAPH_getWindowParameters (w);
			if ((control == AXIS_CHECKBOX_yFromAuto) || 
				(control == AXIS_CHECKBOX_yToAuto) ||
				(control == AXIS_CHECKBOX_xFromAuto) ||
				(control == AXIS_CHECKBOX_xToAuto)) {
				GRAPH_autoScale (w);
			}
			GRAPH_setWindowParameters (w, c);
			break;
	}
	return 0;
}


void GRAPH_setPanelPosToPlotItem (t_graph *w, int panel)
{
	int item, graphItem;
	t_curve *c;
	t_plotItem *p;
	int changes;

	CURVE_getTreeItemNr (w, NULL, &graphItem, 0,0,0);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		p = c->plotItem; 
		if (p != NULL) {
			changes = copyPanelBounds (panel, &p->panelPos);   
			if ((p->session != NULL) && changes) SESSION_setChanges (p->session, 1);     
		}
			
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_NEXT, 0, &item);
	}
}


void GRAPH_closePanel (int panel)
{
	t_graph *g;
	int index;
	
	g = GRAPH_getWindowFromPanelHandle (panel, &index);
	if (g == NULL) return;
	g->visible = 0;
	GRAPH_setWindowParameters (g, NULL);
	
	SetPanelAttribute (g->panelHandle, ATTR_VISIBLE, g->visible); 
	SetTreeItemAttribute (panelCurves, CURVES_TREE, index, ATTR_COLLAPSED, 1);
	SetTreeItemAttribute (panelCurves, CURVES_TREE, index, ATTR_MARK_STATE, g->visible);
	ProcessDrawEvents();
}



int CVICALLBACK GRAPH_panelCallback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	t_graph *w;
	int index;
/*	printf (eventStr(event,eventData1,eventData2));
	printf ("\n");
*/
	switch (event) {
		case EVENT_PANEL_MOVE:
			w = GRAPH_getWindowFromPanelHandle (panel, 0);   
			GRAPH_setPanelPosToPlotItem (w, panel); 
			break;
		case EVENT_PANEL_SIZE:
			w = GRAPH_getWindowFromPanelHandle (panel, 0);   
			GRAPH_setPanelPosToPlotItem (w, panel); 		
			GRAPH_resizePanel (w);
			break;
		case EVENT_GOT_FOCUS:
			w = GRAPH_getWindowFromPanelHandle (panel, 0);   
			if (w != NULL) {
				GetIndexFromValue (panelCurves, CURVES_TREE, &index, (unsigned)w);
				if (index >=0) SetActiveTreeItem (panelCurves, CURVES_TREE, index , VAL_REPLACE_SELECTION_WITH_ITEM);
			}			
			break;
		case EVENT_RIGHT_CLICK:
		case EVENT_LEFT_CLICK:
			if (RUN_inactive()) {
				DisplayPanel (panelCurves);
				SetActivePanel (panel);
			}
			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			GRAPH_closePanel (panel);
/*			w = GRAPH_getWindowFromPanelHandle (panel, &index);   
			w->visible = 0;
			GRAPH_setWindowParameters (w, NULL);
			SetTreeItemAttribute (panelCurves, CURVES_TREE, index, ATTR_COLLAPSED, 1);
			SetTreeItemAttribute (panelCurves, CURVES_TREE, index, ATTR_MARK_STATE, w->visible);
			return 1;*/
			break;
		case EVENT_KEYPRESS:
			switch (eventData1) {
				case ('A' + VAL_MENUKEY_MODIFIER):
					w = GRAPH_getWindowFromPanelHandle(panel, NULL);
					GRAPH_autoScale (w);
					GRAPH_setWindowParameters (w, NULL);
					return 1;
				case ('M' + VAL_MENUKEY_MODIFIER):
//					CallCtrlCallback (,RUN_BTN_startAveraging, EVENT_COMMIT, 0,
//									  0, 0);
					return 1;
				case VAL_ESC_VKEY:
					if ((RUN_getState() == RUN_STATE_ACTIVE) || 
					   (RUN_getState() == RUN_STATE_PAUSED))
						RUN_stop ();
					return 1;
				case VAL_F9_VKEY:
					if (RUN_getState () == RUN_STATE_INACTIVE)  
						RUN_start (activeSession());
					return 1;

			}
			break;
			
	}
	return 0;
}





void GRAPH_autoScale (t_graph *w)
{
	if (w == NULL) return;
	GRAPH_getMinMaxAllCurves (w);
	if (w->yFromAutoscale) w->yFrom = makeNiceNumber(w->minYValue, -2, 2);
	if (w->yToAutoscale)   w->yTo   = makeNiceNumber(w->maxYValue, 2, 2);
	if (w->xFromAutoscale) w->xFrom = w->minXValue;
	if (w->xToAutoscale)   w->xTo   = w->maxXValue;
	if (w->xFromAutoscale && w->xToAutoscale && (w->xFrom == w->xTo)) {
		w->xFrom = w->minXValue * 0.8;
		w->xTo = w->minXValue * 1.2;
	}
	
}


int CVICALLBACK GRAPH_BUTTON_autoScale (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_graph *w;


	
	switch (event) {
		case EVENT_COMMIT:
			w = GRAPH_getWindowFromPanelHandle(panel, NULL);
			GRAPH_autoScale (w);
			GRAPH_setWindowParameters (w, NULL);
			break;
	}
	return 0;
}



/*
int CVICALLBACK GRAPH_changeGraphSize (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_graph *w;
	
	switch (event) {
		case EVENT_COMMIT:
			w = GRAPH_getWindowFromPanelHandle(panel, NULL);
			w->graphFullSize = (control == GRAPH_BTN_graphFull);
			GRAPH_resizeWindow (w);
			break;
	}
	return 0;
}
*/

void GRAPH_createXValues (t_curve *c, double start, double stop)
{
	int i;
	
	free (c->xValues);
	if (c->nValues == 0) {
		c->xValues = NULL;
		return;
	}
	c->xValues = (double *) malloc (sizeof(double) * c->nValues);
	if (c->nValues == 1) c->xValues[1] = start;
	else {
		for (i = 0; i < c->nValues; i++) {
			c->xValues[i] = start + i * (stop - start) / (c->nValues-1);
		}
	}
}



void simulate_DIG (t_graph *w)
{
	
}

/*
t_curve *testcurve (t_graph *w)
{
	t_curve *c2;
	int i;
	
	c2 = CURVE_new (w);
	c2->nValues = 200;		   	
	strcpy (c2->name, "DATA");
	GRAPH_createXValues (c2, w->xFrom, w->xTo);
	
	c2->yValues = (double *) malloc (sizeof(double) * c2->nValues);
	for (i = 0; i < c2->nValues; i++) {
		c2->yValues[i] = sin ((w->xTo - w->xFrom) * i / c2->nValues) + Random (-0.1, 0.1);
	}
	
	return c2;

}


void GRAPH_testSine (t_graph *w)
{	
	t_curve *c, *c2;
	int i;
	
	c = CURVE_new (w);
	c->nValues = 101;
	strcpy (c->name, "TEST01");
	
	w->xFrom = 0;
	w->xTo   = 8;
	w->yFrom = -2;
	w->yTo   = 2;
	strcpy (w->xLabel, "rad");
	strcpy (w->yLabel, "Volts");
	GRAPH_createXValues (c, w->xFrom, w->xTo);
	c->yValues = (double *) malloc (sizeof(double) * c->nValues);
	for (i = 0; i < c->nValues; i++) {
		c->yValues[i] = sin ((w->xTo - w->xFrom) * i / c->nValues);
	}
	c2 = testcurve (w);
	GRAPH_setWindowParameters (w, NULL);
	CURVE_display (w, c);
	
	CURVE_display (w, c2);
	CURVE_display (w, c2);
}



void GRAPH_testTransfer (t_graph *w)
{	
	t_curve *c, *c2;
	int i;
	
	c = CURVE_new (w);
	c->nValues = 15;
	strcpy (c->name, "TEST_TRANSFER");
	
	w->xFrom = 0;
	w->xTo   = 8;
	w->yFrom = 0;
	w->yTo   = 2;
	c->plotStyle = VAL_VERTICAL_BAR;
//	c->lineStyle = Plot
	
	strcpy (w->xLabel, "freq");
	strcpy (w->yLabel, "nAtoms");
	GRAPH_createXValues (c, w->xFrom, w->xTo);
	c->yValues = (double *) malloc (sizeof(double) * c->nValues);
	c->yErrPos = (double *) malloc (sizeof(double) * c->nValues);
	for (i = 0; i < c->nValues; i++) {
		c->yValues[i] = fabs (sin ((w->xTo - w->xFrom) * i / c->nValues)) + 0.2;
		c->yErrPos[i] = 0.1;
	}
//	c2 = testcurve (w);
	GRAPH_setWindowParameters (w, NULL);
	CURVE_display (w, c);
//	CURVE_display (w, c2);
//	CURVE_display (w, c2);
}


void GRAPH_test (t_graph *w)
{
//	GRAPH_testSine (w);
	GRAPH_testTransfer (w);
}
*/



void GRAPH_setAllCurvesNotActive (void)
{
	t_curve *c;
	int nItems, level;
	int i;

	if (panelCurves <= 0) return;
	GetNumListItems (panelCurves, CURVES_TREE, &nItems);
	for (i = 0; i < nItems; i++) {
		GetTreeItemLevel (panelCurves, CURVES_TREE, i, &level);
		if (level == TREELEVEL_CURVES) {
			c = CURVE_getFromIndex (i);
			if (c != NULL) {
				c->active = 0;
				SetTreeCellAttribute (panelCurves, CURVES_TREE,
						  i, CURVES_COL_NAME,
						  ATTR_LABEL_BOLD, c->active);
			}
		}
	}
}	
			


t_graph *GRAPH_getFromCurve (t_curve *c)
{
	int curveItem = -1;
	int graphItem = -1;

	if (c == NULL) return NULL;
	GetIndexFromValue (panelCurves, CURVES_TREE, &curveItem, (unsigned) c);
	GetTreeItem (panelCurves, CURVES_TREE, VAL_ANCESTOR, curveItem,
				 VAL_FIRST, VAL_NEXT_PLUS_SELF, 0, &graphItem);
	return GRAPH_getFromIndex (graphItem);
			
}



int CVICALLBACK GRAPH_graphCallback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	//DebugPrintf ("%s\n",eventStr (event, eventData1, eventData2));
	t_graph *w;
	
	switch (event) {
		case EVENT_VAL_CHANGED:
			w = GRAPH_getWindowFromPanelHandle (panel, 0);
			CURSORS_displayCoordinates (w);
			break;
		case EVENT_RIGHT_CLICK:
			GRAPH_runPopupMenu (panel, eventData1, eventData2);
			break;
		}
	return 0;
}





t_curve *GRAPH_firstCurve (t_graph *g)
{
	
	t_curve *c;
	int graphItem;
	int item;

	if (g == NULL) return NULL;
	
	CURVE_getTreeItemNr (g, NULL, &graphItem, 0,0,0);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	c = CURVE_getFromIndex (item);
	return c;
}


t_curve *GRAPH_nextCurve (t_curve *start, t_graph *g)
{
	t_curve *c;
	int graphItem;
	int item;

	if (g == NULL) return NULL;
	if (start == NULL) return NULL;
	
	CURVE_getTreeItemNr (g, start, &graphItem, &item, 0,0);
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
 				 item, VAL_NEXT, 0, &item);
	c = CURVE_getFromIndex (item);
	return c;
	
}





void CVICALLBACK CURVES_MENUBAR_exportCurve (int menuBar, int menuItem, void *callbackData,
		int panel)
{
    char filename[MAX_PATHNAME_LEN];
    char defaultFilename[MAX_PATHNAME_LEN];
    t_graph *w;
    t_curve *c;

	GRAPH_getSelectionFromTree (&w, &c, 0, 0, 0);		
	if ((c == NULL) || (w == NULL)) return;

	sprintf (defaultFilename, "%04d%s%s", c->startNr, c->name, suffixCurveTxt+1);
    if (FileSelectPopup (smanagerConfig->dataPathToday,
						 defaultFilename, suffixCurveTxt, "Export curve",
						 VAL_SAVE_BUTTON, 0, 0, 1, 1, filename) > 0) {
		strcpy (smanagerConfig->dataPathToday, extractDir (filename));
		CURVE_saveTxt (filenameCharCheck (filename), c, w);
	}
}


void CVICALLBACK CURVES_MENUBAR_import (int menuBar, int menuItem, void *callbackData,
		int panel)
{
    char filename[MAX_PATHNAME_LEN];
    t_graph *w;
    t_curve *c;
    
	GRAPH_getSelectionFromTree (&w, &c, 0,0,0);		
	if  (w == NULL) return;

    if (FileSelectPopup (smanagerConfig->dataPathToday,
						 suffixCurveTxt, suffixCurveTxt,
						 "Import curve", VAL_LOAD_BUTTON, 0, 0, 1, 0,
						 filename) > 0) {
		strcpy (smanagerConfig->dataPathToday, extractDir (filename));
        if (CURVE_loadTxt (filename, &c) == 0) {
        	CURVE_display (w, c, 1, 1, 1);
        }
    }
}


t_curve *CURVE_loadAndDisplay (const char *filename)
{
    t_curve *c;
    t_graph *g;
    int firstCurve;

    c = CURVE_load (filename);
    if (c != NULL) {
    	c->keep = 1;
		if (c->title[0] == 0) strcpy (c->title, "???");
		g = GRAPH_getFromTitle (c->title, c->plotType);
		firstCurve = (g == NULL);
		GRAPH_autoScale (g);
    	CURVE_display (NULL, c, 1, 1, 1);
    	g = GRAPH_getFromCurve (c);
		if (firstCurve) {
			GRAPH_positionPanel (g, c->panelPos);
			if (g->visible) GRAPH_applyWindowParametersToGraph (g);
			DisplayPanel (g->panelHandle);
		}
    	if ((c->values2D != NULL) && c->visible2D) CURVE2D_displayCurve (c, c->panelPos2D);
    	CURVE_displayTreeItem (g, c, 1);
   	    return c;
    }
    else return NULL;

}

void CVICALLBACK CURVES_MENUBAR_loadCurve (int menuBar, int menuItem, void *callbackData,
		int panel)
{
    char filename[MAX_PATHNAME_LEN];
    
    if (FileSelectPopup (smanagerConfig->dataPathToday, suffixCurve, suffixCurve,
						 "Load curve", VAL_LOAD_BUTTON, 0, 1, 1, 0,
						 filename) > 0) {
		strcpy (smanagerConfig->dataPathToday, extractDir (filename));
		CURVE_loadAndDisplay (filename);
    }
}






void CVICALLBACK CURVES_MENUBAR_saveCurve (int menuBar, int menuItem, void *callbackData,
		int panel)
{
    char filename[MAX_PATHNAME_LEN];
    char defaultFilename[MAX_PATHNAME_LEN];
    t_graph *w;
    t_curve *c;

	GRAPH_getSelectionFromTree (&w, &c, 0,0,0);		
	if ((c == NULL) || (w == NULL)) return;
	
    strcpy (defaultFilename, c->name);
    strcat (defaultFilename, suffixCurve+1);
    if (FileSelectPopup (smanagerConfig->dataPathToday, defaultFilename, suffixCurve,
						 "Save curve", VAL_SAVE_BUTTON, 0, 0, 1, 1,
						 filename) > 0) {
		strcpy (smanagerConfig->dataPathToday, extractDir (filename));

		CURVE_save (filenameCharCheck (filename), c, w);
	}
}


void CVICALLBACK CURVES_MENUBAR_startRun (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	CallCtrlCallback (panelSMain, SMAN_BUTTON_start,
					  EVENT_COMMIT, 0, 0, 0);
}


void CVICALLBACK CURVES_MENUBAR_removeAllWindows (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	if (ConfirmPopup ("Remove all windows",  "Do you really want to remove all graph windows\nand delete all curves?")) {
		GRAPH_discardAll ();				
	}
	
}






void CURVES_displayPanel (void)
{
//	DisplayPanel (panelCurves);
	SetActivePanel (panelCurves);
}

int CURVES_panelHandle (void)
{
	return panelCurves;
}



void CURVES_hidePanel (void)
{
	HidePanel (panelCurves);
}





void CURVES_initPanel (int parentPanel)
{
	Rect bounds;
	int panelMenu = -1;
	int subMenu;
	int i;

	if (panelCurves == -1) {
		panelCurves  = LoadPanel (parentPanel, SESSIONMANAGER_uirFile, CURVES);

		EasyTab_ConvertFromCanvas (panelCurves, CURVES_CANVAS);
		EasyTab_LoadPanels (panelCurves, CURVES_CANVAS, 1, 
							SESSIONMANAGER_uirFile, __CVIUserHInst,
							AXIS, &panelAxis, 
							CURSORS, &panelCursors,
							STATISTICS, &panelStatistics, 0);
		
		SetCtrlAttribute (panelCursors, CURSORS_NUMERIC_cursorX1,
						  ATTR_FRAME_COLOR, COLOR_CURSOR1);
		SetCtrlAttribute (panelCursors, CURSORS_NUMERIC_cursorY1,
						  ATTR_FRAME_COLOR, COLOR_CURSOR1);
		SetCtrlAttribute (panelCursors, CURSORS_NUMERIC_cursorX2,
						  ATTR_FRAME_COLOR, COLOR_CURSOR2);
		SetCtrlAttribute (panelCursors, CURSORS_NUMERIC_cursorY2,
						  ATTR_FRAME_COLOR, COLOR_CURSOR2);
						  
		// resize panel to show all;
		EasyTab_GetBounds (panelCurves, CURVES_CANVAS,
						   VAL_EASY_TAB_EXTERIOR_BOUNDS, &bounds);
		SetPanelAttribute (panelCurves, ATTR_HEIGHT, bounds.top + bounds.height + 10);
//		SetPanelSize (panelCurves, bounds.top + bounds.height + 10,
//					  700);
		panelMenu = LoadPanel (0, SESSIONMANAGER_uirFile, MENUCURVES);      
		menuCurves = GetPanelMenuBar (panelMenu);
		panelMenu = LoadPanel (0, SESSIONMANAGER_uirFile, MENUCURVE2);      
		menuCurves2 = GetPanelMenuBar (panelMenu);
		// add colors to menu
		subMenu = NewSubMenu (menuCurves, MCURVES_TREE_COLOR);
		for (i = 0; i < N_CURVE_COLORS; i++) {
			 MENUCURVES_colorItems[i] = NewMenuItem (menuCurves, subMenu, CURVE_colorNames[i], -1, 0, 0, 0);
		}

		// add plot styles to menu
		subMenu = NewSubMenu (menuCurves, MCURVES_TREE_STYLE);
		for (i = 0; i < N_CURVE_STYLES; i++) {
			 MENUCURVES_styleItems[i] = NewMenuItem (menuCurves, subMenu, CURVE_styleNames[i], -1, 0, 0, 0);
		}

		panelMenu = LoadPanel (0, SESSIONMANAGER_uirFile, MENUGRAPH);      
		menuGraph = GetPanelMenuBar (panelMenu);
		SetCtrlAttribute (panelCurves, CURVES_TREE,
						  ATTR_ENABLE_POPUP_MENU, 0);
		panelMenu = LoadPanel (0, SESSIONMANAGER_uirFile, MENUGRA2D);      
		menuGraph2D = GetPanelMenuBar (panelMenu);
		
		
		// panel "Curves"
		CURVES_initTree ();
		CURVES_resizePanel ();
		SetPanelPos (panelCurves, 500, 20);

		// Set Print Attributes
		SetPrintAttribute (ATTR_PRINT_AREA_WIDTH, 1600);
		SetPrintAttribute (ATTR_ORIENTATION, VAL_PORTRAIT);
		SetCtrlAttribute (panelCurves, CURVES_STRING_window, ATTR_WIDTH,
						    ctrlLeft (panelCurves, CURVES_TREE)
						  - ctrlLeft (panelCurves, CURVES_STRING_window));
		SetCtrlAttribute (panelCurves, CURVES_STRING_curve, ATTR_WIDTH,
						    ctrlLeft (panelCurves, CURVES_TREE)
						  - ctrlLeft (panelCurves, CURVES_STRING_curve));
						  
		for (i = 0; i < N_CUSTOM_EVALUATIONPANELS; i++) {
			panelCustomEvaluation[i] = 0;	
		}
		
//		DisplayPanel (panelCurves);
	}
}





int CVICALLBACK CURVES_panelCallback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_GOT_FOCUS:
		case EVENT_PANEL_MOVE:
//			DisplayPanel (panel);
			break;
		case EVENT_LOST_FOCUS:
			break;
		case EVENT_CLOSE:
			break;
		case EVENT_PANEL_SIZE:
			CURVES_resizePanel ();
			break;
	}
	return 0;
}



int CURVES_runTreePopupMenu2 (t_graph *w, int top, int left)
{
	int choice;
	int hasActiveCurve;
	
	hasActiveCurve = GRAPH_hasActiveCurve (w);
	SetMenuBarAttribute (menuCurves2, MCURVES2_TREE_DELETE_ALL_CURVES, ATTR_DIMMED, 0);
	SetMenuBarAttribute (menuCurves2, MCURVES2_TREE_REMOVE_WINDOW, ATTR_DIMMED, hasActiveCurve);
	
	choice = RunPopupMenu (menuCurves2, MCURVES_TREE, panelCurves,
						   top, left, 0, 0, 0, 0);
//			choice = RunPopupMenu (menuCurves, menuCurves_Items[MENU_CURVES],
//								   panel, eventData1, eventData2, 0, 0, 0, 0);
//			choice = arrayFind (menuCurves_Items, N_ITEMS_MENU_CURVES, choice);
	switch (choice) {
		case MCURVES2_TREE_REMOVE_WINDOW:
			if (ConfirmPopupf ("Remove window",  "Do you really want to remove window '%s' and delete all curves?", w->panelTitle) == 1) {
				GRAPH_discard (&w);				
			}
			break;
		case MCURVES2_TREE_DELETE_ALL_CURVES:
			if (ConfirmPopupf ("Delete curves",  "Do you really want to delete all curves from window '%s'?", w->panelTitle) == 1) {
				GRAPH_deleteAllNonActiveCurves (w);
			}
			break;
	}
	return 1;

}




void CURVES_deleteSelectedCurves (int askBefore) 
{
	int item;
	int level;
	int nSelected;
	int selected;
	t_curve *c = NULL;
	t_graph *g;
	int oldItem;
	
	
	// get number of selected items
	if (askBefore) {
		item = VAL_FIRST;
		nSelected = 0;
		GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
					 VAL_NEXT_PLUS_SELF, 0, &item);
		while (item >= 0) {
			GetTreeItemLevel (panelCurves, CURVES_TREE, item, &level);
			if (level == TREELEVEL_CURVES) {
				GetTreeItemAttribute (panelCurves, CURVES_TREE, item,
									  ATTR_SELECTED, &selected);
				if (selected) nSelected++;
			}	
			GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
						 VAL_NEXT, 0, &item);
		}
		if (nSelected == 0) return;
		if (!ConfirmPopupf ("Delete Curves", 
					       "Do you really want do delete\n%d selected curve%s?",
					       nSelected, nSelected == 1 ? "" : "s")) return;
	}

	item = VAL_LAST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
				 VAL_PREV_PLUS_SELF, 0, &item);
	while (item >= 0) {
		GetTreeItemLevel (panelCurves, CURVES_TREE, item, &level);
		GetTreeItemAttribute (panelCurves, CURVES_TREE, item,
							  ATTR_SELECTED, &selected);
		oldItem = item;
		if (selected) {
			if (level == TREELEVEL_CURVES) {
			    c = CURVE_getFromIndex (item);
				GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
							 VAL_PREV, 0, &item);
			    CURVE_delete (NULL, c);
			}
			if (level == TREELEVEL_PLOTWINDOWS) {
				g = GRAPH_getFromIndex (item);
				GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
							 VAL_PREV, 0, &item);
				GRAPH_discard (&g);				
			}
		}	
		if (item == oldItem) 
			GetTreeItem (panelCurves, CURVES_TREE, VAL_ALL, 0, item,
	  	 			     VAL_PREV, 0, &item);
	}
}



int CURVES_runTreePopupMenu (t_graph *w, t_curve *c, int top, int left)
{
	char *help;
	int choice;
	int i;
	
	SetMenuBarAttribute (menuCurves, MCURVES_TREE, ATTR_CHECKED, 0);
	SetMenuBarAttribute (menuCurves, MCURVES_TREE_KEEP, ATTR_CHECKED, c->keep);
	SetMenuBarAttribute (menuCurves, MCURVES_TREE_RENAME, ATTR_DIMMED, c->active);
	SetMenuBarAttribute (menuCurves, MCURVES_TREE_DELETE, ATTR_DIMMED, c->active);
//	SetMenuBarAttribute (menuCurves, MCURVES_TREE_COLORS, ATTR_DIMMED, c->active);

	for (i = 0; i < N_CURVE_COLORS; i++) {
		SetMenuBarAttribute (menuCurves, MENUCURVES_colorItems[i], 
							 ATTR_CHECKED, c->plotColor == CURVE_colors[i]);
	}
	for (i = 0; i < N_CURVE_STYLES; i++) {
		SetMenuBarAttribute (menuCurves, MENUCURVES_styleItems[i], 
							 ATTR_CHECKED, c->plotStyle == CURVE_styles[i]);
	}

						
	choice = RunPopupMenu (menuCurves, MCURVES_TREE, panelCurves,
						   top, left, 0, 0, 0, 0);
//			choice = RunPopupMenu (menuCurves, menuCurves_Items[MENU_CURVES],
//								   panel, eventData1, eventData2, 0, 0, 0, 0);
//			choice = arrayFind (menuCurves_Items, N_ITEMS_MENU_CURVES, choice);
	switch (choice) {
		case MCURVES_TREE_KEEP:
			c->keep = !c->keep;
			
			break;
		
		case MCURVES_TREE_RENAME:
			if (c->active) return 1;
			if (panelRenameCurve == -1) {
				panelRenameCurve =  LoadPanel (0, SESSIONMANAGER_uirFile, RENAME_CUR);
				SetCtrlAttribute (panelRenameCurve, RENAME_CUR_STRING_name,
								  ATTR_MAX_ENTRY_LENGTH, MAX_CURVENAME_LEN-1);
			}
			help = getTmpString();
			sprintf (help, "'%s':", c->name);
			SetCtrlVal (panelRenameCurve, RENAME_CUR_TEXTMSG_name, help);
			SetCtrlVal (panelRenameCurve, RENAME_CUR_STRING_name, c->name);
			SetCtrlAttribute (panelRenameCurve,
							  RENAME_CUR_COMMANDBUTTON_close,
							  ATTR_CALLBACK_DATA, (void *) c);
			InstallPopup (panelRenameCurve);
			CallCtrlCallback (panelRenameCurve, RENAME_CUR_STRING_name,
							  EVENT_LEFT_DOUBLE_CLICK, 0, 0, 0);
			break;
/*		case MCURVES_TREE_DELETE:
			if (c->active) return 1;
			if (ConfirmPopupf ("Delete curves",  "Do you really want to delete curve '%s'?", c->name) == 1) {
				CURVE_delete (w, c);
				GRAPH_displayAllCurves (w);
			}
			break;*/
		case MCURVES_TREE_DELETE:
			if (c->active) return 1;
			CURVES_deleteSelectedCurves (1);
			GRAPH_displayAllCurves (w, 0, 1);
			return 0;
			break;
		default:
			for (i = 0; i < N_CURVE_COLORS; i++) {
				if (choice == MENUCURVES_colorItems[i]) {
					c->plotColor = CURVE_colors[i];
					CURVE_removePlot (w, c, 1);
					CURVE_display (w, c, 1, 0, 1); 
					return 1;
				}
			}
			// plot style changed
			for (i = 0; i < N_CURVE_STYLES; i++) {
				if (choice == MENUCURVES_styleItems[i]) {
					c->plotStyle = CURVE_styles[i];
					if (c->plotStyle == VAL_SCATTER) c->pointStyle = VAL_SOLID_DIAMOND;
					CURVE_removePlot (w, c, 1);
					CURVE_display (w, c, 1, 0, 1); 
					return 1;
				}
			}
	}
	return 1;

}


int CVICALLBACK CURVES_callback_Tree (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_graph *w;


	int checked;
	int clicked2D;
	int clickedCurrent;
	t_curve *c;

	
//	DebugPrintf ("%s\n",eventStr (event, eventData1, eventData2));
	switch (event)
		{
		case EVENT_MARK_STATE_CHANGE:
		case EVENT_COMMIT:
			if (GRAPH_getSelectionFromTree (&w, &c, &checked, &clicked2D, &clickedCurrent) >= 0) {
				if (clickedCurrent) {
					// current curved clicked
					if (c == NULL) return 0;
					c->showCurrentCurve = checked;
					CURVE2D_displayPanel (c);
					CURVE_display (w, c, 1, 0, 1);
					GRAPH_setWindowParameters (w, c);
  					RefreshGraph (w->panelHandle, GRAPH_GRAPH);
  					return 0;
				}
				else if (clicked2D) {
					// 2D curved clicked
					if (c == NULL) return 0;
					if (c->visible2D == checked) return 0;
					c->visible2D = checked;
					CURVE2D_displayPanel (c);
					GRAPH_setWindowParameters (w, c);
  					RefreshGraph (w->panelHandle, GRAPH_GRAPH);
  					return 0;
				}
				else if (c != NULL) {
					// normal curve clicked
//					GRAPH_setWindowParameters (w, c);
					if (c->visible == checked) return 0;
					c->visible = checked;
					if (!c->visible) CURVE_removePlot (w, c, 1);
					if (c->visible) w->visible = 1;
					GRAPH_autoScale (w);
					CURVE2D_displayPanel (c);
					GRAPH_setWindowParameters (w, c);
					CURVE_display (w, c, 0, 0, 1);
 					RefreshGraph (w->panelHandle, GRAPH_GRAPH);
  					return 0;
				}
				else if (w != NULL) {
     				// plot window item clicked
     				w->visible = checked;
					GRAPH_setWindowParameters (w, NULL);
  					RefreshGraph (w->panelHandle, GRAPH_GRAPH);
  					return 0;
     			}
     		}
     		if (w == NULL) return 1;
			return 0;
			break;
		case EVENT_RIGHT_CLICK:	
			GRAPH_getSelectionFromTree (&w, &c, &checked, 0,0);
			if (c == 0) return CURVES_runTreePopupMenu2 (w, eventData1, eventData2);
			return CURVES_runTreePopupMenu (w, c, eventData1, eventData2);
			break;
		}
	return 0;
}



int CVICALLBACK CURVES_callback_Close (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			HidePanel (panelCurves);
			break;
	}
	return 0;
}


int CVICALLBACK RENAMECURVES_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_curve *c;
	t_graph *g;
	
	switch (event) {
		case EVENT_COMMIT:
			c = (t_curve *) callbackData;
			if (c != NULL) GetCtrlVal (panelRenameCurve, RENAME_CUR_STRING_name, c->name);
			RemovePopup (0);
			g = GRAPH_getFromCurve (c);
			CURVE_displayTreeItem (g, c, 0);
			if (c->panel2DPlot > 0) SetPanelAttribute (c->panel2DPlot, ATTR_TITLE, c->name);
			break;
	}
	return 0;
}



void CURVE2D_resizePanel (int panel)
{
	SetCtrlAttribute (panel, CURVE2D_GRAPH, ATTR_WIDTH, panelWidth(panel));	
	SetCtrlAttribute (panel, CURVE2D_GRAPH, ATTR_HEIGHT, panelHeight(panel));	
	
	SetCtrlAttribute (panel, CURVE2D_RADIOBUTTON_showParts, ATTR_TOP, 
					  panelHeight(panel) - 20);
	SetCtrlAttribute (panel, CURVE2D_RADIOBUTTON_showParts, ATTR_LEFT, 
					  panelWidth(panel) - 10 
					  - ctrlWidth (panel, CURVE2D_RADIOBUTTON_showParts)
					  - ctrlLabelWidth (panel, CURVE2D_RADIOBUTTON_showParts));
	SetCtrlAttribute (panel, CURVE2D_BUTTON_interpolate2D, ATTR_TOP, 
					  panelHeight(panel) - 20);
}



void CURVE2D_initPanel (t_curve *c, Rect pos)
{
	int height, width;
	char titleStr[200];
	
	if (c->nValues2D == 0) return;
	if (c->panel2DPlot == -1) {	
		c->panel2DPlot = LoadPanel (0, SESSIONMANAGER_uirFile, CURVE2D);
		SetGraphCursor (c->panel2DPlot, CURVE2D_GRAPH, 1, 0, 0);
		if (pos.width < 0) {
			SetPanelPos (c->panel2DPlot, panelTop (c->panelGraph)+30, panelRight (c->panelGraph)-20);
			height = panelHeight (c->panelGraph) - 60;
			if (height < 100) height = 100;
			width = panelWidth (c->panelGraph)-60;;
			if (width < 100) width = 100;
			SetPanelSize (c->panel2DPlot,  height, width);
			
		}
		else {
			SetPanelPos (c->panel2DPlot, pos.top, pos.left);
			SetPanelSize (c->panel2DPlot, pos.height, pos.width);
		}
		
		CURVE2D_resizePanel(c->panel2DPlot);
		sprintf (titleStr, "%04d %s - %s", c->startNr,
				 c->name, panelTitleStr (c->panelGraph));
		SetPanelAttribute (c->panel2DPlot, ATTR_TITLE, titleStr);
		SetCtrlAttribute (c->panel2DPlot, CURVE2D_GRAPH, ATTR_REFRESH_GRAPH, 0);

//		DisplayPanel (c->panel2DPlot);
	}
}


void CURVE2D_displayPanel (t_curve *c)
{
	int visible;
	
	if (c->panel2DPlot > 0) {
		GetPanelAttribute (c->panel2DPlot, ATTR_VISIBLE, &visible);
		if (visible != c->visible2D) SetPanelAttribute (c->panel2DPlot, ATTR_VISIBLE, c->visible2D);
		if (c->panelPos2D.width >= 0) setPanelBounds (c->panel2DPlot, c->panelPos2D);
		SetCtrlAttribute (c->panel2DPlot,
						  CURVE2D_RADIOBUTTON_showParts, ATTR_VISIBLE, c->nComponentsPositions > 0);
		SetCtrlVal (c->panel2DPlot, CURVE2D_RADIOBUTTON_showParts, c->componentsVisible);
		SetCtrlVal (c->panel2DPlot, CURVE2D_BUTTON_interpolate2D, c->interpolate2D);
	}
}


void CURVE2D_displayCurve (t_curve *c, Rect panelPos)
//this is the old version
{
	int i;
	int red, blue, green;
	int loCol = 16777215;
    int hiCol = 0;

	unsigned char loRed = ((loCol & 0x00FF0000) >> 16);
	unsigned char hiRed = ((hiCol & 0x00FF0000) >> 16);
	unsigned char loGreen = ((loCol & 0x0000FF00) >> 8);
	unsigned char hiGreen = ((hiCol & 0x0000FF00) >> 8);
	unsigned char loBlue = (loCol & 0x000000FF);
	unsigned char hiBlue = (hiCol & 0x000000FF);

	double minVal = DBL_MAX;
	double maxVal = -DBL_MAX;

	double xFrom2D;
	double xTo2D;
	double yFrom2D;
	double yTo2D;
	double xGain, yGain;
	
	double curX, curY;
	int lineHandle, textHandle;

	if (c->nValues2D == 0) return;
	if (c->values2D == NULL) return;
	
	for (i = 0; i < c->nValues2D; i++) {
		if (c->values2D[i] > maxVal) maxVal = c->values2D[i];
		if (c->values2D[i] < minVal) minVal = c->values2D[i];
	}
	
	maxVal = makeNiceNumber (maxVal, 2, 2);
//	minVal = makeNiceNumber (minVal, -2, 2);
	minVal = 0;
	// ------------------------------------------
	//    calculate colors 
	// -----------------------------------------
	if (c->colors2D == NULL) {
		c->nColors2D = 256;
		c->colors2D = (ColorMapEntry *) malloc (sizeof (ColorMapEntry) * c->nColors2D);
	}
	for (i = 0; i < c->nColors2D; i++) {
	    red =   loRed   + i * (hiRed - loRed) / (c->nColors2D-1);
	    green = loGreen + i * (hiGreen - loGreen) / (c->nColors2D-1);
	    blue =  loBlue  + i * (hiBlue - loBlue) / (c->nColors2D-1);
	    (c->colors2D[i]).color = MakeColor ((int)red, (int)green, (int)blue);
	    (c->colors2D[i]).dataValue.valDouble = minVal + (i + 1) * (maxVal - minVal) / (c->nColors2D);
	}
	
	// ------------------------------------------
	//    plot image
	// -----------------------------------------
	CURVE2D_initPanel (c, panelPos);
	DeleteGraphPlot (c->panel2DPlot, CURVE2D_GRAPH, -1, VAL_DELAYED_DRAW);
/*	PlotIntensity (panel, control, image->pixel, image->xDim,
				   image->yDim, VAL_INTEGER, colors, VAL_DK_GREEN,
				   MAXCOLORS-1, 0, 0);
*/	

	xFrom2D = c->xValues2D[0];
	xTo2D   = c->xValues2D[c->n2Dcurves-1];
	yFrom2D = c->xValues[0];
	yTo2D   = c->xValues[c->nValues-1];
	
	// RIGHT y axis
	SetCtrlAttribute (c->panel2DPlot, CURVE2D_GRAPH,
					  ATTR_ACTIVE_YAXIS, VAL_RIGHT_YAXIS);
	SetCtrlAttribute (c->panel2DPlot, CURVE2D_GRAPH,
					  ATTR_YLABEL_VISIBLE, c->xShowSecondAxis);
	if (c->xShowSecondAxis) {
		SetCtrlAttribute (c->panel2DPlot, CURVE2D_GRAPH,
						  ATTR_YNAME, concatLabelAndUnits(c->xLabel2, c->xUnits2));
		SetAxisScalingMode (c->panel2DPlot, CURVE2D_GRAPH, VAL_RIGHT_YAXIS, VAL_MANUAL, 
							yFrom2D*c->xAxis2Multiply, yTo2D*c->xAxis2Multiply);
	}

	// LEFT y axis
	
	SetCtrlAttribute (c->panel2DPlot, CURVE2D_GRAPH,
					  ATTR_ACTIVE_YAXIS, VAL_LEFT_YAXIS);
	SetAxisScalingMode (c->panel2DPlot, CURVE2D_GRAPH,
						VAL_LEFT_YAXIS, VAL_MANUAL, yFrom2D,
						yTo2D);

	
	SetAxisScalingMode (c->panel2DPlot, CURVE2D_GRAPH,
						VAL_BOTTOM_XAXIS, VAL_MANUAL, xFrom2D,
						xTo2D);
	SetCtrlAttribute (c->panel2DPlot, CURVE2D_GRAPH,
					  ATTR_XNAME, concatLabelAndUnits(c->xLabel2D, c->xUnits2D));
	SetCtrlAttribute (c->panel2DPlot, CURVE2D_GRAPH,
					  ATTR_YNAME, concatLabelAndUnits(c->xLabel, c->xUnits));
	
	if (c->nValues <= 0) goto ENDPLOT;
	if (c->n2Dcurves <= 1) goto ENDPLOT;
	yGain = (yTo2D - yFrom2D) / (c->nValues-1);
	xGain = (xTo2D - xFrom2D) / (c->n2Dcurves-1);
	c->plotHandle2D = PlotScaledIntensity (c->panel2DPlot,
										   CURVE2D_GRAPH,
										   c->values2D,
										   c->n2Dcurves,
										   c->nValues, VAL_DOUBLE,
										   yGain, yFrom2D, xGain,
										   xFrom2D, c->colors2D,
										   hiCol, c->nColors2D-1,
										   0, c->interpolate2D);
	GetGraphCursor (c->panel2DPlot, CURVE2D_GRAPH, 1, &curX, &curY);
	SetGraphCursor (c->panel2DPlot, CURVE2D_GRAPH, 1, c->xValues2D[c->activeCurve2D], curY);
//	RefreshGraph (c->panel2DPlot, CURVE2D_GRAPH);
//	CURVE2D_displayPanel (c);
	
	if (c->componentsVisible) {
		for (i = 0; i < c->nComponentsPositions; i++) {
			lineHandle = PlotLine (c->panel2DPlot, CURVE2D_GRAPH, 
					  xFrom2D, c->componentsPositions[i], 
					  xTo2D+10, c->componentsPositions[i], c->componentsColors[i] & VAL_TRANSPARENT);
			SetPlotAttribute (c->panel2DPlot, CURVE2D_GRAPH, lineHandle,
							  ATTR_PLOT_LG_VISIBLE, 0);
			SetPlotAttribute (c->panel2DPlot, CURVE2D_GRAPH, lineHandle, ATTR_LINE_STYLE, VAL_DASH_DOT_DOT);
			if (c->componentsNames[i][0] != 0) {
				textHandle = PlotText (c->panel2DPlot, CURVE2D_GRAPH, xFrom2D + (xTo2D-xFrom2D)/40,
						  c->componentsPositions[i], c->componentsNames[i], 
						  VAL_APP_META_FONT, c->componentsColors[i], VAL_TRANSPARENT);
				SetPlotAttribute (c->panel2DPlot, CURVE2D_GRAPH, textHandle,
								  ATTR_PLOT_LG_VISIBLE, 0);
						  
			}
		}
	}
ENDPLOT:
	RefreshGraph (c->panel2DPlot, CURVE2D_GRAPH);
	CURVE2D_displayPanel (c);
	if (c->panelPos2D.width == -1) c->panelPos2D = getPanelBounds (c->panel2DPlot);

}



void CURVE2D_getPanelBounds (int panel)
{
	t_curve *c;
	t_plotItem *p;
	int changes;

	c = CURVE2D_getFromPanelHandle (panel);
	if (c != NULL) {
		c->panelPos2D = getPanelBounds (panel);
		p = c->plotItem;
		if (p == NULL) return; 
		changes = copyPanelBounds (panel, &p->panelPos2D);   
		if ((p->session != NULL) && changes) SESSION_setChanges (p->session, 1);
	}
}



int CVICALLBACK CURVE2D_callbackPanel (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	
	t_curve *c;
	
	c = CURVE2D_getFromPanelHandle (panel);
	switch (event) {
		case EVENT_PANEL_SIZE:
			CURVE2D_resizePanel (panel);
			CURVE2D_getPanelBounds (panel);
			break;
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			HidePanel (panel);
			if (c != NULL) {
				c->visible2D = 0;
				CURVE_displayTreeItem (NULL, c, 1);
			}
			break;
		case EVENT_PANEL_MOVE:
			CURVE2D_getPanelBounds (panel);
			break;
		case EVENT_RIGHT_CLICK:
		case EVENT_LEFT_CLICK:
			if (RUN_inactive()) {
				DisplayPanel (panelCurves);
				SetActivePanel (panel);
			}
			break;
			
	}
	return 0;
}





void CURVE2D_setValue (t_curve *c, int curveNr, int index, double value)
{
	int i;
	
	if (c->values2D == NULL) return;
	i = index * c->n2Dcurves + curveNr;
	if (i > c->nValues2D) Breakpoint();
	c->values2D[i] =  value;

}


void CURVE2D_copyDataFromCurve (t_curve *c, int curveNr2D, int currentCurveNr)
{
	int i;
	int idx;
	int nAvg;
	double curX, curY;
	
	if (curveNr2D > c->n2Dcurves) return;
	if (c->values2D == NULL) return;
	nAvg = c->averages2D[curveNr2D];
	if (c->yValues == NULL) return;
	for (i = 0; i < c->nValues; i++) {
		idx = i * c->n2Dcurves + curveNr2D;
		if (idx > c->nValues2D) {
			Breakpoint();
		}
		else {
			// simply sum counts
//			c->values2D[idx] =  c->values2D[idx] + c->yValues[currentCurveNr][i];
			
			c->values2D[idx] =  nAvg * c->values2D[idx] + c->yValues[currentCurveNr][i];
			c->values2D[idx] /= (nAvg + 1);
		}
	}
	(c->averages2D[curveNr2D]) ++;
	
//	memcpy (&c->values2D[curveNr * c->nValues], c->yValues, sizeof (double)*c->nValues);
	GetGraphCursor (c->panel2DPlot, CURVE2D_GRAPH, 1, &curX, &curY);
	SetGraphCursor (c->panel2DPlot, CURVE2D_GRAPH, 1, c->xValues2D[c->activeCurve2D], curY);
}



void CURVE2D_resetValues (t_curve *c)
{
	if (c->values2D != NULL) 
		memset (c->values2D, 0, sizeof(double) * c->nValues2D);
	if (c->averages2D != NULL) 
		memset (c->averages2D, 0, sizeof(int) * c->n2Dcurves);
}


void CURVE2D_setActiveCurve (t_curve *c, int curveNr)
{
	int i;
	double curX, curY;
	
	if (curveNr > c->n2Dcurves) return;
	if (c->values2D == NULL) return;
	
	for (i = 0; i < c->nValues; i++) 
		c->yValuesAveraged[i] = c->values2D[i * c->n2Dcurves + curveNr];
		
	c->activeCurve2D = curveNr;
	GetGraphCursor (c->panel2DPlot, CURVE2D_GRAPH, 1, &curX, &curY);
	SetGraphCursor (c->panel2DPlot, CURVE2D_GRAPH, 1, c->xValues2D[c->activeCurve2D], curY);
}



int CURVE2D_saveTxt (const char *filename, t_curve *c, t_graph *w)
{
	int file;
	int i, k;
	char *lineStr;
	unsigned long appendPos;
	unsigned lineSize;
	char tmpStr[200];
	double dbl;
	char *hlp;
	

	if (c == NULL) return 0;
	if (c->nValues == NULL) return 0;

	// -----------------------------------
	// estimate length of string and allocate memory
	// -----------------------------------
	lineSize = (c->nValues) * 2 + 30;
	lineStr = (char *) malloc (lineSize);
	
	// -----------------------------------
	//      open file
	// -----------------------------------
	file = OpenFile (filename, VAL_WRITE_ONLY, VAL_TRUNCATE,
					 VAL_ASCII);
	if (file < 0) return displayFileError (filename);
	
	// -----------------------------------
	//      put header line
	// -----------------------------------
	if ((c->xUnits[0] == 0) && (w != NULL)) strcpy (lineStr, w->xUnits);
	else {
		strcpy (lineStr, c->xUnits);
		if (c->xShowSecondAxis) {
			strcat (lineStr, "\t");
			strcat (lineStr, c->xUnits2);
		}
	}
	appendPos = strlen(lineStr);
	if (c->xValues2D != NULL) {
		for (i = 0; i < c->n2Dcurves; i++) {
			strcpy (tmpStr, "\tS");
			strcat (tmpStr, doubleToStr (c->xValues2D[i]));
			lineStr = stringAppendToBuffer (lineStr, &lineSize, 
							    		    &appendPos, tmpStr);
		}
	}
	strCharChange (lineStr, ' ', '_');
	WriteLine (file, lineStr, -1);
	
	// -----------------------------------
	//      put other lines
	// -----------------------------------
	if(c->values2D!=NULL) {
		for (k = 0; k < c->nValues; k++) {
			strcpy (lineStr, doubleToStr (c->xValues[k]));
			if (c->xShowSecondAxis) {
				strcat (lineStr, "\t");
				strcat (lineStr,  doubleToStr (c->xValues[k]*c->xAxis2Multiply));
			}
		
			appendPos = strlen (lineStr);
			for (i = 0; i < c->n2Dcurves; i++) {
				tmpStr[0] = '\t';
				dbl = c->values2D[k * c->n2Dcurves + i];
				strcpy (tmpStr+1, doubleToStr(dbl));
				lineStr = stringAppendToBuffer (lineStr, &lineSize, 
								    		    &appendPos, tmpStr);
			}	   
			WriteLine (file, lineStr, -1);
		}
	}
	CloseFile (file);
	return 0;
}


int CURVE2D_saveTxtAsMatrix (const char *filename, t_curve *c)
{
	int file;
	int i, k;
	char lineStr[100];
	

	if (c == NULL) return 0;
	if (c->nValues == NULL) return 0;

	// -----------------------------------
	//      open file
	// -----------------------------------
	file = OpenFile (filename, VAL_WRITE_ONLY, VAL_TRUNCATE,
					 VAL_ASCII);
	if (file < 0) return displayFileError (filename);
	
	// -----------------------------------
	//      put header line
	// -----------------------------------
	strcpy (lineStr, "X\tY\tZ");
	WriteLine (file, lineStr, -1);

	// -----------------------------------
	//      all lines
	// -----------------------------------
	for (k = 0; k < c->nValues; k++) {
		for (i = 0; i < c->n2Dcurves; i++) {
			sprintf (lineStr, "%d\t%d\t%s", k, i, doubleToStr(c->values2D[k * c->n2Dcurves + i]));
			WriteLine (file, lineStr, -1);
		}	   
	}
	
	CloseFile (file);
	return 0;
}



int CVICALLBACK CURVES_callback_curveNrChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_graph *w;
	t_curve *c;
	int curveNr;
	int checked;
	
	switch (event) {
		case EVENT_COMMIT:
			if (GRAPH_getSelectionFromTree (&w, &c, &checked, 0,0) >= 0) {
				if (c == NULL) return 0;
				if (w == NULL) return 0;
     			GetCtrlVal (panelCurves, CURVES_NUMERIC_curve, &curveNr);
     			CURVE2D_setActiveCurve (c, curveNr-1);
				CURVE_removePlot (w, c, 1);        			
     			CURVE_displayAveragedCurve (w, c);
				CURVE_display (w, c, 1, 0, 1);
     			RefreshGraph (w->panelHandle, GRAPH_GRAPH);
     			GRAPH_setWindowParameters (w, c);
     		}
			break;
	}
	return 0;
}



void GRAPH_resetUsedByActiveSession (void)
{
	t_graph *g;
	int item;
	
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
				 VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		g = GRAPH_getFromIndex (item);
		if (g != NULL) g->usedByActiveSession = 0;
		GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, item, item,
					 VAL_NEXT, 0, &item);
		// check if graph is used in current session
	}
}


void GRAPH_displayAll2DCurves (t_graph *w)
{
	int graphItem;
	int item;
	t_curve *c;
	
	CURVE_getTreeItemNr (w, NULL, &graphItem, 0,0,0);
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
				 item, VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		c = CURVE_getFromIndex (item);
		if (c->panel2DPlot > 0) SetPanelAttribute (c->panel2DPlot, ATTR_VISIBLE, c->visible2D);
		GetTreeItem (panelCurves, CURVES_TREE, VAL_CHILD, graphItem,
					 item, VAL_NEXT, 0, &item);
	}
}


void GRAPH_displayOnlyUsedPanels (void)
{
	t_graph *g;
	int item;
	
	item = VAL_FIRST;
	GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
				 VAL_NEXT_PLUS_SELF, 0, &item);
	while (item >= 0) {
		g = GRAPH_getFromIndex (item);
		
		
		// check if graph is used in current session
		g->visible = g->usedByActiveSession;
		SetPanelAttribute (g->panelHandle, ATTR_VISIBLE, g->visible);
		GRAPH_displayAll2DCurves (g);
		SetTreeItemAttribute (panelCurves, CURVES_TREE, item, ATTR_COLLAPSED, !g->visible);
		SetTreeItemAttribute (panelCurves, CURVES_TREE, item,
							  ATTR_LABEL_COLOR, g->visible ? VAL_BLACK : VAL_LT_GRAY);
		GetTreeItem (panelCurves, CURVES_TREE, VAL_SIBLING, 0, item,
					 VAL_NEXT, 0, &item);
	}
}









void GRAPH_PRINT_resizePanel (void)
{
	int width;
	int graphWidth;
	
	width = panelWidth (panelPrint);
	
	graphWidth = width * 2 / 3;
	
	SetCtrlAttribute (panelPrint, graphPanelPrint, ATTR_WIDTH, graphWidth);
	SetCtrlAttribute (panelPrint, graphPanelPrint,
					  ATTR_LEGEND_LEFT, graphWidth);
	
	SetCtrlAttribute (panelPrint, graphPanelPrint, ATTR_HEIGHT, 
					  ctrlTop (panelPrint, PRINT_TEXTMSG_date)
					  - ctrlBottom (panelPrint, PRINT_STRING_title) - 5);
	// set width + height of legend
	SetCtrlAttribute (panelPrint, graphPanelPrint, ATTR_LEGEND_WIDTH, 500);
//					  panelWidth (panelPrint) - graphWidth);
//	SetCtrlAttribute (panelPrint, graphPanelPrint, ATTR_LEGEND_HEIGHT, 
//					  ctrlHeight (panelPrint, graphPanelPrint));
					  
	
	
	// set width of title bar
	SetCtrlAttribute (panelPrint, PRINT_STRING_title, ATTR_WIDTH,
					  ctrlWidth (panelPrint, graphPanelPrint) 
					  - ctrlLeft (panelPrint, PRINT_STRING_title));
	
	

}


void setLegend (int panel, int graph, int plot, char *text)
{
	char setText[300];
	int len;
	int ok;
	
	len = strlen (text);
	if (len > 32) len = 32;
	text[len] = 0;
	do {
//		SetPlotAttribute (panel, graph, plot, ATTR_PLOT_LG_TEXT, "TEST");
		SetPlotAttribute (panel, graph, plot, ATTR_PLOT_LG_TEXT, text);
		GetPlotAttribute (panel, graph, plot, ATTR_PLOT_LG_TEXT, setText);
		ok = strcmp (setText, text) == 0;
		if (!ok) {
			len--;
			text[len] = 0;
		}
	} while (!ok && (len > 0));
}
		



void GRAPH_PRINT_setVisibility (int visible)
{
	SetCtrlAttribute (panelPrint, PRINT_COMMANDBUTTON_abort, ATTR_VISIBLE, visible);
	SetCtrlAttribute (panelPrint, PRINT_COMMANDBUTTON_print, ATTR_VISIBLE, visible);
	SetCtrlAttribute (panelPrint, PRINT_STRING_title,
					  ATTR_LABEL_VISIBLE, visible);
	SetCtrlAttribute (panelPrint, PRINT_STRING_title,
					  ATTR_VISIBLE, visible);
	SetCtrlAttribute (panelPrint, PRINT_TEXTBOX_comment,
					  ATTR_LABEL_VISIBLE, visible);
	SetCtrlAttribute (panelPrint, PRINT_TEXTMSG_title,
					  ATTR_VISIBLE, !visible);
}



void GRAPH_PRINT_createPanel (t_graph *g, int panel, int ctrl, t_curve *curve2D)
{
	char date[50];
	t_curve *c;
	char *helpStr;
	
	if ((g == NULL) && (curve2D == NULL)) return;
	if (panelPrint == -1) panelPrint = LoadPanel (0, SESSIONMANAGER_uirFile, PRINT);
	
	graphPanelPrint = DuplicateCtrl (panel, ctrl,
							  panelPrint, "", 
							  ctrlBottom (panelPrint, PRINT_STRING_title), 0);
	GRAPH_PRINT_resizePanel ();
	SetPanelAttribute (panelPrint, ATTR_BACKCOLOR, VAL_WHITE);
	SetCtrlAttribute (panelPrint, graphPanelPrint,
					  ATTR_NUM_CURSORS, 0);
	SetCtrlAttribute (panelPrint, graphPanelPrint,
					  ATTR_CALLBACK_FUNCTION_POINTER, NULL);
	SetCtrlAttribute (panelPrint, graphPanelPrint,
					  ATTR_GRAPH_BGCOLOR, VAL_WHITE);
	SetCtrlAttribute (panelPrint, graphPanelPrint, ATTR_EDGE_STYLE,
					  VAL_FLAT_EDGE);
	SetCtrlAttribute (panelPrint, PRINT_TEXTMSG_title,
					  ATTR_TEXT_BGCOLOR, VAL_WHITE);
//	SetCtrlAttribute (panelPrint, PRINT_TEXTMSG_title,
//					  ATTR_VISIBLE, 0);
	// create legend
	SetCtrlAttribute (panelPrint, graphPanelPrint,
					  ATTR_LEGEND_VISIBLE, 1);
	SetCtrlAttribute (panelPrint, graphPanelPrint,
					  ATTR_PLOT_BGCOLOR, VAL_WHITE);
	SetCtrlAttribute (panelPrint, graphPanelPrint,
					  ATTR_LEGEND_TOP, ctrlTop (panelPrint, graphPanelPrint));
	SetCtrlAttribute (panelPrint, graphPanelPrint,
					  ATTR_LEGEND_PLOT_BGCOLOR, VAL_WHITE);
	SetCtrlAttribute (panelPrint, PRINT_TEXTBOX_comment, ATTR_VISIBLE, 1);					  

    // ----------------------------------
	//       create Legend
    // ----------------------------------
	helpStr = getTmpString();
	if (curve2D == NULL) {
		// normal panel
		c = GRAPH_firstCurve (g);
		while (c != NULL) {
			if (c->visible && (c->plotHandlesAveraged[0] > 0)) {
				sprintf (helpStr, "%04d \"%s\" ", c->startNr, c->name);
				if (strcmp (c->dateStr, dateStr()) != 0) {
					strcat (helpStr, "(");
					strcat (helpStr, c->dateStr);
					strcat (helpStr, ")");
				}

				SetPlotAttribute (panelPrint, graphPanelPrint,
								  c->plotHandlesAveraged[0], ATTR_PLOT_LG_VISIBLE, 1);
				setLegend (panelPrint, graphPanelPrint, c->plotHandlesAveraged[0], helpStr);
				SetPlotAttribute (panelPrint, graphPanelPrint,
								  c->plotHandlesAveraged[0], ATTR_PLOT_LG_TEXT_COLOR,
								  VAL_BLACK);
			}

			c = GRAPH_nextCurve (c, g);
		}
	}
	else {
		// 2D panel
		sprintf (helpStr, "%04d \"%s\" ", curve2D->startNr, curve2D->name);
		if (strcmp (curve2D->dateStr, dateStr()) != 0) {
			strcat (helpStr, "(");
			strcat (helpStr, curve2D->dateStr);
			strcat (helpStr, ")");
		}
		SetPlotAttribute (panelPrint, graphPanelPrint,
						  curve2D->plotHandle2D, ATTR_PLOT_LG_VISIBLE, 1);
		setLegend (panelPrint, graphPanelPrint, curve2D->plotHandle2D, helpStr);
		SetPlotAttribute (panelPrint, graphPanelPrint,
						  curve2D->plotHandle2D, ATTR_PLOT_LG_TEXT_COLOR,
						  VAL_BLACK);
	}
	
    // ----------------------------------
    //     set time + date
    // ----------------------------------
    strcpy (date, dateStr());
    strcat (date, "  ");
    strcat (date, timeStr());
    SetCtrlVal (panelPrint, PRINT_TEXTMSG_date, date);
	SetCtrlAttribute (panelPrint, PRINT_TEXTMSG_date,
					  ATTR_TEXT_BGCOLOR, VAL_WHITE);
	GRAPH_PRINT_setVisibility (1);      					  
	InstallPopup (panelPrint);
	
}


int GRAPH_runPopupMenu2D (int panel, int top, int left)
{
	int choice;
	t_curve *curve;
	
	choice = RunPopupMenu (menuGraph2D, GRAPH2D_MENU, panel,
						   top, left, 0, 0, 0, 0);
	switch (choice) {
		case GRAPH2D_MENU_PRINT:
			curve = CURVE2D_getFromPanelHandle (panel);
			GRAPH_PRINT_createPanel (NULL, panel, CURVE2D_GRAPH, curve);
			break;
	}	
	return 0;
}


dRect MakeDRect (double xFrom, double xTo, double yFrom, double yTo)
{
	static dRect rect;
	
	rect.xFrom = xFrom;	
	rect.xTo   = xTo;
	rect.yFrom = yFrom;
	rect.yTo 	 = yTo;
	
	return rect;
}


int dRect_isEqual (dRect *r1, dRect *r2)
{
	if (r1->xFrom != r2->xFrom) return 0;
	if (r1->xTo != r2->xTo) return 0;
	if (r1->yFrom != r2->yFrom) return 0;
	if (r1->yTo != r2->yTo) return 0;
	return 1;
	
}

void GRAPH_getCurrentAxis (t_graph *g, dRect *axis)
{
	*axis = MakeDRect (g->xFrom, g->xTo, g->yFrom, g->yTo);
}



void GRAPH_zoom (t_graph *g, dRect target)
{
	int N_ZOOM_STEPS = 10;
	dRect current;
	int i;
	
	
	GRAPH_getCurrentAxis (g, &current);
	for (i = 0; i < N_ZOOM_STEPS; i++) {
		GRPAH_rememberCursorPositions (g, 1);
		g->xFrom = current.xFrom + (target.xFrom - current.xFrom) * (1.0*i)/(N_ZOOM_STEPS-1);
		g->xTo   = current.xTo   + (target.xTo   - current.xTo  ) * (1.0*i)/(N_ZOOM_STEPS-1);
		g->yFrom = current.yFrom + (target.yFrom - current.yFrom) * (1.0*i)/(N_ZOOM_STEPS-1);
		g->yTo   = current.yTo   + (target.yTo   - current.yTo  ) * (1.0*i)/(N_ZOOM_STEPS-1);
		GRAPH_setWindowParameters (g, NULL);
		GRPAH_rememberCursorPositions (g, 0);
		RefreshGraph (g->panelHandle, GRAPH_GRAPH);
		Delay (0.05);
	}
	

}




int GRAPH_runPopupMenu (int panel, int top, int left)
{
	char *help;
	int choice;
	int i, nDevices;
	t_graph *g;
	t_session *s;
	double x1, y1, x2, y2;
	int freqAxis;
	t_sweep *sw;
	dRect currentZoomRegion, zoomRegion;
	
	#define N_DEVICES 10
	int devicesC1[N_DEVICES];
	int devicesC2[N_DEVICES];
	int devicesDIFF[N_DEVICES];

	t_sweep *sweeps[N_DEVICES];
		
	g = GRAPH_getWindowFromPanelHandle (panel, NULL);
	s = activeSession();
	help = getTmpString();

	// set menu bar attribute CURSORS:
	SetMenuBarAttribute (menuGraph,
						 GRAPHMENU_GRAPH_CURSORS_CURSORS0,
						 ATTR_CHECKED, g->nCursors == 0);
	SetMenuBarAttribute (menuGraph,
						 GRAPHMENU_GRAPH_CURSORS_CURSORS1,
						 ATTR_CHECKED, g->nCursors == 1);
	SetMenuBarAttribute (menuGraph,
						 GRAPHMENU_GRAPH_CURSORS_CURSORS2,
						 ATTR_CHECKED, g->nCursors == 2);
	
	
	// check if axis = frequency
	freqAxis = (strcmp (g->xUnits, "GHz") == 0);
	SetMenuBarAttribute (menuGraph, GRAPHMENU_GRAPH_FREQ, ATTR_DIMMED, 
						 !freqAxis || (g->nCursors == 0));
	SetMenuBarAttribute (menuGraph, GRAPHMENU_GRAPH_FREQ_C1, ATTR_DIMMED, 
						 g->nCursors < 1);
	if (g->nCursors >= 1) {
		GetGraphCursor (g->panelHandle, GRAPH_GRAPH, 1, &x1, &y1);
		if (g->nCursors >= 2) GetGraphCursor (g->panelHandle, GRAPH_GRAPH, 2, &x2, &y2);
	}						 
	
	SetMenuBarAttribute (menuGraph, GRAPHMENU_GRAPH_FREQ_C2, ATTR_DIMMED, 
						 g->nCursors < 2);
	SetMenuBarAttribute (menuGraph, GRAPHMENU_GRAPH_FREQ_DIFF, ATTR_DIMMED, 
						 g->nCursors < 2);
	SetMenuBarAttribute (menuGraph, GRAPHMENU_GRAPH_ZOOM, ATTR_DIMMED, 
						 g->nCursors < 2);
	SetMenuBarAttribute (menuGraph, GRAPHMENU_GRAPH_UNZOOM, ATTR_DIMMED, 
						 !g->wasZoomed);

	EmptyMenu (menuGraph, GRAPHMENU_GRAPH_FREQ_C1_SUBMENU);
	EmptyMenu (menuGraph, GRAPHMENU_GRAPH_FREQ_C2_SUBMENU);
	EmptyMenu (menuGraph, GRAPHMENU_GRAPH_FREQ_DIFF_SUBMEN);
	nDevices = 0;
	if (freqAxis) {
		// insert all frequency synthesizers into list
		for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
			sw = SWEEP_ptr (s, i);
			if ((sw->type == SWEEP_TYPE_SYNTHESIZER) && (sw->active) && (nDevices < N_DEVICES)) {
				sprintf (help, "center freq. %s", strGPIBlabel (sw->channel));
				
				devicesC1[nDevices] = NewMenuItem (menuGraph, GRAPHMENU_GRAPH_FREQ_C1_SUBMENU, help, -1, 0, 0, 0);
				devicesC2[nDevices] = NewMenuItem (menuGraph, GRAPHMENU_GRAPH_FREQ_C2_SUBMENU, help, -1, 0, 0, 0);
				sprintf (help, "sweep range %s", strGPIBlabel (sw->channel));
				devicesDIFF[nDevices] = NewMenuItem (menuGraph, GRAPHMENU_GRAPH_FREQ_DIFF_SUBMEN, help, -1, 0, 0, 0);
				sweeps[nDevices] = sw;
				nDevices++;
			}
		}
		// fill the others with 0
		for (i = nDevices; i < N_DEVICES; i++) {
			devicesC1[i] = -1;
			devicesC2[i] = -1;
			devicesDIFF[i] = -1;
			sweeps[i] = NULL;
		}
	}

	choice = RunPopupMenu (menuGraph, GRAPHMENU_GRAPH, panel,
						   top, left, 0, 0, 0, 0);
//			choice = RunPopupMenu (menuCurves, menuCurves_Items[MENU_CURVES],
//								   panel, eventData1, eventData2, 0, 0, 0, 0);
//			choice = arrayFind (menuCurves_Items, N_ITEMS_MENU_CURVES, choice);
	

	switch (choice) {
		case GRAPHMENU_GRAPH_PRINT:
			GRAPH_PRINT_createPanel (g, g->panelHandle, GRAPH_GRAPH, NULL);
			break;
		case GRAPHMENU_GRAPH_CURSORS_CURSORS0:
			g->nCursors = 0;
			CURSORS_setParameters (g);
			break;
		case GRAPHMENU_GRAPH_CURSORS_CURSORS1:
			g->nCursors = 1;
			CURSORS_setParameters (g);
			break;
		case GRAPHMENU_GRAPH_CURSORS_CURSORS2:
			g->nCursors = 2;
			CURSORS_setParameters (g);
			break;
		case GRAPHMENU_GRAPH_ZOOM:
			g->xFromAutoscale = 0;
			g->xToAutoscale = 0;
			g->yFromAutoscale = 0;
			g->yToAutoscale = 0;
			GRAPH_getCurrentAxis (g, &currentZoomRegion);
			zoomRegion = MakeDRect (min (x1, x2), max (x1, x2), min (y1, y2), max (y1, y2) );
			if (dRect_isEqual (&currentZoomRegion, &zoomRegion)) return 1;
			GRAPH_getCurrentAxis (g, &g->lastZoomRegion);
			GRAPH_zoom (g, zoomRegion);
			g->wasZoomed = 1;
			break;
		case GRAPHMENU_GRAPH_UNZOOM:
			GRAPH_zoom (g, g->lastZoomRegion);
			g->wasZoomed = 0;
			break;
		case GRAPHMENU_GRAPH_FREQ_C1:
			
			g = g;
			break;
		default:
			for (i = 0; i < nDevices; i++) {
				if (choice == devicesC1[i]) {
					if (ConfirmPopupf ("Set frequency", 
									   "Do you really want to set the center frequency of\n"
									   "%s to %1.9f %s ?",
									   strGPIBlabel (sweeps[i]->channel), x1, g->xUnits)) {
						sweeps[i]->center = x1;	
						sweeps[i]->from = x1 - sweeps[i]->span/2000.0;
						sweeps[i]->to   = x1 + sweeps[i]->span/2000.0;
						SWEEP_setValues (sweeps[i], s->nSweepPoints);
					}
					return 0;
				}
				if (choice == devicesC2[i]) {
					if (ConfirmPopupf ("Set frequency", 
									   "Do you really want to set the center frequency of\n"
									   "%s to %1.9f %s ?",
									   strGPIBlabel (sweeps[i]->channel), x2, g->xUnits)) {
						sweeps[i]->center = x2;	
						sweeps[i]->from = x2 - sweeps[i]->span/2000.0;
						sweeps[i]->to   = x2 + sweeps[i]->span/2000.0;
						SWEEP_setValues (sweeps[i], s->nSweepPoints);
					}
					return 0;
				}
				if (choice == devicesDIFF[i]) {
					if (ConfirmPopupf ("Set frequency", 
									   "Do you really want to set the frequency sweep of\n"
									   "%s to %1.9f --> %1.9f %s ?",
									   strGPIBlabel (sweeps[i]->channel), x1, x2, g->xUnits)) {
						sweeps[i]->from = x1;
						sweeps[i]->to   = x2;
						sweeps[i]->span   = (sweeps[i]->to - sweeps[i]->from) * 1000.0;
						sweeps[i]->center =  sweeps[i]->from + (sweeps[i]->to - sweeps[i]->from) / 2;
						SWEEP_setValues (sweeps[i], s->nSweepPoints);
					}
					return 0;
				}

			}
	}
	return 1;

    #undef N_DEVICES
}

int CVICALLBACK PRINT_callback_abort (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			RemovePopup (0);
			DiscardCtrl (panelPrint, graphPanelPrint);
			graphPanelPrint = -1;
			break;
		}
	return 0;
}





int CVICALLBACK PRINT_callback_print (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int lines;
	char title[200];
	int width;
	int height = 1500;
	
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal (panelPrint, PRINT_STRING_title, title);
			SetCtrlVal (panelPrint, PRINT_TEXTMSG_title, title);
			GetCtrlAttribute (panelPrint, PRINT_TEXTMSG_title, ATTR_WIDTH, &width);
			SetCtrlAttribute (panelPrint, PRINT_TEXTMSG_title, ATTR_LEFT, 
							  max ((ctrlWidth (panelPrint, graphPanelPrint) - width) / 2, 0));
		    GRAPH_PRINT_setVisibility (0);
//			SetCtrlAttribute (panelPrint, PRINT_STRING_title,
//							  ATTR_FRAME_COLOR, VAL_OFFWHITE);
//			SetCtrlAttribute (panelPrint, PRINT_TEXTBOX_comment,
//							  ATTR_FRAME_COLOR, VAL_WHITE);
			GetNumTextBoxLines (panelPrint, PRINT_TEXTBOX_comment, &lines);
			SetCtrlAttribute (panelPrint, PRINT_TEXTBOX_comment, ATTR_VISIBLE, lines > 0);
					  
			
			SetPrintAttribute (ATTR_BITMAP_PRINTING, 1);
			SetPrintAttribute (ATTR_SYSTEM_PRINT_DIALOG_ONLY, 1);
//			SetPrintAttribute (ATTR_PRINT_AREA_WIDTH, 400);
			SetPrintAttribute (ATTR_PRINT_AREA_HEIGHT, 2000);
			SetPrintAttribute (ATTR_PRINT_AREA_WIDTH, VAL_INTEGRAL_SCALE);
			SetPrintAttribute (ATTR_ORIENTATION, VAL_LANDSCAPE);
			PrintPanel (panelPrint, "", 1, VAL_FULL_PANEL, 1);
			RemovePopup (0);
		    GRAPH_PRINT_setVisibility (1);
			DiscardCtrl (panelPrint, graphPanelPrint);
			graphPanelPrint = -1;
			break;
		}
	return 0;
}

int CVICALLBACK PRINT_panel_callback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:

			break;
		case EVENT_PANEL_SIZE:
		    GRAPH_PRINT_resizePanel ();
		    break;
		}
	return 0;
}

int CVICALLBACK GRAPH_graph2D_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:

			break;
		case EVENT_RIGHT_CLICK:
			GRAPH_runPopupMenu2D (panel, eventData1, eventData2);
			break;
			
		}
	return 0;
}



int CVICALLBACK CURVE2D_showPartsOfExperiment_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_curve *c;
	switch (event)
		{
		case EVENT_COMMIT:
			c = CURVE2D_getFromPanelHandle (panel);
			if (c == NULL) return 0;
			GetCtrlVal (panel, CURVE2D_RADIOBUTTON_showParts, &c->componentsVisible);
			GetCtrlVal (panel, CURVE2D_BUTTON_interpolate2D, &c->interpolate2D);
			CURVE2D_displayCurve (c, c->panelPos2D);
			break;
		}
	return 0;
}









void CUSTOM_initPanel (int nr)
{
	if (nr > N_CUSTOM_EVALUATIONPANELS) return;
	if (panelCustomEvaluation[nr] <= 0) {
		panelCustomEvaluation[nr] = LoadPanel (0, SESSIONMANAGER_uirFile, panelIDcustom[nr]);
	}
	DisplayPanel (panelCustomEvaluation[nr]);
}



int CVICALLBACK CUSTOM1_startEvaluation_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			CUSTOM1_startEvaluation ();
			break;
		}
	return 0;
}

int CVICALLBACK CUSTOM1_abort_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			HidePanel (panel);
			break;
		}
	return 0;
}



int CVICALLBACK CUSTOM1_panel_callback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			HidePanel (panel);
			break;
		}
	return 0;
}



void CUSTOM1_printf (char* format, ... )
{
	va_list arg;

	va_start( arg, format );
    vpprintf(panelCustomEvaluation[0], CUSTOM1_TEXTBOX, format, arg  );
    va_end( arg );
}


void CUSTOM2_printf (char* format, ... )
{
	va_list arg;

	va_start( arg, format );
    vpprintf(panelCustomEvaluation[1], CUSTOM1_TEXTBOX, format, arg  );
    va_end( arg );
	ProcessDrawEvents ();
    
}


void CVICALLBACK CURVES_MENUBAR_custom1 (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	CUSTOM_initPanel (0);
}


void CVICALLBACK CURVES_MENUBAR_custom2 (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	CUSTOM_initPanel (1);
}




int CVICALLBACK CUSTOM2_startEvaluation_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			CUSTOM2_startEvaluation ();
			break;
		}
	return 0;
}


int panelCustom (int nr)
{
	return panelCustomEvaluation[nr-1];
}

