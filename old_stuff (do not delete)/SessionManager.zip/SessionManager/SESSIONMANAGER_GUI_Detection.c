#include <userint.h>
#include "UIR_SessionManager.h"

#include "INCLUDES_SESSIONMANAGER.h"


int panelDetectors = -1;   

	

//=======================================================================
//
//    edit detection parameters
//
//=======================================================================
enum { 
	TIME_WINDOW_TABLE_COL_NAME = 1,
	TIME_WINDOW_TABLE_COL_ACTIVE,
	TIME_WINDOW_TABLE_COL_START,
	TIME_WINDOW_TABLE_COL_END
};

enum { 
	LEVEL_TABLE_COL_NO = 1,
	LEVEL_TABLE_COL_NAME,
	LEVEL_TABLE_COL_VOLTAGE
};


enum {  
	DETECTIONPAR_COL_NAME,
	DETECTIONPAR_COL_DETECTOR,
	DETECTIONPAR_COL_ATOMS,
	DETECTIONPAR_COL_ERROR,
	
	N_TIMEINTERVAL_COL
};



void DETECTORS_setValues (t_session *s, t_detectionParameters *d)
{
	int i;
	int panel;
	int nRows;
	int error;

	
	panel = panelDetectors;
	
	if (d != NULL) {
		SetCtrlVal (panel, DETECTORS_STRING_name, d->name);
		SetCtrlVal (panel, DETECTORS_RADIOBUTTON_det1, d->detectorActive[0]);
		// detection ramp
		SetCtrlVal (panel, DETECTORS_NUMERIC_rampStart, d->det1_rampStartVoltage);
		SetCtrlVal (panel, DETECTORS_NUMERIC_rampStop, d->det1_rampStopVoltage);
		SetCtrlVal (panel, DETECTORS_NUMERIC_rampDuration, d->det1_rampDuration);
		SetCtrlVal (panel, DETECTORS_NUMERIC_triggerRamp, d->det1_rampTrigger);
		SetCtrlVal (panel, DETECTORS_RING_referencePos, d->det1_rampTriggerReference);
		// time windows
		GetNumTableRows (panel, DETECTORS_TABLE_windows, &nRows);
		if (nRows > s->nLevels) 
			DeleteTableRows (panel, DETECTORS_TABLE_windows, s->nLevels, nRows - s->nLevels);
		if (nRows < s->nLevels) 
			InsertTableRows (panel, DETECTORS_TABLE_windows, -1, s->nLevels - nRows, VAL_USE_MASTER_CELL_TYPE);
		
		error = 0;
		for (i = 0; i < s->nLevels; i++) {
			SetTableCellVal (panel, DETECTORS_TABLE_windows, 
						     MakePoint (TIME_WINDOW_TABLE_COL_NAME, i+1),
							 s->levelNames[i]);
			SetTableCellVal (panel, DETECTORS_TABLE_windows, 
							 MakePoint (TIME_WINDOW_TABLE_COL_ACTIVE, i+1),
							 d->det1_levelActive[i]);
			SetTableCellVal (panel, DETECTORS_TABLE_windows, 
							 MakePoint (TIME_WINDOW_TABLE_COL_START, i+1),
							 d->det1_timeStart[i]);
			SetTableCellAttribute (panel, DETECTORS_TABLE_windows,
								   MakePoint (TIME_WINDOW_TABLE_COL_START, i+1),
								   ATTR_CELL_DIMMED,
								   !d->det1_levelActive[i]);
			SetTableCellVal (panel, DETECTORS_TABLE_windows, 
							 MakePoint (TIME_WINDOW_TABLE_COL_END, i+1),
							 d->det1_timeEnd[i]);
			SetTableCellAttribute (panel, DETECTORS_TABLE_windows, 
							 	MakePoint (TIME_WINDOW_TABLE_COL_END, i+1),
							 	ATTR_CELL_DIMMED, !d->det1_levelActive[i]);
		}
		error = DETECTIONPAR_inconsistent (s, d, 0);
		SetCtrlAttribute (panel, DETECTORS_TEXTMSG_warning1a, ATTR_VISIBLE, error && (d->detectorActive[0]));
		SetCtrlVal (panel, DETECTORS_RING_referencePos_2, d->det2_timeReference);
	}
	SetAttributeForCtrls (panelDetectors, ATTR_DIMMED, 
						  (d == NULL) || (!d->detectorActive[0]), 0,
					      DETECTORS_TEXTMSG_ramp, 
					      DETECTORS_NUMERIC_rampStart, 
					      DETECTORS_TEXTMSG_start1,
					      DETECTORS_NUMERIC_rampStop,
					      DETECTORS_TEXTMSG_stop1,
					      DETECTORS_NUMERIC_rampDuration,
					      DETECTORS_TEXTMSG_dur1,
					      DETECTORS_TEXTMSG_ramp2,
					      DETECTORS_NUMERIC_triggerRamp,
					      DETECTORS_RING_referencePos,
					      DETECTORS_TABLE_windows,
						  0);
// ------------------------------------
//           DETECTOR2
// ------------------------------------
	
	if (d != NULL) {
		error = DETECTIONPAR_inconsistent (s, d, 1);
		SetCtrlAttribute (panel, DETECTORS_TEXTMSG_warning2, ATTR_VISIBLE,
						  error && (d->detectorActive[1]));
		SetCtrlVal (panel, DETECTORS_RADIOBUTTON_det2, d->detectorActive[1]);
		SetCtrlVal (panel, DETECTORS_NUMERIC_timeStart, d->det2_timeStart );
		SetCtrlVal (panel, DETECTORS_NUMERIC_timeEnd, d->det2_timeEnd);
//		SetCtrlVal (panel, DETECTORS_RING_defaultLevel, d->det2_defaultLevel);
				
		
	}

	SetAttributeForCtrls (panel, ATTR_DIMMED, 
						  (d == NULL) || (!d->detectorActive[1]), 0,
//						  DETECTORS_BUTTON_useTimeWindow,
						  DETECTORS_NUMERIC_timeStart,
						  DETECTORS_TEXTMSG_start4,
						  DETECTORS_NUMERIC_timeEnd,
						  DETECTORS_TEXTMSG_end4,
					      DETECTORS_RING_referencePos_2,
						  0);
}


void DETECTORS_getValues (t_session *s, t_detectionParameters *d)
{
	int i;
	int panel;
	
	if (d == NULL) return;
	
	panel = panelDetectors;
	
	GetCtrlVal (panel, DETECTORS_RADIOBUTTON_det1, &d->detectorActive[0]);

	GetCtrlVal (panel, DETECTORS_STRING_name, d->name);
	// detection ramp
	GetCtrlVal (panel, DETECTORS_NUMERIC_rampStart, 
				&d->det1_rampStartVoltage);
	GetCtrlVal (panel, DETECTORS_NUMERIC_rampStop, 
				&d->det1_rampStopVoltage);
	GetCtrlVal (panel, DETECTORS_NUMERIC_rampDuration,
				&d->det1_rampDuration);
	GetCtrlVal (panel, DETECTORS_NUMERIC_triggerRamp,
				&d->det1_rampTrigger);
	GetCtrlVal (panel, DETECTORS_RING_referencePos,
				&d->det1_rampTriggerReference);
	// time windows
	for (i = 0; i < s->nLevels; i++) {
		GetTableCellVal (panel, DETECTORS_TABLE_windows, 
						 MakePoint (TIME_WINDOW_TABLE_COL_START, i+1),
						 &d->det1_timeStart[i]);
		GetTableCellVal (panel, DETECTORS_TABLE_windows, 
						 MakePoint (TIME_WINDOW_TABLE_COL_END, i+1),
						 &d->det1_timeEnd[i]);
		GetTableCellVal (panel, DETECTORS_TABLE_windows, 
						 MakePoint (TIME_WINDOW_TABLE_COL_ACTIVE, i+1),
						 &d->det1_levelActive[i]);
						 
	}

// DETECTOR2
//	GetCtrlVal (panelDetectors, DETECTORS_RADIOBUTTON_det2, 
//				d->detector == 2);
//	GetCtrlVal (panel, DETECTORS_BUTTON_useTimeWindow, &d->det2_useTimeWindow);
						  
	GetCtrlVal (panel, DETECTORS_RADIOBUTTON_det2, &d->detectorActive[1]);
	GetCtrlVal (panel, DETECTORS_RING_referencePos_2, &d->det2_timeReference);
	GetCtrlVal (panel, DETECTORS_NUMERIC_timeStart,
				&d->det2_timeStart);
	GetCtrlVal (panel, DETECTORS_NUMERIC_timeEnd,
				&d->det2_timeEnd);
}


void DETECTORS_fillNamesToListbox (int panel, int control, t_session *s)
{
    int i;
    t_detectionParameters *d;

	setNumListItems (panel, control, ListNumItems (s->lDetectionParameters)+1);
	ReplaceListItem (panel, control, 0, "NONE", 0);
	for (i = 1; i <= ListNumItems (s->lDetectionParameters); i++) {
		d = DETECTIONPAR_ptr (s, i);
		ReplaceListItem (panel, control, i, d->name, i);
	}
}


void DETECTORS_fillNamesToTree (int panel, int control, t_session *s)
{
    int i;
    t_detectionParameters *d;
    t_atom *a;

    char *help;
    int newItem;
    int okay;
    int len;

	help = getTmpString();
	setNumTreeItems (panel, control, ListNumItems (s->lDetectionParameters));
//	ClearListCtrl (panel, control);

	for (i = 1; i <= ListNumItems (s->lDetectionParameters); i++) {
		ListGetItem (s->lDetectionParameters, &d, i);
		d->atoms[0]   = 0;
	}

	for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
		ListGetItem (s->lAtoms, &a, i);
		if ((a->active) && (a->detect)) {
			d = DETECTIONPAR_ptr (s, a->detectionParameters);
			if (d != NULL) {
			 	len = strlen (d->atoms);
			 	if (len == 0) strcat (d->atoms, intToStr (i));
			 	else if (len < MAX_DET_ATOMS_LEN-10) {
			 		strcat (d->atoms, ", ");
			 		strcat (d->atoms, intToStr (i));
			 	}
			}
		}
	}
	
	
	for (i = 1; i <= ListNumItems (s->lDetectionParameters); i++) {
		d = DETECTIONPAR_ptr (s, i);
		// -----------------------------
		//      display name
		// -----------------------------
		sprintf (help, " %s", d->name);
		newItem = i-1;
		SetTreeItemAttribute (panel, control, newItem, ATTR_CTRL_VAL, i);
		SetTreeCellAttribute (panel, control, newItem, DETECTIONPAR_COL_NAME,
							  ATTR_LABEL_TEXT, help);
/*		SetTreeCell
		newItem = InsertTreeItem (panel, control, VAL_SIBLING, 0,
								  VAL_LAST, help, NULL, NULL, i);
*/		// -----------------------------
		//      display detector
		// -----------------------------
		if (d->detectorActive[0] && d->detectorActive[1]) strcpy (help, "1+2");
		else if (d->detectorActive[0]) strcpy (help, "1");
		else if (d->detectorActive[1]) strcpy (help, "2");
		else help[0] = 0;	
		SetTreeCellAttribute (panel, control, newItem, DETECTIONPAR_COL_DETECTOR,
							  ATTR_LABEL_TEXT, help);
		SetTreeCellAttribute (panel, control, newItem, DETECTIONPAR_COL_DETECTOR,
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_CENTER_JUSTIFIED);
		okay = !(DETECTIONPAR_inconsistent (s, d, 0) || DETECTIONPAR_inconsistent (s, d, 1));
		SetTreeCellAttribute (panel, control, newItem, DETECTIONPAR_COL_ATOMS,
							  ATTR_LABEL_TEXT, d->atoms);
			  
		SetTreeCellAttribute (panel, control, newItem,
							  DETECTIONPAR_COL_ERROR, ATTR_LABEL_COLOR,
							  okay ? VAL_BLACK: VAL_RED);
		SetTreeCellAttribute (panel, control, newItem,
							  DETECTIONPAR_COL_ERROR, ATTR_LABEL_TEXT,
							  okay ? "": "Error!");
	}
}


void DETECTORS_displayAllNames (t_session *s)
{
    t_detectionParameters *d;
    int nr = -1;
    int nItems;
    int panel, ctrl;
    
    if (s == NULL) return;
    
    panel = panelDetectors;
    ctrl  = DETECTORS_TREE_parameterSets;
    
	DETECTORS_fillNamesToTree (panel, ctrl, s);

	GetNumListItems (panel, ctrl, &nItems);
	if (nItems > 0) GetCtrlVal (panel, ctrl, &nr);
	d = DETECTIONPAR_ptr (s, nr);
	DETECTORS_setValues (s, d);
}




void DETECTORS_initPanel (void)
{

	int i;

	int nColumns;
	
	static int help2 = 1 + TABLE_NOT_CHANGE_COLORS;
		 
	if (panelDetectors != -1) return;
	
	panelDetectors = LoadPanel (0, SESSIONMANAGER_uirFile, DETECTORS); 
	panelDetectors = panelDetectors;
	
	ChainCtrlCallback (panelDetectors, DETECTORS_TABLE_windows, TABLE_processEvents_CB, &help2,
					   "TABLE_processEvents");

	SCONFIG_POSITIONS_initRingReference (panelDetectors, DETECTORS_RING_referencePos);
	SCONFIG_POSITIONS_initRingReference (panelDetectors, DETECTORS_RING_referencePos_2);
	
	// init sub panelDetectors "Levels"
	SetCtrlAttribute (panelDetectors, DETECTORS_NUMERIC_nLevels, ATTR_MAX_VALUE, MAX_LEVELS);
	SetTableRowAttribute (panelDetectors, DETECTORS_TABLE_levelNames,
						  LEVEL_TABLE_COL_NAME,
						  ATTR_MAX_ENTRY_LENGTH, MAX_LEVELNAME_LEN);
	
	GetNumTreeColumns (panelDetectors, DETECTORS_TREE_parameterSets, &nColumns);
	for (i = 0; i < nColumns-1; i++) {
		DeleteTreeColumn (panelDetectors, DETECTORS_TREE_parameterSets, -1);
	}
	
	// create new tree columns
	SetCtrlAttribute (panelDetectors, DETECTORS_TREE_parameterSets,
					  ATTR_COLUMN_LABELS_VISIBLE, 1);
	for (i = 1; i < N_TIMEINTERVAL_COL; i++) 
		InsertTreeColumn (panelDetectors, DETECTORS_TREE_parameterSets, -1, "");

	// set attributes for columns
	SetTreeColumnAttribute (panelDetectors, DETECTORS_TREE_parameterSets, DETECTIONPAR_COL_DETECTOR,
							ATTR_COLUMN_WIDTH, 30);
	SetTreeColumnAttribute (panelDetectors, DETECTORS_TREE_parameterSets, DETECTIONPAR_COL_DETECTOR, 
							ATTR_LABEL_TEXT, "det.");
	SetTreeColumnAttribute (panelDetectors, DETECTORS_TREE_parameterSets, DETECTIONPAR_COL_DETECTOR,
							ATTR_LABEL_JUSTIFY,
							VAL_CENTER_CENTER_JUSTIFIED);

	SetTreeColumnAttribute (panelDetectors, DETECTORS_TREE_parameterSets, DETECTIONPAR_COL_NAME,
							ATTR_COLUMN_WIDTH, 120);
	SetTreeColumnAttribute (panelDetectors, DETECTORS_TREE_parameterSets, DETECTIONPAR_COL_NAME, 
							ATTR_LABEL_TEXT, "name");

	SetTreeColumnAttribute (panelDetectors, DETECTORS_TREE_parameterSets, DETECTIONPAR_COL_ATOMS,
							ATTR_COLUMN_WIDTH, 120);
	SetTreeColumnAttribute (panelDetectors, DETECTORS_TREE_parameterSets, DETECTIONPAR_COL_ATOMS, 
							ATTR_LABEL_TEXT, "atoms");
	SetTreeColumnAttribute (panelDetectors, DETECTORS_TREE_parameterSets, DETECTIONPAR_COL_ATOMS,
							ATTR_LABEL_JUSTIFY,
							VAL_CENTER_CENTER_JUSTIFIED);
}


void DETECTORS_displayPanel (t_session *s)
{
	 DETECTORS_initPanel ();
	 DETECTORS_displayAll (s);
	 InstallPopup (panelDetectors);
}


void DETECTORS_setLevels (t_session *s)
{
	int nRows;
	int i;
	int panel, ctrl;

	panel = panelDetectors;
	ctrl  = DETECTORS_TABLE_levelNames;
	GetNumTableRows (panel, ctrl, &nRows);
	if (nRows > s->nLevels) 
		DeleteTableRows (panel, ctrl, s->nLevels, nRows - s->nLevels);
	if (nRows < s->nLevels) 
		InsertTableRows (panel, ctrl, -1, s->nLevels - nRows,VAL_USE_MASTER_CELL_TYPE);
	for (i = 0; i < s->nLevels; i++) {
		SetTableCellVal (panel, ctrl, MakePoint(LEVEL_TABLE_COL_NO, i+1), i+1);
		SetTableCellVal (panel, ctrl, MakePoint(LEVEL_TABLE_COL_NAME, i+1), s->levelNames[i]);
		SetTableCellVal (panel, ctrl, MakePoint(LEVEL_TABLE_COL_VOLTAGE, i+1), s->levelVoltages[i]);
	}
	SetCtrlVal (panel, DETECTORS_NUMERIC_nLevels, s->nLevels);
}


void DETECTORS_getLevels (t_session *s)
{
	int nRows;
	int i;
	int panel, ctrl;

	panel = panelDetectors;;
	ctrl  = DETECTORS_TABLE_levelNames;

	GetCtrlVal (panel, DETECTORS_NUMERIC_nLevels, &s->nLevels);

	GetNumTableRows (panel, ctrl, &nRows);
	for (i = 0; i < nRows; i++) {
		GetTableCellVal (panel, ctrl, MakePoint(LEVEL_TABLE_COL_NAME, i+1), s->levelNames[i]);
		GetTableCellVal (panel, ctrl, MakePoint(LEVEL_TABLE_COL_VOLTAGE, i+1), &s->levelVoltages[i]);
	}
}



void DETECTORS_displayAll (t_session *s)
{
	int dimmed;
	int panel;

	
	panel = panelDetectors;
	dimmed =  (ListNumItems (s->lDetectionParameters) == 0);
	SetAttributeForCtrls (panel, ATTR_DIMMED, dimmed, 0,
						  DETECTORS_STRING_name,
						  DETECTORS_RADIOBUTTON_det1,
						  DETECTORS_TEXTMSG_flat,
						  DETECTORS_RADIOBUTTON_det2,
						  DETECTORS_TEXTMSG_roof,
						  DETECTORS_BTN_deleteParameters,
						  
						  0);
	DETECTORS_setLevels (s);
	DETECTORS_displayAllNames (s);
}


	
//=======================================================================
//
//     clicked on an event name in Listbox 
//
//=======================================================================
int CVICALLBACK DETECTORS_listboxClicked (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	t_detectionParameters *activePar;
						 
	switch (event) {
		case EVENT_VAL_CHANGED:
		case EVENT_COMMIT:
            GetCtrlVal (panel, control, &nr);
			activePar = DETECTIONPAR_ptr (activeSession(), nr);
            DETECTORS_setValues (activeSession(), activePar);
			break;
	}
	return 0;
}


int CVICALLBACK DETECTORS_parameterChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	t_detectionParameters *activePar;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			GetCtrlVal (panelDetectors, DETECTORS_TREE_parameterSets, &nr);
			activePar = DETECTIONPAR_ptr (s, nr);
            DETECTORS_getValues (s, activePar);
			DETECTORS_displayAllNames (s);
            DETECTORS_setValues (s, activePar);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}


 CVICALLBACK DETECTORS_detectorChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	t_detectionParameters *activePar;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			GetCtrlVal (panelDetectors, DETECTORS_TREE_parameterSets, &nr);
			activePar = DETECTIONPAR_ptr (s, nr);
            DETECTORS_getValues (s, activePar);
//            DETECTORS_setValues (s, activePar);
			DETECTORS_displayAllNames (s);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}



int CVICALLBACK DETECTORS_new (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_detectionParameters *new;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
		    new = DETECTIONPAR_new (s);
		    DETECTIONPAR_init (new);
		    strcpy (new->name, "?");
 			DETECTORS_displayAll (s);
 			SetCtrlVal (panelDetectors, DETECTORS_TREE_parameterSets, 
 						ListNumItems (s->lDetectionParameters));
			SetActiveCtrl (panelDetectors, DETECTORS_STRING_name);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}

int CVICALLBACK DETECTORS_delete (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	t_detectionParameters *activePar;
	t_session *s;
	t_atom *a;
	int i;

	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
 			GetCtrlVal (panelDetectors, DETECTORS_TREE_parameterSets, &nr);
			activePar = DETECTIONPAR_ptr (s, nr);
			if (ConfirmPopupf ("Delete event",
							 "Do you really want to delete\nthe selected detection parameters '%s'?", 
							 activePar->name) == 0) return 0;							 
			DETECTIONPAR_delete (s, nr);

            for (i = 1; i <= ListNumItems(s->lAtoms); i++) {
	            a = ATOM_ptr (s, i);
		        if (a->detectionParameters == nr) a->detectionParameters = 0;
		        if (a->detectionParameters > nr)  a->detectionParameters--;
			}
			DETECTORS_displayAllNames (s);
 			GetCtrlVal (panelDetectors, DETECTORS_TREE_parameterSets, &nr);
			activePar = DETECTIONPAR_ptr (s, nr);
            DETECTORS_setValues (s, activePar);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}



					  
int CVICALLBACK DETECTORS_importButton (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *import, *s;
	int i;
	int index, checked;
	t_detectionParameters *source, *new;
	
	switch (event) {
		case EVENT_COMMIT:
			import = (t_session *) callbackData;
			// check if "done" pressed
			if (control == IMPORT_DET_COMMANDBUTTON_done) {
				s = activeSession();
				for (i = 1; i <= ListNumItems (import->lDetectionParameters); i++) {
					GetIndexFromValue (panel, IMPORT_DET_LISTBOX_names, &index, i);
					IsListItemChecked (panel, IMPORT_DET_LISTBOX_names, index, &checked);
					if (checked) {
						source = DETECTIONPAR_ptr (import, i); 
			    		new = DETECTIONPAR_new (s);
			    		DETECTIONPAR_duplicate (new, source);
					}
				}
			}
			SESSION_free (import);
			RemovePopup (0);    
			break;
	}
	return 0;
}




int CVICALLBACK DETECTORS_import (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int newPanel;
    char filename[MAX_PATHNAME_LEN];
    const char titleStr[] = "Import detection paramaters";
    static t_session *new;
	
	switch (event) {				
		case EVENT_COMMIT:
		    if (FileSelectPopup (smanagerConfig->defaultPath, "*.ses", "*.ses",
								 titleStr, VAL_LOAD_BUTTON, 0, 1, 1, 0,
								 filename) <= 0) return 0; 
		    new = SESSION_new ();
		    if (SESSION_load  (filename, new) == 0) {
				newPanel = LoadPanel (0, SESSIONMANAGER_uirFile, IMPORT_DET);
				SetCtrlAttribute (newPanel , IMPORT_DET_COMMANDBUTTON_done,
								  ATTR_CALLBACK_DATA, new);
				SetCtrlAttribute (newPanel , IMPORT_DET_COMMANDBUTTON_abort,
								  ATTR_CALLBACK_DATA, new);
				DETECTORS_fillNamesToListbox (newPanel, IMPORT_DET_LISTBOX_names, new);
				InstallPopup (newPanel);
			}
			else { 
				SESSION_free (new);
			}
			break;
	}
	return 0;
}





int CVICALLBACK DETECTORS_changeLevels (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	int nr;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			DETECTORS_getLevels (s);
			DETECTORS_setLevels (s);
 			GetCtrlVal (panelDetectors, DETECTORS_TREE_parameterSets, &nr);
//		   	ATOMS_fillLevelsToRing (panelDetectors, DETECTORS_RING_defaultLevel, s);
          
            DETECTORS_setValues (s, DETECTIONPAR_ptr (s, nr));
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}



int CVICALLBACK DETECTION_callback_done (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	
	switch (event)
		{
		case EVENT_COMMIT:
			s = activeSession();
			TIMEINTERVAL_calculateAll (s, 1,1);
//			PLOTITEM_displayTree (RUN_subPanelStd (),RUN_STD_TREE_plotItems, activeSession());
			RUN_setParameters (s, 0);
  			ATOMS_fillLevelsToRing (subPanelDetection(), ATOMS_DET_RING_voltDet2, s, 1);			
			ATOMS_DETECTOR_initPanel (s);
			ATOMS_displayAllValues (s);     
			RemovePopup (0);
		}
	return 0;
}

int CVICALLBACK DETECTION_callback_edit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			DETECTORS_displayPanel (activeSession());   
			break;
	}
	return 0;
}

