#if !defined (SESSIONMANAGER_GUI_MAIN)
#define SESSIONMANAGER_GUI_MAIN

int SESSIONMANAGER_initPanel (void);




#endif
