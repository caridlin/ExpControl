#include <userint.h>
#include "UIR_SessionManager.h"

#include "INCLUDES_SESSIONMANAGER.h"





int panelFilters = -1;
int panelMore = -1;

int panelFilterCriteria[MAX_FILTER_CRITERIA];
int FILTER_RING_intervalsFrom[N_DETECTORS] = {
		FCRITERION_RING1,
		0
	};
int FILTER_RING_intervalsTo[N_DETECTORS] = {
		FCRITERION_RING2,
		0
	};
	


int FILTERS_initPanel (void)
{
	int top, height;
	int i;
	

	SetCtrlAttribute (panelFilters, FILTERS_NUMERIC_nCriteria, ATTR_MAX_VALUE, MAX_FILTER_CRITERIA);
	SetCtrlAttribute (panelFilters, FILTERS_STRING_name,
					  ATTR_MAX_ENTRY_LENGTH, MAX_FILTERNAME_LEN-1);
	
	// init panel "filter criteria"
	panelFilterCriteria[0] = LoadPanel (panelFilters, SESSIONMANAGER_uirFile, FCRITERION);
	SetCtrlAttribute (panelFilterCriteria[0], FCRITERION_DECORATION, ATTR_TOP, 0);
	SetCtrlAttribute (panelFilterCriteria[0], FCRITERION_DECORATION, ATTR_LEFT, 0);
	top = ctrlBottom (panelFilters, FILTERS_NUMERIC_nCriteria) + 8;
	SetPanelPos (panelFilterCriteria[0], top, 0);
	height = ctrlHeight (panelFilterCriteria[0], FCRITERION_DECORATION);
	SetPanelSize (panelFilterCriteria[0],
				  height,
				  ctrlWidth  (panelFilterCriteria[0], FCRITERION_DECORATION));
	FILTER_RING_intervalsFrom[1] = DuplicateCtrl (panelFilterCriteria[0], FILTER_RING_intervalsFrom[0],
										 panelFilterCriteria[0], 0,
										 VAL_KEEP_SAME_POSITION,
										 VAL_KEEP_SAME_POSITION);
	FILTER_RING_intervalsTo[1] = DuplicateCtrl (panelFilterCriteria[0], FILTER_RING_intervalsTo[0],
										 panelFilterCriteria[0], 0,
										 VAL_KEEP_SAME_POSITION,
										 VAL_KEEP_SAME_POSITION);
	DisplayPanel (panelFilterCriteria[0]);
	
	for (i = 1; i < MAX_FILTER_CRITERIA; i++) {
		panelFilterCriteria[i] = DuplicatePanel (panelFilters, panelFilterCriteria[0],
												 0, top + i * height, 0);
		DisplayPanel (panelFilterCriteria[i]);
		
	}
	// -----------------------
	//    button "done"
	// -----------------------
/*	SetCtrlAttribute (panelFilters, FILTERS_COMMANDBUTTON_close,
					  ATTR_TOP, top + MAX_FILTER_CRITERIA * height + 10);
	SetPanelSize (panelFilters, 
				  ctrlBottom (panelFilters, FILTERS_COMMANDBUTTON_close) + 10,
				  panelWidth (panelFilterCriteria[0]));
	SetCtrlAttribute (panelFilters, FILTERS_COMMANDBUTTON_close,
					  ATTR_LEFT, 
					  panelWidth (panelFilters) -
					  ctrlWidth (panelFilters, FILTERS_COMMANDBUTTON_close) - 5);
					  
	SetCtrlAttribute (panelFilters, FILTERS_COMMANDBUTTON_close,
					  ATTR_LEFT, 
					  panelWidth (panelFilters) -
					  ctrlWidth (panelFilters, FILTERS_COMMANDBUTTON_close) - 5);
*/	// ----------------------------
	//    button "displayListOfTI"
	// ----------------------------
/*	SetCtrlAttribute (panelFilters, FILTERS_COMMANDBUTTON_listTI,
					  ATTR_LEFT, 
					  panelWidth (panelFilters) -
					  ctrlWidth (panelFilters, FILTERS_COMMANDBUTTON_listTI) - 10);
	SetCtrlAttribute (panelFilters, FILTERS_COMMANDBUTTON_listTI,
					  ATTR_TOP, 
					  top + MAX_FILTER_CRITERIA * height + 10);
					  
	SetPanelPos (panelFilters, VAL_AUTO_CENTER, VAL_AUTO_CENTER);

*/	
/////load more interval panel
	panelMore = LoadPanel (panelFilters,
									 SESSIONMANAGER_uirFile,
									 MoreInterv);
	SetPanelPos (panelMore, 200, 200);
	SetPanelAttribute (panelMore, ATTR_ZPLANE_POSITION, 0);
	DisplayPanel (panelMore);
	SetPanelAttribute (panelMore, ATTR_VISIBLE, 0);
	return 0;
}


char *FILTERCRITERION_listTimeIntervalsStr (t_session *s, t_filterCriterion *fc)
{
	static char help[200];
	int i;
	char *copyPos, *addStr;
	t_timeInterval *t;
	
	help[0] = 0;
	copyPos = help;
	
	for (i = 0; i < fc->nAdditionalTimeIntervals; i++) {
		t = TIMEINTERVAL_ptrList (s->lTimeIntervals[fc->detector], 
								  fc->additionalTimeIntervals[i]);
		if (t == NULL) addStr = "??"; 
		else addStr = t->idStr;
		if (i > 0) {
			copyPos[0] = ',';
			copyPos++;
		}
		strcpy (copyPos, addStr);
		copyPos += strlen (addStr);
	}
	return help;
}




void FILTERCRITERION_setValues (t_session *s, t_filterCriterion *fc, int panel)
{
	 SetCtrlVal (panel, FCRITERION_RADIOBUTTON_active, fc->active);
	 SetAttributeForCtrls (panel, ATTR_DIMMED, !fc->active, 0,
	 					   FCRITERION_RINGSLIDE_logic,
	 					   FCRITERION_NUMERIC_minCounts,
	 					   FCRITERION_NUMERIC_maxCounts,
	 					   FCRITERION_NUMERIC_detector,
	 					   FILTER_RING_intervalsFrom[0],
	 					   FILTER_RING_intervalsFrom[1],
	 					   FILTER_RING_intervalsTo[0],
	 					   FILTER_RING_intervalsTo[1],
	 					   FCRITERION_RADIOBUTTON_and,
	 					   FCRITERION_TEXTMSG_N,
	 					   FCRITERION_RADIOBUTTON_hasTo,
	 					   0);
	 SetCtrlVal (panel, FCRITERION_RINGSLIDE_logic, fc->logic);
	 SetCtrlVal (panel, FILTER_RING_intervalsFrom[0], fc->timeIntervalFrom[0]);
	 SetCtrlVal (panel, FILTER_RING_intervalsFrom[1], fc->timeIntervalFrom[1]);
	 SetCtrlVal (panel, FCRITERION_RADIOBUTTON_hasTo, fc->hasTimeIntervalTo);
	 SetCtrlVal (panel, FILTER_RING_intervalsTo[0], fc->timeIntervalTo[0]);
	 SetCtrlVal (panel, FILTER_RING_intervalsTo[1], fc->timeIntervalTo[1]);
	 
	 SetCtrlAttribute (panel, FCRITERION_STRING_editList, ATTR_DIMMED,
	 				   !fc->active || !fc->hasAdditionalTimeIntervals);
	 SetCtrlAttribute (panel, FCRITERION_COMMANDBUTTON_edit, ATTR_DIMMED,
	 				   !fc->active || !fc->hasAdditionalTimeIntervals);
	 SetCtrlVal (panel, FCRITERION_RADIOBUTTON_and, fc->hasAdditionalTimeIntervals);
	 SetCtrlVal (panel, FCRITERION_STRING_editList,
	 			 FILTERCRITERION_listTimeIntervalsStr (s, fc));
	 
	 SetCtrlVal (panel, FCRITERION_NUMERIC_minCounts, fc->minCounts);
	 SetCtrlVal (panel, FCRITERION_NUMERIC_maxCounts, fc->maxCounts);
	 SetCtrlVal (panel, FCRITERION_NUMERIC_detector, fc->detector+1);
	 if (fc->active) {
		 SetCtrlAttribute (panel, FILTER_RING_intervalsFrom[0], ATTR_VISIBLE, fc->detector == 0);
		 SetCtrlAttribute (panel, FILTER_RING_intervalsTo[0], ATTR_VISIBLE, fc->detector == 0);
		 SetCtrlAttribute (panel, FILTER_RING_intervalsTo[0], ATTR_DIMMED, !fc->hasTimeIntervalTo);
		 SetCtrlAttribute (panel, FILTER_RING_intervalsFrom[1], ATTR_VISIBLE, fc->detector == 1);
		 SetCtrlAttribute (panel, FILTER_RING_intervalsTo[1], ATTR_VISIBLE, fc->detector == 1);
		 SetCtrlAttribute (panel, FILTER_RING_intervalsTo[1], ATTR_DIMMED, !fc->hasTimeIntervalTo);
	 }
}


void FILTERCRITERION_getValues (t_filterCriterion *fc, int panel)
{
	 GetCtrlVal (panel, FCRITERION_RADIOBUTTON_active, &fc->active);
	 GetCtrlVal (panel, FCRITERION_RINGSLIDE_logic, &fc->logic);
	 GetCtrlVal (panel, FCRITERION_NUMERIC_minCounts, &fc->minCounts);
	 GetCtrlVal (panel, FCRITERION_NUMERIC_maxCounts, &fc->maxCounts);
	 GetCtrlVal (panel, FCRITERION_NUMERIC_detector, &fc->detector);
	 fc->detector --;
	 GetCtrlVal (panel, FILTER_RING_intervalsFrom[0], &fc->timeIntervalFrom[0]);
	 GetCtrlVal (panel, FILTER_RING_intervalsFrom[1], &fc->timeIntervalFrom[1]);
	 GetCtrlVal (panel, FCRITERION_RADIOBUTTON_hasTo, &fc->hasTimeIntervalTo);
	 GetCtrlVal (panel, FILTER_RING_intervalsTo[0], &fc->timeIntervalTo[0]);
	 GetCtrlVal (panel, FILTER_RING_intervalsTo[1], &fc->timeIntervalTo[1]);
	 GetCtrlVal (panel, FCRITERION_RADIOBUTTON_and, &fc->hasAdditionalTimeIntervals);
	 
	 
}

				   

char *FILTERS_usedByPlotItemStr (t_session *s, int filterID)
{
	int i,j;
	t_plotItem *p;
	int nFilters;
	char *str;
	char *copyPos;
	int len;
	int used;
	
	str = getTmpStr(); 
	copyPos = str;
	
	if (s == NULL) return str;
	if (filterID == 0) return str;
	
	for (i = ListNumItems (s->lPlotItems); i >= 1; i--) {
		used = 0;
		ListGetItem (s->lPlotItems, &p, i);
		if (p->dataFilterID == filterID) used = 1;
		else if (p->correlationsFilterIDOneAtom == filterID) used = 1;
		else {
			// delete ref to filter in correlation
			nFilters = 1 << p->correlationsNAtoms;
			for (j = 0; (j < nFilters) && !used; j++) {
				if (p->correlationsFilterID[j] == filterID) used = 1;
			}
		}
		if (used) {
			if (copyPos != str) {
				copyPos[0] = ',';
				copyPos++;
			}
			strncat (copyPos, p->name, 10);
			len = strlen (p->name);
			copyPos += min (len, 10);
		}
	}
	return str;
}




void FILTERS_setValues (t_session *s, int nr)
{
	t_filter *f;
	int i;
	
	if (nr <= 0) f = NULL;
	else f = FILTER_ptr (s, nr);

	SetAttributeForCtrls (panelFilters, ATTR_DIMMED, f == NULL, 0,
						  FILTERS_LISTBOX_filters,
						  FILTERS_STRING_name,
						  FILTERS_STRING_usedByPlotitem,
						  FILTERS_BTN_deleteFilter,
						  FILTERS_RING_otherDataFilter,
						  FILTERS_NUMERIC_nCriteria, 0);
	for (i = 0; i < MAX_FILTER_CRITERIA; i++) {
		SetPanelAttribute (panelFilterCriteria[i], ATTR_DIMMED, 
						   (f == NULL) || (i >= f->nFilterCriteria));
		SetPanelAttribute (panelFilterCriteria[i], ATTR_VISIBLE, 
						   (f != NULL) && (i < f->nFilterCriteria));
		if (f != NULL) FILTERCRITERION_setValues (s, &f->criterion[i], panelFilterCriteria[i]);		
	}
	
	if (f == NULL) return;
	
	SetCtrlVal (panelFilters, FILTERS_STRING_name, f->name);
	SetCtrlVal (panelFilters, FILTERS_RING_otherDataFilter, f->otherFilterID);

	SetCtrlVal (panelFilters, FILTERS_NUMERIC_nCriteria, f->nFilterCriteria);
	SetCtrlVal (panelFilters, FILTERS_STRING_usedByPlotitem,  
			    FILTERS_usedByPlotItemStr (s, nr));
	SetCtrlVal (panelFilters, FILTERS_LISTBOX_filters, nr);
}
	



int FILTER_nameExists (t_session *s, char *name, int nr)
{
	int i;
	t_filter *f2;
	
	for (i = 1; i <= ListNumItems(s->lFilters); i++) {
		if (i != nr) {
			f2 = ListGetPtrToItem (s->lFilters, i);
			if (strcmp (f2->name, name) == 0) return 1;
		}
	} 
	return 0;
}

//=======================================================================
//
//    get values of filter from 
//
//=======================================================================
void FILTERS_getValues (t_session *s, int nr)
{
	t_filter *f;
	int i;
	
	f = FILTER_ptr (s, nr);
	if (f == NULL) return;

	GetCtrlVal (panelFilters, FILTERS_STRING_name, f->name);
	if (FILTER_nameExists (s, f->name, nr)) {
		do strcat (f->name, "_"); while (FILTER_nameExists (s, f->name, nr));
		MessagePopupf ("Warning!", "Duplicate filter names are not allowed.\n"
					   "Name has been changed to '%s'.",  f->name);
	}
	GetCtrlVal (panelFilters, FILTERS_NUMERIC_nCriteria, &f->nFilterCriteria);
	GetCtrlVal (panelFilters, FILTERS_RING_otherDataFilter, &f->otherFilterID);

	for (i = 0; i < MAX_FILTER_CRITERIA; i++) {
		FILTERCRITERION_getValues (&f->criterion[i], panelFilterCriteria[i]);		
	}
}
	




//=======================================================================
//
//    display all AnalogBlock names in a listbox
//
//=======================================================================
void FILTERS_fillNamesToList (int panel, int control, t_session *s, int addNone)
{
    int i, n;
    t_filter *f;
    char help[MAX_FILTERNAME_LEN + 100];
    
	n = ListNumItems (s->lFilters);
	setNumListItems (panel, control, n+addNone);
	if (addNone) ReplaceListItem (panel, control, 0, "NONE", 0);
	for (i = 1; i <= n; i++) {
		f = FILTER_ptr (s, i);
		help[0] = 0;
		strcat (help, f->name);
		strcat (help, strSpace50);
		ReplaceListItem (panel, control, i-1+addNone, help, i);
	}
}



void FILTERS_displayAll (t_session *s)
{
	int i, det;
	
	for (i = 0; i < MAX_FILTER_CRITERIA; i++) {
		for (det = 0; det < N_DETECTORS; det ++) {
			TIMEINTERVAL_fillToRing (panelFilterCriteria[i], FILTER_RING_intervalsFrom[det], s, det);
			TIMEINTERVAL_fillToRing (panelFilterCriteria[i], FILTER_RING_intervalsTo[det], s, det);
		}
	}
	FILTERS_fillNamesToList (panelFilters, FILTERS_LISTBOX_filters, s, 0);
	FILTERS_fillNamesToList (panelFilters, FILTERS_RING_otherDataFilter, s, 1);
    FILTERS_setValues (s, 1);
}



void FILTERS_displayPanel (t_session *s)
{
	 FILTERS_initPanel ();
	 FILTERS_displayAll (s);
//	 InstallPopup (panelFilters);
}





int CVICALLBACK FILTER_ParameterEdited (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlVal (panelFilters , FILTERS_LISTBOX_filters, &nr);
			s = activeSession();
			FILTERS_getValues (s, nr);
        	switch (control) {
        		case FILTERS_STRING_name:
        	   		FILTERS_fillNamesToList (panelFilters, FILTERS_LISTBOX_filters, s, 0);
       				FILTERS_fillNamesToList (panelFilters, FILTERS_RING_otherDataFilter, s, 1);
        	   		break;
        	}
            FILTERS_setValues (s, nr);
			break;
	}
	return 0;
}




//=======================================================================
//
//     clicked on a filter name
//
//=======================================================================
int CVICALLBACK FILTERS_listboxCLicked (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr;
	

	switch (event) {
		case EVENT_VAL_CHANGED:
		case EVENT_COMMIT:
            GetCtrlVal (panel, control, &nr);
            FILTERS_setValues (activeSession(), nr);
			break;
	}
	return 0;
}



int CVICALLBACK FILTER_deleteFilter_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
    int nr;
    t_session *s;
    t_filter *f;
		
  	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal (panelFilters , FILTERS_LISTBOX_filters, &nr);
			s = activeSession();
			f = FILTER_ptr (s, nr);
			if (f == NULL) return 0;
			if (ConfirmPopupf ("Delete filter",
							 "Do you really want to delete\nfilter '%s'?", f->name) == 0) return 0;							 
			FILTER_delete (s, nr);
        	FILTERS_fillNamesToList (panelFilters , FILTERS_LISTBOX_filters, s, 0);
        	FILTERS_fillNamesToList (panelFilters, FILTERS_RING_otherDataFilter, s, 1);
		    if (nr > 1) nr --;
            FILTERS_setValues (s, nr);
            
			SESSION_setChanges (s, 1);
			break;
		}
	return 0;
}



//=======================================================================
//
//      new filter
//
//=======================================================================
int CVICALLBACK FILTER_newFilter_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
    t_filter *new;
    t_session *s;
    int nr;

	switch (event)
		{
		case EVENT_COMMIT:
		    s = activeSession();
		    new = FILTER_new (s);
		    new->nFilterCriteria = 1;
		    nr = ListNumItems (s->lFilters);
		    do {
    			sprintf (new->name, "filter %d", nr);
    			nr++;
    		} while (FILTER_nameExists (s, new->name, 0));
        	FILTERS_fillNamesToList (panelFilters, FILTERS_LISTBOX_filters, s, 0);
        	FILTERS_fillNamesToList (panelFilters, FILTERS_RING_otherDataFilter, s, 1);
			FILTERS_setValues (s, ListNumItems (s->lFilters));
			SetActiveCtrl (panelFilters , FILTERS_STRING_name);
			SESSION_setChanges (s, 1);
			break;
		}
	return 0;
}



int CVICALLBACK FILTER_displayListOfTimeIntervals_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			RUN_displayListOfTimeIntervalsInNewWindow (activeSession());
			break;
	}
	return 0;
}



int CVICALLBACK FILTER_editListTimeIntervals_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			SetPanelAttribute (panelMore, ATTR_ZPLANE_POSITION, 0);
			SetPanelAttribute (panelMore, ATTR_VISIBLE, 1);
			break;
		}
	return 0;
}


int CVICALLBACK panelMore_close_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			SetPanelAttribute (panelMore, ATTR_VISIBLE, 0);
			break;
		}
	return 0;
}
