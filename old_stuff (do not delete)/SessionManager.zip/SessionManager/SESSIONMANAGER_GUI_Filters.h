
#if !defined (SESSIOMANAGER_GUI_FILTERS)
#define SESSIOMANAGER_GUI_FILTERS


int FILTERS_initPanel (void);

void FILTERS_displayAll (t_session *s);

void FILTERS_displayPanel (t_session *s);

void FILTERS_fillNamesToList (int panel, int control, t_session *s, int addNone);

t_filter *FILTER_getCorrelationFilter (t_session *s, int plotItemNr, int atom, int level);


#endif
