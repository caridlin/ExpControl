#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"


void CURVE_setStyle (t_curve *c, t_plotItem *p, int autoColor); 
void CURVE_setStyleCurrent (t_curve *c, t_plotItem *p, int evenRepetition);





extern t_run *activeRun;


int speedMode = 1;


//int panelVelocity = -1;
//int panelArrTimes = -1;
//int panelTransfer = -1;
//int panelCounts   = -1;


void COUNTERDATA_print (int panel, int ctrl, t_counterData *r)
{
	int i;
	
//	SetCtrlVal (panelAcq, AMAIN_NUMERIC_nShots, r->nShots+1);
	
	for (i = 0; i < r->nCurves; i++)
	{
//		 pprintf (panel, ctrl, arrayToStr (r->counts[i], r->nCounts[i]));
	}
	
}



t_counterData *COUNTERDATA_getDataset (t_run *r, int run, int repetition, int counter)
{
	int index;
	
	if (r->data[counter] == NULL) return NULL;
	index = RUN_datasetIndex (r, run, repetition);
	return r->data[counter][index];
}


double COUNTERDATA_sumInterval (t_counterData *d, int timeInterval, unsigned __int64 *sumI64, unsigned *nSummed)
{
	int nSteps;
	int k;
	unsigned __int64 sum;  
	
	*nSummed = 0;
	if ((d == NULL) || (d->error != 0)) {
		if (sumI64 != NULL) *sumI64 = 0;
		return 0.0;
	}
	
	sum = 0;
	if (d->counts != NULL) {
		if (timeInterval == d->nTimeIntervals) *nSummed = d->nCounts / d->nTimeIntervals - 1;
		else *nSummed = d->nCounts / d->nTimeIntervals;
		for (k = 0; k < *nSummed; k++) {
			// check if filter criteria are met
			sum += d->counts[k*d->nTimeIntervals + timeInterval];
		}
	}
	
	if (sumI64 != NULL) *sumI64 = sum;
	return ui64toDouble (sum);
}


double COUNTERDATA_averageInterval (t_counterData *d, int timeInterval)
{
	  return 0;
}


void FILTERS_setKeepResults (t_session *s, int keep)
{
	t_filter *f;
	int i;
	
	for (i = ListNumItems (s->lFilters); i > 0; i--) {
	  	ListGetItem (s->lFilters, &f, i);
	  	f->keepFilteredDataInResults = keep;
	}
}



int FILTER_criteriaMet (t_filter *f, t_counterData **data, int k, int checkForOtherFilter)
{
	int criteriaMet;
	// data: counterData of detector 1 and 2
	t_filterCriterion *fc;
	int fcDet;
	unsigned compareCounts;
	int i, j, nIntervals;
	int from, to;
	int interval;
	
	criteriaMet = 1;
	
	for (i = 0; i < f->nFilterCriteria; i++) {
		fc = &f->criterion[i];
		if (fc->active) {
			fcDet = fc->detector;
			if (data[fcDet] != NULL) {
				nIntervals = data[fcDet]->nTimeIntervals;
				
				// get intervals 'from' --> 'to' to count
				from = fc->timeIntervalFrom[fcDet];
			    if (fc->hasTimeIntervalTo) {
					to = fc->timeIntervalTo[fcDet];
					if (to < from) swapInt (&from, &to);
				}
				else {
					to = fc->timeIntervalFrom[fcDet];				
				}
				
				if ((from < nIntervals) && (to < nIntervals)) {
					// valid time intervals
					compareCounts = 0;
					
					// sum all counts in relevant time intervals
					for (interval = from; interval <= to; interval++) {
						compareCounts += data[fcDet]->counts[k*nIntervals + interval];
					}
					
					// sum counts in other time intervals
					if (fc->hasAdditionalTimeIntervals) {
						for (j = 0; j < fc->nAdditionalTimeIntervals; j++) {
							interval = fc->additionalTimeIntervals[j];
							if ((interval < nIntervals ) && ((interval < from) || (interval > to))) {
								// add, if interval valid and not already counted before
								compareCounts += data[fcDet]->counts[k*nIntervals + interval];
							}
						}
				
					}
					criteriaMet = ((compareCounts >= fc->minCounts) && (compareCounts <= fc->maxCounts));
					criteriaMet ^= fc->logic;
				}
				else criteriaMet = 0;
			}
			if (!criteriaMet) return 0;
		}
		
	}
	if (checkForOtherFilter && (f->otherFilterID != 0)) {
		if (f->otherFilterPtr == f) return 1;
		return FILTER_criteriaMet ((t_filter *) f->otherFilterPtr, data, k, 0);
	}
	return 1;
}

/*
void FILTERRESULTS_calculateStdDev (t_filterResults *fr)
{
	int k;
	double var, help;
	// -----------------------------		
	//   	calculate standard deviation
	// -----------------------------		
	if (fr->countsArray == NULL) return;
	if (fr->nSummedDatasets < 1) return;
	
	var = 0;
	// calculate sum of squared deviations from mean
	for (k = 0; k < fr->nSteps; k++) {
		if (fr->countsArray[k] >= 0) {			
			help = fr->average - 1.0 * fr->countsArray[k];
			var += help * help;
		}

	}
	// calculate standard deviation
	fr->stdDev = sqrt (var / (fr->nSummedDatasets - 1));
	// calculate standard error 
	fr->stdErr = fr->stdDev / sqrt (fr->nSummedDatasets); 		
}
*/




void FILTERRESULTS_sum (t_filterResults *rSum, t_filterResults *resultToAdd)
{
	rSum->sum 		      += resultToAdd->sum;
	rSum->sumSquares      += resultToAdd->sumSquares;
	rSum->nSummedDatasets += resultToAdd->nSummedDatasets;
}


void FILTERRESULTS_calculateAverage (t_filterResults *fr)
{
	double dSum, dSumSquares, dN;
 	
	// ---------------------------
	//     calculate average 
	// ---------------------------
	if (fr->nSummedDatasets != 0) {
		fr->average = (1.0 * ui64toDouble (fr->sum)) / fr->nSummedDatasets;
	}		
	// 
	// -----------------------------		
	//   	calculate standard deviation
	//
	// quick formula, see:
	// http://de.wikipedia.org/wiki/Standardabweichung
	// -----------------------------		
	if (fr->nSummedDatasets < 1) return;
	
	// convert to double (in order to prevent overflow and rounding Errors)
	dSumSquares = ui64toDouble (fr->sumSquares);
	dSum        = ui64toDouble (fr->sum);
	dN 			= fr->nSummedDatasets;
	fr->stdDev = sqrt ((dN * dSumSquares - dSum * dSum) / (dN - 1));
	// calculate standard error 
	fr->stdErr = fr->stdDev / sqrt (dN); 		

}

int FILTER_apply (t_filter *f, t_counterData *d, t_filterResults *fr)
{
	int i, k;
	unsigned __int64 counts;
	int criteriaMet;
	t_counterData* data[N_DETECTORS];
	t_counterData* dataOther;

	FILTERRESULTS_init (fr);
	if (d == NULL) return -1;
	if (f == NULL) return -1;
	// maybe data of detector 1 is filtered conditionned to data of detector 2
	// or the other way round
	data[0] = NULL;
	data[1] = NULL;
	dataOther = (t_counterData*) d->dataOtherDetector;
	if (dataOther != NULL) data[dataOther->detector] = dataOther;
	data[d->detector] = d;
	

	if (d->nTimeIntervals == 0) return -1;
	// invalid number of counts
	if (d->nCounts % d->nTimeIntervals != 0) return -1;

	// -----------------------------------------
	//   calculate number of steps
	//   note: last count is not registered
	// ------------------------------------------
	fr->nSteps = d->nCounts / d->nTimeIntervals;
	if ( (f->timeIntervalToCountStart == d->nTimeIntervals) 
		||(f->timeIntervalToCountStop == d->nTimeIntervals))
		fr->nSteps = d->nCounts / d->nTimeIntervals - 1;
	if (fr->nSteps == 0) return -1;
	
	
	// everyting ok: start execution of filter
	fr->executed = 1;
	
	// keepResults
	if (f->keepFilteredDataInResults) {
		fr->countsArray = (int *) malloc (sizeof(int) * fr->nSteps);
	}
	
	// -----------------------------		
	// 		calculate sum:
	// -----------------------------
	for (k = 0; k < fr->nSteps; k++) {
		// check if filter criteria are met
		if (FILTER_criteriaMet (f, data, k, 1)) {
			counts = 0;
			for (i = f->timeIntervalToCountStart; i <= f->timeIntervalToCountStop; i++) {
				counts += d->counts[k*d->nTimeIntervals + i];
			}
			fr->sum += counts;
			fr->sumSquares += counts * counts;
			fr->nSummedDatasets ++;
		}
		else counts = -1; // criteria not met
		if (f->keepFilteredDataInResults) fr->countsArray[k] = counts;
	}
	
	FILTERRESULTS_calculateAverage (fr);
	// remember for which dataset the filter was applied
	fr->dataID = d->dataID;

	return 0;

}



// apply filter to counterdata
// and return pointer to filter with  
//  contains the calculated data


int COUNTERDATA_applyFilter (t_counterData *d, int resultsIndex, t_filter *fs, t_filterResults *fr)
{
	FILTERRESULTS_init (fr);
	if (fs == NULL) return -1;
	if (d == NULL) return -1;
	if (d->error != 0) return 0;
	if (resultsIndex >= d->nFilterResults) return -1;
	if (resultsIndex < 0) return -1;
	FILTER_apply (fs, d, &d->filterResults[resultsIndex]);
	*fr = d->filterResults[resultsIndex];
	if (fr->executed) return 0;
	else return -1;
}




/*
int COUNTERDATA_sumAllRuns (t_run *r, t_counterData *d, int resultsIndex, t_filterResults *rSum)
{
	int i;
	t_counterData *d2;
	
	FILTERRESULTS_init (rSum);
	for (i = 0; i < r->nRuns; i++) {
		d2 = COUNTERDATA_getDataset (r, i, d->repetition, d->counterNr);
		if ((d2 != NULL) && (resultsIndex < d2->nFilterResults) && (d2->error == 0)) {
			FILTERRESULTS_sum (rSum, &d2->filterResults[resultsIndex]);
		}
	}
	FILTERRESULTS_calculateAverage (rSum);
	return 0;
}
*/


int COUNTERDATA_sumAllRuns (t_run *r, int repetition, int counter, int resultsIndex, t_filterResults *rSum)
{
	int i;
	t_counterData *d2;
	
	FILTERRESULTS_init (rSum);
	for (i = 0; i < r->nRuns; i++) {
		d2 = COUNTERDATA_getDataset (r, i, repetition, counter);
		if ((d2 != NULL) && (resultsIndex < d2->nFilterResults) && (d2->error == 0)) {
			FILTERRESULTS_sum (rSum, &d2->filterResults[resultsIndex]);
		}
	}
	FILTERRESULTS_calculateAverage (rSum);
	return 0;
}




int COUNTERDATA_calculatePlotItem (t_run *r, t_counterData *d, int repetition, int det, int plotItemNr, int sumAllRuns)
{
	t_filter *f;
	t_plotItem *p;
	t_session *s;
	
	s = r->session;
	p = PLOTITEM_ptr (s, plotItemNr);
	if (p == NULL) return -1;

	if (d != NULL) {
		if (!p->active) return -1;
		if (p->transfer) return -1;
		d->nTimeIntervals = ListNumItems (r->lTimeIntervals[det]);
		f = FILTER_ptr (s, p->dataFilterID);
		if (p->dataFilterID == 0) f->criterion[0].detector = det;
		p->filter = f;
		f->timeIntervalToCountStart = p->interval[det];
		f->timeIntervalToCountStop  = p->interval[det];
		f->otherFilterPtr = FILTER_ptr (s, f->otherFilterID);
		COUNTERDATA_applyFilter (d, plotItemNr-1, f, &p->filterResultsCurrent);
		p->hasDataCalculated = 1;
	}
//	if (TIMEINTERVAL_ptrList (s->lTimeIntervals[det], f->timeIntervalToCountStart) == NULL) return -1;
//  if (TIMEINTERVAL_ptrList (s->lTimeIntervals[det], f->timeIntervalToCountStop) == NULL) return -1;
	
	if (sumAllRuns) {
		FILTERRESULTS_init (&p->filterResultsAll);
		if (COUNTERDATA_sumAllRuns (r, repetition, COUNTERS_NCOUNTS[det], plotItemNr-1, &p->filterResultsAll) != 0) return -1;
//		p->hasDataCalculated = 1;

	}
	
	return 0;
}


/*
double COUNTERDATA_averageTimeInterval (t_counterData *d, int timeInterval, int plotItemNr)
{
	if (COUNTERDATA_calculateTimeInterval (d, timeInterval, plotItemNr) != 0) return 0;
	return d->filterResults[plotItemNr].average;
}


double COUNTERDATA_sumTimeInterval (t_counterData *d, 
								    int timeInterval,
	                                int *nSummed,
	                                int plotItemNr)
{
	if (nSummed != NULL) *nSummed = 0;
	if (COUNTERDATA_calculateTimeInterval (d, timeInterval, plotItemNr) != 0) return 0;
	if (nSummed != NULL) *nSummed = d->filterResults[plotItemNr].nSummedDatasets;
	return ui64toDouble (d->filterResults[plotItemNr].sum);
}



void COUNTERDATA_sumAllDatasets (t_run *r, 
							 int repetition, int counter, 
							 int nTimeIntervals,
							 int timeInterval,
						 	 double *sum, int *nSummed)
{
	int i;
	int index;
	
	t_counterData *d;
	unsigned __int64 totalSum;
	unsigned __int64 totalSteps;
	int nDataSets;
	
	t_filter fSum;
	t_filter *f; // result
	
	FILTER_init (&fSum);
	nDataSets = 0;	
	totalSum   = 0;
	totalSteps = 0;
	if (sum != NULL) *sum = 0;
	if (nSummed != NULL) *nSummed = 0;

	if (timeInterval > nTimeIntervals) return;
	if (r->data[counter] == NULL) return;
	// ---------------------------
	//    create filter
	// ---------------------------
	fSum.timeIntervalToEvaluate = timeInterval;
	
	// -------------------------------------------------
	//      sum time intervals of different datasets
	//      of all runs
	// -------------------------------------------------
	for (i = 0; i < r->nRuns; i++) {
		index = RUN_datasetIndex (r, i, repetition);
		d = r->data[counter][index];
		if (d != NULL) {
			d->nTimeIntervals = nTimeIntervals;
			FILTER_applyToCounterData (&fSum, d, -1);
			if (f != NULL) {
//				totalSum   += f->sum;
//				totalSteps += f->nSummedDatasets;
				nDataSets ++;
			}
		}
	}
//	if ((totalSteps > 0)  && (average != NULL)) 
//		*average = ui64toDouble (totalSum / totalSteps);
	if (nSummed != NULL) *nSummed = totalSteps;
	if (sum != NULL) *sum = ui64toDouble (totalSum);
}
*/



int COUNTERDATA_copyReceivedData (t_counterData *data, char *buffer, unsigned buffersize)
{
	IniText ini;
	FILE *file;
	
	ini = Ini_New (0);
	Ini_SetDuplicateChecking (ini, 0);
	
	Ini_ReadFromBuffer (ini, buffer, buffersize);
	Ini_GetCounterData (ini, data, 0);
//	Ini_DisplayContents (ini, 1);
	

	Ini_Dispose (ini);
	return 0;
}



int COUNTERDATA_saveFile (char *buffer, unsigned buffersize)
{
   	unsigned l;
   	int error;
   	
   	l = strlen(buffer)+1;
	error = saveBufferToFile (buffer, &buffer[l], buffersize-l);
	return error;
}






t_graph *RUN_createPlotGraphAxes (t_run *r, t_plotItem *p)//, const char *graphName, const char *units)
{
	t_graph *w;
	t_session *s;
	t_sweep *sw;
	
	s = r->session;	
	sw = r->sweep;
	PLOTITEM_getPanelTitle (s, p, sw->plotAxisName);
	w = GRAPH_getFromTitle (p->panelTitle, p->type);
	if (w != NULL) {
		// graph existed already:
		if (p->panelPos.width < 0) p->panelPos = getPanelBounds (w->panelHandle);
		return w;
	}

	w = GRAPH_newPlotWindow (0, p->panelTitle);
	w->plotType = p->type;
	strcpy (w->xLabel, sw->plotAxisName);
	strcpy (w->xUnits, sw->units);
	if (strcmp (w->xUnits, "�s") == 0) w->xDigits = 2;
	if (strcmp (w->xUnits, "V") == 0) w->xDigits = 3;

	strcpy (w->xAsciiFileColumnLabel, sw->quantity);

	w->yFrom 		  = 0;
	w->yToAutoscale   = 1;
	if (p->transfer) {
		strcpy (w->yLabel, "transfer");
		strcpy (w->yAsciiFileColumnLabel, "transfer");
		strcpy (w->yUnits, "");
		w->yTo 			  = 1;
		w->yToAutoscale   = 0;
		w->yFromAutoscale = 0;
		w->yDigits = 4;
	}
	else {
		strcpy (w->yLabel, "counts / curve");
		strcpy (w->yAsciiFileColumnLabel, "counts");
		strcpy (w->yUnits, "");
	}

	switch (p->type) {
		case PLOT_TYPE_DIG:
			w->defaultPos = PANEL_POS_FULLSIZE; 
			strcpy (w->xLabel, "voltage detector");
			strcpy (w->xUnits, "voltage");
//			strcpy (w->yUnits, "counts");
//			w->xFromAutoscale = 1;
//			w->xToAutoscale   = 1;
			w->yFromAutoscale = 0;
			w->showSlider_number = 1;
			w->xDigits = 3;
			break;
		case PLOT_TYPE_VELOCITYDIST:
			w->defaultPos = PANEL_POS_TOP_RIGHT; 
//			strcpy (w->yLabel, "counts");
			strcpy (w->xLabel, "velocity");
			strcpy (w->xUnits, "m/s");
			w->yFromAutoscale = 0;
			w->xDigits = 2;
			break;

		case PLOT_TYPE_ARRIVALTIMES:
			w->defaultPos = PANEL_POS_TOP_LEFT; 
//			strcpy (w->yLabel, "counts");
			strcpy (w->xLabel, "time");
			strcpy (w->xUnits, "�s");
			strcpy (w->xAsciiFileColumnLabel, "time");
			w->yFromAutoscale = 0;
			w->xDigits = 2;
			break;
		case PLOT_TYPE_NCOUNTS:
			w->yFromAutoscale = 0;
			if (p->transfer) w->defaultPos = PANEL_POS_BOTTOM_LEFT; 
			else w->defaultPos = PANEL_POS_BOTTOM_RIGHT; 
			break;
		case PLOT_TYPE_MULTIPLE_AS_INDEX:
			strcpy (w->xLabel, "time");
			strcpy (w->xUnits, "ms");
			strcpy (w->xAsciiFileColumnLabel, "time");
			strcpy (w->yLabel, "counts");
			w->xDigits = 0;
			break;
			
	}	
	GRAPH_positionPanel (w, p->panelPos);
	return w;
}



void RUN_averageCurve_DIG (t_curve *c, int *nAveragesToDo)
{
	int i;
	double add;

	if (c == NULL) return;
	
	if (*nAveragesToDo < 0) {
		// -----------------------
		//    new curve created
		// -----------------------
	//	if (c->nAveraged == 0) {
			c->plotStyle = VAL_FAT_LINE;
			c->lineStyle = VAL_DASH;
			for (i = 0; i < c->nValues; i++) c->yValuesAveraged[i] = 0;
			c->averagedOnTop = 1;
//		}
		c->nValuesVisibleAvg = c->nValues;
		c->nAveraged = 0;
	}
	*nAveragesToDo = abs(*nAveragesToDo);

	if (*nAveragesToDo > 0) {
		for (i = 0; i < c->nValues; i++) {
			add = c->yValuesAveraged[i] * c->nAveraged;
			c->yValuesAveraged[i] = (add + c->yValues[0][i]) / (c->nAveraged + 1);
		}
		c->nAveraged ++;
		(*nAveragesToDo) --;
		c->plotColor = (*nAveragesToDo == 0) ? CURVE_colorAuto_DIG(c) :  VAL_GREEN ;
		if (*nAveragesToDo % 10 == 0) CURVE_getMinMax (c);
		c->keep = 1;
	}
}


// -----------------------------------------------------
// -----------------------------------------------------
//              create curve: DIG
// -----------------------------------------------------
// -----------------------------------------------------

void RUN_createPlot_DIG (t_run *r)
{
	t_curve *c;
	t_graph *w;
	char strCurveName[30];
	int i, k;
	t_counterData *data;
	int nTimeIntervals;
	char *help;
	unsigned avg;
	t_plotItem *p;
	int index;


	
	p = PLOTITEM_dig (r->session);
	data = r->lastData;
	if (data == NULL) return;
	if (data->error) return;
	
	SetCtrlVal (panelDig(), RUN_DIG_NUMERIC_nAveragesDone, abs(r->nAveragesToDo));


	nTimeIntervals = ListNumItems (r->lTimeIntervals[data->detector]);
	k = r->sweep->nPoints*nTimeIntervals*r->sweep->stepRepetitions;
	if (k != data->nCounts) {					  
		help= getTmpString ();
		sprintf (help, "WRONG NUMBER OF GATE SIGNALS (%d expected but %d detected)",
					   k, data->nCounts);
		data->error    = COUNTER_ERROR_WRONG_GATE;
		data->errorStr = strnewcopy (data->errorStr, help);
		return;
	}
	
	w = RUN_createPlotGraphAxes(r, p);//, r->sweep->plotAxisName, r->sweep->units);
// ----------------------------------------------------
//    create curve 
// ----------------------------------------------------
	sprintf (strCurveName, "DIG detector %d", data->detector+1);
	
	c = CURVE_create (w, strCurveName, r->sweep->nPoints, 0);
	c->active = 1;
	c->startNr = r->startNr;
	if (data->repetition == 0) p->keepCurve = 0;
//	c->keep = p->keepCurve;

	if (c->newCurve) {
//		c->plotStyle = VAL_FAT_LINE;
//		c->plotColor = CURVE_DIG_COLOR;
		c->plotColorCurrent = CURVE_DIG_COLOR;
		c->plotStyleCurrent = VAL_FAT_LINE;
		w->newGraph = 1;
		c->newCurve = 0;
		CURVE_allocateMemoryRun (c, 1);
		CURVE_allocateMemoryForOneCurve (c, 0, c->nValues);
		c->currentCurve = 0;
		c->yValuesVisible[0] = 0;
		c->keep = 0;
	}
//	if (c->plotItem == NULL) {
 // debug stefan 050405
		c->xFrom = r->sweep->from;
		c->xTo   = r->sweep->to;
		CURVE_setXValues (c, 1);		
		c->plotItem = p;
		c->showCurrentCurve = 1;
		w->sliderCurve = c;
//	}
	c->sumYValues = 0;
	for (i = 0; i < c->nValues; i++) {
//		c->xValues[i] = SWEEP_value2 (r->sweep, c->nValues*r->sweep->stepRepetitions, i*r->sweep->stepRepetitions);
		if ( (2*i+1) < data->nCounts) {
			// average over copies per repetition
			avg = 0;
			for (k = 0; k < r->sweep->stepRepetitions; k++) {
				index = nTimeIntervals*(i*r->sweep->stepRepetitions + k) +1;
				if (index >= data->nCounts) Breakpoint();
				else avg += data->counts[index]; 				
			}
			c->yValues[0][i] = (1.0 * avg) / r->sweep->stepRepetitions;
			c->sumYValues += c->yValues[0][i];
		}
		else 
			c->yValues[0][i] = 0;
//		c->yValues[i] = i * i * r->currentRepetition;
	}
	c->yValuesVisible[0] = c->nValues;
	c->nCurvesWritten = 1;
	c->autoScaleCurrentCurve = 1;
	
	CURVE_getMinMax (c);
	if (r->session->counterOn[1]) {
		if (data->detector == 1) w->sliderCurve = c;
	}
	else w->sliderCurve = c;
	
	w->showSlider_number = 1;

// ----------------------------------------------------
//    create averaged curve
// ----------------------------------------------------
	RUN_averageCurve_DIG (c, &r->nAveragesToDo);
// ----------------------------------------------------
//    display curve(s)
// ----------------------------------------------------
	p->curve = c;
	CURVE_displayTreeItem (w, c, 1);
	
 	GRAPH_displayAllCurves (w, 0, 1);
//	if (data->repetition == 0) DisplayPanel (w->panelHandle);
}


/*
char *getCurveName (t_run *r, const char *defaultName, int current)
{
	char *curveName;
	int level;
	const char currentStr[] = "__";
	
	curveName = getTmpString();
	
	
	if (r->nRepetitionsPerSweepPoint == 1) {
		if (current) strcpy (curveName, currentStr);
		strcat (curveName, defaultName);
	}
	else {
		level = r->session->transferLevel[r->lastData->repetition % r->nRepetitionsPerSweepPoint];
		sprintf (curveName, "%s%s level %s", 
				 current ? currentStr : "",
				 defaultName, r->session->levelNames[level]);
	}
	return curveName;
}
*/

void createXAxis2D (t_run *r, t_curve *c)
{
	int i;
	
	for (i = 0; i < c->n2Dcurves; i++) {
		c->xValues2D[i] = SWEEP_value2 (r->sweep, c->n2Dcurves, i);
	}
	strcpy (c->xLabel2D, r->sweep->plotAxisName);
//	strcpy (c->yLabel2D, c->xLabel);
	strcpy (c->xUnits2D, r->sweep->units);
}


// calculate the error of the transfer
double errorTransfer (double n0, double n1)
{
	return sqrt (n0*n1*(n0+n1))/sqr (n0+n1);
}


void CURVE_addPosition (t_curve *c, const char *labelStr, int color,
						double position, double minPos, double maxPos)
{
	int p;
	
	p = c->nComponentsPositions ;
	if (p >= CURVES_MAX_POSITIONS) return;
	if ((position < minPos) || (position > maxPos)) return;
	if (c->xAxis2Multiply == 0) c->xAxis2Multiply = 1;
	c->componentsPositions[p] = position / c->xAxis2Multiply ;
	strcpy (c->componentsNames[p], labelStr);
	c->componentsColors[p] = color;
	c->nComponentsPositions ++;
}


void CURVE_addAllPositions (t_session *s, t_curve *c)
{
	double minPos, maxPos;
	int i;
	t_dataField *d;
	
	if (s == NULL) return;
	if (c == NULL) return;
	c->nComponentsPositions = 0;
	if (c->xValues == NULL) return;
	minPos = c->xValues[0] *c->xAxis2Multiply ;
	maxPos = c->xValues[c->nValues-1] * c->xAxis2Multiply ;
//	CURVE_addPosition (c, "Test", VAL_RED, 200.0, minPos, maxPos);
	
	for (i = 0; i < N_POSITIONS; i++) {
		d = df (i);
		if (i == POS_RAMSEY2) {
		  i = i;
		}
		if (d->graphDisplay) {
			CURVE_addPosition (c, d->graphDisplayName, 
							   d->graphDisplayColor, s->atomConfig->position[i], minPos, maxPos);
		}
	}
		
}


// ===================================================================
//
//    initializes plots for arrival times and velocity distribution
//
// ===================================================================

t_curve *RUN_createPlotInit_ArrTimesAndVelDist (t_run *r, t_plotItem *p, t_counterData *data, int nPoints, int *d)
{
	t_graph *w;
	int n2Dcurves = 0;
	t_curve *c;
	int i, k;
	
	if (data == NULL) return NULL;
	w = RUN_createPlotGraphAxes(r, p);//, "velocity", "m/s");

	n2Dcurves = r->nRepetitionsPerRun;
	c = CURVE_create (w, p->name, nPoints, n2Dcurves);
	if (c == NULL) return NULL;
	c->startNr  = r->startNr;
	c->active = 1;
	CURVE_setStyle (c, p, 0);
	c->keep = p->keepCurve;
	if (c->newCurve) {
		c->showCurrentCurve = r->nRuns > 1;
		c->newCurve = 0;
		w->newGraph = 1;
		c->showCurrentCurve = 0;
		c->nCurvesWritten = 0;
		strcpy (c->info, r->infoStr);
	}
	if (p->curve == NULL) {
		createXAxis2D (r, c);
		c->visible2D = p->create2DPlot;
		CURVE2D_resetValues (c);
		c->nCurvesWritten = 0;
		CURVE_allocateMemoryRun (c, 1);
		CURVE_allocateMemoryForOneCurve (c, 0, c->nValues);
		c->currentCurve = 0;
		c->yValuesVisible[0] = 0;
		c->showCurrentCurve = 0;
		c->nCurvesWritten = 0;
		c->panelPos2D = p->panelPos2D;
	}
	if (!p->create2DPlot) {
		if (c->panel2DPlot > 0) DiscardPanel (c->panel2DPlot);
		c->panel2DPlot = -1;
	}
	
		d[0] = 0;
		d[1] = 0;

	if (p->detector == 0) {
		d[0] = 0;
		d[1] = 0;
	}
	else {
		// MAYBE BUG 29/08/2006
		if ((!p->transfer) && (p->detector == 1) && (r->session->transferOn)) {
			// transfer detector 2	
			// choose right duplicate of dataset
			d[0] = SESSION_getTransferLevelNr (r->session, p->level);
			if (d[0] < 0) d[0] = 0;
		}
		else if (p->transfer) {
			d[0] = 1;
			d[1] = 0;
		}
	}

	
	
	// get duplicate no d[i], which corresponds to the level p->level[i]
/*	for (i = 0; i < N_SESSION_TRANSFER_LEVELS; i++) {
		d[i] = 0;
	
		if (p->transfer) {
			d[0] = r->session->transferLevel[0];
			d[1] = r->session->transferLevel[1];
//			for (k = 0; k < N_SESSION_TRANSFER_LEVELS; k++) {
//				if (r->session->transferLevel[k] == p->level[i]) d[i] = k;
//			}
		}
	}
	
*/	
	return c;

}


void RUN_createPlotEnd_ArrTimesAndVelDist (t_run *r, t_curve *c, t_plotItem *p, t_counterData *data)
{
	// show entire curve
	if (c->yValuesVisible != NULL) c->yValuesVisible[0] = c->nValues;
	if (c->nCurvesWritten < data->run+1) c->nCurvesWritten = data->run+1;
	if (!c->showCurrentCurve) c->showCurrentCurve = (data->run > 1);
	// add data to old curve
	CURVE2D_copyDataFromCurve (c, data->repetition, 0);
	// retain averaged data
	CURVE2D_setActiveCurve (c, data->repetition);
	c->nValuesVisibleAvg = c->nValues;
	//  display curve
	p->curve = c;
}



// --------------------------------------------------------------
// --------------------------------------------------------------
//              create curve: arrival times
// --------------------------------------------------------------
// --------------------------------------------------------------
void RUN_createPlot_ARRIVALTIMES (t_run *r, t_plotItem *p)
{
	t_curve *c = NULL;
	int i;
	t_counterData *data;
	double N[N_SESSION_TRANSFER_LEVELS];
	
	int d[N_SESSION_TRANSFER_LEVELS];

	data = r->lastData;
	c = RUN_createPlotInit_ArrTimesAndVelDist (r, p, data, data->nBins, d);
	if (c == NULL) return;

	// first call: create X-Axis
	if (p->curve == NULL) {
		c->xFrom = 1.0E-3 * (0.5) * (double) data->binSize * data->timeUnit_ns + p->arrivalTimesBinStart_us;
		c->xTo   = 1.0E-3 * ((1.0*data->nBins) - 0.5) * (double) data->binSize * data->timeUnit_ns + p->arrivalTimesBinStart_us;
		CURVE_setXValues (c, 1);		
//		for (i = 0; i < data->nBins; i++) {
//			c->xValues[i] = 1.0E-3 * ((double) i+0.5) * (double) data->binSize * data->timeUnit_ns + p->arrivalTimesBinStart_us;
//		}		
	}
		
	if (c->yValues != NULL) {
		for (i = 0; i < c->nValues; i++) {
	//		if (p->arrivalTimesBinAuto) binStart = r->session->dSmallestTime_us;
	//		binStart = p->arrivalTimesBinStart_us;
	//		binStart -= DURATION_FIRST_BLOCK_ns / 1000.0;
	//		c->xValues[i] = 1.0E-3 * ((double) i+0.5) * (double) data->binSize * data->timeUnit_ns + p->arrivalTimesBinStart_us;

// BUG

			
			if (data->binnedCounts[d[0]] == NULL) {
				i = i;
			}
			else {
				N[0] = (1.0 * data->binnedCounts[d[0]][i]);// / r->nCopiesPerRepetition;
				if ((p->transfer) && (data->nDuplicates > 1)) {
					N[1] = (1.0 * data->binnedCounts[d[1]][i]);// / r->nCopiesPerRepetition;
					if (N[0] + N[1] != 0.0) {
						c->yValues[0][i] = N[0]/(N[0]+N[1]);
					}
					else c->yValues[0][i] = 0;
				}
				else c->yValues[0][i] = N[0] / r->nCopiesPerRepetition;
			}
		}
	}
	
	RUN_createPlotEnd_ArrTimesAndVelDist (r, c, p, data);
}





// --------------------------------------------------------------
// --------------------------------------------------------------
//              create curve: velocity distribution
// --------------------------------------------------------------
// --------------------------------------------------------------

void RUN_createPlot_VELOCITYDIST (t_run *r, t_plotItem *p)
{
	t_curve *c = NULL;
	int i, k;
	t_counterData *data;
	double N[N_SESSION_TRANSFER_LEVELS];
	int d[N_SESSION_TRANSFER_LEVELS];
	int plotAll = 0;
	
	data = r->lastData;

	if (!plotAll) {
		c = RUN_createPlotInit_ArrTimesAndVelDist (r, p, data, data->velocityNPoints, d);
		if (c == NULL) return;

		if (p->curve == NULL) {
			// get xValues
			c->xFrom = data->velocityStart;
			c->xTo   = data->velocityEnd;
			CURVE_setXValues (c, 1);		
			if (p->type == PLOT_TYPE_VELOCITYDIST) {
				// second y axis (position) in 2D plot
	/*			c->showRightAxis2D = p->velocityShowPositionAxis;
				strcpy (c->yRightLabel2D, "position");
				strcpy (c->yRightUnits2D, "mm");
				c->rightAxis2DScalingFactor = p->velocityTimeMultiply_us / 1000;*/
				// second x axis (position) in normal plot
				c->xShowSecondAxis = p->velocityShowPositionAxis;
				strcpy (c->xLabel2, "position");
				strcpy (c->xAsciiFileColumnLabel2, "mm");
				strcpy (c->xUnits2, "mm");
				c->xAxis2Multiply = p->velocityTimeMultiply_us / 1000;
				CURVE_addAllPositions (r->session, c);
				c->componentsVisible = p->velocityShowExperimentParts;
			}
		}
	}

	for (i = 0; i < data->velocityNPoints; i++) {
//		c->xValues[i] = getStepOutputVoltage (data->velocityStart, data->velocityEnd, 1,
//   							              data->velocityNPoints, i);
		N[0] = data->velocityPoints[d[0]][i];
		if ((p->transfer) && (data->nDuplicates > 1)) {
			N[1] = data->velocityPoints[d[1]][i];
			if (N[0] + N[1] != 0.0) c->yValues[0][i] = N[0] / (N[0] + N[1]);
			else c->yValues[0][i] = 0;
		}
		else c->yValues[0][i] = N[0] / r->nCopiesPerRepetition;
	}

 	RUN_createPlotEnd_ArrTimesAndVelDist (r, c, p, data);
}






void RUN_createPlot_NCOUNTS (t_run *r, int plotItemNr)
{
	t_curve *c = NULL;
	t_graph *w;
	t_session *s;
	double dSum, dSumSquares, dN;
	double dSum2;

	

	int i;
	int index;
	int det;
	int nLevels;
	
	t_timeInterval *t;
	t_counterData *data;
	int nTimeIntervals;
	t_plotItem *p;
	t_filterResults *fr;
    t_filterResults *frTransfer1, *frTransfer2;
	t_plotItem *pTransfer1, *pTransfer2;
	
	

	s = r->session;
	p = PLOTITEM_ptr (s, plotItemNr);
// plot number of counts as a function of 
	
	// ckeck for error
	data = r->lastData;
	if (data == NULL) return;
	if (data->error) return;
	if ((data->detector < 0) && (data->detector > 1)) return;
	det = data->detector;
	
	if (p->curve == NULL) PLOTITEM_calculateTimeIntervals (s, p);
	nTimeIntervals = ListNumItems (r->lTimeIntervals[det]);
	data->nTimeIntervals = nTimeIntervals;
	if (!p->transfer) COUNTERDATA_calculatePlotItem (r, data, data->repetition, det, plotItemNr, 1);

	t = TIMEINTERVAL_ptrList (s->lTimeIntervals[det], p->interval[det]);

	index = data->repetition;
	
	
// ----------------------------------------------------
//    create curve 
// ----------------------------------------------------
	if (p->curve == NULL) {
		w = RUN_createPlotGraphAxes (r, p);
		c = CURVE_create (w, p->name, r->sweep->nPoints, 0);
	}
		
	else {
		w = GRAPH_getFromCurve (p->curve);
		c = p->curve;
	}
	

	if (c == NULL) return;
	
	c->keep = p->keepCurve;
	c->active = 1;
	c->startNr  = r->startNr;
	// very first creation curve 
	if (c->newCurve) {
		w->newGraph = 1;
		c->hasErrorBars = 1;  
		c->hasErrorBarsCurrent = 0;  		
		c->keep = p->keepCurve;
		c->newCurve = 0;
		c->nValuesVisibleAvg = 0;
		if (p->transfer) {
//			sprintf (c->info, "%s, atom %d, %s --> %s", 
//					 r->infoStr, t[0]->atomNr, s->levelNames[t[0]->levelNr], s->levelNames[t[1]->levelNr]);
		}
		else {
			if (t == NULL) c->info[0] = 0;
			else sprintf (c->info, "%s, at.%d, %s (%s, d=%d)", 
				     r->infoStr, p->atomNr, s->levelNames[t->levelNr], t->idStr, p->detector);
		}
	}
	
	// first creation curve 
	// after the session has started
	if (p->curve == NULL) {
		CURVE_allocateMemoryRun (c, r->nRuns);
		c->nValuesVisibleAvg = 0; 
		c->xFrom = r->sweep->from;
		c->xTo   = r->sweep->to;
		CURVE_setXValues (c, 1);		

		for (i = 0; i < c->nValues; i++) {
			c->yValuesAveraged[i] = 0.0;
			c->yErrPosAveraged[i] = 0.0;
			c->yAverages[i] = 0;
		}
		c->nCurvesWritten = 0;   
		CURVE_setStyle (c, p, -1);
		for (i = 0; i < r->nRuns; i++) c->yValuesVisible[i] = 0;
		c->plotNumbers  = (c->nValues < 5);
	}
	p->curve = c;


	// calculate transfer for current dataset

	CURVE_allocateMemoryForOneCurve (c, data->run, c->nValues);
	if ((c->nValues == 0) || (index >= c->nValues)) {
//		Breakpoint();
		return;
	}
// --------------------------------
// --------------------------------
//     CURRENT curve: set value
// --------------------------------
// --------------------------------
	if (c->yValues[data->run] == NULL) return;
	c->yValues[data->run][index] = 0;
	if (c->hasErrorBarsCurrent) c->yErrPos[data->run][index] = 0;

	if (p->transfer) {
//		PLOTITEM_calculateTransfer (s, p, 1, &frTransfer1, &frTransfer2);
		pTransfer1 = PLOTITEM_ptr (s, p->plotItemTransfer1);
		pTransfer2 = PLOTITEM_ptr (s, p->plotItemTransfer2);
		frTransfer1 = &pTransfer1->filterResultsCurrent;
		frTransfer2 = &pTransfer2->filterResultsCurrent;
		if ((pTransfer1 == NULL) || (pTransfer2 == NULL)) return;
	
		// check if data was already calculated
		if ((frTransfer1 == NULL) || (frTransfer1->dataID != data->dataID)) {
			COUNTERDATA_calculatePlotItem (r, data, data->repetition, det, p->plotItemTransfer1, 1);
			frTransfer1 = &pTransfer1->filterResultsCurrent;
		}
		if ((frTransfer2 == NULL) || (frTransfer2->dataID != data->dataID)) {
			COUNTERDATA_calculatePlotItem (r, data, data->repetition, det, p->plotItemTransfer2, 1);
			frTransfer2 = &pTransfer2->filterResultsCurrent;
		}
		if ((frTransfer1 == NULL) || (frTransfer2 == NULL)) return;
		
		// -----------------------
		//    show transfer
		// -----------------------
		dSum        = ui64toDouble (frTransfer1->sum);
		dSum2       = ui64toDouble (frTransfer2->sum);
		if (dSum + dSum2 != 0.0) {
			c->yValues[data->run][index] = dSum2 / (dSum + dSum2 );
			if (c->hasErrorBarsCurrent) 
				c->yErrPos[data->run][index] = errorTransfer (dSum, dSum2);
		}
	}	
	else {
		// -----------------------
		//    show N counts
		// -----------------------
		fr = &p->filterResultsCurrent;
		dSumSquares = ui64toDouble (fr->sumSquares);
		dSum        = ui64toDouble (fr->sum);
		dN 			= fr->nSummedDatasets;
		if (fr->nSummedDatasets != 0) {
			c->yValues[data->run][index] = dSum / dN;
			if (c->hasErrorBarsCurrent) 
				c->yErrPos[data->run][index] = sqrt (dSum) / dN;
		}
	}
	c->currentCurve = data->run;
	if (!c->showCurrentCurve) c->showCurrentCurve = r->nRuns > 1;
	
	if (c->yValuesVisible[data->run] < index+1) c->yValuesVisible[data->run] = index+1;
	if (c->nCurvesWritten < data->run+1) c->nCurvesWritten = data->run+1;
    c->markerPoint = index;	
// --------------------------------
// --------------------------------
//     AVERAGED curve: set value
// --------------------------------
// --------------------------------
	c->yValuesAveraged[index] = 0;
	c->yErrPosAveraged[index] = 0;
	if (p->transfer) {
		frTransfer1 = &pTransfer1->filterResultsAll;
		frTransfer2 = &pTransfer2->filterResultsAll;
		if ((frTransfer1 == NULL) || (frTransfer2 == NULL)) return;
		// -----------------------
		//    show transfer
		// -----------------------
		dSum        = ui64toDouble (frTransfer1->sum);
		dSum2       = ui64toDouble (frTransfer2->sum);
		if (dSum + dSum2 != 0.0) {
			c->yValuesAveraged[index]  = dSum2 / (dSum + dSum2 );
			c->yErrPosAveraged[index] = errorTransfer (dSum, dSum2);
		}
	}
	else {
		// -----------------------
		//    show N counts
		// -----------------------
		fr = &p->filterResultsAll;
		dSumSquares = ui64toDouble (fr->sumSquares);
		dSum        = ui64toDouble (fr->sum);
		dN 			= fr->nSummedDatasets;
		if (fr->nSummedDatasets != 0) {
			c->yValuesAveraged[index] = dSum / dN;
			c->yErrPosAveraged[index] = sqrt (dSum)  / dN;
		}
	}
	if (data->run == 0) c->nValuesVisibleAvg = index+1;
//	c->nValuesVisible = c->nValues; //index + 1;


	p->curve = c;



}



void RUN_createPlot_MULTIPLE_AS_INDEX (t_run *r, int plotItemNr)
{
	t_curve *c = NULL;
	t_graph *w;
	t_session *s;
	double dSum, dSumSquares, dN;
	double dSum2;

	

	int i;
//	int index;
	int det;
	int nLevels;
	
	t_timeInterval *t;
	t_counterData *data;
	int nTimeIntervals;
	t_plotItem *p;
	t_filterResults *fr;
	t_atom *a;
	t_filter *filter;
	int nInterval;
	int index;
	
	
	int timeIntervalFirst, timeIntervalStep;
	

	s = r->session;
	p = PLOTITEM_ptr (s, plotItemNr);
	// ckeck for error
	data = r->lastData;
	if (data == NULL) return;
	if (data->error) return;
	if ((data->detector < 0) && (data->detector > 1)) return;
	det = data->detector;
	a = ATOM_ptr (s, p->atomNr);
	if (a == NULL) return;
	if (!a->hasMultiples) return;
	
	timeIntervalFirst = TIMEINTERVAL_getNr (s, det, p->atomNr, 1, p->level);
	timeIntervalStep = TIMEINTERVAL_getNr (s, det, p->atomNr, 2, p->level) - timeIntervalFirst;
	
	nTimeIntervals = ListNumItems (r->lTimeIntervals[det]);
	data->nTimeIntervals = nTimeIntervals;

//	if (!p->transfer) COUNTERDATA_calculatePlotItem (r, data, data->repetition, det, plotItemNr, 1);

//	t = TIMEINTERVAL_ptrList (s->lTimeIntervals[det], p->interval[det]);

//	index = data->repetition;
	
	
// ----------------------------------------------------
//    create curve 
// ----------------------------------------------------
	if(p->multipleAsIndexNBinAtoms <=0 )   p->multipleAsIndexNBinAtoms = 1;
	if (p->multipleAsIndexNBinAtoms > a->nMultiples ) 
		p->multipleAsIndexNBinAtoms  = a->nMultiples ;
	/////////////////////
	if (p->curve == NULL) {
		w = RUN_createPlotGraphAxes (r, p);
		if (p->multipleAsIndexSumAllRuns) {
			//////
			c = CURVE_create (w, p->name, a->nMultiples / p->multipleAsIndexNBinAtoms, 1);
			/////////
		}
		else {
			//////////////
			c = CURVE_create (w, p->name, a->nMultiples / p->multipleAsIndexNBinAtoms, r->nRuns);
			////////////////////
		}
	}
		
	else {
		w = GRAPH_getFromCurve (p->curve);
		c = p->curve;
	}
	

	if (c == NULL) return;
	
	c->keep = p->keepCurve;
	c->active = 1;
	c->startNr  = r->startNr;
	// very first creation curve 
	if (c->newCurve) {
		w->newGraph = 1;
		c->hasErrorBars = 0;  
		c->hasErrorBarsCurrent = 0;  		
		c->keep = p->keepCurve;
		c->newCurve = 0;
		c->nValuesVisibleAvg = 0;
		sprintf (c->info, "%s, at.%d", r->infoStr, p->atomNr);
	}
	
	// first creation of curve 
	// after the session has started
	if (p->curve == NULL) {
		if (p->multipleAsIndexSumAllRuns) {
			CURVE_allocateMemoryRun (c, 1);
			//////////
			c->yValuesVisible[0] = a->nMultiples / p->multipleAsIndexNBinAtoms;
			///////////////
			c->n2Dcurves = 1;
			CURVE_allocateMemoryForOneCurve (c, 0, c->nValues);
		}
		else {
			CURVE_allocateMemoryRun (c, r->nRuns);
			for (i = 0; i < r->nRuns; i++) c->yValuesVisible[i] = 0;
			c->n2Dcurves = r->nRuns;
		}
		c->nValuesVisibleAvg = 0; 
		c->xFrom = 0;
		c->xTo   = (a->nMultiples-1)*a->delay / 1000.0;
		if (a->nMultiples == p->multipleAsIndexNBinAtoms) c->xTo = 0;
		CURVE_setXValues (c, 1);		

		for (i = 0; i < c->nValues; i++) {
			c->yValuesAveraged[i] = 0.0;
			c->yErrPosAveraged[i] = 0.0;
			c->yAverages[i] = 0;
		}
		c->nCurvesWritten = 0;   
		CURVE_setStyle (c, p, -1);
//		for (i = 0; i < r->nRuns; i++) c->yValuesVisible[i] = 0;
		c->plotNumbers  = (c->nValues < 5);
//		c->n2Dcurves = r->nRuns;
		
	///////////////////////////////////	

	//	c->xValues2D = malloc(sizeof(double) * r->nRuns); 
	/*	for(i=0;i<r->nRuns;i++) {
			c->xValues2D[i] = i;
		}*/	  
//		c->Values2D = malloc(sizeof(double) * r->nRuns*c->n);  */
	//////////////////////////////////////	
	}
	p->curve = c;


	// calculate transfer for current dataset

	if (!p->multipleAsIndexSumAllRuns) {
		CURVE_allocateMemoryForOneCurve (c, data->run, c->nValues);
	}
	if (c->nValues == 0) {
//		Breakpoint();
		return;
	}
// --------------------------------
// --------------------------------
//     CURRENT curve: set value
// --------------------------------
// --------------------------------
	if (c->yValues[data->run] == NULL) return;

	// -----------------------
	//    show N counts
	// -----------------------
	if (p->multipleAsIndexFilterForEachMultipleID == 0) {
		for (i = 0; i < a->nMultiples; i++) {
			nInterval = timeIntervalFirst + i * timeIntervalStep;
	    	index = i / p->multipleAsIndexNBinAtoms;
		    if (p->multipleAsIndexSumAllRuns) {
		    //////////////////////
		    	if (index < c->nValues) {
					if (nInterval < data->nCounts) c->yValuesAveraged[index ] += data->counts[nInterval];
					c->yValues[0][index] = c->yValuesAveraged[index ];
				}
		    ///////////////////////
		    }
		    else {
		    	if (index < c->nValues) {
					if (nInterval < data->nCounts)  
						c->yValues[data->run][index] = data->counts[nInterval];
					else 
						c->yValues[data->run][index] = 0;
				}
			}
		}
	}
	else {
/*		filter = FILTER_ptr (s, p->multipleAsIndexFilterForEachMultipleID);
	//	p->multipleAsIndexFilterForEachMultipleID
		for (i = 0; i < a->nMultiples; i++) {
			// apply filters
			// fr = &p->filterResultsCurrent;
			filter->timeIntervalToCountStart = timeIntervalStart + i * timeIntervalStep;
			filter->timeIntervalToCountStop = filter->timeIntervalToCountStart;
			// change filter criteria
			FILTER_apply (filter, data, &fr);
			c->yValues[data->run][index] = fr->sum;
		}*/
	}
	
	
    if (p->multipleAsIndexSumAllRuns) {
		c->showCurrentCurve = 0;
		c->nValuesVisibleAvg = c->nValues;
		c->averages2D[0] = 0;
 		CURVE2D_copyDataFromCurve (c, 0, 0);
	}
	else {    
		c->currentCurve = data->run;
		c->showCurrentCurve = 1;
		c->autoScaleCurrentCurve = 1;
		c->yValuesVisible[data->run] = c->nValues;
		if (c->nCurvesWritten < data->run+1) c->nCurvesWritten = data->run+1;
		if (data->run == 0) c->nValuesVisibleAvg = c->nValues;
 		CURVE2D_copyDataFromCurve (c, data->run, data->run);
	}

	
//	c->nValuesVisible = c->nValues; //index + 1;

	p->curve = c;

}


void PLOTITEM_calculateTransfer_NCOUNTS (t_run *r, t_plotItem *p, 
								 double *transfer, double *errTransfer,
								 double *allTransfer, double *allErrTransfer)
{								 
    t_filterResults *frTransfer1, *frTransfer2;
	t_plotItem *pTransfer1, *pTransfer2;
	double dSum, dSum2;
	double trans1, trans2;
	double err1, err2;
	t_session *s;
	int sumAll = 0;
   
	s = r->session;
	trans1 = 0;
	err1 = 0;
	trans2 = 0;
	err2 = 0;
	
	if (!p->transfer)  goto THE_END;
	pTransfer1 = PLOTITEM_ptr (s, p->plotItemTransfer1);
	pTransfer2 = PLOTITEM_ptr (s, p->plotItemTransfer2);
	if ((pTransfer1 == NULL) || (pTransfer2 == NULL)) goto THE_END;
	frTransfer1 = &pTransfer1->filterResultsCurrent;
	frTransfer2 = &pTransfer2->filterResultsCurrent;

	// check if data was already calculated
/*	if (data != NULL) {
		if ((frTransfer1 == NULL) || (frTransfer1->dataID != data->dataID)) {
			COUNTERDATA_calculatePlotItem (r, data, data->repetition, det, p->plotItemTransfer1, sumAll);
			frTransfer1 = &pTransfer1->filterResultsCurrent;
		}
		if ((frTransfer2 == NULL) || (frTransfer2->dataID != data->dataID)) {
			COUNTERDATA_calculatePlotItem (r, data, data->repetition, det, p->plotItemTransfer2, sumAll);
			frTransfer2 = &pTransfer2->filterResultsCurrent;
		}
	}
*/
	if ((frTransfer1 != NULL) && (frTransfer2 != NULL)) {
		dSum        = ui64toDouble (frTransfer1->sum);
		dSum2       = ui64toDouble (frTransfer2->sum);
		if (dSum + dSum2 != 0.0) {
			trans1 = dSum2 / (dSum + dSum2 );
			err1   = errorTransfer (dSum, dSum2);
		}
	}
	
	// -----------------------
	//       all runs
	// -----------------------
	frTransfer1 = &pTransfer1->filterResultsAll;
	frTransfer2 = &pTransfer2->filterResultsAll;
	if ((frTransfer1 != NULL) && (frTransfer2 != NULL)) {
		dSum        = ui64toDouble (frTransfer1->sum);
		dSum2       = ui64toDouble (frTransfer2->sum);
		if (dSum + dSum2 != 0.0) {
			trans2 = dSum2 / (dSum + dSum2 );
			err2 = errorTransfer (dSum, dSum2);
		}
	}

THE_END:
	if (transfer != NULL)    *transfer = trans1;
	if (errTransfer != NULL) *errTransfer = err1;
	
	if (allTransfer != NULL) *allTransfer = trans2;
	if (allErrTransfer != NULL) *allErrTransfer = err2;
	
}



int RUN_calculateAllPlotItems (t_run *r, t_counterData *d, int repetition, int detector, int sumAllRuns)
{
	int i;
	int nPlotItems;
	
	if (r == NULL) return -1;
	if (r->session == NULL) return -1;
	nPlotItems = ListNumItems (r->session->lPlotItems);
	COUNTERDATA_allocateFilterResults (d, nPlotItems);        
	for (i = 1; i <= nPlotItems ; i++) {
		PLOTITEM_calculateTimeIntervals (r->session, PLOTITEM_ptr (r->session, i));		
		COUNTERDATA_calculatePlotItem (r, d, repetition, detector, i, sumAllRuns);
	}
	return 0;
}



void RUN_allocateAllFiltersInCounterData (t_run *r)
{
	int c, i;
	int nFilterResults;
	
	if (r->session == NULL) nFilterResults = 0;
	else nFilterResults = ListNumItems (r->session->lPlotItems);
	for (c = 0; c < N_COUNTERS; c++) {
		for (i = 0; i < r->nData[c]; i++) {
			if (r->data[c][i] != NULL) {
				COUNTERDATA_allocateFilterResults (r->data[c][i], nFilterResults);
			}
		}
	}
}



/*
int RUN_calculateAllPlotItemsForAllData (t_run *r, int *nCalculated, int type)
{
	int i;
	int nPlotItems;
	t_plotItem *p;
	int counter, dataSet;
	t_counterData *data;
	int typeOk;
	
	if (r == NULL) return -1;
	if (r->session == NULL) nPlotItems = 0;
	else nPlotItems = ListNumItems (r->session->lPlotItems);
	*nCalculated = 0;
	
	for (i = 1; i <= nPlotItems; i++) {
		p = PLOTITEM_ptr (r->session, i);
		p->hasDataCalculated = 0;
		p->hasTableColumn = 0;
		typeOk = (type == PLOT_TYPE_NONE) || (p->type == type);
		if (p->active && typeOk) {
			PLOTITEM_calculateTimeIntervals (r->session, p);		
			for (counter = 0; counter < N_COUNTERS; counter++) {
				for (dataSet = 0; dataSet < r->nData[counter]; dataSet++) {
					data = r->data[counter][dataSet];
					if (data != NULL) {
						if (i == 1) COUNTERDATA_allocateFilterResults (data, nPlotItems);        
						COUNTERDATA_calculatePlotItem (r, data, data->repetition, counter, i, 0);
					}
				}
			}
			p->hasTableColumn = (p->hasDataCalculated || p->transfer);
			if (p->hasTableColumn) (*nCalculated)++;
		}
	}
/*
	for (i = 1; i <= nPlotItems; i++) {
		p = PLOTITEM_ptr (r->session, i);
		if ((p->active) && (p->transfer)) {
			COUNTERDATA_calculatePlotItem (r, data, i, 0);
		}
		if (p->hasDataCalculated) (*nCalculated)++;
	}
*/
/*	return 0;
	
}
*/




#define DEBUG 0

void RUN_generatePlot (t_run *r)
{
	t_counterData *data;
	t_plotItem *p;
	int k;
	int nCountsExpected;
	t_graph *g = NULL;
	char *help;
	int i;
	t_curve *c;
	int firstShot, lastShot, displayGraph;
	int counterOK;

#ifdef MEASUREDURATION
	clock_t time;
	time = clock();
#endif

	data = r->lastData;
	if (data == NULL) return;
	if (data->error) return;
	displayGraph = 0;

	if ((data->counterNr == COUNTER_NCOUNTS_DET2) || (data->counterNr == COUNTER_NCOUNTS_DET1)) {
		// -------------------------------------
		//   check if number of counts correct
		// -------------------------------------
		nCountsExpected = r->nCopiesPerRepetition * ListNumItems (r->lTimeIntervals[data->detector]);
//		if ((data->detector == 0) && (r->session->transferOn)) nCountsExpected *= 2;
		if (nCountsExpected != data->nCounts) {					  
			// counts missing or too many: set flag
			help= getTmpString ();
			sprintf (help, "WRONG NUMBER OF GATE SIGNALS  (%d counts expected but %d counts detected)",
						   nCountsExpected, data->nCounts);
			data->error    = COUNTER_ERROR_WRONG_GATE;
			data->errorStr = strnewcopy (data->errorStr, help);
			return;
		}
	}
	
	RUN_calculateAllPlotItems (r, data, data->repetition, data->detector, 1);
	
	GRAPH_setAllDisplayed (0);

#ifdef MEASUREDURATION
			printf ("t ('GRAPH_setAllDisplayed') = %d ms\n", timeStop(time));
#endif

	for (k = 1; k <= ListNumItems (r->session->lPlotItems); k++) {
		p = PLOTITEM_ptr (r->session, k);
		PLOTITEM_getCounter (p);
//		if (DEBUG) printf ("plotItem=%s, CL=%d, ",p->name, p->countsLevel);

		counterOK = (data->counterNr == p->counter) || (p->counter == -1);
		if (p->active && counterOK) {
			switch (p->type) {
				case PLOT_TYPE_VELOCITYDIST:
					if ((data->counterNr == COUNTERS_ARRIVALTIMES[0]) 
						|| (data->counterNr == COUNTERS_ARRIVALTIMES[1])) {
						RUN_createPlot_VELOCITYDIST (r, p);
					}
					break;
				case PLOT_TYPE_ARRIVALTIMES:
					if ((data->counterNr == COUNTERS_ARRIVALTIMES[0]) 
						|| (data->counterNr == COUNTERS_ARRIVALTIMES[1])) {
						RUN_createPlot_ARRIVALTIMES (r, p);
					}
					break;
				case PLOT_TYPE_NCOUNTS:
					if ((data->counterNr == COUNTERS_NCOUNTS[0]) 
						|| (data->counterNr == COUNTERS_NCOUNTS[1])) {
						RUN_createPlot_NCOUNTS (r, k);	
					}
					#ifdef DISPLAY_TESTDATA
						c = p->curve;
						c->yValuesAveraged[data->repetition] = 0.06 + Random (-0.02, 0.02);
						c->yErrPosAveraged[data->repetition] = 0.02;
					#endif 
					break;
				case PLOT_TYPE_MULTIPLE_AS_INDEX:
					if ((data->counterNr == COUNTERS_NCOUNTS[0]) 
						|| (data->counterNr == COUNTERS_NCOUNTS[1])) {
						RUN_createPlot_MULTIPLE_AS_INDEX (r, k);	
					}
					
					break;
					
			}

#ifdef MEASUREDURATION
			printf ("t ('RUN_createPlot_NCOUNTS, ...') = %d ms\n", timeStop(time));
#endif
		   
			lastShot =  ((data->run == r->nRuns) && (data->repetition == r->nRepetitionsPerRun));

			displayGraph = !speedMode || lastShot || (data->repetition % r->session->updatePoints == 0);

		// 
			if (p->firstUsed) {
				GRAPH_positionPanel (p->graph, p->panelPos);
				p->firstUsed = 0;
			}

			
			if (p->curve != NULL) {
				p->curve->plotItem =  p;
				if ((p->create2DPlot) && (r->nRepetitionsPerRun > 1)) {
					CURVE2D_displayCurve (p->curve, p->panelPos2D); 
				}
				if (lastShot) {
					// last curve was taken
//					p->curve->active = 0;
					// hide current curve
					p->curve->showCurrentCurve = 0;
					if ((p->type == PLOT_TYPE_ARRIVALTIMES) && (p->type == PLOT_TYPE_VELOCITYDIST)) {
						// prevent current curve from being saved
						p->curve->yValuesVisible[0] = 0;
					}
				}
				CURVE_setTime (p->curve);
				CURVE_getMinMax (p->curve);

			}
		}
		if (DEBUG) printf ("\n");
	}
		
	// display all graphs
	
	if (displayGraph) {
		for (k = 1; k <= ListNumItems (r->session->lPlotItems); k++) {
			p = PLOTITEM_ptr (r->session, k);
	 		g = GRAPH_getFromCurve (p->curve);
		 	if (g && !g->displayed) {
				if (DEBUG) printf ("DISPLAYED %s.", g->panelTitle);
				g->displayed = 1;			 	
				firstShot = (data->repetition == 0) && (data->run == 0);
				if (firstShot) g->visible = 1;
			 	GRAPH_displayAllCurves (g, firstShot, firstShot);
		 	 	if (firstShot) DisplayPanel (g->panelHandle);
		 	}
		}
	}
	
#ifdef MEASUREDURATION
			printf ("t ('GRAPH_displayAllCurves, ...') = %d ms\n", timeStop(time));
#endif
	
		
	if (DEBUG) printf ("\n");
}




void RUN_generatePlotFromOldData (t_run *r, int plotItemID)
{

	int i;
	int rep;
	int nPlotItems;
	t_graph *g;		 
	t_plotItem *p;
	t_counterData *d;
	
	if (r == NULL) return;
	p = PLOTITEM_ptr (r->session, plotItemID);
	if (p == NULL) return;
	PLOTITEM_getCounter (p);
	nPlotItems = ListNumItems (r->session->lPlotItems);
	
	switch (p->type) {
		case PLOT_TYPE_VELOCITYDIST:
//			RUN_createPlot_VELOCITYDIST (r, p);
			break;
		case PLOT_TYPE_ARRIVALTIMES:
//			RUN_createPlot_ARRIVALTIMES (r, p);
			break;
		case PLOT_TYPE_NCOUNTS:
			p->curve = NULL;
			if (!p->transfer) {
				// calculate all Data
				for (i = 0; i < r->nData[p->counter]; i++) {
					r->lastData = r->data[p->counter][i];
					d = r->lastData;
					if (d != NULL) {
						COUNTERDATA_allocateFilterResults (d , nPlotItems);        
						COUNTERDATA_calculatePlotItem (r, d, d->repetition, d->detector, plotItemID, 0);
					}
				}
				// sum all datasets
				for (rep = 0; rep < r->nRepetitionsPerRun; rep++) {
					r->lastData  = COUNTERDATA_getDataset (r, 0, rep, p->counter);
					d = r->lastData;
					COUNTERDATA_sumAllRuns (r, rep, p->counter, plotItemID-1, &p->filterResultsAll);
					RUN_createPlot_NCOUNTS (r, plotItemID);	
				}
			}
			break;
	}


	if (p->firstUsed) {
		GRAPH_positionPanel (p->graph, p->panelPos);
		p->firstUsed = 0;
	}

	if (p->curve == NULL) return;
	p->curve->plotItem =  p;
	if ((p->create2DPlot) && (r->nRepetitionsPerRun > 1)) {
		CURVE2D_displayCurve (p->curve, p->panelPos2D); 
	}
	// last curve was taken
	p->curve->active = 0;
	// hide current curve
	p->curve->showCurrentCurve = 0;
	if ((p->type == PLOT_TYPE_ARRIVALTIMES) && (p->type == PLOT_TYPE_VELOCITYDIST)) {
		// prevent current curve from being saved
		p->curve->yValuesVisible[0] = 0;
	}
	CURVE_setTime (p->curve);
	CURVE_getMinMax (p->curve);

	g = GRAPH_getFromCurve (p->curve);
 	if (g != NULL) {
	 	GRAPH_displayAllCurves (g, 1, 1);
	 	DisplayPanel (g->panelHandle);
	}
	
}



void RUN_processReceivedData (t_run *r)
{
	t_counterData *data;
	clock_t time;
	
	data = r->lastData;
	if (data == NULL) return;
	
	COUNTERDATA_allocateFilterResults (data, ListNumItems (r->session->lPlotItems));

	switch (data->counterNr) {
		case COUNTER_ARRIVALTIMES_DET1: 
		case COUNTER_NCOUNTS_DET1: 
			data->detector = 0;
			break;
		case COUNTER_NCOUNTS_DET2: 
		case COUNTER_ARRIVALTIMES_DET2: 
			data->detector = 1;
			break;
	};
	
	switch (r->mode) {
		case SESSIONMODE_STANDARD:
			if (r->session->saveRunData);
//			printf ("PUTTING run=%d,rep=%d,ctr=%d\n",data->run,data->repetition,data->counterNr);
			time = clock();
			RUN_putCounterData (r, data);
			RUN_generatePlot (r);
// measure duration of 
#ifdef MEASUREDURATION
			printf ("t ('RUN_generatePlot') = %d ms\n", timeStop(time));
#endif
			break;
		case SESSIONMODE_DIG:
			RUN_createPlot_DIG (r);
			break;
	}

	if (data->error) {
		RUN_printf ("--------------------------------------------------\n"
					"ERROR (run %d, rep. %d, ctr. %d): %s.\n", 
					data->run,
					data->repetition,
					data->counterNr,
					data->errorStr ? data->errorStr : "");
	}
	
	if (r->mode == SESSIONMODE_DIG) {
		COUNTERDATA_free (r->lastData);
		free (r->lastData);
		r->lastData = NULL;
	}
	

};




