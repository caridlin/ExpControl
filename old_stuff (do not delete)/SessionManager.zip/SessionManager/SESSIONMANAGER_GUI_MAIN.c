#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"
#include "DRIVER_MI6021.h"

int panelSMain = -1;
int panelMiniRun = 0;
int ctrlButtonStop = 0;

extern int panelConfig;
extern int panelAtoms;
extern int panelOutputs;
extern int panelRun;
extern int panelSweep;
extern int panelPlotItems;
extern int panelFilters;
extern int subPanelStd; 
extern int subPanelDig;

extern int quitProgramFlag;


extern t_run *activeRun;

t_smanagerConfig *smanagerConfig;

int menuSessionList		  = -1;  // popup-menu sequence list

int MENU_SESSIONMANAGER_EDIT 		= -1;
int MENU_SESSIONMANAGER_EDIT_CLOSE  = -1;
int MENU_SESSIONMANAGER_EDIT_SHOW   = -1;
int MENU_SESSIONMANAGER_EDIT_RENAME  = -1;

#define COLOR_READONLY VAL_DK_GRAY

enum {  
	SESSIONS_COL_NAME,
	SESSIONS_COL_INFO,
//	SESSIONS_COL_STARTNR,

	N_SESSIONS_COL
};

#define SESSIONS_COL_NAME_WIDTH 145


/************************************************************************/
/************************************************************************/
/*
/*    session handling 
/*
/************************************************************************/
/************************************************************************/

int getActiveSessionNr (void)
{
    return smanagerConfig->activeSessionNr;
}



// ---------------------------------------------
//   display active sequence  
// ---------------------------------------------
void SESSION_displayActive (void)
{
	t_session *s;
	s = activeSession();
	// ----------------------------------	
	//    display new sessionname
	// ----------------------------------
	SESSIONMANAGER_setFilenameToTitle (s->filename, s->changes);
	SESSIONMANAGER_displayList (0);  
	// set panel to orange if session is "read only"
	SetCtrlAttribute  (panelSMain, SMAN_TEXTMSG_readOnly, ATTR_VISIBLE, s->readOnly);
	SetCtrlAttribute (panelSMain, SMAN_TEXTMSG_readOnly,
					  ATTR_TEXT_BGCOLOR, COLOR_READONLY);
	EasyTab_SetAttribute (panelSMain, SMAN_CANVAS_tabCtrl, ATTR_EASY_TAB_BG_COLOR,
						  s->readOnly ? COLOR_READONLY : VAL_MED_GRAY);
	SetPanelAttribute (panelSMain, ATTR_BACKCOLOR, s->readOnly ? COLOR_READONLY : VAL_MED_GRAY);
	SetCtrlVal (panelSMain, SMAN_NUMERIC_updatePoints, s->updatePoints);	
	// ----------------------------------	
	//    display items of panel "atoms"
	// ----------------------------------
	ATOMS_TABLE_init (s);
	ATOMS_VELOCITY_initPanel (s);
	ATOMS_displayAllValues (s);
	// ----------------------------------	
	//    display items of panel "config"
	// ----------------------------------
	SCONFIG_POSITIONS_initPanel (s);
	SCONFIG_setRfParameters (s->atomConfig);
	SCONFIG_setPositions (s->atomConfig); 
	// ----------------------------------	
	//    display items of panel "sweeps"
	// ----------------------------------
	SWEEP_displayAll (s);
	// ----------------------------------	
	//    display items of panel "run"
	// ----------------------------------
	RUN_displayAll (s);
	// ----------------------------------	
	//    display items of panel "outputs"
	// ----------------------------------
	OUTPUTS_setValues (s);
	// ----------------------------------	
	//    display items of panel "plotItems"
	// ----------------------------------
	PLOTITEM_displayAll (s);
	// ----------------------------------	
	//    display items of panel "filters"
	// ----------------------------------
	FILTERS_displayAll (s);

	SESSIONMANAGER_displayMemoryInfo ();
	
}



int nSessions (void)
{
	return ListNumItems (smanagerConfig->listOfSessions);
}



// ---------------------------------------------
//   set 'nr' as active sequence  
// ---------------------------------------------
void SESSION_setAsActive (int nr)
{
	 if (nr > nSessions() || (nr < 1)) nr = nSessions();
	 smanagerConfig->activeSessionNr = nr;
	 SESSION_displayActive ();
}


// ---------------------------------------------
//   returns pointer to the active sequence
// ---------------------------------------------
t_session *activeSession (void)
{
	t_session *s;
	
	if (smanagerConfig->activeSessionNr <= 0) return NULL;
	ListGetItem (smanagerConfig->listOfSessions, &s, smanagerConfig->activeSessionNr);
	return s;
}    






int SESSIONMANAGER_quit (void)
{
	int i;
	t_session *s;
	
    for (i = nSessions(); i > 0; i--) {
	// ---------------------------------------------
	//   test if changes were made
	// ---------------------------------------------
		s = SESSION_ptr (i);
	    if (s->changes) {
	        switch (messagePopupSaveChanges (s->filename)) {
				// ---------------------------------------------
				//   save before close
				// ---------------------------------------------
	            case VAL_GENERIC_POPUP_BTN1:
					if (SESSIONMANAGER_saveSession (s) != 0) return 0 ;            
	                //if (SESSION_save (s->filename, s) != 0) return -1;
	                break;
				// ---------------------------------------------
				//   cancel 
				// ---------------------------------------------
	            case VAL_GENERIC_POPUP_BTN3:
	                return 0;
			}            
		}
	}
	writeSessionManagerConfig (smanagerConfig);

	CURVES_hidePanel ();
	RUNS_hidePanel ();
	
	TCP_closeClient();
	RUN_setState (RUN_STATE_INACTIVE);
//	GRAPH_discardAll ();
	return 1;
	
}


void SESSION_setChanges (t_session *s, int changes)
{
    if (s->changes != changes) {
    	if (s == activeSession()) SESSIONMANAGER_setFilenameToTitle (s->filename, changes);
        s->changes = changes;
        SESSIONMANAGER_displayList (0);
    }
	
}










//=======================================================================
//
//    init submenu for session manager
//
//=======================================================================
void SESSIONMANAGER_initMenus (void)
{


//	int mainMenu, menuFile, menuSpecial;
	
	menuSessionList = NewMenuBar (0); 
	
	MENU_SESSIONMANAGER_EDIT = NewMenu (menuSessionList, "EDITSESSION", -1);
	MENU_SESSIONMANAGER_EDIT_CLOSE = NewMenuItem (menuSessionList, 
		MENU_SESSIONMANAGER_EDIT, "Close", -1, 0, 0, 0);
	MENU_SESSIONMANAGER_EDIT_RENAME = NewMenuItem (menuSessionList, MENU_SESSIONMANAGER_EDIT, "Rename", -1, 0,
	 			 0, 0);
	MENU_SESSIONMANAGER_EDIT_SHOW = NewMenuItem (menuSessionList, MENU_SESSIONMANAGER_EDIT, "Show", -1, 0,
	 			 0, 0);
}



int SESSIONMANAGER_init (int outPanel, int outCtrl)
	
{
	DATAFIELD_initAll ();
	
	smanagerConfig = (t_smanagerConfig *) malloc (sizeof (t_smanagerConfig));
	initSessionManagerConfig (smanagerConfig) ;
 	
 	setCtrlStrf (outPanel, outCtrl, "Loading sessions...");
	readSessionManagerConfig (smanagerConfig);
    if (SESSIONMANAGER_initPanel (outPanel, outCtrl) < 0) return -1;
	if (activeSession()== NULL) {
		MENU_newSession (-1, -1, NULL, -1);
	}
	SESSION_setAsActive (smanagerConfig->activeSessionNr);	
	SESSIONMANAGER_displayList (1);  
 	setCtrlStrf (outPanel, outCtrl, "Initializing TCP/IP connection to ExperimentControl V%1.2f", ProgramVersion);
	TCP_setServerName (smanagerConfig->TCPserverName);
	TCP_initClient (smanagerConfig->TCPserverName, SESSIONMANAGER_parseTCPString, 0);
	
/*	if (TCP_initClient (smanagerConfig->TCPserverName, SESSIONMANAGER_parseTCPString) != 0) {
#ifndef EXPERIMENTCONTROL
    	MessagePopup ("Error", "The TCP/IP connection to ExperimentControl.exe could not be established.");
    	launchExperimentControl (0, 0);
#endif 
	}
*/
	RUN_setState (RUN_STATE_INACTIVE);
	
 	setCtrlStr (outPanel, outCtrl, "");
	DisplayPanel (panelSMain);
	CURVES_initPanel(0);
//	RUNS_initPanel ();

	SetActivePanel (panelAtoms);
	SetActiveCtrl (panelAtoms, ATOMS_NUMERIC_number);

	SetWaitCursor (0);

    return 0;
}



void SESSIONMANAGER_discardPanel (void)
{
	int panel;
	
	panel = panelSMain;
	HidePanel (panel);
	
	EasyTab_RemovePanel (panel, SMAN_CANVAS_tabCtrl, panelAtoms);
	DiscardPanel (panelAtoms);
	EasyTab_RemovePanel (panel, SMAN_CANVAS_tabCtrl, panelRun);
	DiscardPanel (panelRun);
	EasyTab_RemovePanel (panel, SMAN_CANVAS_tabCtrl, panelSweep);
	DiscardPanel (panelSweep);
	EasyTab_RemovePanel (panel, SMAN_CANVAS_tabCtrl, panelOutputs);
    DiscardPanel (panelOutputs);
	EasyTab_RemovePanel (panel, SMAN_CANVAS_tabCtrl, panelConfig);
	SCONFIG_discardPanel ();
	
	DiscardPanel (panel);
}

/*
void initToolbar (void)
{
	int panelIcons = -1;
	ToolbarType toolbar;
	
	Toolbar_New (panelSMain, 0, "", 0, 0, 1, 1,
				 &toolbar);
	panelIcons = LoadPanel (0, SESSIONMANAGER_uirFile, ICONS);
	Toolbar_InsertItemFromCtrl (toolbar, END_OF_LIST, kCommandButton, 1,
						"test", kNoCallback, 0, 0, 0, panelIcons, ICONS_CANVAS_QUIT);
	Toolbar_InsertItemFromCtrl (toolbar, END_OF_LIST, kCommandButton, 1,
						"test", kNoCallback, 0, 0, 0, panelIcons, ICONS_PICTURE_STOP);
	Toolbar_InsertItemFromCtrl (toolbar, END_OF_LIST, kCommandButton, 1,
						"test", kNoCallback, 0, 0, 0, panelIcons, ICONS_PICTURE_A);
	Toolbar_Display (toolbar);
	
	DiscardPanel (panelIcons);
}
*/

void SESSIONMANAGER_initTree (int panel, int ctrl)
{
	
	int scrollbarSize;
	
	setNumTreeColumns (panel, ctrl, N_SESSIONS_COL);

	// set attributes for columns
	SetTreeColumnAttribute (panel, ctrl, SESSIONS_COL_NAME,
							ATTR_COLUMN_WIDTH, SESSIONS_COL_NAME_WIDTH);
	SetTreeColumnAttribute (panel, ctrl, SESSIONS_COL_NAME, 
							ATTR_LABEL_TEXT, "session (.ses)");

	GetCtrlAttribute (panel, ctrl, ATTR_SCROLL_BAR_SIZE, &scrollbarSize);
	SetTreeColumnAttribute (panel, ctrl, SESSIONS_COL_INFO,
							ATTR_COLUMN_WIDTH, 
							ctrlWidth (panel, ctrl) - SESSIONS_COL_NAME_WIDTH - scrollbarSize);
	SetTreeColumnAttribute (panel, ctrl, SESSIONS_COL_INFO, 
							ATTR_LABEL_TEXT, "info");

/*	SetTreeColumnAttribute (panel, ctrl, SESSIONS_COL_STARTNR,
							ATTR_COLUMN_WIDTH, 30);
	SetTreeColumnAttribute (panel, ctrl, SESSIONS_COL_STARTNR, 
							ATTR_LABEL_TEXT, "start no.");
*/
}



void SESSIONMANAGER_initMiniPanelRun (void) 
{
	Rect screen;
	int titlebarThickness = 20;
	int frameThickness    = 5;
	int top, left1, left2, width, height;
	int width1;
	int screenNr;
	
	
	// test if two screens present
	if (GetMonitorAttribute (2, ATTR_WIDTH, &screen.width) < 0) return;
	

	panelMiniRun = LoadPanel (0, SESSIONMANAGER_uirFile, MINIRUN);

		//DisplayPanel (w->panelHandle);
	GetMonitorAttribute (1, ATTR_LEFT, &left1);		 
	GetMonitorAttribute (2, ATTR_LEFT, &left2);		 
	screenNr = left1 < left2 ? 2 : 1;


	GetMonitorAttribute (screenNr, ATTR_WIDTH, &screen.width);		
	GetMonitorAttribute (screenNr, ATTR_TOP,  &screen.top);
	GetMonitorAttribute (screenNr, ATTR_LEFT, &screen.left);		 
	GetMonitorAttribute (screenNr, ATTR_HEIGHT, &screen.height);
	
	

	top    = titlebarThickness +  frameThickness;
	top = 0;
	left1   = screen.left + (screen.width - panelWidth (panelMiniRun));
	
	SetPanelPos (panelMiniRun, top, left1);
}


int SESSIONMANAGER_initPanel (int outPanel, int outCtrl)
{
 	 const char strInitializing[] = "Initializing user interface...";

 	 Rect bounds;
 	 int err;
 	 
 	 char metaFont[] = "Tab Edit Meta Font 3";
	 
 	setCtrlStr (outPanel, outCtrl, strInitializing);
	// ------------------------------------------
	//    load main panel
	// -----------------------------------------
    panelSMain = LoadPanel (0, SESSIONMANAGER_uirFile, SMAN);

	SetCtrlAttribute (panelSMain, SMAN_STRING_status, ATTR_TEXT_BGCOLOR,
					  VAL_MED_GRAY);
	SetCtrlAttribute (panelSMain, SMAN_TREE_sessions,
					  ATTR_ZPLANE_POSITION, 0);
	SetCtrlVal (panelSMain, SMAN_TEXTMSG_sessionName, "");
	SESSIONMANAGER_initTree (panelSMain, SMAN_TREE_sessions);
					  
					  
//	SetCtrlAttribute (panelMain(), MAIN_NUM_RUN_repetitions,
//					  ATTR_TEXT_BGCOLOR, VAL_MED_GRAY);
	// ------------------------------------------
	//    load subpanels:
	//    atoms, display, 
	// -----------------------------------------
	
	
	panelAtoms = LoadPanel (panelSMain, SESSIONMANAGER_uirFile, ATOMS);
	panelSweep = LoadPanel (panelSMain, SESSIONMANAGER_uirFile, SWEEP);
	panelRun = LoadPanel (panelSMain, SESSIONMANAGER_uirFile, RUN);
	panelPlotItems = LoadPanel (panelSMain, SESSIONMANAGER_uirFile, PLOTITEMS);
	panelFilters = LoadPanel (panelSMain, SESSIONMANAGER_uirFile, FILTERS);
	panelOutputs = LoadPanel (panelSMain, SESSIONMANAGER_uirFile, OUTPUTS);
	panelConfig = LoadPanel (panelSMain, SESSIONMANAGER_uirFile, SCONFIG);

/*

	if (err = EasyTab_LoadPanels (panelSMain, SMAN_CANVAS_tabCtrl, 
				1, SESSIONMANAGER_uirFile, __CVIUserHInst,
				ATOMS,   	&panelAtoms, 
//				DETECTORS,	&SESSIONMANAGER_panelDetectors,
				SWEEP,	    &panelSweep,
				RUN,	    &panelRun,
				PLOTITEMS,  &panelPlotItems,
				FILTERS,    &panelFilters,
				OUTPUTS,    &panelOutputs,
				SCONFIG,	&panelConfig,
				0) < 0) {
		MessagePopupf ("Error", "Error in Function 'EasyTab_LoadPanels'\n%s", GetGeneralErrorString (err));
		return -1;
	}
*/	
	// ------------------------------------------
	//    init subpanels 
	// -----------------------------------------
 	setCtrlStrf (outPanel, outCtrl, "%s    %s", strInitializing, "ATOMS");
	if (ATOMS_initPanel () < 0) return -1;
 	setCtrlStrf (outPanel, outCtrl, "%s    %s", strInitializing, "CONFIG");
	if (SCONFIG_initPanel () < 0) return -1;
 	setCtrlStrf (outPanel, outCtrl, "%s    %s", strInitializing, "SWEEP");
	if (SWEEP_initPanel () < 0) return -1;
 	setCtrlStrf (outPanel, outCtrl, "%s    %s", strInitializing, "RUN");
	if (RUN_initPanel() < 0) return -1;
 	setCtrlStrf (outPanel, outCtrl, "%s    %s", strInitializing, "OUTPUTS");
	if (OUTPUTS_initPanel() < 0) return -1;
 	setCtrlStrf (outPanel, outCtrl, "%s    %s", strInitializing, "PLOTITEMS");
	if (PLOTITEM_initPanel() < 0) return -1;
 	setCtrlStrf (outPanel, outCtrl, "%s    %s", strInitializing, "DATA FILTERS");
	if (FILTERS_initPanel() < 0) return -1;
 	setCtrlStr (outPanel, outCtrl, strInitializing);


	EasyTab_ConvertFromCanvas (panelSMain, SMAN_CANVAS_tabCtrl);
	EasyTab_AddPanels (panelSMain, SMAN_CANVAS_tabCtrl,
					   1, panelAtoms,
					   panelSweep, panelRun, panelPlotItems, 
					   panelFilters, panelOutputs, panelConfig, 0);
	EasyTab_SetTabAttribute (panelSMain, SMAN_CANVAS_tabCtrl,
							 panelRun,
							 ATTR_EASY_TAB_LABEL_COLOR,
							 VAL_GREEN);
	EasyTab_GetBounds (panelSMain, SMAN_CANVAS_tabCtrl,
					   VAL_EASY_TAB_EXTERIOR_BOUNDS, &bounds);
	SetPanelSize (panelSMain, 
				  bounds.top + bounds.height + ctrlHeight (panelSMain, SMAN_STRING_status),
				  bounds.left + bounds.width);
    CreateMetaFont (metaFont, VAL_DIALOG_FONT, 20, 0, 0, 0, 0);
    
	SetCtrlAttribute (panelSMain, SMAN_STRING_status, ATTR_TOP, 
					  panelHeight(panelSMain) - ctrlHeight (panelSMain, SMAN_STRING_status));
	SetCtrlAttribute (panelSMain, SMAN_STRING_status,
					  ATTR_WIDTH, panelWidth(panelSMain));

	// define start + stop button
	ctrlButtonStop = DuplicateCtrl (panelSMain, SMAN_BUTTON_start,
									panelSMain, "STOP (ESC)",
									VAL_KEEP_SAME_POSITION,
									VAL_KEEP_SAME_POSITION);
	SetCtrlAttribute (panelSMain, SMAN_BUTTON_start,
					  ATTR_CMD_BUTTON_COLOR, VAL_GREEN);
	SetCtrlAttribute (panelSMain, ctrlButtonStop ,
					  ATTR_CMD_BUTTON_COLOR, VAL_RED);
	SetCtrlAttribute (panelSMain, ctrlButtonStop ,
					  ATTR_SHORTCUT_KEY, VAL_ESC_VKEY);
									

	SetPanelPos (panelSMain, 100, screenWidth()-panelWidth(panelSMain) - 5);

	// place up/down buttons
	SetAttributeForCtrls (panelSMain, ATTR_TOP,
				ctrlTop (panelSMain, SMAN_STRING_status)
				- ctrlHeight (panelSMain, SMAN_COMMANDBUTTON_up) - 2,
				0, 
				SMAN_COMMANDBUTTON_up, 
				SMAN_COMMANDBUTTON_down, 
				SMAN_COMMANDBUTTON_top, 
				SMAN_COMMANDBUTTON_bottom, 
				0);

	SetCtrlAttribute (panelSMain, SMAN_TREE_sessions, ATTR_HEIGHT,
				      ctrlTop (panelSMain, SMAN_COMMANDBUTTON_up) 
				      - ctrlTop (panelSMain, SMAN_TREE_sessions)-3);
				      
//	DETECTION_initPanel ();
//   	SESSIONCONFIG_initPanel ();
	// ------------------------------------------
	//    init menubar
	// -----------------------------------------
	SESSIONMANAGER_initMenus ();
//	initToolbar();
	SESSIONMANAGER_displayList (1);
//SESSION_initializeListBox ();

	SESSIONMANAGER_initMiniPanelRun ();
	
	return 0;
}


//=======================================================================
//
//    display current filename in title
//
//=======================================================================
void SESSIONMANAGER_setFilenameToTitle (const char *filename, int changes)
{
	char help[MAX_PATHNAME_LEN];
	
	sprintf (help, "Session Manager V%1.2f - ", ProgramVersion);
	strcat (help, filename);
	if (changes) strcat (help, " *");
	SetPanelAttribute (panelSMain, ATTR_TITLE, help);
	strcpy (help, extractFilename (filename));
	if (changes) strcat (help, " *");
	SetCtrlVal (panelSMain, SMAN_TEXTMSG_sessionName, help);
}




// ---------------------------------------------
//   create list entry
// ---------------------------------------------
char *SESSION_createListEntry (t_session *s)
{
    static char buf[200];
    static int tab1 = -1;
    static int tab2 = -1;
    int dummy;
	
	int bgcolor = VAL_WHITE;
	int fgcolor = VAL_BLACK;

    
    if (s == activeSession()) {
       bgcolor = VAL_RED;
       fgcolor = VAL_BLACK;
    }
   
   strcpy (buf, "");
   appendColorSpec (buf, bgcolor, fgcolor);
/*   switch (s->shortcut) {
        case VAL_F5_VKEY:
        	strcat (buf, " F5 ");
        	break;
        case VAL_F6_VKEY:
        	strcat (buf, " F6 ");
        	break;
        case VAL_F7_VKEY:
        	strcat (buf, " F7 ");
        	break;
        case VAL_F8_VKEY:
        	strcat (buf, " F8 ");
        	break;
        default: strcat (buf, "    ");
    }
        	
*/        	
    if (tab1 == -1) {
    	GetTextDisplaySize ("12/08/2004", VAL_EDITOR_META_FONT, &dummy, &tab1);
    	GetTextDisplaySize ("12/08/2004|"START_ZEROES_STR, VAL_EDITOR_META_FONT, &dummy, &tab2);
    }
    	
    appendColorSpec (buf, bgcolor, fgcolor);
    // create blank item
    if (s == NULL) {
		strcat (buf, "           ");
		appendJustification (buf, tab1, LeftJustify);
		appendVLine (buf);    
    	appendJustification (buf, tab2, LeftJustify);
		appendVLine (buf);    
		strcat (buf, "                           ");
		return buf;
    }
	
	if ((s->dateStr[0] != 0) && (s->readOnly)) strcat (buf, s->dateStr);
	else strcat (buf, "           ");
//    strcat (buf, "10/10/1000");
	
    appendJustification (buf, tab1, LeftJustify);
    appendVLine (buf);
    if ((s->startNr >= 0) && (s->readOnly)) strcat (buf, intToStr0 (N_STARTNR_DIGITS, s->startNr));
    else strcat (buf, START_ZEROES_STR);
    appendJustification (buf, tab2, LeftJustify);
    appendVLine (buf);
    strcat (buf, extractFilename (s->filename));
    if (s->changes) strcat (buf, " *");
    strcat (buf, "                                            ");
    return buf;
}



/*// ---------------------------------------------
//   Insert or overrides a list item
// ---------------------------------------------
void SESSIONMANAGER_OverrideListItem (int panel, int ctrl, int index, const char *txt, int value)
{
	int nLines;
	GetNumListItems (panel, ctrl, &nLines);
	if (index < nLines) 
        ReplaceListItem (panel, ctrl, index, txt, value);
    else
        InsertListItem (panel, ctrl, index, txt, value);
}
*/ 
 
void SESSIONMANAGER_displayTreeItem (int panel, int ctrl, t_session *s, int itemNr)
{
   	char name[MAX_PATHNAME_LEN];
   	char infoStr[100];
   	int color;
   	int isActiveSession;
   	int nSpaces, spaceWidth, nameWidth, nameLength;
   	int i;
   	static int firstCall = 1;
   	const char metafont[] = "NIDialogMetaFontBOLD";

	// -----------------------------
	//      display name
	// -----------------------------
	changeSuffix (name, extractFilename (s->filename), 
					    s->changes ? "*" : "");
	isActiveSession = (s == activeSession());
	if (isActiveSession) color = VAL_BLACK;
	else if (s->readOnly) color = VAL_DK_GRAY;
	else color = VAL_BLACK;
	
	// fill name with spaces for active session 
	if (isActiveSession) {
		if (firstCall) {
			CreateMetaFont (metafont, VAL_DIALOG_META_FONT, 13, 1, 0, 0, 0);
			firstCall = 0;
		}
		GetTextDisplaySize (" ", metafont, NULL,
							&spaceWidth);
		GetTextDisplaySize (name, metafont, NULL,
							&nameWidth);
		nSpaces = (SESSIONS_COL_NAME_WIDTH - nameWidth) / spaceWidth;
		if (nSpaces > 0) {
			nameLength = strlen (name);
			for (i = 0; i < nSpaces; i++) name[nameLength+i] = ' ';
			name[nameLength+nSpaces] = 0;
		}
	}
	
	
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_NAME,
						  ATTR_LABEL_TEXT,  name);
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_NAME,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_LEFT_JUSTIFIED);
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_NAME,
						  ATTR_LABEL_COLOR, color);
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_NAME,
						  ATTR_LABEL_BOLD, isActiveSession);
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_INFO,
						  ATTR_LABEL_BOLD, isActiveSession);
	
	// date
/*	if ((s->startNr > 0) && (s->readOnly)) {
		sprintf (infoStr, "%s %s", intToStr0 (N_STARTNR_DIGITS, s->startNr), s->dateStr);
	}
	else {
		strcpy (infoStr, s->dateStr);
	}
*/
	// date
	infoStr[0] = 0;
	if (s->startNr > 0) {
		sprintf (infoStr, "%s%s ", 
				s->readOnly ? "R" : " ", intToStr0 (N_STARTNR_DIGITS, s->startNr));
	}
	if (s->readOnly) strcat (infoStr, s->dateStr);
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_INFO,
						  ATTR_LABEL_TEXT, infoStr);
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_INFO,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_LEFT_JUSTIFIED);
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_INFO,
						  ATTR_LABEL_COLOR, 
						  VAL_BLACK);
	// change background color for active session
	SetTreeCellAttribute (panel, ctrl, itemNr, VAL_ALL_OBJECTS,
						  ATTR_LABEL_BGCOLOR,
						  isActiveSession ? VAL_GREEN: VAL_WHITE);
	SetTreeCellAttribute (panel, ctrl, itemNr, VAL_ALL_OBJECTS,
						  ATTR_LABEL_BGCOLOR,
						  isActiveSession ? VAL_GREEN: VAL_WHITE);
						  // startNr
/*	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_STARTNR,
						  ATTR_LABEL_TEXT, 
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_STARTNR,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panel, ctrl, itemNr, SESSIONS_COL_STARTNR,
						  ATTR_LABEL_COLOR, VAL_LT_GRAY);
*/	
	
} 


void SESSIONMANAGER_displayActiveTreeItem (void)
{
	SESSIONMANAGER_displayTreeItem (panelSMain, SMAN_TREE_sessions, 
								    activeSession(), getActiveSessionNr ()-1);
	SetActiveCtrl (panelSMain, SMAN_TREE_sessions);
	ProcessDrawEvents();
}

// ---------------------------------------------
//   display the list of sessions
// ---------------------------------------------
void SESSIONMANAGER_displayList (int changeFirstLine)
{
    int i;
	int panel = panelSMain;
	int ctrl = SMAN_TREE_sessions;
	t_session *s;

	setNumTreeItems (panel, ctrl, nSessions());
	for (i = 1; i <= nSessions(); i++) {
		s = SESSION_ptr (i);
		SESSIONMANAGER_displayTreeItem (panel, ctrl, s, i-1);
	}

/*
	if (panelSMain == -1) return;
	GetNumListItems (panelSMain, SMAN_LISTBOX_sessions, &nLines);
    for (i = 1; i <= nSessions(); i++)
    {
         SESSIONMANAGER_OverrideListItem (panelSMain, SMAN_LISTBOX_sessions, i-1, 
		       SESSION_createListEntry (SESSION_ptr(i)), i);
    }
    // fill rest with blank lines
    blankItem = SESSION_createListEntry (NULL);
    GetCtrlAttribute (panelSMain, SMAN_LISTBOX_sessions, ATTR_VISIBLE_LINES, &numVisibleItems);
    for (i = nSessions(); i < numVisibleItems; i++) {
        SESSIONMANAGER_OverrideListItem (panelSMain, SMAN_LISTBOX_sessions, i, blankItem, 0);
    }
	if (i < nLines) 
		DeleteListItem (panelSMain, SMAN_LISTBOX_sessions, i, -1);
	
	if (changeFirstLine) {
		firstVisibleLine = getActiveSessionNr () - numVisibleItems / 2;
		if (firstVisibleLine + numVisibleItems > nSessions()) firstVisibleLine = nSessions() - numVisibleItems;
		SetCtrlAttribute (panelSMain, SMAN_LISTBOX_sessions, ATTR_FIRST_VISIBLE_LINE,
						  firstVisibleLine);
	}
*/		
}



void SESSION_appendToList (t_session *s)
{
    ListInsertItem (smanagerConfig->listOfSessions, &s, END_OF_LIST);
    SESSIONMANAGER_displayList (0);
}



/************************************************************************/
/************************************************************************/
/*
/*    Main Menu functions 
/*
/************************************************************************/
/************************************************************************/


 




//=======================================================================
//
//   load sequence 
//
//=======================================================================
int SESSIONMANAGER_loadSession (const char *filename)
{
    t_session *new;
    int err;

    new = SESSION_new ();
    if ((err = SESSION_load (filename, new)) == 0) {
        // append new sequence
        SESSION_appendToList (new);
	    SESSION_setAsActive (nSessions());
    	SESSIONMANAGER_displayList (1);  
    	writeSessionManagerConfig (smanagerConfig);
    }
    else {  // Fehler beim Laden
        MessagePopup ("Error", "Load error");
        free (new);
    }
    return err;
}



//=======================================================================
//
//    create an empty sequence  
//
//=======================================================================
t_session *SESSION_createEmptySession (void)
{

    t_session *new;
    
   	// ---------------------------------------------
    //   create a new sequence
	// ---------------------------------------------
    new = SESSION_new ();
    SESSION_init (new);
	// ---------------------------------------------
    //   set filename 
	// ---------------------------------------------
    strcpy (new->filename, SESSION_defaultFilename);  
//    setSystemDefaults (new);

//    a = newAtom (new);
//    initAtom (a);
    
    return new;
}


int SESSION_getNrFromPtr (t_session *s)
{
    t_session *ptr;
    int i;
    
    for (i = nSessions(); i > 0; i--) {
    	ptr = SESSION_ptr (i);
    	if (ptr == s) return i;
	}
	return 0;
}



//=======================================================================
//
//    close session
//
//=======================================================================
int SESSION_close (int nr)
{
    t_session *s;	
    int isActiveSession;
	char command[MAX_PATHNAME_LEN];
	int defaultErr;
    
	s = SESSION_ptr (nr);
	if (s == NULL) return 0;
	// ---------------------------------------------
	//   close corresponding sequence if 
	//   Hardware control is active
	// ---------------------------------------------
	if (getLaunchState()) {
		sprintf (command, "%s %s", TCP_CMD_CLOSE, extractFilename(s->filename));
		changeSuffix (command, command, SEQUENCE_fileSuffix);	
		defaultErr = TCP_displayErrorMessages (0);		
		TCP_clientSendStrf (command);
		TCP_displayErrorMessages (defaultErr);		
	}
	// ---------------------------------------------
	//   test if changes were made
	// ---------------------------------------------
    if (s->changes) {
        switch (messagePopupSaveChanges (s->filename)) {
			// ---------------------------------------------
			//   save before close
			// ---------------------------------------------
            case VAL_GENERIC_POPUP_BTN1:
				if (SESSIONMANAGER_saveSession (s) != 0) return -1;            
                //if (SESSION_save (s->filename, s) != 0) return -1;
                break;
			// ---------------------------------------------
			//   cancel 
			// ---------------------------------------------
            case VAL_GENERIC_POPUP_BTN3:
                return -1;
		}            
	}
	
	isActiveSession = (s == activeSession());
	ListRemoveItem (smanagerConfig->listOfSessions, 0, nr);
   	SESSION_free (s); 
    free (s);
    s = NULL;

	if (nSessions() == 0) {
		// ---------------------------------------------
		//   no sessions in memory 
		// ---------------------------------------------
	    SESSION_appendToList (SESSION_createEmptySession ());
		SESSION_setAsActive (nSessions());

	}
	else {
		// ---------------------------------------------
		//   determine new active session
		// ---------------------------------------------
	    if (isActiveSession) {
	    	// active session was closed
			SESSION_setAsActive (nr-1);
			//SESSION_displayActive ();
		}
		else {
			// inactive session was closed
			if (nr < smanagerConfig->activeSessionNr) 
					smanagerConfig->activeSessionNr--;
			if (smanagerConfig->activeSessionNr <= 0) smanagerConfig->activeSessionNr = 1;
			SESSIONMANAGER_displayList (0);   
		}
	}

     return 0;
}

   

//=======================================================================
//
//    Menu: New session 
//
//=======================================================================
void CVICALLBACK MENU_newSession (int menuBar, int menuItem, void *callbackData,
        int panel)
{
    SESSION_appendToList (SESSION_createEmptySession ());
	SESSION_setAsActive (nSessions());
}



void CVICALLBACK MENU_loadSession (int menuBar, int menuItem, void *callbackData,
		int panel)
{
    char filename[MAX_PATHNAME_LEN];
    
    if (FileSelectPopup (smanagerConfig->defaultPath, "*.ses", "*.ses",
						 "Load session", VAL_LOAD_BUTTON, 0, 1, 1, 0,
						 filename) > 0) {
		strcpy (smanagerConfig->defaultPath, extractDir (filename));
        SESSIONMANAGER_loadSession  (filename);      
    }
}


int SESSIONMANAGER_saveSession (t_session *s) 
{
    char help[500];
    int err;

    if (strcmp (s->filename, SESSION_defaultFilename) == 0) {
        SESSIONMANAGER_saveAs (s);
        return 0;
    }
    
    if (s->readOnly) {
		sprintf (help, "Warning! The session\n\n\"%s\"\n\nhas \"read only\" status."
    				   " It was probably reloaded from saved data.\n", s->filename); 		
		switch (GenericMessagePopup ("Warning", help, "Discard changes",
									 "Save as...", "Abort", 0, 0, 0,
									 VAL_GENERIC_POPUP_BTN1,
									 VAL_GENERIC_POPUP_BTN1,
									 VAL_GENERIC_POPUP_BTN3)) {
				case VAL_GENERIC_POPUP_BTN1: return 0;
				case VAL_GENERIC_POPUP_BTN2: 
        			SESSIONMANAGER_saveAs (s);
					return 0;
				case VAL_GENERIC_POPUP_BTN3: return -1;
				default: return -1;
		}
    }
    
    sprintf (help, "Saving %s.\n", s->filename);
    SetCtrlVal (panelSMain, SMAN_STRING_status, help);
    if ((err = SESSION_save (s->filename, s)) == 0) {
        s->changes = 1;
        SESSION_setChanges (s, 0);
//    	writeSessionManagerConfig (smanagerConfig);
    	s->readOnly = 0;
    }
    return err;

}



void CVICALLBACK MENU_saveSession (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	SESSIONMANAGER_saveSession (activeSession());
}



void CVICALLBACK MENU_closeSession (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	SESSION_close (smanagerConfig->activeSessionNr);    
}


void MENU_closeAllSessions (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	int i;
	
	writeSessionManagerConfig (smanagerConfig);
    for (i = nSessions(); i > 0; i--) {
        if (i != getActiveSessionNr()) {
	        if (SESSION_close (i) != 0) goto END;
	    }
	}
	
	SESSION_close (getActiveSessionNr());

END:
    SESSIONMANAGER_displayList (1);   
	writeSessionManagerConfig (smanagerConfig);

}




void CVICALLBACK MENU_detection (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	DETECTORS_displayPanel (activeSession()) ;
}


void CVICALLBACK MENU_filters (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	FILTERS_displayPanel (activeSession());
}


void CVICALLBACK MENU_diagram (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	DIAGRAM_displayPanel (activeSession()) ;
}


void CVICALLBACK MENU_createSequence (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	char filename[MAX_PATHNAME_LEN];
	t_session *s;

	s = activeSession();
	changeSuffix (filename, s->filename, ".seq");

	SetWaitCursor (1);

	if (SESSIONMANAGER_createSequence (s, filename, 1) == 0) {
//		SEQUENCE_save (filename, s->sequence);
		SESSIONMANAGER_transmitSequence (s);
	}
	SetWaitCursor (0);
	
//	EVENTS_checkForConflicts (s, 1, NULL);
//	EVENTS_displayPanel (s);   
}


void CVICALLBACK MENU_displayEvents (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	t_session *s;
	
	s = activeSession ();
	SetWaitCursor (1);
	
	SESSIONMANAGER_createSequence (s, "", 0);
//	EVENTS_checkForConflicts (s, 1, NULL);
//	EVENTS_checkTimesOfEvents (s, 0);
	EVENTS_displayPanel (s);   
	SetWaitCursor (0);
}



void CVICALLBACK MENU_startExperimentControl (int menuBar, int menuItem, void *callbackData,
		int panel)
{
    int err;
#ifndef EXPERIMENTCONTROL
    SetWaitCursor (1);
    err = launchExperimentControl (1, 1);
    SetWaitCursor (0);
#endif 
}


void CVICALLBACK MENU_quitExperimentControl (int menuBar, int menuItem, void *callbackData,
		int panel)
{
    int err;
#ifndef EXPERIMENTCONTROL
	err = TCP_clientSendCommand (TCP_CMD_QUIT);
#endif 
}


void CVICALLBACK MENU_displayCounts (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	t_run *r;
	
	r = activeRun;
	if (r != NULL) {
		COUNTS_displayRun (r);
		DisplayPanel (r->panelCounts);
	}
}


void CVICALLBACK MENU_curves (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	CURVES_displayPanel ();
}



void CVICALLBACK MENU_runs (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	RUNS_displayPanel ();
}



void CVICALLBACK MENU_createDataPath (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	RUN_createTodaysDataPath (smanagerConfig);
	if (!ConfirmPopupf ("Create directory", "Do you want to create the directory\n%s ?\n",
					     smanagerConfig->dataPathToday)) return;
	if (mkDirs (smanagerConfig->dataPathToday) != 0) return;
}


void CVICALLBACK MENU_digitalOutputs (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	OUTPUTS_DIRECT_start ();
}


void SESSIONMANAGER_backupProgramOLD (int backupExe)
{
	const char program[] = "c:\\program files\\winzip\\wzzip.exe";
	const char options[] = "-a -p -r -^ -yp -x..\\Releases_ExperimentControl\\*.exe -x..\\TestData\\*.* -x..\\TestPrograms\\*.* ";
	const char zipFile[] = "SessionManager_%02d%02d%02d.zip";
	char filename[100];

	const char fileList[] = " ..\\*.cws ..\\*.prj ..\\*.c ..\\*.h ..\\*.uir ..\\*.ico ..\\*.txt ";
	
	const char exeFile[] =
			#ifdef _CVI_DEBUG_
				" ..\\SessionManage?_dbg.exe"
			#else
				" ..\\SessionManage?.exe"
			#endif
				" ..\\ExperimentContro?.exe";

	
	char commandStr[500];
	int handle;
	int errorCode;
	int month, day, year;
	
	GetSystemDate (&month, &day, &year);
	sprintf (filename, zipFile, day, month, year % 100);
	if (!ConfirmPopupf ("Save program and source code", "This operation will save Session Manager together with\n"
					  "the source code in the current data directory.\n\n"
					  "Filename: %s\n\n"
					  "Do you want to continue?", filename)) return;

	errorCode = FileExists (program, 0);
	if (errorCode != 1) {
		MessagePopupf ("Error", "Command line module of WINZIP \n'%s' not found.\n\n"
					   "Note:\n"
					   "You can download the file together with WINZIP at www.winzip.com\n"
					   "(see 'WinZip Command Line Support Add-On').", program);
		return;
	}
	RUN_createTodaysDataPath (smanagerConfig);
	if (mkDirs (smanagerConfig->dataPathToday) != 0) return;

	DeleteFile (strAdd (smanagerConfig->dataPathToday, filename));
	strcpy (commandStr, "\"");
	strcat (commandStr, program);
	strcat (commandStr, "\"");
	strcat (commandStr, options);
	strcat (commandStr, "\"");
	strcat (commandStr, smanagerConfig->dataPathToday);
	strcat (commandStr, filename);
	strcat (commandStr, "\" ");
	strcat (commandStr, fileList);
	if (backupExe) strcat (commandStr, exeFile);
	errorCode = LaunchExecutableEx (commandStr, LE_SHOWNORMAL,
									&handle);
	if (errorCode != 0) {
		MessagePopupf ("Error", "Function 'LaunchExecutableEx()' failed.\n\nError code %d: %s",
						errorCode, errorStringUtility (errorCode));
		return;
	}
	RetireExecutableHandle (handle);


}




void SESSIONMANAGER_backupProgram (int backupExe)
{
//	const char program[] = "D:\\LAB\\Software\\ExperimentControl\\zip.exe ";
	const char options[] = "-q -R ";
	const char excludes[] = ""; //"-x ..\\Releases_ExperimentControl\\*.exe ..\\TestData\\*.* ..\\TestPrograms\\*.* ";
	const char zipFile[] = "SessionManager_%02d%02d%02d";
	char filename[100];
	
	const char fileList[] = " *.cws *.prj *.c *.h *.uir *.ico *.txt *.config "
							" exe\\"ZIPEXE 
							" exe\\"UNZIPEXE;
	
	const char exeFile[] =
			#ifdef _CVI_DEBUG_
				" \\exe\\SessionManager_dbg.exe"
			#else
				" \\exe\\SessionManager.exe"
			#endif
				" \\exe\\ExperimentControl.exe";

	
	char commandStr[500];
	int handle;
	int errorCode;
	int month, day, year;
	char zipExePath[MAX_PATHNAME_LEN];
	
	GetSystemDate (&month, &day, &year);
	sprintf (filename, zipFile, day, month, year % 100);
	if (!ConfirmPopupf ("Save program and source code", "This operation will save Session Manager together with\n"
					  "the source code in the current data directory.\n\n"
					  "Filename: %s\n\n"
					  "Do you want to continue?", filename)) return;


//	MakePathname (GetProjectDir, ZIPEXE, zipExePath);
	GetProjectDir (zipExePath);
	strcat (zipExePath, "\\");
	strcat (zipExePath, ZIPEXE);

	errorCode = FileExists (zipExePath, 0);
	if (errorCode != 1) {
		MessagePopupf ("Error", "ZIP Command line module '%s' not found.\n\n", zipExePath);
		return;
	}
	RUN_createTodaysDataPath (smanagerConfig);
	if (mkDirs (smanagerConfig->dataPathToday) != 0) return;

	DeleteFile (strAdd (smanagerConfig->dataPathToday, filename));
	
	commandStr[0] = 0;
	strcpy (commandStr, "\"");
	strcat (commandStr, zipExePath);
	strcat (commandStr, "\" ");
	
	strcat (commandStr, options);
	
	strcat (commandStr, "\"");
	strcat (commandStr, smanagerConfig->dataPathToday);
	strcat (commandStr, filename);
	strcat (commandStr, "\" ");
	
	strcat (commandStr, fileList);
	if (backupExe) strcat (commandStr, exeFile);
	
/*	strcat (commandStr, "\"");
	strcat (commandStr, excludes);
	strcat (commandStr, "\" ");
	
*/	

	SetDir ("D:\\LAB\\Software\\ExperimentControl\\");
	errorCode = LaunchExecutableEx (commandStr, LE_HIDE, &handle);
	if (errorCode != 0) {
		MessagePopupf ("Error", "Function 'LaunchExecutableEx()' failed.\n\nError code %d: %s",
						errorCode, errorStringUtility (errorCode));
		return;
	}
	RetireExecutableHandle (handle);

	MessagePopupf (backupExe ? "Save program and source code" : "Save source code", 
			       "'%s.zip' successfully generated.", filename);
}



void CVICALLBACK MENU_saveProgram (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	SESSIONMANAGER_backupProgram (1);
}




void CVICALLBACK MENU_saveSourceCode (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	SESSIONMANAGER_backupProgram (0);
}

				 




//=======================================================================
//
//    Menu: Save copy As
//
//=======================================================================
void CVICALLBACK MENU_saveSessionCopyAs (int menuBar, int menuItem, void *callbackData,
        int panel)
{

    char filename[MAX_PATHNAME_LEN];
    char help[MAX_PATHNAME_LEN];

 	RUN_createTodaysDataPath (smanagerConfig);
	mkDirs (smanagerConfig->dataPathToday);
    if (FileSelectPopup (smanagerConfig->dataPathToday, extractFilename(activeSession()->filename), "*.ses",
                         "Save copy of session as", VAL_SAVE_BUTTON,
                         0, 0, 1, 1, filename) > 0) {
    	sprintf (help, "Saving %s.\n", filename);
    	SetCtrlVal (panelSMain, SMAN_STRING_status, help);
		strcpy (smanagerConfig->defaultPath, extractDir (filename));
    	if (!SESSION_filenameExists (filename)) {
    		if (SESSION_save (filename, activeSession()) == 0) 
    		   SESSIONMANAGER_loadSession (filename);
	    }
	    else {
    	    MessagePopup ("Error", "Cannot overwrite file.\n\nThe selected file is already opened by Session Manager.");
	    }
	    
    }
}



int SESSIONMANAGER_saveAs (t_session *s) 
{
    char filename[MAX_PATHNAME_LEN];
    char help[MAX_PATHNAME_LEN];
    int err = 0;
 
	RUN_createTodaysDataPath (smanagerConfig);
	mkDirs (smanagerConfig->dataPathToday);
	if (FileSelectPopup (smanagerConfig->dataPathToday, extractFilename(s->filename), "*.ses",
                         "Save session as", VAL_SAVE_BUTTON,
                         0, 0, 1, 1, filename) > 0) {
    	sprintf (help, "Saving %s.\n", filename);
    	SetCtrlVal (panelSMain, SMAN_STRING_status, help);
		strcpy (smanagerConfig->defaultPath, extractDir (filename));
	    s->startNr = -1;
	    s->dateStr[0] = 0;
	    err = SESSION_save (filename, s);
//    	SESSIONMANAGER_displayList ();
    	if (!SESSION_filenameExists (filename)) {
	    	strcpy (s->filename, filename);  
	    	if (s == activeSession()) SESSIONMANAGER_setFilenameToTitle (filename, s->changes);
	    }
	    else {
    	    MessagePopup ("Error", "Cannot overwrite file.\n\nThe selected file is already opened by Session Manager.");
	    }
    	SESSIONMANAGER_displayList (0);
		SESSION_displayActive ();
    }
    return err;
}

//=======================================================================
//
//    Menu: Save As
//
//=======================================================================
void CVICALLBACK MENU_saveSessionAs (int menuBar, int menuItem, void *callbackData,
        int panel)
{
    SESSIONMANAGER_saveAs (activeSession());

}


//=======================================================================
//
//    Menu: "quit" 
//
//=======================================================================
void CVICALLBACK SMAIN_MENU_Quit (int menuBar, int menuItem, void *callbackData,
        int panel)
{
	if (!ConfirmPopup ("Quit Program", "Do you really want to quit Sessionmanager?")) return;
	
	if (!SESSIONMANAGER_quit()) return;
	
/*	if ((handleExperimentControl >=  0) && (getLaunchState() == 1)) {
		TerminateExecutable (handleExperimentControl);
		setLaunchState (0);
	}
*/	QuitUserInterface (0);
}




void SESSION_rename (int sessionNr)
{
	t_session *s;
	
	char name[MAX_PATHNAME_LEN];
	
	s = SESSION_ptr (sessionNr);
	if (s == NULL) return;
	
	strcpy (name, extractFilename(s->filename));
	
	if (GenericMessagePopup ("Rename Session", "Enter new name for session", 
							 "Abort", "Done", 0, name, 100, 0,
						 VAL_GENERIC_POPUP_INPUT_STRING,
						 VAL_GENERIC_POPUP_BTN2,
						 VAL_GENERIC_POPUP_BTN1) == VAL_GENERIC_POPUP_BTN2) {
		strcpy (s->filename, extractDir (s->filename));
		strcat (s->filename, name);
		strcat (s->filename, ".ses");
		s->changes = 1;
		SESSIONMANAGER_displayList (0);  
		if (s == activeSession()) SESSIONMANAGER_setFilenameToTitle (s->filename, s->changes);
	}
					 
	
}


//=======================================================================
//
//    Session List clicked 
//
//=======================================================================
int CVICALLBACK SESSION_listClicked (int panel, int control, int event,
        void *callbackData, int eventData1, int eventData2)
{
    int sessionNr;
    char txt[100];
    int numVisibleLines, firstVisibleLine, lineHeight;
    int lineClicked;
    int item;
    
    if (RUN_getState() != RUN_STATE_INACTIVE) return 0;
    GetCtrlVal (panel, control, &sessionNr);
    sessionNr++;
    switch (event)
        {						
        case EVENT_LEFT_DOUBLE_CLICK:
			if (sessionNr > nSessions()) return 0;
     		SESSION_setAsActive (sessionNr);
     		break;
        case EVENT_RIGHT_CLICK:
			if (sessionNr > nSessions()) return 0;
			// ---------------------------------------------
			//   determine line of list box
			// ---------------------------------------------
/*			GetCtrlAttribute (panel, control, ATTR_VISIBLE_LINES,
							  &numVisibleLines);
			GetCtrlAttribute (panel, control, ATTR_FIRST_VISIBLE_LINE,
							  &firstVisibleLine);
            lineHeight = (ctrlHeight(panel,control) / numVisibleLines);
            lineClicked = 1 + firstVisibleLine + (eventData1 - ctrlTop (panel, control)) / lineHeight;
            if (lineClicked  > nSessions()-1) return 1; 
            SetCtrlVal (panel, control, lineClicked);
            sessionNr = lineClicked+1;
*/            
			// ---------------------------------------------
			//   display filename in menu
			// ---------------------------------------------
            sprintf (txt, "Close  %s", extractFilename(SESSION_ptr(sessionNr)->filename));
			SetMenuBarAttribute (menuSessionList, MENU_SESSIONMANAGER_EDIT_CLOSE,
								 ATTR_ITEM_NAME, txt);
			// ---------------------------------------------
			//   open popup menu
			// ---------------------------------------------
/*			GRAPH_getSelectionFromTree (&w, &c, &checked, 0,0);
			if (c == 0) return CURVES_runTreePopupMenu2 (w, eventData1, eventData2);
			return CURVES_runTreePopupMenu (w, c, eventData1, eventData2);
*/			
            item = RunPopupMenu (menuSessionList, MENU_SESSIONMANAGER_EDIT, panel, 
                eventData1, eventData2, 0,0,0,0);
            if (item == MENU_SESSIONMANAGER_EDIT_CLOSE) {
            	SESSION_close (sessionNr);
   				writeSessionManagerConfig (smanagerConfig);
   			}

            else if (item == MENU_SESSIONMANAGER_EDIT_SHOW)
                SESSION_setAsActive (sessionNr);
            else if (item == MENU_SESSIONMANAGER_EDIT_RENAME)
            	SESSION_rename (sessionNr);
/*            else if (item == MENU_SEQMANAGER_EDIT_SHORTCUT_F5) 
				setShortcut (seqNr, VAL_F5_VKEY);
			else if (item == MENU_SEQMANAGER_EDIT_SHORTCUT_F6) 
		 		setShortcut (seqNr, VAL_F6_VKEY);
		 	else if (item == MENU_SEQMANAGER_EDIT_SHORTCUT_F7)
				setShortcut (seqNr, VAL_F7_VKEY);
			else if (item == MENU_SEQMANAGER_EDIT_SHORTCUT_F8)
				setShortcut (seqNr, VAL_F8_VKEY);
			
*/          
			return 1;
			break;
        }
    return 0;
}



int CVICALLBACK SMAIN_TabClicked (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int tabPanel;
	t_session *s;
	
	if (quitProgramFlag) return 0;
	switch (event)
		{
		case EVENT_TAB_CHANGED:
			EasyTab_GetAttribute (panel, control, ATTR_EASY_TAB_ACTIVE_PANEL, &tabPanel);
			s = activeSession();
			if (tabPanel == panelAtoms) {
//				ATOMS_TABLE_init (s);
				ATOMS_VELOCITY_initPanel (s);
				ATOMS_DETECTOR_initPanel (s);
				ATOMS_displayAllValues (s);     
			}
			else if (tabPanel == panelConfig) {
				SCONFIG_POSITIONS_initPanel (s);
				SCONFIG_setRfParameters (s->atomConfig);
				SCONFIG_setPositions (s->atomConfig); 
//				SCONFIG_ACQUISITION_setParameters (s);
//				SCONFIG_SEQGEN_setParameters (s, smanagerConfig);
//				DETECTORS_displayAll (s);
				SCONFIG_KILLER_setValues (s, 0);
				SCONFIG_KILLER_setValues (s, 1);
				FILTERS_displayAll (s);
			}
			else if (tabPanel == panelRun) {
				RUN_displayAll(s);
			}
			else if (tabPanel == panelSweep) {
				SWEEP_displayAll (s);
			}
			else if (tabPanel == panelOutputs) {
				OUTPUTS_setValues (s);
			}
			else if (tabPanel == panelPlotItems) {
				PLOTITEM_displayAll (s);				
			}
			else if (tabPanel == panelFilters) {
				FILTERS_displayAll (s);				
			}
			
			
		}
	return 0;
}






// dim controls if session ist started
void SESSIONMANAGER_dimControls (t_session *s, int dimmed)
{
	int menuBar;
	
	EasyTab_SetTabAttribute (panelSMain, SMAN_CANVAS_tabCtrl, panelConfig,
							 ATTR_EASY_TAB_DIMMED, dimmed);
	EasyTab_SetTabAttribute (panelSMain, SMAN_CANVAS_tabCtrl, panelAtoms,
							 ATTR_EASY_TAB_DIMMED, dimmed);
	EasyTab_SetTabAttribute (panelSMain, SMAN_CANVAS_tabCtrl, panelSweep,
							 ATTR_EASY_TAB_DIMMED, dimmed);
	EasyTab_SetTabAttribute (panelSMain, SMAN_CANVAS_tabCtrl, panelOutputs,
							 ATTR_EASY_TAB_DIMMED, dimmed);
	EasyTab_SetTabAttribute (panelSMain, SMAN_CANVAS_tabCtrl, panelPlotItems,
							 ATTR_EASY_TAB_DIMMED, dimmed || (s->mode == SESSIONMODE_DIG));
//	SetAttributeForCtrls (panelSMain, ATTR_DIMMED, dimmed, 0, 
//						  SMAN_BTN_createSequence, 0);
	SetCtrlAttribute (panelSMain, SMAN_TREE_sessions, ATTR_CTRL_MODE,
					  dimmed ? VAL_INDICATOR : VAL_HOT );
	menuBar = GetPanelMenuBar (panelSMain);
	SetMenuBarAttribute (menuBar, MAINMENU_FILE, ATTR_DIMMED, dimmed);
	SetMenuBarAttribute (menuBar, MAINMENU_RESULTS_RUNS, ATTR_DIMMED, dimmed);
	SetMenuBarAttribute (menuBar, MAINMENU_SPECIAL_CREATESEQ, ATTR_DIMMED, dimmed);
	SetMenuBarAttribute (menuBar, MAINMENU_SPECIAL_DISPLAYEVENTS, ATTR_DIMMED, dimmed);
	SetMenuBarAttribute (menuBar, MAINMENU_SPECIAL_DETECTION, ATTR_DIMMED, dimmed);

	SetAttributeForCtrls (panelRun, ATTR_DIMMED, 
						  dimmed, 0, 
						  RUN_CANVAS, 
						  RUN_COMMANDBUTTON_edit,
						  0);

	SetAttributeForCtrls (panelSMain, ATTR_DIMMED, 
						  dimmed, 0, 
//						  SMAN_BUTTON_saveLast, 
						  SMAN_BUTTON_deleteLast,
						  0);
						 
	setCtrlHot2 (panelSMain, SMAN_BTN_saveRunData, !dimmed);
	
					  
	// acq mode				  
	setCtrlHot (panelRun, RUN_NUMERIC_curveStart, !dimmed);
	setCtrlHot (panelRun, RUN_NUMERIC_curveEnd, !dimmed);
	setCtrlHot2 (panelRun, RUN_RINGSLIDE_acqMode, !dimmed);
	setCtrlHot2 (panelRun, RUN_RINGSLIDE_killerCh, !dimmed);
	// start number etc...
	setCtrlHot2 (panelRun, RUN_RADIOBUTTON_saveTimes, !dimmed);
	// counters
//	setCtrlHot2 (panelRun, RUN_RADIOBUTTON_auto, !dimmed);
	setCtrlHot2 (panelRun, RUN_RADIOBUTTON_CTR0, !dimmed);
	setCtrlHot2 (panelRun, RUN_RADIOBUTTON_CTR1, !dimmed);
	setCtrlHot2 (panelRun, RUN_RADIOBUTTON_CTR6, !dimmed);
	setCtrlHot2 (panelRun, RUN_RADIOBUTTON_CTR7, !dimmed);
	setCtrlHot2 (panelRun, RUN_RADIOBUTTON_CTR7, !dimmed);
	// transfer 
	setCtrlHot2 (panelRun, RUN_RADIOBUTTON_transfer, !dimmed);
	setCtrlHot2 (panelRun, RUN_RING_transferAtom, !dimmed);
	setCtrlHot2 (panelRun, RUN_RING_transferLevel1, !dimmed);
	setCtrlHot2 (panelRun, RUN_RING_transferLevel2, !dimmed);
	if (s->mode == SESSIONMODE_DIG) {
		// sub menu "DIG"	
		setCtrlHot2 (subPanelDig, RUN_DIG_RING_channel, !dimmed);
		setCtrlHot (subPanelDig, RUN_DIG_NUMERIC_from, !dimmed);
		setCtrlHot (subPanelDig, RUN_DIG_NUMERIC_to, !dimmed);
		setCtrlHot (subPanelDig, RUN_DIG_NUMERIC_nSteps, !dimmed);
		setCtrlHot (subPanelDig, RUN_DIG_NUMERIC_nCopies, !dimmed);
//		setCtrlHot (subPanelDig, RUN_DIG_NUMERIC_nAverages, !dimmed);
		setCtrlHot2 (subPanelDig, RUN_DIG_STRING_windowName, !dimmed);
	}
	else {
		// sub menu "standard "
		setCtrlHot (subPanelStd, RUN_STD_NUMERIC_nRuns, !dimmed);
		setCtrlHot (subPanelStd, RUN_STD_NUMERIC_nSweepPoints, !dimmed);
		setCtrlHot (subPanelStd, RUN_STD_NUMERIC_nCurves, !dimmed);
		setCtrlHot (subPanelStd, RUN_STD_LISTBOX_sweeps, !dimmed);
	}
	
	if (dimmed == 0) {
		EasyTab_SetAttribute (panelSMain, SMAN_CANVAS_tabCtrl,
							  ATTR_EASY_TAB_ACTIVE_PANEL,
							  lastActivePanel());
		DisplayPanel (lastActivePanel());
	}
	// dim menu items in window "curves"
	menuBar = GetPanelMenuBar (CURVES_panelHandle());
	SetMenuBarAttribute (menuBar, CURVESMENU_WINDOW_REMOVE_ALL,
						 ATTR_DIMMED, dimmed);
}




int SESSIONMANAGER_startRun_checkCorrectPath (t_session *s) 
{
	t_smanagerConfig *c;
	char *filename;
	char *path;

	c = smanagerConfig;

	if (s->readOnly) {
//		if (!ConfirmPopupf ("Warning", "Session has \"read only\" status"
//				      " (it was probably reloaded from saved data).\n\n"
//				      "Do you want to save the session in the directory\n'%s'\n"
//				      "and then start the session?", c->dataPathToday)) return -1;
		filename = extractFilename (s->filename);
		strcpy (s->filename, c->dataPathToday);
		strcat (s->filename, filename);
		s->readOnly = 0;
		if (mkDirs (c->dataPathToday) != 0) return -1;
		if (SESSIONMANAGER_saveSession (s) != 0) {
			s->readOnly = 1;
			return 0;
		}
		SESSION_displayActive ();
		return 0;
	}
	// check if session is saved in today's data path
	path = extractDir (s->filename);
	if (stricmp (c->dataPathToday, path) != 0) {
//		if (!ConfirmPopupf ("Warning", "Session is not saved in today's data directory.\n\n"
//				      "Do you want to save the session in the directory\n'%s'\n"
//				      "before starting?", c->dataPathToday)) return 0;
		filename = extractFilename (s->filename);
		strcpy (s->filename, c->dataPathToday);
		strcat (s->filename, filename);
		if (mkDirs (c->dataPathToday) != 0) return -1;
		if (SESSIONMANAGER_saveSession (s) != 0) return -1;
		SESSION_displayActive ();
		return 0;
	}
	return 0;
}



int CVICALLBACK SESSIONMANAGER_startRun (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	
	switch (event)
		{
		case EVENT_COMMIT:
			s = activeSession(); 
			if (control == ctrlButtonStop) {
				// -----------------------
				//  "STOP" button pressed
				// -----------------------
				switch (RUN_getState()) {
					case RUN_STATE_ACTIVE:
					case RUN_STATE_PAUSED:
						RUN_stop ();
						break;
					case RUN_STATE_STOPPED:
						RUN_setState (RUN_STATE_INACTIVE);
						SESSIONMANAGER_displayMemoryInfo ();  
						break;
				}
			}
			else {
				// -----------------------
				//  "START" button pressed
				// -----------------------
				switch (RUN_getState()) {
					case RUN_STATE_INACTIVE: 
				    	RUN_setState (RUN_STATE_ACTIVE);
						RUN_createTodaysDataPath (smanagerConfig);
						if (SESSIONMANAGER_startRun_checkCorrectPath (s) != 0) {
				    		RUN_setState (RUN_STATE_INACTIVE);
							return 0;
						}
						if (s->changes) SESSIONMANAGER_saveSession (s);
						SetCtrlVal (panelSMain, SMAN_NUMERIC_run, 0);
						if (RUN_start (s) != 0) {
				    		// start failed
				    		RUN_setState (RUN_STATE_INACTIVE);
						}
						SESSIONMANAGER_displayMemoryInfo ();  
						break;
				}
			}
		}
	return 0;
}





void SESSIONMANAGER_dataReceived (t_run *r, int repetition, int run, int startNr, 
							      char *buffer, unsigned bufferSize)
{
	t_counterData *data;

	if (RUN_getState() == RUN_STATE_INACTIVE) {
		setCtrlStrf (panelSMain, SMAN_STRING_status, 
				"Received data although run is not active.");
	}
	if (r == NULL) return;
	data = COUNTERDATA_new ();
	r->lastData = data;

	// receive CounterData
	if (COUNTERDATA_copyReceivedData (data, buffer, bufferSize) != 0) {
	
		RUN_stop ();
	}
	else {

		if (data->startNr != r->startNr) {
			MessagePopupf ("Error!", "Received counter data from start no %d\n"
						  "Current start is no %d", startNr, r->startNr);
			return;
		}
		if (data->repetition >= r->nRepetitionsPerRun) {
			MessagePopupf ("Error!", "Received counter data from repetion no %d\n"
						  "but max number of repetitions is %d", data->repetition+1, r->nRepetitionsPerRun);
			return;
		}
		if (data->run >= r->nRuns) {
			MessagePopupf ("Error!", "Received counter data from run no %d\n"
						  "but max number of runs is %d", data->run+1, r->nRuns);
			return;
		}
		RUN_processReceivedData (r);
	}
	RUN_displayRunNr (r);
}


void SESSIONMANAGER_programMI6021 (int nChannels, char *buffer, unsigned bufferSize)
{
	t_outputData *outData;
	int i;
	unsigned outBufferSize;

	outData = OUTPUTDATA_getExternalAOChannelsFromBuffer (buffer, bufferSize, nChannels);   

	outBufferSize  = 0;
	for (i = 0; i < outData->AOnChannels[0]; i++) {
		outBufferSize += sizeof (short)* outData->ExternalTotalSamples[i];
		outData->AO_ShiftSamples[i] = MI6021_NSAMPLES_BEFORE_TRIGGER;
	}
	outData->AO_OutBuf[0] = (short *) malloc (outBufferSize);
	
	// DEBUG
//	outData->AO_Values[0][1] = 8191;
	OUTPUTDATA_writeAOBytesToOutputBuffer (outData, 0);

	DEVICE_MI6021_startOutput (outData);

	OUTPUTDATA_free (outData, 1);
}


void SESSIONMANAGER_programMI6021_constVoltages (double voltage1, double voltage2)
{
}


void SESSIONMANAGER_displayRunNr (t_session *s, int runNr, int repetitionNr)
{
	int displayPanel;
	int visible;
	
	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_run, ATTR_VISIBLE, 1);
	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_repetition, ATTR_VISIBLE, 1);

	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_run, ATTR_CTRL_VAL, runNr);
	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_repetition, ATTR_CTRL_VAL, repetitionNr);

	
	if (panelMiniRun <= 0) return;

	SetCtrlAttribute (panelMiniRun, MINIRUN_NUMERIC_run, ATTR_CTRL_VAL, runNr);
	SetCtrlAttribute (panelMiniRun, MINIRUN_NUMERIC_repetition, ATTR_CTRL_VAL, repetitionNr);
	
	displayPanel = s->mode == SESSIONMODE_STANDARD;
	
	GetPanelAttribute (panelMiniRun, ATTR_VISIBLE, &visible);
	if (visible != displayPanel) {
		if (displayPanel) DisplayPanel (panelMiniRun);
		else HidePanel (panelMiniRun);
	}
	
	
}

// ====================================================
//
//     this function is called when
//     command via TCPIP is received
//
// ====================================================

void SESSIONMANAGER_parseTCPString (char *buffer, unsigned long bufferSize)
{
	char *parts[MAX_COMMANDSTRING_PARTS];
	int nParts;
	unsigned long l;

	int startNr = -1;
	t_run *r;
	int repetition;
	int run;
	int commandID;
	

    cutCommandString (buffer, parts, &nParts);
   	l = strlen(buffer)+1;
	r = activeRun;
	commandID = TCP_cmdStrID (parts[0]);
	switch (commandID) {
		case TCP_CMD_ID_MI6021_STOP:
			DEVICE_MI6021_stop();
			break;
		case TCP_CMD_ID_MI6021_PROGRAM: 
			SESSIONMANAGER_programMI6021 (strToInt (parts[1]), &buffer[l], bufferSize-l);
			break;
		case TCP_CMD_ID_MI6021_RESET:
			DEVICE_MI6021_reset();
			break;
		case TCP_CMD_ID_MI6021_CONSTVOLTAGE:
			if (nParts < 3) return;
			DEVICE_MI6021_outputConstantVoltages (strtol (parts[1], 0, 10), strtol (parts[2], 0, 10));
			break;			
			
		case TCP_CMD_ID_DATA:
	    	// start sequence
			startNr	= -1;
			run = 0;
			repetition = 0;
			if (nParts >= 2) StrToInt (parts[1], &repetition);
			if (nParts >= 3) StrToInt (parts[2], &run);
			if (nParts >= 4) StrToInt (parts[3], &startNr);
			SESSIONMANAGER_displayRunNr (r->session, run+1, repetition+1);
			SESSIONMANAGER_dataReceived (r, repetition, run, startNr, &buffer[l], bufferSize-l);
			break;
	    // ===========================
	    //  received "STOPPED"
	    // ===========================
		case TCP_CMD_ID_STOPPED:
			SetCtrlAttribute (panelSMain, SMAN_NUMERIC_run, ATTR_VISIBLE, 1);
			SetCtrlAttribute (panelSMain, SMAN_NUMERIC_repetition, ATTR_VISIBLE, 1);
			if (panelMiniRun) HidePanel (panelMiniRun);
	    	RUN_cmdStoppedReceived (r);
	    	break;
	    case TCP_CMD_ID_FILE:
			COUNTERDATA_saveFile (&buffer[l], bufferSize-l);
			break;
	}
}	 


int CVICALLBACK SESSIONMANAGER_panelCallback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{

	switch (event) {
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:
			SMAIN_MENU_Quit (0, 0, 0, 0);
			break;
		case EVENT_KEYPRESS:
//			i = (VAL_MENUKEY_MODIFIER + 'R');
			switch (eventData1) {
				case VAL_F9_VKEY:
					EasyTab_SetAttribute (panelSMain, SMAN_CANVAS_tabCtrl, 
										  ATTR_EASY_TAB_ACTIVE_PANEL, panelRun);
					CallCtrlCallback (panelSMain, SMAN_BUTTON_start, EVENT_COMMIT,
									  eventData1, eventData2, NULL);
					break;
				case (VAL_MENUKEY_MODIFIER + 'R'):
					EasyTab_SetAttribute (panelSMain, SMAN_CANVAS_tabCtrl, 
										  ATTR_EASY_TAB_ACTIVE_PANEL, panelRun);
					break;
   			}
   			

			break;
	}
	return 0;
}







void ERROR_showMessagef (const char *format, ...)
{
	char helpStr[500];
	static int panelError = -1;
	int visible;
	
	va_list arg;

	va_start( arg, format );
    vsprintf(helpStr, format, arg  );
    va_end( arg );

	if (panelError == -1) {
		panelError = LoadPanel (0, SESSIONMANAGER_uirFile, ERRPANEL); 
	}
	GetPanelAttribute (panelError, ATTR_VISIBLE, &visible);
	if (visible) return;
	SetCtrlAttribute (panelError, ERRPANEL_TEXTBOX, ATTR_FRAME_COLOR,
					  VAL_PANEL_GRAY);
	DeleteTextBoxLines (panelError, ERRPANEL_TEXTBOX, 0, -1);
	InsertTextBoxLine (panelError, ERRPANEL_TEXTBOX, -1, "\n");
	SetCtrlVal (panelError, ERRPANEL_TEXTBOX, helpStr);
	InstallPopup (panelError);
}




int CVICALLBACK ERROR_callback_done (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			RemovePopup (0);
			break;
	}
	return 0;
}



void SESSIONMANAGER_displayMemoryInfo (void)
{
	unsigned usage;
	unsigned totalPhysical;
	unsigned totalVirtual;
	unsigned availPhysical;
	unsigned availVirtual;
	
//	return;
	
	GetMemoryInfo (&usage, &totalPhysical, NULL, &totalVirtual,
			   &availPhysical, NULL, &availVirtual);
	SetCtrlVal (panelSMain, SMAN_NUMERIC_memoryUsage, (double)availPhysical / MB);
			   
//	tprintf ("Memory usage %d percent (available: %d MB of %d MB, virtual: %d MB of %d MB)\n",
//			usage,  availPhysical / MB, totalPhysical/ MB, availVirtual/ MB, totalVirtual/ MB);
}			





int CVICALLBACK SESSIONMANAGER_memoryClicked_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_LEFT_CLICK:            
		case EVENT_RIGHT_CLICK:            
			SESSIONMANAGER_displayMemoryInfo ();
			break;
	}
	return 0;
}

int CVICALLBACK SESSINMANAGER_updateMemoryTimer_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_TIMER_TICK:
			SESSIONMANAGER_displayMemoryInfo ();  
			break;
	}
	return 0;
}


int CVICALLBACK SESSIONMANAGER_updatePointsChanged_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession(); 
			if (s != NULL) GetCtrlVal (panelSMain, SMAN_NUMERIC_updatePoints, &s->updatePoints);
			break;
	}
	return 0;
}





void SESSION_moveinList (t_session *s, int oldIndex, int direction)
{
	int newIndex;
	t_session *newItem, *oldItem;
	t_plotItem *p;
	int i, n;
	
	n = nSessions();
	if ((oldIndex < 1) || (oldIndex > n)) return;
	newIndex = oldIndex + direction;
	if ((newIndex < 1) || (newIndex > n)) return;
	if (oldIndex == smanagerConfig->activeSessionNr) smanagerConfig->activeSessionNr = newIndex;	
	ListGetItem (smanagerConfig->listOfSessions, &oldItem, oldIndex);
	ListGetItem (smanagerConfig->listOfSessions, &newItem, newIndex);
	ListReplaceItem (smanagerConfig->listOfSessions, &newItem, oldIndex);
	ListReplaceItem (smanagerConfig->listOfSessions, &oldItem, newIndex);
	SESSIONMANAGER_displayTreeItem (panelSMain, SMAN_TREE_sessions, newItem, oldIndex-1);
	SESSIONMANAGER_displayTreeItem (panelSMain, SMAN_TREE_sessions, oldItem, newIndex-1);
	SetCtrlAttribute (panelSMain, SMAN_TREE_sessions,
					  ATTR_CTRL_INDEX, newIndex-1);
	for (i = 0; i < n; i++)  {
		SetTreeItemAttribute (panelSMain, SMAN_TREE_sessions, i, ATTR_SELECTED, i == (newIndex-1));
	}
	SetCtrlAttribute (panelSMain, SMAN_TREE_sessions,
					  ATTR_CTRL_INDEX, newIndex-1);
}


int CVICALLBACK SESSION_moveInList_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr;
	int i;
	
	switch (event)
		{
		case EVENT_COMMIT:
//			GetCtrlIndex (panelSMain, SMAN_TREE_sessions, &nr);
			nr = getActiveSessionNr();
			switch (control) {
				case SMAN_COMMANDBUTTON_up:
					SESSION_moveinList (activeSession(), nr, -1);
					break;
				case SMAN_COMMANDBUTTON_down:
					SESSION_moveinList (activeSession(), nr, 1);
					break;
				case SMAN_COMMANDBUTTON_top:
					for (i = nr; i > 1; i--) {
						SESSION_moveinList (activeSession(), i, -1);
						Delay(0.05);
						ProcessDrawEvents();
					}
					break;
				case SMAN_COMMANDBUTTON_bottom:
					for (i = nr; i <= nSessions(); i++) {
						SESSION_moveinList (activeSession(), i, 1);
						Delay(0.05);
						ProcessDrawEvents();
					}
					break;
			}
			writeSessionManagerConfig (smanagerConfig);
			break;
		}
	return 0;
}
