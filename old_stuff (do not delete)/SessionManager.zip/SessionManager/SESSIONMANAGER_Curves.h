#if !defined (SESSIOMANAGER_PLOT)
#define SESSIOMANAGER_PLOT



#define MAX_PLOTNAME_LEN 50

// maximum number of points allowed in 2D plot
#define  MAX_VALUES_PLOT2D 500000  


#define VAL_VERTICAL_BAR_ERROR 1000

#define GRAPH_BACKGOUND_COLOR   VAL_DK_GRAY
#define GRAPH_GRID_COLOR		VAL_LT_GRAY

#define CURVE_DEFAULT_COLOR				VAL_ORANGE
#define CURVE_CURRENT_DEFAULT_COLOR		VAL_ORANGE
#define CURVE_DIG_COLOR			VAL_ORANGE
#define CURVE_DEFAULT_COLOR_E	VAL_LT_RED
#define CURVE_DEFAULT_COLOR_G   VAL_LT_BLUE

#define VAL_COLOR_AUTO -1
#define VAL_STYLE_AUTO -1
#define NO_VALUE -1.0E-300


//int plotColor (int i);

#define suffixCurveP  ".curve"
#define suffixCurve  "*"suffixCurveP


#define suffixCurveTxtP  ".dat"
#define suffixCurveTxt  "*"suffixCurveTxtP


#define MAX_CURVENAME_LEN 100
#define MAX_CURVEINFO_LEN 300
#define MAX_AXISNAME_LEN 50

#define MAX_UNIT_LEN 30
#define MAX_TITLE_LEN 100
#define MAX_DATESTR_LEN 20
#define MAX_TIMESTR_LEN 10

#define MAX_COMPONENT_NAME 25
#define CURVES_MAX_POSITIONS 20


typedef struct dRect 
{
	double xFrom;
	double xTo;
	double yFrom;
	double yTo;
} dRect;


int dRect_isEqual (dRect *r1, dRect *r2);


typedef struct {
	char name[MAX_CURVENAME_LEN];
	int startNr;
	
	char info[MAX_CURVEINFO_LEN];
	
	char dateStr[MAX_DATESTR_LEN];
	char timeStr[MAX_DATESTR_LEN];
	int plotType;
	
	char title[MAX_TITLE_LEN];
	char xLabel[MAX_AXISNAME_LEN];
	char xAsciiFileColumnLabel[MAX_AXISNAME_LEN]; 
	char xUnits[MAX_UNIT_LEN];
	
	char yLabel[MAX_AXISNAME_LEN];
	char yAsciiFileColumnLabel[MAX_AXISNAME_LEN]; 
	char yUnits[MAX_UNIT_LEN];
	int xDigits;

	int xShowSecondAxis;
	double xAxis2Multiply;
	char xLabel2[MAX_AXISNAME_LEN];
	char xAsciiFileColumnLabel2[MAX_AXISNAME_LEN]; 
	char xUnits2[MAX_UNIT_LEN];

	int yShowSecondAxis;
	double yAxis2Multiply;
	char yLabel2[MAX_AXISNAME_LEN];
	char yAsciiFileColumnLabel2[MAX_AXISNAME_LEN]; 
	char yUnits2[MAX_UNIT_LEN];

	int yDigits;
	int yDigits2;
	double xFrom, xTo;
	
	double *xValues;
	
	// AVERAGED CURVE
	int nValues;    // number of values in *xValues, 
			 	    //                     *yValues, 
	int nValuesVisibleAvg;
	double *yValuesAveraged;  // values of averaged curve
							  // if data = counts:
							  // data contains sum of all counts
	int divideAveraged;       // to plot data
	
	double *yErrPosAveraged;
	double *yErrNegAveraged;
	int *yAverages;

	// SINGLE CURVES OF ALL RUNS
	int averagedOnTop;		  // show averaged curve on top
							  // of the current curve
	int showCurrentCurve;
	int currentCurve;
	int nCurves;		    // number of curves in **yValues
							 // = array size of **yValues
	int nCurvesWritten;		// number of curves writtes
	unsigned *yValuesArrSize;     // size of the arrays in **yValues, **yErrPos, **yErrNeg
	unsigned *yValuesVisible;
	double **yValues;		// values of all runs
	double **yErrPos;
	double **yErrNeg;
	
	// total number of points per yValue

	int nAveraged;
	
	int hasErrorBars;
	int hasErrorBarsCurrent;
	int plotStyleCurrent;
	int plotColorCurrent;
	int pointStyleCurrent;
	int lineStyleCurrent;

	int plotStyle;
	int plotColor;
	int pointStyle;
	int lineStyle;
	int plotNumbers; // flag if numbers should be shown with bars
	Rect panelPos;
	
	// 2D curve	
	unsigned nValues2D;
	unsigned n2Dcurves;
	double *values2D;
	char xLabel2D[MAX_AXISNAME_LEN];
//	char yLabel2D[MAX_AXISNAME_LEN];
	char xUnits2D[MAX_UNIT_LEN];

/*	int showRightAxis2D;
	double rightAxis2DScalingFactor;
	char yRightLabel2D[MAX_AXISNAME_LEN];
	char yRightUnits2D[MAX_UNIT_LEN];
*/
	double *xValues2D;
	int *averages2D;
	int activeCurve2D;
	int nColors2D;
	int interpolate2D;
	int error2D;
	
	Rect panelPos2D;
// ---------------------------
// ---------------------------
//  values set during runtime
// ---------------------------
// ---------------------------
	int keep;   // do not overwrite curve if
	int visible;
	int visible2D;
	int active;
	int panelGraph;
	int newCurve;

	double maxYValue;
	double minYValue;
	double maxXValue;
	double minXValue;
	double sumYValues;
	
	int nPlotHandlesCurrent;  // number of plot handles current curve
	int *plotHandlesCurrent;

	int nPlotHandlesAveraged; // number of plot handles averaged curve
	int *plotHandlesAveraged;
	
	int panel2DPlot;
	int plotHandle2D;
	ColorMapEntry *colors2D;
	void *plotItem;
	
	int componentsVisible;
	int nComponentsPositions;
	double componentsPositions[CURVES_MAX_POSITIONS];
	int componentsColors[CURVES_MAX_POSITIONS];
	char componentsNames[CURVES_MAX_POSITIONS][MAX_COMPONENT_NAME];
	
	int markerPoint;   
	int autoScaleCurrentCurve;  // put this flag to 1 if you want that the current 
								// curves can change the 
} t_curve;


#define MAX_CURSORS 2

typedef struct {
	int visible;
	int plotType;
	
	t_curve *sliderCurve;
	int showSlider_number;
	int showStatusLine;
	
/*	int subPanelAxis;
	int subPanelStatistics;
	int subPanelCursors;
*/	
	char panelTitle[MAX_TITLE_LEN];

	char xLabel[MAX_AXISNAME_LEN];
	char xAsciiFileColumnLabel[MAX_AXISNAME_LEN]; 
	char xUnits[MAX_UNIT_LEN];
	int xDigits;
	double xFrom;
	double xTo;
	double xIncrement;
	int xFromAutoscale;
	int xToAutoscale;

	int xShowSecondAxis;
	double xAxis2Multiply;
	char xLabel2[MAX_AXISNAME_LEN];
	char xAsciiFileColumnLabel2[MAX_AXISNAME_LEN]; 
	char xUnits2[MAX_UNIT_LEN];

	char yLabel[MAX_AXISNAME_LEN];
	char yAsciiFileColumnLabel[MAX_AXISNAME_LEN]; 
	char yUnits[MAX_UNIT_LEN];
	int yDigits;
	double yFrom;
	double yTo;
	double yIncrement;
	int yFromAutoscale;
	int yToAutoscale;
	
	int yShowSecondAxis;
	double yAxis2Multiply;
	char yLabel2[MAX_AXISNAME_LEN];
	char yAsciiFileColumnLabel2[MAX_AXISNAME_LEN]; 
	char yUnits2[MAX_UNIT_LEN];

// ----------------------------------
//   parameters set during runtime
// ----------------------------------
	int panelHandle;
	int defaultPos;
	int usedByActiveSession;
//	int alwaysVisible;
	int newGraph;
	int displayed;
	int canShowCounts;
	int showCounts; //show counts instead of counts/curve

	double maxYValue;
	double minYValue;
	double maxXValue;
	double minXValue;

	int graphFullSize;
	
	int nCursors;
	int wasZoomed;
	dRect lastZoomRegion;
} t_graph;


void CURVE_init (t_curve *c);
						   
void CURVE_free (t_curve *c);


t_curve *CURVE_new (void);

int CURVE_delete (t_graph *w, t_curve *c);

t_curve *CURVE_getFromIndex (int item);

void CURVE_getWeightedMeanOfAllDatasets (t_curve *c, int index);

//////////////////////////////////
void CURVE2D_allocateMemory (t_curve *c, int nShots, int n2Dcurves);
//////////////////////////////////

void CURVE_allocateMemoryForOneCurve (t_curve *c, int curveNr, int nValues);

void CURVE_allocateMemoryRun (t_curve *c, int nRuns);

void CURVE_allocateMemory (t_curve *c, int nShots);

void CURVE_setXValues (t_curve *c, int doFill);


t_curve *CURVE_getPtrFromName (t_graph *w, const char *name, int checkKeepState);

//t_curve *CURVE_getPtrFromName (t_graph *w, const char *name);

int CURVE_loadTxt (const char *filename, t_curve **returnCurve);

int CURVE_saveTxt (const char *filename, t_curve *c, t_graph *g);

void CURVE_setTime (t_curve *c);


void CURVE_getMinMax (t_curve *c);

//int CURVE_nr (t_graph *w, t_curve *c);


int CURVE_getTreeItemNr (t_graph *w, t_curve *c, int *plotItem, int *curveItem, 
					      int *curve2DItem, int *currentCurveItem);

//void CURVE_getTreeItemNr (t_graph *w, t_curve *c, int *plotItem, int *curveItem);
//void CURVE_getTreeItemNr (t_graph *w, t_curve *c, int *plotItem, int *curveItem, int *curve2DItem);


t_curve *CURVE_create (t_graph *w, const char *name, int nPoints, int n2Dcurves);     

int CURVE_average (t_graph *w, t_curve *c, int *nAveragesToDo);

void CURVE_removePlot (t_graph *w, t_curve *c, int delayedDraw);

//void CURVE_removePlot (t_graph *w, t_curve *c);

void CURVE_displayCross (t_graph *w, t_curve *c, int display);


void CURVE_display (t_graph *w, t_curve *c, int refresh, 
				    int setMarkStates, int setTreeItem);


t_curve *CURVE_loadAndDisplay (const char *filename);

int CURVE_colorAuto_DIG (t_curve *curve);

void CURVE_displayTreeItem (t_graph *w, t_curve *c, int setMarkStates);


enum {
	PANEL_POS_FULLSIZE,
	PANEL_POS_TOP_LEFT,
	PANEL_POS_TOP_RIGHT,
	PANEL_POS_BOTTOM_LEFT,	
	PANEL_POS_BOTTOM_RIGHT
};
	
//
// up = 1, down = 0;
// 
//void GRAPH_positionPanel (int panel, int pos);
void GRAPH_positionPanel (t_graph *g, Rect r);//(int panel, int pos)


t_graph *GRAPH_createFromCurveData (t_curve *c);


void GRAPH_init (t_graph *w);

void GRAPH_free (t_graph *w);

//t_graph *GRAPH_newPlotWindow (t_session *s, int parentPanel, const char *title, int pos);

t_graph *GRAPH_newPlotWindow (int parentPanel, const char *title);

//t_graph *GRAPH_getWindowFromPanelHandle (int panelHandle, int *index);


t_graph *GRAPH_getFromTitle (const char *strTitle,
									   int plotType);

/*
int GRAPH_getWindowFromAxisName (t_graph **w, 
	  						    const char *xAxisName,
								const char *yAxisName,
								const char *strTitle);
*/
//t_graph *GRAPH_getWindowFromAxisName (const char *axisName);

void GRAPH_setWindowParameters (t_graph *w, t_curve *c);

void GRAPH_discard (t_graph **w);
											   
void GRAPH_discardAll (void);

void GRAPH_getWindowParameters (t_graph *w);

void GRAPH_removeCurveWithName (t_graph *w, char *name);

void GRAPH_deleteAllNonActiveCurves (t_graph *w);


void GRAPH_autoScale (t_graph *w);

t_graph *GRAPH_getFromCurve (t_curve *c);


void GRAPH_resetUsedByActiveSession (void);

void GRAPH_displayOnlyUsedPanels (void);

int GRAPH_hasActiveCurve (t_graph *w);


void GRAPH_displayAllCurves (t_graph *w, int setMarkStates, int setTreeItems);


void GRAPH_test (t_graph *w);

void GRAPH_setAllCurvesNotActive (void);

void GRAPH_setAllDisplayed (int displayed);

int GRAPH_runPopupMenu (int panel, int top, int left);

t_curve *GRAPH_firstCurve (t_graph *g);

t_curve *GRAPH_nextCurve (t_curve *start, t_graph *g);

void GRAPH_RemoveReferenceToPlotItem (void *plotItem);

//void GRAPH_setBoundingRect (t_graph *g, Rect r);

t_graph *GRAPH_getWindowFromPanelHandle (int panelHandle, int *index);


void CURVES_displayPanel (void);

void CURVES_hidePanel (void);


void CURVES_initPanel (int parentPanel);

int CURVES_panelHandle (void);

void CURSORS_setParameters (t_graph *w);


void CURVE2D_displayPanel (t_curve *c);

void CURVE2D_setValue (t_curve *c, int curveNr, int index, double value);


void CURVE2D_copyDataFromCurve (t_curve *c, int curveNr2D, int currentCurveNr);

void CURVE2D_setActiveCurve (t_curve *c, int curveNr);


void CURVE2D_displayCurve (t_curve *c, Rect pos);

void CURVE2D_resetValues (t_curve *c);

int CURVE2D_saveTxt (const char *filename, t_curve *c, t_graph *w);

int CURVE2D_saveTxtAsMatrix (const char *filename, t_curve *c);



void CURVE_colorNamesToRing (int panel, int ctrl);
void CURVE_styleNamesToRing (int panel, int ctrl); 



void CUSTOM1_printf (char* format, ... );
void CUSTOM2_printf (char* format, ... );

int panelCustom (int nr);


#endif
