#if !defined(SESSIONMANAGER_DATASTRUCTURE)
#define SESSIONMANAGER_DATASTRUCTURE

#define DEBUG_MODE 1   // print debug output yes/no?

#include "UIR_SessionManager.h"
#include "SessionManager_Curves.h"
// identifiers for data fields


//#define programVersionSessionManager 1.2

extern const char SESSIONMANAGER_uirFile[];
extern const char SESSION_defaultFilename[];
extern const char SESSION_fileSuffix[];
extern const char RUN_fileSuffix[];
extern const char SESSIONMANAGER_uirFile[];

#define COLOR_REFERENCE VAL_BLUE
#define VAL_YES_NO 100
#define VAL_LEVEL  101

#define N_CAVITIES 2

// number of leading zeroes in start Nr
#define startSearchName "????_*"
#define startDirName    "%04d_%s"
#define START_ZEROES_STR "    "

#define N_STARTNR_DIGITS 4
//#define N_START_ZEROES 4

#define VAL_COLOR_SHIELDINGBOX   VAL_BLUE
#define VAL_COLOR_CIRCBOX_HOLE  VAL_BLUE

#define VAL_COLOR_CAVITY        VAL_RED
#define VAL_COLOR_CAVITYRING    VAL_DK_RED
#define VAL_COLOR_CAVITYMODE    VAL_DK_RED

#define VAL_COLOR_RAMSEY        VAL_DK_GREEN
#define VAL_COLOR_RAMSEYEXT     VAL_LT_GREEN


// choose which items to display in 2D graph

#define DISPLAY_2DGRAPH_CAVITYMODE 1

// ==========================================================
//       POSITIONS (mm)
// ==========================================================

#define HALF_SIZE_RAMSEY 18.0
#define HALF_SIZE_CAVITY 27.0
#define HALF_SIZE_MODE    6.0

#define POSITION_UNASSIGNED -1E30

#define POSITION_SHILEDING_BOX_ENTRANCE 36.0
#define POSITION_HOLE_CIRC_BOX		    18.0
#define POSITION_SHILEDING_BOX_EXIT    258.0

// config 3 Ramsey
#define POSITION_3R_RAMSEY1	56.8
#define POSITION_3R_CAVITY1	101.9
#define POSITION_3R_RAMSEY2	147.0
#define POSITION_3R_CAVITY2	192.1
#define POSITION_3R_RAMSEY3	237.2


// config 2 Ramsey
#define POSITION_2R_RAMSEY1	74.9
#define POSITION_2R_CAVITY1	120.0
#define POSITION_2R_CAVITY2	174.1
#define POSITION_2R_RAMSEY3	219.2


#define POSITION_DETECTOR1  278.0
#define POSITION_DETECTOR2  308.0

#define TRANSMIT_KILLER_NONE 0
#define TRANSMIT_KILLER_LECROY 1
#define TRANSMIT_KILLER_MI6021 2


enum {
	POS_REPUMPER = 0,
	POS_LASER1,
	POS_PURIF,
	POS_HOLE_CIRC_BOX,
	POS_SHIELDINGBOX_ENTRANCE,

	POS_RAMSEY1,
	POS_RING1_C1,
	POS_START_CAVITY1,
	POS_CENTER_CAVITY1,
	POS_END_CAVITY1,
	POS_RING2_C1,
	POS_RAMSEY2,

	POS_RING1_C2,
	POS_START_CAVITY2,
	POS_CENTER_CAVITY2,
	POS_END_CAVITY2,
	POS_RING2_C2,
	POS_RAMSEY3,
	
	POS_SHIELDINGBOX_EXIT,
	
	POS_DETECTOR1,
	POS_DETECTOR2,
	
	N_POSITIONS,

	DF_NR,
	DF_ACTIVE,
	DF_NAME,
	
	DF_VELOCITY_SELECTION,
	DF_VELOCITY,
	DF_VELOCITY_SPREAD,
	DF_REPUMPER_FREQ,	  
	DF_REPUMPER_POWER,  
	DF_REPUMPER_DURATION,
	DF_REPUMPER_TIME,
	DF_REPUMPER_TIME_REFERENCE,
//	DF_REPUMPER_ALWAYS_ON,
	DF_DEPUMPER_DURATION,
	DF_DEPUMPER_TIME,


//	DF_ALWAYS_ON_LASER1,
	DF_DURATION_LASER1,
	DF_TIME_L2,
	DF_TIME_OP,
	DF_DURATION_L2,
	DF_DURATION_OP,
	
	DF_CIRC_TRIGGER_RF,
	DF_CIRC_TRIGGER_RAMP,
	DF_CIRC_52D_TIME,
	DF_CIRC_52D_DURATION,
	
	DF_STATE,			  
	DF_PURIF_START_G,       
	DF_PURIF_END_G,
	DF_PURIF_START_E,       
	DF_PURIF_END_E,
	
	DF_KILLER1_TIME_REFERENCE,
	DF_KILLER1_START_FIRST,
	DF_KILLER1_ACTIVE,

	DF_KILLER2_TIME_REFERENCE,
	DF_KILLER2_START_FIRST,
	DF_KILLER2_ACTIVE,
	
	DF_DETECT,
	DF_VOLTAGE_DETECTOR2,
	DF_VOLTAGE_DETECTOR2_TIME,
	DF_VOLTAGE_DETECTOR2_TIME_REFERENCE,

	DF_HASMULTIPLES,
	DF_NMULTIPLES,
	DF_MULTIPLE_DELAY,

//	DF_AUTO_CALCULATE_TIMES,

	N_DATAFIELDS
};

#define TIMEBASE_DIGITAL 0
#define TIMEBASE_ANALOG 1


typedef struct {
    int active;
    const char *idName;
    int graphDisplay;
    const char *graphDisplayName;
    int graphDisplayColor;
   
    // definitions concerning table
    const char *tableColumnName;
    int tableColumnWidth;
    int dataType;            
    int tableCellType;		 // data type of table cell (VAL_STRING, VAL_INTEGER, ...)
    int isEditable;

    unsigned long contentOffset;
   // element to display data
    int panelID;			// 
    int controlID;
   
	const char *positionName;  // if datafield is a position, save name of position
    int controlIDposition;	   // control ID of position
    int controlIDlabel;	       // label of control ID of position
    int cavity;
    
    int timebase;  // digital or analog timebase 
} t_dataField;



t_dataField *df (int i);

void DATAFIELD_init (t_dataField *f);

void DATAFIELD_initAll(void);

int DATAFIELD_fromName (char *name);

const char *DATAFIELD_graphDisplayName (int datafieldID);






//********************************************************************
//
//    't_atomConfig'
//
//	  configuration data for atom editor
//
//********************************************************************

#define N_TABLE_CONFIGS 3
#define N_TABLECONFIG_NAME_LEN 30

#define N_RF_CHANNELS 4


#define N_PARAMETERS_TRANSFER_FUNCT 3

typedef struct {
//	int nCavities;   // change between old and new setup

	double rfMultiplexerFrequency[N_RF_CHANNELS];
	double rfMultiplexerVelocity [N_RF_CHANNELS];
	double rfMultiplexerPower    [N_RF_CHANNELS];
	int nPositions;
//	int posFieldID;
	double position[N_POSITIONS];
	int positionReference;
    
    int activeConfig;
    char tableConfigName[N_TABLE_CONFIGS][N_TABLECONFIG_NAME_LEN];
    int nTableColumns[N_TABLE_CONFIGS];
    int tableColumns[N_TABLE_CONFIGS][N_DATAFIELDS];
    
//    int nTableColumnsOrder;
//    int tableColumnsOrder[N_DATA_FIELDS];
    
    int referenceAtom;
    int referenceAtomPosition;

	// transfer functions killer
	int transferFunct[N_CAVITIES];
	double parametersTransferFunct[N_CAVITIES][N_PARAMETERS_TRANSFER_FUNCT];
	int setDefaultVoltage[N_CAVITIES]; // switch between default voltage and detuning
	double killerDefaultVoltage[N_CAVITIES];
	double killerDefaultDetuning[N_CAVITIES];
} t_atomConfig;


void ATOMCONFIG_init  (t_atomConfig *c, t_atomConfig *defaultc);


typedef struct {
// ========================================
//    GENERAL settings 
// ========================================
	char defaultPath[MAX_PATHNAME_LEN];
	char dataPath[MAX_PATHNAME_LEN];
	char dataPathToday[MAX_PATHNAME_LEN];
	
	t_atomConfig *defaultAtomConfig;
	ListType listOfDataFields;
	
// ========================================
//    SEQUENCES 
// ========================================
	ListType listOfSessions;
	int activeSessionNr;
// ========================================
//    TCP/IP
// ========================================
	char *TCPserverName;
} t_smanagerConfig;


extern t_smanagerConfig *smanagerConfig;

void initSessionManagerConfig (t_smanagerConfig *c);





//********************************************************************
//
//    t_session
//
//    stores complete information of a session
//
//********************************************************************

// sweeptypes (voltage- and frequency sweeps)
enum {
	SWEEP_TYPE_ANALOGCHANNEL = 0,
	SWEEP_TYPE_SYNTHESIZER,
	SWEEP_TYPE_POWERSUPPLY,
	
	N_SWEEPTYPES
};

#define	SESSIONMODE_STANDARD 0
#define	SESSIONMODE_DIG		 1
//#define	SESSIONMODE_VELOCITYDIST 2

#define MAX_LEVELNAME_LEN 30
#define MAX_LEVELS 6


#define N_DETECTORS 2

#define N_SESSION_TRANSFER_LEVELS 2

#define DEFAULT_DIG_WINDOWNAME "DIG"

typedef struct {
// ========================================
//    general info
// ========================================
   	char filename[MAX_PATHNAME_LEN];
   	double programVersion;
	int shortcut;
	
    int changes;				  // true if changes made
    // true if session was loaded
    // from previous run
    int readOnly;
    int startNr;   // only used for sessions saved in the data directory
    int lastStarted; // last startnr of this session
    char dateStr[MAX_DATESTR_LEN];
    int updatePoints;

    int activeAtomNo;
    ListType lAtoms;	
    t_atomConfig *atomConfig;
    int laser1AlwaysOn;
    int laser2AlwaysOn;
    int optPumpingAlwaysOn;
    
    int repumperAlwaysOn;
	int repumperFrequency;
	int repumperPower;
	
    t_sequence *sequence;
    
    int saveRunData;
    int saveArrivalTimes;
    int generateRandomCounterData;

    char *comments;
	
	ListType lFilters;
	ListType lDetectionParameters;
	
	int nSweeps[N_SWEEPTYPES];
	ListType lSweeps;

	ListType lEvents;
	int plotSweepParameter;

// parameters data acquisition
	int mode;
	double curveStart_us;// in �s
	double curveEnd_us;
	int nAverages;

// parameters standard
// --------------------
	int nRuns;
	int nSweepPoints;
	int nCurves;
//	int nRepetitionsPerSweepPoint;
	

	// parameters DIG
	int DIG_channel;		 // DAC output channel
	double DIG_voltageFrom;  // sweep start voltage
	double DIG_voltageTo;	 // sweep end voltage
	int DIG_nSteps;			 // number of steps
	int DIG_copiesPerStep;   // copies per step
	char DIG_windowName[MAX_TITLE_LEN];
	
	// detector levels
	int nLevels;
	char levelNames[MAX_LEVELS][MAX_LEVELNAME_LEN+1];
	double levelVoltages[MAX_LEVELS];
	
	// time intervals for the 2 detectors
	int counterOn[N_COUNTERS];
//	int counterAuto;
	
	int transferOn;
	int transferAtom;
	int transferLevel[N_SESSION_TRANSFER_LEVELS];
	ListType lTimeIntervals[N_DETECTORS];
	
	// plotItems
	ListType lPlotItems;

	// transfer functions killer
//	double parametersTransferFunct[N_CAVITIES][N_PARAMETERS_TRANSFER_FUNCT];
//	double killerDefaultVoltage[N_CAVITIES];
	int transmitKillerCurves;	  //0 none    1 Le Croy  2 MI 6021
	
	// digital outputs
	int digitalOutputs_preset[N_DIO_CHANNELS];
	int digitalOutputs_onOff[N_DIO_CHANNELS];
	
// -------------------------------------
//		parameters used during runtime
// -------------------------------------
	int selectedPlotItem;
    int loadedWithRunData;
    int FIRST_KILLER_CHANNEL;
    void *run;
    t_waveform *waveformDet2;
} t_session;




void SESSION_init (t_session *s);

void SESSION_free (t_session *s);

t_session *SESSION_new (void);

t_session *SESSION_ptr (int nr);

int SESSION_filenameExists (const char *filename);       

int SESSION_getTransferLevelNr (t_session *s, int level);

t_session *SESSION_duplicate (t_session *s);

int SESSION_nTotalAtoms (t_session *s);


//==========================================================
//
//    t_atom
//
//    stores all parameters of atoms
//
//==========================================================

#define MAX_ATOMNAME_LEN 40

#define STATE_NONE -1
#define STATE_E 0
#define STATE_G 1

#define ATOM_DETECTION_USE_TRANSFER_LEVELS 0
#define ATOM_DETECTION_SET_VOLTAGE 		   1
#define ATOM_DETECTION_NONE 			   2


typedef struct {
   	char name[MAX_ATOMNAME_LEN];
    int active;
    int hasMultiples;
    int nMultiples;
    double delay;
//	int alwaysOnL1;
	double durationL1;  // duration laser 1 (420 nm)
	double timeL2;
	double durationL2;  // duration laser 2 (1015 nm)
	double timeOP;
	double durationOP;  // duration opt pumping (780 nm)
	
	
	// circularization
	double circTriggerRF;
	double circTriggerRamp;
	double circ52dTime;
	double circ52dDuration;
	
	// state preparation
	int state;
	double purifStart_e;
	double purifDuration_e;
	double purifStart_g;
	double purifDuration_g;
	
	//  velocity selection
	int velocitySelection;
	double velocity;
	double velocitySpread;
	double velocitySpreadDoppler;

	int repumperFrequency;
	int repumperPower;
	double repumperDuration;
	double repumperTime;
	int repumperTimeReference;
//	int repumperAlwaysOn;
	double depumperAngleDuration;
	double depumperAngleTime;
	
	
	
	// events
	ListType lAtomEvents;
	
	// killer
	int killerTimeReference    [N_CAVITIES];
//	int killerStartVary        [N_CAVITIES];
	double killerStartFirst    [N_CAVITIES];
//	double killerStartIncrement[N_CAVITIES];
	int nKillerPoints[N_CAVITIES];
	t_point *killerPoints[N_CAVITIES];
	int killerActive[N_CAVITIES];

	// parameters detection
	int detect;
	int detectionParameters;
	int detectionUseLevelsOfTransfer;
	int detectionSetLevel;
	int detectionLevel;
	double detectionTime;
	int detectionTimeReference;
	
	int nTimes;
	double time[N_POSITIONS];
} t_atom;

double ATOM_time(t_atom* a,double position);

void ATOM_resetAbsoluteTimes (t_atom *a);

void ATOM_init (t_atom *a);

void ATOM_free (t_atom *a);  

t_atom *ATOM_new (t_session *s);

void ATOM_duplicate (t_atom *dest, t_atom *source);

void ATOM_delete (t_session *session, int nr);

t_atom *ATOM_ptr (t_session *session, int nr);

ListType ATOM_listDuplicate (ListType list);


//==========================================================
//
//    t_atomEvent
//
//    events associated with each atom
//
//==========================================================

#define MAX_EVENTNAME_LEN 50


typedef struct {
	int active;
	int eventStyle;
	char name[MAX_EVENTNAME_LEN];
	int deviceType;				// 0 = digital, 1 = analogCh
	int digitalChannel;
	int analogChannel;
	int pulseStartReference;
	int pulseStartVary;
	double pulseStartFirst;
	double pulseStartIncrement;
	int pulseDurationVary;
	double pulseDurationFirst;
	double pulseDurationIncrement;
	int voltageVary;
	double voltageFirst;
	double voltageIncrement;
} t_atomEvent;

#define ATOMEVENT_DEVICETYPE_DIGITAL 0
#define ATOMEVENT_DEVICETYPE_ANALOG 1


t_atomEvent *ATOMEVENT_ptr (t_atom *a, int nr);
									   
void ATOMEVENT_init (t_atomEvent *e);

t_atomEvent *ATOMEVENT_new (t_atom *a);

void ATOMEVENT_free (t_atomEvent *e);

void ATOMEVENT_delete (t_atom *a, int nr);

void ATOMEVENT_duplicate (t_atomEvent *dest, t_atomEvent *source);

ListType ATOMEVENT_listDuplicate (ListType list);



//==========================================================
//
//    t_sweep
//
//    stores all parameters of a sweep
//
//==========================================================

#define SWEEP_DEFAULT_HARMONIC 4	
#define SWEEP_DEFAULT_RF_ON 1	

// sweep types uses internally
#define SWEEP_TYPE_DIGITALCHANNEL 1000
#define SWEEP_TYPE_KILLER_POINT   1001
#define	SWEEP_TYPE_REPETITION     1002  // no sweep parameter

#define MAX_SWEEPNAME_LEN 200

#define MAX_SWEEP_CTRLS_CHANGED 5

typedef struct {
	char name[MAX_SWEEPNAME_LEN];
	char quantity[MAX_AXISNAME_LEN]; // e.g. time/ frequency etc
	char plotAxisName[MAX_AXISNAME_LEN];
	char units[MAX_UNIT_LEN];
	int type;
	int active;
	int sweepOn;
	int panel;

//	int changeMode;
	int channel;
// sweep Voltage
	double from;
	double to;
	double center;
	double span;
	int nPoints;
	
// sweep Point
	double increment;
	int stepRepetitions;
	
// type: SWEEP_TYPE_SYNTHESIZER
	int rfOn;
	int pulseMode;
	int harmonic;
	double outputPower;
	
// type: SWEEP_TYPE_POWERSUPPLY
	int deviceChannel;
	double current_mA;
	
// parameters changed during runtime only
	int lastCtrlsChanged[MAX_SWEEP_CTRLS_CHANGED]; // memorizes last control that were changed
											 // index 0: most recent
} t_sweep;


t_sweep *SWEEP_ptr (t_session *s, int nr);

t_sweep *SWEEP_ptrType (t_session *s, int type, int nr, int *swNr);
									   
void SWEEP_init (t_sweep *sw);

void SWEEP_free (t_sweep *sw);

void SWEEP_freeAll (t_session *s);

t_sweep *SWEEP_new (t_session *s);

void SWEEP_delete (t_session *s, int nr);

void SWEEP_duplicate (t_sweep *dest, t_sweep *source);

t_sweep *SWEEP_ptrFromPanel (t_session *s, int panel);

int SWEEP_isSameDeviceActive (t_session *s, t_sweep *old);


ListType SWEEP_listDuplicate (ListType list);


//==========================================================
//
//    t_run
//
//    stores all parameters of a run
//    (filenames, acquired data etc.)
//
//==========================================================



#define MAX_DATESTR_LEN 20
#define MAX_TIMESTR_LEN 10

#define MAX_INFOSTR_LEN 200

typedef struct {
	char dateStr[MAX_DATESTR_LEN];
	char timeStr[MAX_TIMESTR_LEN];
	char infoStr[MAX_INFOSTR_LEN];
	
	char softwareVersionStr[50];
	int startNr;
	
	char dataDirectory   [MAX_PATHNAME_LEN];
	char filenameSession [MAX_PATHNAME_LEN];
	char filenameSequence[MAX_PATHNAME_LEN];
	char filenameRun     [MAX_PATHNAME_LEN];
	char filenameData    [MAX_PATHNAME_LEN];
	
	int nRuns;
	int nRepetitionsPerRun;
	int nCopiesPerRepetition;

	int nAveragesToDo;
	
	int mode;

// counterData (as transmitted from TCP_IP)
	t_counterData *lastData;
	
	int nData[N_COUNTERS];
	t_counterData **data[N_COUNTERS];
	// index = run *r->nRepetitionsPerRun + repetition
	
 	t_counterData *dataSum;
 	t_graph *plotWindow;
 	t_sweep *sweep;
 	
 	int freeSession;	// free session if RUN_free() is called
 						// (used if old run data is loaded)
 	t_session *session;
 	
 	ListType lTimeIntervals[N_DETECTORS];
 	int panelCounts;
 	IniText seqIni;
 	int dataSaved;
 	int lastStateDigitalLine[N_DIO_CHANNELS];
 	
} t_run;


void RUN_init (t_run *r, t_graph *w);

void RUN_free (t_run *r);

void RUN_putCounterData (t_run *r, t_counterData *data);

int RUN_datasetIndex(t_run *r, int run, int repetition);

int RUN_dataMaxDatasets (t_run *r, int counter);


//t_counterData *RUN_getCounterData (t_run *r, int run, int repetition, int counter);

t_run *RUN_new (void);



//==========================================================
//
//    t_detectionParameters
//
//    detection parameters associated with each session
//
//==========================================================


#define MAX_DETECTIONPARNAME_LEN 50
#define MAX_DET_ATOMS_LEN 100

typedef struct {
	char name[MAX_DETECTIONPARNAME_LEN ];	
	int detectorActive[N_DETECTORS];
	char atoms[MAX_DET_ATOMS_LEN];

// DETECTOR 1 (flat)
	// detection ramp
	double det1_rampStartVoltage;
	double det1_rampStopVoltage;
	double det1_rampDuration;
	double det1_rampTrigger;
	int det1_rampTriggerReference;
	// time windows e/g
	int det1_levelActive[MAX_LEVELS];
	double det1_timeStart[MAX_LEVELS];
	double det1_timeEnd[MAX_LEVELS];

// DETECTOR 2 (roof)
	double det2_timeStart;
	double det2_timeEnd;
	int det2_timeReference;
//	int det2_defaultLevel;
} t_detectionParameters;


t_detectionParameters *DETECTIONPAR_ptr (t_session *s, int nr);
									   
void DETECTIONPAR_init (t_detectionParameters *d);

void DETECTIONPAR_free (t_detectionParameters *d);

t_detectionParameters *DETECTIONPAR_new (t_session *s);

void DETECTIONPAR_delete (t_session *s, int nr);

void DETECTIONPAR_duplicate (t_detectionParameters *dest, 
							 t_detectionParameters *source);

//t_detectionParameters *DETECTIONPAR_fromAtom (t_session *s, t_atom *a);

int DETECTIONPAR_inconsistentNr (t_session *s, int nr, int detector);

int DETECTIONPAR_inconsistent (t_session *s, t_detectionParameters *d, int detector);

ListType DETECTIONPAR_listDuplicate (ListType list);


#define MAX_INTERVAL_NAME_LEN 40

typedef struct {
	char name[MAX_INTERVAL_NAME_LEN];
	char idStr[10];
	int atom;
	int multiple;
	char atomNrStr[10];
//	int copyNr;
	int levelNr;
//	double timeStart_us;
//	double timeEnd_us;
	int timeStart;
	int timeEnd;
	int repetition; // transfer: (a, b, c, ...) 
} t_timeInterval;


t_timeInterval *TIMEINTERVAL_ptrList (ListType list, int ID);
									   
void TIMEINTERVAL_init (t_timeInterval  *d);

void TIMEINTERVAL_free (t_timeInterval  *d);

t_timeInterval *TIMEINTERVAL_new (ListType list);

int TIMEINTERVAL_nrForAtom (ListType list, int atomNr);

int TIMEINTERVAL_getNr (t_session *s, int detector, int atom, int multiple, int level);

//int TIMEINTERVAL_getNr (t_session *s, int detector, int atom, int level);


t_timeInterval *TIMEINTERVAL_ptrForAtom (ListType list, int atomNr);

void TIMEINTERVAL_getMinMax (ListType list, int *min, int *max);

//void TIMEINTERVAL_sort (ListType lists);
void TIMEINTERVAL_insertInOrder (ListType list, t_timeInterval *new);


void TIMEINTERVAL_duplicate (t_timeInterval *dest, t_timeInterval *source);

void TIMEINTERVAL_duplicateList (ListType destList, ListType sourceList, int startItem);


void TIMEINTERVAL_freeList (ListType list);

ListType TIMEINTERVAL_listDuplicate (ListType list);





// auxiliary datastructure
// datastrucutre to describe "events", i.e.
// digital- and analog pulses
// used to create .seq files

typedef struct {
	char name[MAX_EVENTNAME_LEN];

	char atomStr[10];
	int time;
	int duration;
	
	// variable pulses
	int timeIncrement;
	int durationIncrement;										 
	
	int lastDuration;
	int lastTime;
	
	int alwaysOn;
	int DIG_channel;
//	
	int AO_channel;
	int waveform;
	double constVoltage;
	int voltageVary;
	double voltageIncrement;
	
	char *conflicts;
	int isAbsoluteTimeReference;
} t_event;




t_event *EVENT_ptr (t_session *s, int nr);
									   
void EVENT_init (t_event *e);

t_event *EVENT_new (t_session *s);

void EVENT_free (t_event *e);

void EVENT_freeAll (ListType listOfEvents);


void EVENT_delete (t_session *s, int nr);

ListType EVENT_listDuplicate (ListType list);






#define MAX_FILTER_CRITERIA 5 
#define MAX_ADDITIONAL_TIMEINTERVALS 5

typedef struct {
	int active;
	int logic;	    // 0 = if,  1 = if NOT
	int detector;

	int timeIntervalFrom[N_DETECTORS];
	int hasTimeIntervalTo;
	int timeIntervalTo[N_DETECTORS];
	unsigned minCounts;
	unsigned maxCounts;
	
	int hasAdditionalTimeIntervals;
	int nAdditionalTimeIntervals;
	int additionalTimeIntervals[MAX_ADDITIONAL_TIMEINTERVALS];
} t_filterCriterion;



void FILTERCRITERION_init (t_filterCriterion *c);

void FILTERCRITERION_free (t_filterCriterion *c);




#define MAX_FILTERNAME_LEN 80

// filter to treat datasets of t_counterData
typedef struct {
//	int isActive;
	char name[MAX_FILTERNAME_LEN];	

// filter criteria	
	int nFilterCriteria;
	int otherFilterID;
	void *otherFilterPtr;
	
	t_filterCriterion criterion[MAX_FILTER_CRITERIA];

	int timeIntervalToCountStart;
	int timeIntervalToCountStop;
	
	int keepFilteredDataInResults;
	
	// flags used if filter is used for correlations
/*	int correlationsPlotItemNr;

//	void *correlationsPlotItemPtr;
	int correlationsAtom;
	int correlationsLevel;
*/
} t_filter;



void FILTER_init (t_filter *f);

void FILTER_free (void *f);
							
void FILTER_duplicate (t_filter *dest, t_filter *source);

int FILTER_compare (t_filter *f1, t_filter *f2);

t_filter *FILTER_new (t_session *s);

t_filter *FILTER_ptr (t_session *s, int filterNr);

void FILTER_delete (t_session *s, int filterID);

ListType FILTER_listDuplicate (ListType list);




#define PLOT_TYPE_NONE -1
#define	PLOT_TYPE_DIG 0
#define	OLD_PLOT_TYPE_TRANSFER 1
#define	PLOT_TYPE_VELOCITYDIST 2
#define	PLOT_TYPE_ARRIVALTIMES 3
#define PLOT_TYPE_NCOUNTS 4
#define PLOT_TYPE_CORRELATIONS 5
#define PLOT_TYPE_MULTIPLE_AS_INDEX 6


//#define N_PLOT_TYPES 4



enum {
	PLOTITEM_ERR_NONE = 0,
	PLOTITEM_ERR_INVALID_ATOM,
	PLOTITEM_ERR_ATOM_NOT_ACTIVE,
	PLOTITEM_ERR_ATOM_NOT_DETECTED,
	PLOTITEM_ERR_COUNTER_NOT_ACTIVATED,
	PLOTITEM_ERR_INVALID_PARAMETERS,
	PLOTITEM_ERR_NO_DETECTIONPAR,
	PLOTITEM_ERR_INVALID_LEVEL,
	PLOTITEM_ERR_LEVEL_NOT_DETECTED,
	PLOTITEM_ERR_INVALID_DETECTOR,
	PLOTITEM_ERR_INVALID_TIMEINTERVAL,
	PLOTITEM_ERR_TRANSFERPAR,
	PLOTITEM_ERR_ATOM_NOT_SELECTED_FOR_TRANSFER,
	PLOTITEM_ERR_LEVEL_NOT_SELECTED_FOR_TRANSFER,
	PLOTITEM_ERR_IDENTICAL_LEVELS,
	PLOTITEM_ERR_NO_DET1,
	PLOTITEM_ERR_NO_DET2,
	PLOTITEM_ERR_INVALID_PLOTRANGE_VEL,
	PLOTITEM_ERR_INVALID_PLOTRANGE_ARR,
	PLOTITEM_ERR_PLOTITEM_TRANSFER1,
	PLOTITEM_ERR_PLOTITEM_TRANSFER2,
	PLOTITEM_ERR_INVALID_PLOTITEM_TRANSFER1,
	PLOTITEM_ERR_INVALID_PLOTITEM_TRANSFER2,
	PLOTITEM_ERR_NO_PLOTITEM_TRANSFER1,
	PLOTITEM_ERR_NO_PLOTITEM_TRANSFER2,
	PLOTITEM_ERR_PLOTITEM_TRANSFER1_IS_TRANSFER,
	PLOTITEM_ERR_PLOTITEM_TRANSFER2_IS_TRANSFER,
	PLOTITEM_ERR_NOT_ACTIVE_TRANSFER1,
	PLOTITEM_ERR_NOT_ACTIVE_TRANSFER2,
	PLOTITEM_ERR_CORRELATIONS,
	PLOTITEM_ERR_TOO_MANY_COUNTS_IN_2DGRAPH_ARR,
	PLOTITEM_ERR_TOO_MANY_COUNTS_IN_2DGRAPH_VEL,
	PLOTITEM_ERR_ATOM_HAS_NO_MULTIPLES,
	PLOTITEM_ERR_MULTIPLES_AS_INDEX_MORE_THAN_ONE_SWEEPPOINT,
//	PLOTITEM_ERR_MULTIPLES_AS_INDEX_MORE_THAN_ONE_CURVE,
	
	N_PLOTITEM_ERR
};


#define MAX_PLOTITEMNAME_LEN 50
#define PLOTITEMS_TRANSFER_LEVELS 2

#define MAX_CORRELATION_ATOMS 5
#define MAX_CORRELATION_CURVES (1<<(MAX_CORRELATION_ATOMS)) // max. number of curves = 2^MAX_CORRELATION_ATOMS

typedef struct {
	int active;
	int counter;
	char name[MAX_PLOTITEMNAME_LEN];
	int error;
	int type;
	int atomNr;
	int multiple;
	int detector;
	int excludeDoubleCounts;		
	int dataFilterID;  // ID of data Filter

	// --------------------------
	//   velocity distribution
	// --------------------------
	int velocityNPoints;
	double velocityStart;
	double velocityEnd;
	int velocityShowPositionAxis;
	int velocityShowExperimentParts;
	double velocityTimeMultiply_us;
	
	// --------------------------
	//   arrival times
	// --------------------------
	double arrivalTimesBinSize_us;
	int arrivalTimesBinAuto;
	double arrivalTimesBinStart_us;
	double arrivalTimesBinEnd_us;
	int arrivalTimesNBins;
	
	// --------------------------
	//   N counts /  transfer
	// --------------------------
	int transfer;
//	int useTransferLevels;
	int fixedIntervals;
	int level;
	int interval[N_DETECTORS];
	int plotItemTransfer1;
	int plotItemTransfer2;

	// --------------------------
	//   correlations
	// --------------------------
	int correlationsNAtoms;
	int correlationsAtomNumber[MAX_CORRELATION_ATOMS];
	int correlationsAtomMultiple[MAX_CORRELATION_ATOMS];
	int correlationsLevel[2][MAX_CORRELATION_ATOMS];
	int correlationsFilterID[MAX_CORRELATION_CURVES];
	t_filter *correlationsFilter[MAX_CORRELATION_CURVES];
	int correlationsFilterIDOneAtom;
	t_filter *correlationsFilterOneAtom;

	t_curve *correlationsCurves[MAX_CORRELATION_CURVES];
	
	// --------------------------
	//   multipleAsIndex
	// --------------------------
	int multipleAsIndexNBinAtoms;	
	int multipleAsIndexFilterForEachMultipleID;
	int multipleAsIndexSumAllRuns;
	
	// --------------------------
	//   auto save data
	// --------------------------
	int keepCurve;   // create a new curve at every run
	int saveCurve;
	int saveTxt;   
	//	int saveTimes;
	// ---------------------
	//     curve style
	// ---------------------
	int plotColor;
	int plotStyle;
	int plotColorCurrent;
	int plotStyleCurrent;
	
	
	
// ----------------------------------
// ----------------------------------
//   parameters set duyring runtime
// ----------------------------------
// ----------------------------------
	int create2DPlot;  	
	t_curve *curve;			// curve associated with plot item
	t_graph *graph;
	
	int autoSetWindowName; 
	char panelTitle[MAX_TITLE_LEN];
	
	Rect panelPos2D;
	Rect panelPos;
	int firstUsed;
	t_session *session;  // reference to session
	t_filterResults filterResultsCurrent;
	t_filterResults filterResultsAll;
	t_filter *filter;
	
	int hasDataCalculated;
	int hasTableColumn;
} t_plotItem;


t_plotItem *PLOTITEM_ptr (t_session *s, int nr);
									   
void PLOTITEM_init (t_plotItem *e);

t_plotItem *PLOTITEM_new (t_session *s);

void PLOTITEM_free (t_plotItem *e);

void PLOTITEM_delete (t_session *s, int nr);


void PLOTITEM_deleteReferenceToCurve (t_session *s, t_graph *g, t_curve *c);

void PLOTITEM_deleteAllReferencesToCurves (t_session *s);

void PLOTITEM_getPtrToFilter (t_session *s, t_plotItem *p);

ListType PLOTITEM_listDuplicate (ListType list);



char *levelStr (t_session *s, int nr);


#endif


