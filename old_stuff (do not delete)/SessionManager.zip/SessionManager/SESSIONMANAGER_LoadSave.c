#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"



/************************************************************************/
/*
/*    Definitions of data elements in for session (*.ses) files
/* 
/*	  (sections and tags for functions Ini_... (see Libaray inifile.c)
/*
/************************************************************************/

// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//
// 	WARNING: DO UNTER NO CIRCUMSTANCES CHANGE THE NAMES OF
// 			 THESE STRINGS!!!
//
// 			 THIS WILL AFFECT THE COMPATIBILITY TO 
//			 PREVIOUS PROGRAM VERSIONS.
//
//           Any modification should be only to ADD new variables or
//           sections, which are not recognized by older program versions.
//
// !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


// general information for the session
const char INI_SECTION_SESSIONINFO[]				= "SessionInfo";
const char INI_TAG_SESSIONINFO_Version[]			= "ProgramVersion";

const char INI_TAG_SESSIONINFO_startNr[]    		= "startNr";
const char INI_TAG_SESSIONINFO_lastStarted[]    	= "lastStarted";
const char INI_TAG_SESSIONINFO_date[]    		    = "date";
const char INI_TAG_SESSIONINFO_updatePoints[]		= "updatePoints";
const char INI_TAG_SESSIONINFO_nAtoms[]    			= "nAtoms";
const char INI_TAG_SESSIONINFO_counterOn[]    		= "counterOn";
const char INI_TAG_SESSIONINFO_repumperAlwaysOn[]   = "repumperAlwaysOn";
const char INI_TAG_SESSIONINFO_laser1AlwaysOn[]     = "laser1AlwaysOn";  
const char INI_TAG_SESSIONINFO_laser2AlwaysOn[]     = "laser2AlwaysOn";  
const char INI_TAG_SESSIONINFO_optPumpingAlwaysOn[] = "optPumpingAlwaysOn";  

const char INI_TAG_SESSIONINFO_repumperFrequency[] = "repumperFrequency";
const char INI_TAG_SESSIONINFO_repumperPower[] 	= "repumperPower";


const char INI_TAG_SESSIONINFO_mode[]    			= "mode";
const char INI_TAG_SESSIONINFO_shortStr[]    		= "shortStr";
const char INI_TAG_SESSIONINFO_comments[]    		= "comments";

const char INI_TAG_SESSIONINFO_nSweeps[] 			= "nSweeps";
const char INI_TAG_SESSIONINFO_nPlotItems[] 		= "nPlotItems";
const char INI_TAG_SESSIONINFO_nFilters[]			= "nFilters";

const char INI_TAG_SESSIONINFO_nSweepPoints[]       = "nSweepPoints";
const char INI_TAG_SESSIONINFO_nCurves[] = "nCurves";
const char INI_TAG_SESSIONINFO_nRuns[] 			= "nRuns";
const char INI_TAG_SESSIONINFO_plotSweepParameter[] 		= "plotSweepParameter";
const char INI_TAG_SESSIONINFO_nDetectionParameters[] = "nDetectionParameters";
const char INI_TAG_SESSIONINFO_nGraphParameters[] = "nGraphParameters";
const char INI_TAG_SESSIONINFO_saveRunData[]        = "saveRunData";
const char INI_TAG_SESSIONINFO_saveArrivalTimes[]   = "saveArrivalTimes";
const char INI_TAG_SESSIONINFO_generateRandomCounterData[] = "generateRandomCounterData";


const char INI_TAG_SESSIONINFO_curveDuration[]  = "curveDuration";	// old version < 2.53 
const char INI_TAG_SESSIONINFO_curveStart[]     = "curveStart";	
const char INI_TAG_SESSIONINFO_curveEnd[]       = "curveEnd";	
const char INI_TAG_SESSIONINFO_nAverages[]		= "nAverages";	
const char INI_TAG_SESSIONINFO_killerActive[]	= "killerActive";	

const char INI_TAG_SESSIONINFO_DIG_voltageFrom[]  = "DIG_voltageFrom";	
const char INI_TAG_SESSIONINFO_DIG_voltageTo[]    = "DIG_voltageTo";	
const char INI_TAG_SESSIONINFO_DIG_nSteps[]  	  = "DIG_nSteps";	
const char INI_TAG_SESSIONINFO_DIG_channel[] 	  = "DIG_channel";	
const char INI_TAG_SESSIONINFO_DIG_copiesPerStep[] = "DIG_copiesPerStep";	
const char INI_TAG_SESSIONINFO_DIG_windowName[]    = "DIG_windowName";	

const char INI_TAG_SESSIONINFO_transferAtom[]  = "transferAtom";	
const char INI_TAG_SESSIONINFO_transferOn[]    = "transferOn";	
const char INI_TAG_SESSIONINFO_transferLevel[] = "transferLevel";	
const char INI_TAG_SESSIONINFO_transferInterval[] = "transferInterval";

const char INI_TAG_SESSIONINFO_digitalOutputs_preset[] = "digitalOutputs_preset";
const char INI_TAG_SESSIONINFO_digitalOutputs_onOff[] = "digitalOutputs_onOff";	



const char INI_SECTION_LEVELS[]	= "Levels";
const char INI_TAG_LEVELS_nLevels[] = "nLevels";  
const char INI_TAG_LEVELS_voltages[] = "voltages";  
const char INI_TAG_LEVELS_name[] = "name%d";  

//----------------------------------
//    t_plotItem
// ---------------------------------

const char INI_SECTION_PLOTITEM[]  = "PlotItem%d";
const char INI_TAG_PLOTITEM_active[]			= "active";	
const char INI_TAG_PLOTITEM_name[] 				= "name";	
const char INI_TAG_PLOTITEM_type[] 				= "type";	
const char INI_TAG_PLOTITEM_atom[] 				= "atom";	
const char INI_TAG_PLOTITEM_multiple[] 			= "multiple";	
const char INI_TAG_PLOTITEM_detector[] 			= "detector";
const char INI_TAG_PLOTITEM_excludeDoubleCounts[] = "excludeDoubleCounts"; 
const char INI_TAG_PLOTITEM_dataFilterID[]		= "dataFilterID";

// old version (prior to V2.63)
const char INI_TAG_PLOTITEM_OLD_countsInterval[] = "countsInterval";
const char INI_TAG_PLOTITEM_OLD_countsLevel[]		= "countsLevel";
const char INI_TAG_PLOTITEM_OLD_transfer_level1[] 	= "transfer_level1";	
const char INI_TAG_PLOTITEM_OLD_transfer_level2[] 	= "transfer_level2";
const char INI_TAG_PLOTITEM_OLD_countsFixedInterval[]     = "countsFixedInterval";     

const char INI_TAG_PLOTITEM_transferShow[]   = "transfer_show";
const char INI_TAG_PLOTITEM_level[] 	     = "level";
//const char INI_TAG_PLOTITEM_useTransferLevels[] = "useTransferLevels";

const char INI_TAG_PLOTITEM_interval[]       = "interval_det%d";
const char INI_TAG_PLOTITEM_plotItemTransfer1[] = "plotItemTransfer1";
const char INI_TAG_PLOTITEM_plotItemTransfer2[] = "plotItemTransfer2";
const char INI_TAG_PLOTITEM_fixedIntervals[] = "fixedIntervals";

const char INI_TAG_PLOTITEM_velocityNPoints[]	= "velocityNPoints";	
const char INI_TAG_PLOTITEM_velocityStart[]		= "velocityStart";	
const char INI_TAG_PLOTITEM_velocityEnd[]		= "velocityEnd";	
const char INI_TAG_PLOTITEM_velocityShowPositionAxis[] = "velocityShowPositionAxis";
const char INI_TAG_PLOTITEM_velocityShowExperimentParts[] = "velocityShowExperimentParts";
const char INI_TAG_PLOTITEM_velocityTimeMultiply[] = "velocityTimeMultiply";



const char INI_TAG_PLOTITEM_binsize[] 			= "binsize";	
const char INI_TAG_PLOTITEM_binAuto[] 			= "binAuto";	
const char INI_TAG_PLOTITEM_binStart[] 			= "binStart";	
const char INI_TAG_PLOTITEM_binEnd[] 			= "binEnd";	
const char INI_TAG_PLOTITEM_nBins[]			    = "nBins";	

const char INI_TAG_PLOTITEM_saveCurve[] 		= "saveCurve";
const char INI_TAG_PLOTITEM_saveTxt[] 			= "saveTxt";
const char INI_TAG_PLOTITEM_keepCurve[] 		= "keepCurve";
const char INI_TAG_PLOTITEM_createPlot2D[] 		= "createPlot2D";
const char INI_TAG_PLOTITEM_autoSetWindowName[] = "autoSetWindowName";
const char INI_TAG_PLOTITEM_panelTitle[] 		= "panelTitle";
const char INI_TAG_PLOTITEM_plotStyle[] 		= "plotStyle";
const char INI_TAG_PLOTITEM_plotColor[] 		= "plotColor";
const char INI_TAG_PLOTITEM_plotStyleCurrent[] 	= "plotStyleCurrent";
const char INI_TAG_PLOTITEM_plotColorCurrent[]	= "plotColorCurrent";
const char INI_TAG_PLOTITEM_panelPos2D[] 		= "panelPos2D";
const char INI_TAG_PLOTITEM_panelPos[] 			= "panelPos";

const char INI_TAG_PLOTITEM_correlationsNAtoms[] = "correlationsNAtoms";
const char INI_TAG_PLOTITEM_correlationsAtomNumber[]     = "correlationsAtomNumber";
const char INI_TAG_PLOTITEM_correlationsAtomMultiple[]  = "correlationsAtomMultiple"; 
const char INI_TAG_PLOTITEM_correlationsLevel1[] = "correlationsLevel1";
const char INI_TAG_PLOTITEM_correlationsLevel2[] = "correlationsLevel2";
const char INI_TAG_PLOTITEM_correlationsFilterID[] = "correlationsFilterID";
const char INI_TAG_PLOTITEM_correlationsFilterIDOneAtom[] = "correlationsFilterIDOneAtom";

const char INI_TAG_PLOTITEM_multipleAsIndexNBinAtoms[] = "multipleAsIndexNBinAtoms";
const char INI_TAG_PLOTITEM_multipleAsIndexFilterForEachMultipleID[] = "multipleAsIndexFilterForEachMultipleID";
const char INI_TAG_PLOTITEM_multipleAsIndexSumAllRuns[] = "multipleAsIndexSumAllRuns";

   


const char INI_SECTION_GRAPHPAR[]  = "GraphParameters%d";
const char INI_TAG_GRAPHPAR_height[] = "height";
const char INI_TAG_GRAPHPAR_width[] = "width";
const char INI_TAG_GRAPHPAR_top[] = "top";
const char INI_TAG_GRAPHPAR_left[] = "left";
const char INI_TAG_GRAPHPAR_panelTitle[] = "panelTitle";





// waveforms
const char INI_SECTION_ATOMS[] 			= "Atom%d";
const char INI_SECTION_ATOMS_TIMES[] 	= "Atom%d_TIMES";

const char INI_TAG_ATOM_hasMultiples[]  = "hasMultiples";
const char INI_TAG_ATOM_nMultiples[]  = "nMultiples";
const char INI_TAG_ATOM_delay[]		  = "Delay";

const char INI_TAG_ATOM_name[] 	  	= "Name";

const char INI_TAG_ATOM_active[] 	= "active";
//const char INI_TAG_ATOM_time[]    = "time_%s";
const char INI_TAG_ATOM_circTriggerRF[]        = "circTriggerRF";
const char INI_TAG_ATOM_circTriggerRamp[] 	   = "circTriggerRamp";
const char INI_TAG_ATOM_circ52dTime[] 	   = "circ52dTime";
const char INI_TAG_ATOM_circ52dDuration[]  = "circ52dDuration";
//const char INI_TAG_ATOM_alwaysOnL1[] = "alwaysOnL1";
const char INI_TAG_ATOM_durationL1[] = "durationL1";
const char INI_TAG_ATOM_timeL2[] = "time L2";
const char INI_TAG_ATOM_durationL2[] = "durationL2";
const char INI_TAG_ATOM_timeOP[] = "time OP";
const char INI_TAG_ATOM_durationOP[] = "durationOP";



const char INI_TAG_ATOM_state[]       = "state";
const char INI_TAG_ATOM_purifStart_e[] 	  = "purifStart_e";
const char INI_TAG_ATOM_purifDuration_e[] = "purifDuration_e";
const char INI_TAG_ATOM_purifStart_g[] 	  = "purifStart_g";
const char INI_TAG_ATOM_purifDuration_g[] = "purifDuration_g";

const char INI_TAG_ATOM_velocitySelection[] = "velocitySelection";
const char INI_TAG_ATOM_velocity[] 	        = "velocity";
const char INI_TAG_ATOM_velocitySpread[] 	= "velocitySpread";
const char INI_TAG_ATOM_velocitySpreadDoppler[]= "velocitySpreadDoppler";

const char INI_TAG_ATOM_repumperFrequency[] = "repumperFrequency";
const char INI_TAG_ATOM_repumperPower[] 	= "repumperPower";
const char INI_TAG_ATOM_repumperDuration[] 	= "repumperDuration";
const char INI_TAG_ATOM_repumperTime[]      = "repumperTime";
const char INI_TAG_ATOM_repumperTimeReference[] = "repumperTimeReference";
//const char INI_TAG_ATOM_repumperAlwaysOn[] = "repumperAlwaysOn";
const char INI_TAG_ATOM_depumperDuration[] 	= "depumperDuration";
const char INI_TAG_ATOM_depumperTime[]      = "depumperTime";

const char INI_SECTION_ATOMS_KILLER[] 		= "Atom%d_Cavity%d_Killer";
const char INI_TAG_ATOM_killerTimeReference[]   = "killerTimeReference";
const char INI_TAG_ATOM_killerStartFirst[]      = "killerStartFirst";
const char INI_TAG_ATOM_nKillerPoints[] 		= "nKillerPoints";
const char INI_TAG_ATOM_killerActive[] 		    = "killerActive";

const char INI_TAG_ATOM_detect[]  				= "detect";
const char INI_TAG_ATOM_detectionParameters[]  = "detectionParameters";
const char INI_TAG_ATOM_detectionLevel[]  	   = "detectionLevel";
const char INI_TAG_ATOM_detectionTime[]  = "detectionTime";
const char INI_TAG_ATOM_detectionTimeReference[]  = "detectionTimeReference";
const char INI_TAG_ATOM_detectionUseLevelsOfTransfer[] = "detectionUseLevelsOfTransfer";
const char INI_TAG_ATOM_detectionSetLevel[] = "detectionSetLevel";
//const char INI_TAG_ATOM_defaultDetectionLevel[] = "defaultDetectionLevel";

const char INI_TAG_ATOM_nEvents[] 	    = "nEvents";




const char INI_SECTION_ATOMCONFIG[] 		 = "AtomConfig";

const char INI_TAG_ATOMCONFIG_rfFrequency[]  = "rfFrequency";
const char INI_TAG_ATOMCONFIG_rfVelocity[]   = "rfVelocity";
const char INI_TAG_ATOMCONFIG_rfPower[]      = "rfPower";
const char INI_TAG_ATOMCONFIG_position[]     = "pos_%15s";
const char INI_TAG_ATOMCONFIG_positionReference[]   = "positionReference";
const char INI_TAG_ATOMCONFIG_nDisplayedTableColumns[] = "nDisplayedTableColumns";
const char INI_TAG_ATOMCONFIG_activeConfig[] = "activeConfig";
const char INI_TAG_ATOMCONFIG_tableConfig[] = "tableConfig%d";
const char INI_TAG_ATOMCONFIG_tableConfigName[] = "tableConfigName%d";

const char INI_TAG_ATOMCONFIG_referenceAtom[] = "referenceAtom";
const char INI_TAG_ATOMCONFIG_referenceAtomPosition[] = "referenceAtomPosition";

const char INI_TAG_ATOMCONFIG_transferFunct[] 			= "transferFunction%d";
const char INI_TAG_ATOMCONFIG_parametersTransferFunct[] = "parametersTransferFunction%d";
const char INI_TAG_ATOMCONFIG_setDefaultVoltage[] 		= "setDefaultVoltage%d";
const char INI_TAG_ATOMCONFIG_killerDefaultVoltage[]    = "killerDefaultVoltage%d";
const char INI_TAG_ATOMCONFIG_killerDefaultDetuning[]   = "killerDefaultDetuning%d";


const char INI_SECTION_SEQGEN[]  			  = "SequenceGeneration";
const char INI_TAG_SEQGEN_circUpper[]		  = "circ upper";
const char INI_TAG_SEQGEN_circLower[]		  = "circ lower";
const char INI_TAG_SEQGEN_voltageRamp[]		  = "voltageRamp";
const char INI_TAG_SEQGEN_shortStr[]		  = "shortStr";




const char INI_SECTION_EVENT[] 		    = "Atom%d_Event%d";

const char INI_TAG_EVENT_active[]         = "active";
const char INI_TAG_EVENT_eventStyle[]     = "eventStyle"; 
const char INI_TAG_EVENT_name[]           = "name";
const char INI_TAG_EVENT_deviceType[]  	  = "deviceType";
const char INI_TAG_EVENT_digitalChannel[] = "digitalChannel";
const char INI_TAG_EVENT_analogChannel[]  = "analogChannel";
const char INI_TAG_EVENT_pulseStartReference[]    = "pulseStartReference";
const char INI_TAG_EVENT_pulseStartVary[]         = "pulseStartVary";
const char INI_TAG_EVENT_pulseStartFirst[]        = "pulseStartFirst";
const char INI_TAG_EVENT_pulseStartIncrement[]    = "pulseStartIncrement";
const char INI_TAG_EVENT_pulseDurationVary[]      = "pulseDurationVary";
const char INI_TAG_EVENT_pulseDurationFirst[]     = "pulseDurationFirst";
const char INI_TAG_EVENT_pulseDurationIncrement[] = "pulseDurationIncrement";
const char INI_TAG_EVENT_voltageVary[]      	  = "voltageVary";
const char INI_TAG_EVENT_voltageFirst[]           = "voltageFirst";
const char INI_TAG_EVENT_voltageIncrement[]       = "voltageIncrement";


const char INI_SECTION_DETECTIONPAR[]           = "DetectionParameters%d";
const char INI_TAG_DETECTIONPAR_name[] 			= "name";
const char INI_TAG_DETECTIONPAR_detectorActive[] 		= "detectorActive";
const char INI_TAG_DETECTIONPAR_rampStart[] 	= "rampStart";
const char INI_TAG_DETECTIONPAR_rampStop[] 		= "rampStop";
const char INI_TAG_DETECTIONPAR_rampDuration[] 	= "rampDuration";
const char INI_TAG_DETECTIONPAR_rampTriggerReference[] = "rampTriggerReference";
const char INI_TAG_DETECTIONPAR_rampTrigger[]   = "rampTrigger";
const char INI_TAG_DETECTIONPAR_levelActive[] 	= "levelActive";
const char INI_TAG_DETECTIONPAR_timeStart1[] 	= "timeStart1";
const char INI_TAG_DETECTIONPAR_timeEnd1[] 	    = "timeEnd1";

const char INI_TAG_DETECTIONPAR_useTimeWindow[] = "useTimeWindow";
const char INI_TAG_DETECTIONPAR_timeStart2[] 	= "timeStart2";
const char INI_TAG_DETECTIONPAR_timeEnd2[] 		= "timeEnd2";
//const char INI_TAG_DETECTIONPAR_defaultLevel2[] = "defaultLevel2";
const char INI_TAG_DETECTIONPAR_timeReference[] = "timeReference";

const char INI_SECTION_SWEEP[] = "Sweep%d";
const char INI_TAG_SWEEP_name[]		    = "name";
const char INI_TAG_SWEEP_plotAxisName[] = "plotAxisName";
const char INI_TAG_SWEEP_units[] 		= "units";
const char INI_TAG_SWEEP_type[] 		= "type";
const char INI_TAG_SWEEP_active[] 		= "active";
const char INI_TAG_SWEEP_channel[] 		= "channel";
const char INI_TAG_SWEEP_changeMode[] 	= "changeMode";
const char INI_TAG_SWEEP_from[] 		= "from";
const char INI_TAG_SWEEP_to[] 			= "to";
const char INI_TAG_SWEEP_center[] 		= "center";
const char INI_TAG_SWEEP_span[] 		= "span";
const char INI_TAG_SWEEP_sweepOn[] 		= "sweepOn";
const char INI_TAG_SWEEP_rfOn[] 		= "rfOn";
const char INI_TAG_SWEEP_pulseMode[] 	= "pulseMode";
const char INI_TAG_SWEEP_harmonic[] 	= "harmonic";
const char INI_TAG_SWEEP_outputPower[] 	= "outputPower";
const char INI_TAG_SWEEP_deviceChannel[]= "deviceChannel";
const char INI_TAG_SWEEP_current[] 		= "current";



const char INI_SECTION_runRepetition[] 		 = "Run%d_Repetition%d";
const char INI_SECTION_RUN_GENERAL[] 	 = "General";
const char INI_TAG_RUN_detector[]        = "detector";
const char INI_TAG_RUN_nRuns[]        	 = "nRuns";
const char INI_TAG_RUN_nRepetitions[]    = "nRepetitions";
const char INI_TAG_RUN_nCopies[]         = "nCopies";
//const char INI_TAG_RUN_nSequenceDuplicates[]   = "nSequenceDuplicates";

const char INI_TAG_RUN_filenameCounterData[] = "filenameCounterData";
const char INI_TAG_RUN_date[]			 = "date";
const char INI_TAG_RUN_time[]			 = "time";
const char INI_TAG_RUN_currentRun[]		 = "currentRun";
const char INI_TAG_RUN_currentRepetition[]= "currentRepetition";
const char INI_TAG_RUN_softwareVersion[] = "softwareVersion";
const char INI_TAG_RUN_dataDirectory[] 	 = "dataDirectory";
const char INI_TAG_RUN_sessionFilename[] = "filenameSession";
const char INI_TAG_RUN_sequenceFilename[]= "filenameSequence";
const char INI_TAG_RUN_writtenDatasets[] = "writtenDatasets";
const char INI_TAG_RUN_startNr[]		 = "startNr";
const char INI_TAG_RUN_nDatasets[]		 = "nDatasets";
const char INI_TAG_RUN_infoStr[]		 = "info";





const char INI_SECTION_FILTER[] 		= "Filter%d";

const char INI_TAG_FILTER_name[] 		= "name";
const char INI_TAG_FILTER_nCriteria[]   = "nCriteria";
const char INI_TAG_FILTER_otherFilter[] = "otherFilterID";


const char INI_TAG_FILTERCRITERION_active[]   = "active%d";
const char INI_TAG_FILTERCRITERION_logic[]    = "logic%d";
const char INI_TAG_FILTERCRITERION_detector[] = "detector%d";
const char INI_TAG_FILTERCRITERION_hasTimeIntervalTo[] = "hasTimeIntervalTo_%d";
const char INI_TAG_FILTERCRITERION_timeIntervalFrom1[] = "timeIntervalFrom1_%d";
const char INI_TAG_FILTERCRITERION_timeIntervalFrom2[] = "timeIntervalFrom2_%d";
const char INI_TAG_FILTERCRITERION_timeIntervalTo1[] = "timeIntervalTo1_%d";
const char INI_TAG_FILTERCRITERION_timeIntervalTo2[] = "timeIntervalTo2_%d";
const char INI_TAG_FILTERCRITERION_minCounts[] = "minCounts_%d";
const char INI_TAG_FILTERCRITERION_maxCounts[] = "maxCounts_%d";
const char INI_TAG_FILTERCRITERION_hasAdditionalTimeIntervals[] = "hasAdditionalTimeIntervals_%d";
const char INI_TAG_FILTERCRITERION_nAdditionalTimeIntervals[]   = "nAdditionalTimeIntervals_%d";
const char INI_TAG_FILTERCRITERION_additionalTimeIntervals[]    = "additionalTimeIntervals_%d";




char SCONF_REG_SUBKEY[]= "Software\\Session Manager";

char SCONF_GENERAL[]   			    = "GENERAL";
char SCONF_TAG_DEFAULT_PATH[] 				= "DefaultPath";
char SCONF_TAG_DISPLAYED_SESSION_NO[] 	    = "DisplayedSessionNo";
char SCONF_TAG_NUMBER_OF_SESSIONS[]         = "NumberOfSessionss";
char SCONF_TAG_NAME_SESSION[] 			    = "Name%02d";
char SCONF_TAG_TCP_SERVER_NAME[] 			= "TCPserverName";


//char SCONF_TAG_MASTERSEQUENCE[] 	    = "masterSequence";
char SCONF_TAG_dataPath[] 	    = "dataPath";
char SCONF_TAG_dataPathToday[] 	    = "dataPathToday";

const char INI_SECTION_CURVE[]	= "Curve%d";

const char INI_TAG_CURVE_name[]    = "name";            
//const char INI_TAG_CURVE_session[] = "session";            
const char INI_TAG_CURVE_info[] = "info";            
const char INI_TAG_CURVE_startNr[] = "startNr";
const char INI_TAG_CURVE_time[] = "time";            
const char INI_TAG_CURVE_date[] = "date";            
const char INI_TAG_CURVE_plotType[] = "plotType";            
const char INI_TAG_CURVE_nValues[] = "nValues";            
const char INI_TAG_CURVE_nValuesVisibleAvg[] = "nValuesVisible";            
const char INI_TAG_CURVE_showCurrentCurve[] = "showCurrentCurve";
const char INI_TAG_CURVE_xValues[] = "xValues";            
const char INI_TAG_CURVE_xFrom[] = "xFrom";            
const char INI_TAG_CURVE_xTo[] = "xTo";            
const char INI_TAG_CURVE_visible2D[] = "visible2D";            

const char INI_TAG_CURVE_yValues_OLD[] = "yValues";            
const char INI_TAG_CURVE_yErrPos_OLD[] = "yErrPos";            
const char INI_TAG_CURVE_yErrNeg_OLD[] = "yErrNeg";            

const char INI_TAG_CURVE_hasErrorBars[]    = "hasErrorBars";            
const char INI_TAG_CURVE_hasErrorBarsCurrent[] = "hasErrorBarsCurrent";            
const char INI_TAG_CURVE_yValuesAveraged[] = "yValuesAveraged";            
const char INI_TAG_CURVE_yErrPosAveraged[] = "yErrPosAveraged";            
const char INI_TAG_CURVE_yErrNegAveraged[] = "yErrNegAveraged";            

const char INI_TAG_CURVE_nCurves[] = "nCurves";            
//const char INI_TAG_CURVE_yValuesArrSize[] = "yValuesArrSize";
//const char INI_TAG_CURVE_yValuesVisible[] = "yValuesVisible";
const char INI_TAG_CURVE_yValues[] = "yValues%d";
const char INI_TAG_CURVE_yErrPos[] = "yErrPosRun%d";
const char INI_TAG_CURVE_yErrNeg[] = "yErrNegRun%d";


const char INI_TAG_CURVE_nAveraged[] = "nAveraged";            
const char INI_TAG_CURVE_plotStyle[] = "plotStyle";            
const char INI_TAG_CURVE_plotColor[] = "plotColor";            
const char INI_TAG_CURVE_pointStyle[] = "pointStyle";            
const char INI_TAG_CURVE_lineStyle[] = "lineStyle";     
const char INI_TAG_CURVE_plotNumbers[] = "plotNumbers";
//const char INI_TAG_CURVE_keep[] = "keep";     

const char INI_TAG_CURVE_title[] = "title";     
const char INI_TAG_CURVE_xLabel[] = "xLabel";     
const char INI_TAG_CURVE_xLabel2[] = "xLabel2";     
const char INI_TAG_CURVE_yLabel[] = "yLabel";     
const char INI_TAG_CURVE_yLabel2[] = "yLabel2";     
const char INI_TAG_CURVE_xUnits[] = "xUnits";     
const char INI_TAG_CURVE_xUnits2[] = "xUnits2";     
const char INI_TAG_CURVE_yUnits[] = "yUnits"; 
const char INI_TAG_CURVE_yUnits2[] = "yUnits2";     
const char INI_TAG_CURVE_xDigits[] = "xDigits"; 
const char INI_TAG_CURVE_yDigits[] = "yDigits"; 
const char INI_TAG_CURVE_yDigits2[] = "yDigits2"; 
const char INI_TAG_CURVE_divideAveraged[] = "divideAveraged"; 
const char INI_TAG_CURVE_averagedOnTop[] = "averagedOnTop";

const char INI_TAG_CURVE_xShowSecondAxis[] = "xShowSecondAxis";
const char INI_TAG_CURVE_yShowSecondAxis[] = "yShowSecondAxis";
const char INI_TAG_CURVE_xAxis2Multiply[] = "xAxis2Multiply";
const char INI_TAG_CURVE_yAxis2Multiply[] = "yAxis2Multiply";


const char INI_TAG_CURVE_xAsciiFileColumnLabel[] = "xAsciiFileColumnLabel";
const char INI_TAG_CURVE_yAsciiFileColumnLabel[] = "yAsciiFileColumnLabel";
const char INI_TAG_CURVE_xAsciiFileColumnLabel2[] = "xAsciiFileColumnLabel2";
const char INI_TAG_CURVE_yAsciiFileColumnLabel2[] = "yAsciiFileColumnLabel2";

const char INI_TAG_CURVE_panelPos2D[]= "panelPos2D";
const char INI_TAG_CURVE_panelPos[]	 = "panelPos";
const char INI_TAG_CURVE_values2D[]	 = "values2D";
const char INI_TAG_CURVE_interpolate2D[] = "interpolate2D";
//const char INI_TAG_CURVE_xFrom2D[]   = "xFrom2D";
//const char INI_TAG_CURVE_yFrom2D[]   = "yFrom2D";
//const char INI_TAG_CURVE_xTo2D[]	 = "xTo2D";
//const char INI_TAG_CURVE_yTo2D[]     = "yTo2D";
const char INI_TAG_CURVE_xLabel2D[]	 = "xLabel2D";
//const char INI_TAG_CURVE_yLabel2D[]	 = "yLabel2D";
const char INI_TAG_CURVE_xUnits2D[]  = "xUnits2D";
const char INI_TAG_CURVE_xValues2D[] = "xValues2D";

const char INI_TAG_CURVE_nComponentsPositions[] = "nComponentsPositions";
const char INI_TAG_CURVE_componentsVisible[]    = "componentsVisible";
const char INI_TAG_CURVE_componentsPositions[]  = "componentsPositions";
const char INI_TAG_CURVE_componentsNames[]      = "componentsName%d";
const char INI_TAG_CURVE_componentsColors[]	    = "componentsColors";



/******************************************************************************/
/*
/*   FUNCTIONS: Ini_GetPosition (...)
/*			    Ini_GetPosition (...)
/*
/******************************************************************************/

void Ini_PutPosition (IniText ini, const char *section, const char *tag, int value)
{
	t_dataField *d;
	
	d = df(value);
	if (d == NULL) return;
	Ini_PutString (ini, section, tag, d->idName);
}


int Ini_GetPosition (IniText ini, const char *section, const char *tag, int *value)
{
	char help[50];
	int df;
	
	if (Ini_GetStringIntoBuffer (ini, section, tag, help, 50) <= 0) return 1;
	df = DATAFIELD_fromName (help);
	if (df >= 0) {
		*value = df;
		return 0;
	}
	return 1;
}


/******************************************************************************/
/*
/*   FUNCTIONS: Ini_GetAtomConfig (...)
/*			    Ini_PutAtomConfig (...)
/*
/*    Reads/writes data for an atom in 
/*    in Section "[AtomConfig]" from/to "ini-style"-file
/*    --  called by function "loadSession(...), "saveSession(...)", 
/*	  --  uses datatype "IniText" defined in Libaray "inifile.c"
/*
/******************************************************************************/

const char *posToStr (int id)
{
	t_dataField *d;

	d = df(id);
	if (d == NULL) return "";
	return d->idName;
}






void Ini_PutPositionArray (IniText ini, const char *sectionName, const char *tagName, 
					   int *posArray, int nPositions)
{
	int i;
	unsigned appendPos;
	char *str;
	
	str = (char *) malloc (50 * nPositions + 10);
	
	str[0] = 0;
	appendPos = strlen(str);
	for (i = 0; i < nPositions; i++) {
		if (appendPos > 0) {
			str[appendPos] = ',';
			appendPos++;
		}
		strcpy (str + appendPos, posToStr(posArray[i]));
		appendPos += strlen (posToStr(posArray[i]));
	}
	Ini_PutString (ini, sectionName, tagName, str);
	free (str);
}

void Ini_GetPositionArray (IniText ini, const char *sectionName, const char *tagName, 
					   	   int *array, int arraySize, int *nPositions)
{
	char *str = NULL;
 	char *endCh, *startCh;
	
	*nPositions = 0;
	Ini_GetStringCopy (ini, sectionName, tagName, &str);
	startCh = str;
	endCh   = str;
	while (endCh != NULL) {
	 	endCh = strchr (startCh, ',');
		if (endCh != NULL) *endCh = 0;
	 	if (*nPositions < arraySize) {
		 	array[*nPositions] = DATAFIELD_fromName (startCh); 	
		 	if (array[*nPositions] >= 0) (*nPositions)++;
		}
		if (endCh != NULL) startCh = endCh + 1;
	}
	free (str);
}


void Ini_PutAtomConfig (IniText ini, t_atomConfig *c)
{
    int i;
    char tagName[80];

	Ini_PutDataArray (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_rfFrequency,
			  c->rfMultiplexerFrequency, N_RF_CHANNELS, VAL_DOUBLE);
	Ini_PutDataArray (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_rfVelocity,
			  c->rfMultiplexerVelocity, N_RF_CHANNELS, VAL_DOUBLE);
	Ini_PutDataArray (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_rfPower,
			  c->rfMultiplexerPower, N_RF_CHANNELS, VAL_DOUBLE);
			  
	for (i = 0; i < N_TABLE_CONFIGS; i++) {
		if (c->nTableColumns[i] > 0) {
			sprintf (tagName, INI_TAG_ATOMCONFIG_tableConfig, i);
			Ini_PutPositionArray (ini, INI_SECTION_ATOMCONFIG, tagName, 
							   	   c->tableColumns[i],  c->nTableColumns[i]);
		}
		sprintf (tagName, INI_TAG_ATOMCONFIG_tableConfigName, i);
		Ini_PutString (ini, INI_SECTION_ATOMCONFIG, tagName, c->tableConfigName[i]);
	}
	Ini_PutInt (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_activeConfig, c->activeConfig);
	

	for (i = 0; i < N_POSITIONS; i++) {
		sprintf (tagName, INI_TAG_ATOMCONFIG_position, df(i)->idName);
		Ini_PutDouble (ini, INI_SECTION_ATOMCONFIG, tagName,
			  c->position[i]);
	}
	
	Ini_PutPosition (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_positionReference,
			  	     c->positionReference);
	// reference atom
	Ini_PutInt (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_referenceAtom,
			  c->referenceAtom);
	Ini_PutPosition (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_referenceAtomPosition,
			  		 c->referenceAtomPosition);
			  		 
	// put killer parameters
	for (i = 0; i < N_CAVITIES; i++) {
		sprintf (tagName, INI_TAG_ATOMCONFIG_transferFunct, i);
		Ini_PutInt (ini, INI_SECTION_ATOMCONFIG, tagName, c->transferFunct[i]);

		sprintf (tagName, INI_TAG_ATOMCONFIG_parametersTransferFunct, i);
		Ini_PutDataArray (ini, INI_SECTION_ATOMCONFIG, tagName,
						  c->parametersTransferFunct[i], N_PARAMETERS_TRANSFER_FUNCT, VAL_DOUBLE);	
		
		sprintf (tagName, INI_TAG_ATOMCONFIG_setDefaultVoltage, i);
		Ini_PutInt (ini, INI_SECTION_ATOMCONFIG, tagName, c->setDefaultVoltage[i]);

		sprintf (tagName, INI_TAG_ATOMCONFIG_killerDefaultVoltage, i);
		Ini_PutDouble (ini, INI_SECTION_ATOMCONFIG, tagName, c->killerDefaultVoltage[i]);
	
		sprintf (tagName, INI_TAG_ATOMCONFIG_killerDefaultDetuning, i);
		Ini_PutDouble (ini, INI_SECTION_ATOMCONFIG, tagName, c->killerDefaultDetuning[i]);
	}
			  		 
}



void Ini_GetAtomConfig (IniText ini, t_atomConfig *c)
{
    int i;
    char tagName[80];

	
	
	ATOMCONFIG_init(c, smanagerConfig->defaultAtomConfig);
	
	Ini_GetDataArrayEx (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_rfFrequency,
			  c->rfMultiplexerFrequency, N_RF_CHANNELS, VAL_DOUBLE);
	Ini_GetDataArrayEx (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_rfVelocity,
			  c->rfMultiplexerVelocity, N_RF_CHANNELS, VAL_DOUBLE);
	Ini_GetDataArrayEx (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_rfPower,
			  c->rfMultiplexerPower, N_RF_CHANNELS, VAL_DOUBLE);
			  
	for (i = 0; i < N_POSITIONS; i++) {
		sprintf (tagName, INI_TAG_ATOMCONFIG_position, df(i)->idName);
		Ini_GetDouble (ini, INI_SECTION_ATOMCONFIG, tagName,
			  &c->position[i]);
	}
	
	Ini_GetPosition (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_positionReference,
					 &c->positionReference);

	for (i = 0; i < N_TABLE_CONFIGS; i++) {
		sprintf (tagName, INI_TAG_ATOMCONFIG_tableConfig, i);
		if (Ini_ItemExists (ini, INI_SECTION_ATOMCONFIG, tagName)) {
			Ini_GetPositionArray (ini, INI_SECTION_ATOMCONFIG, tagName, 
							   	  c->tableColumns[i], N_DATAFIELDS, &c->nTableColumns[i]);
		}
		   
		sprintf (tagName, INI_TAG_ATOMCONFIG_tableConfigName, i);
		Ini_GetStringIntoBuffer (ini, INI_SECTION_ATOMCONFIG, tagName, c->tableConfigName[i], N_TABLECONFIG_NAME_LEN);
	}
	Ini_GetInt (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_activeConfig, &c->activeConfig);
	if (c->activeConfig >= N_TABLE_CONFIGS) c->activeConfig = N_TABLE_CONFIGS;
	
/*
	k = 0;
	Ini_GetInt (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_nDisplayedTableColumns,
			    &n);
	for (i = 0; i < n; i++) {
		sprintf (tagName, INI_TAG_ATOMCONFIG_tableColumn, i);
		if (Ini_GetPosition (ini, INI_SECTION_ATOMCONFIG, tagName, &c->displayedTableColumns[k]) == 0) k ++;
	}
	if (k != 0) c->nDisplayedTableColumns = k;
*/

	// reference atom
	Ini_GetInt (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_referenceAtom,
			  &c->referenceAtom);
	Ini_GetPosition (ini, INI_SECTION_ATOMCONFIG, INI_TAG_ATOMCONFIG_referenceAtomPosition,
			  &c->referenceAtomPosition);
	
	// get killer parameters
	for (i = 0; i < N_CAVITIES; i++) {
		sprintf (tagName, INI_TAG_ATOMCONFIG_transferFunct, i);
		Ini_GetInt (ini, INI_SECTION_ATOMCONFIG, tagName, &c->transferFunct[i]);

		sprintf (tagName, INI_TAG_ATOMCONFIG_parametersTransferFunct, i);
		Ini_GetDataArrayEx (ini, INI_SECTION_ATOMCONFIG, tagName,
						  c->parametersTransferFunct[i], N_PARAMETERS_TRANSFER_FUNCT, VAL_DOUBLE);	
		
		sprintf (tagName, INI_TAG_ATOMCONFIG_setDefaultVoltage, i);
		Ini_GetInt (ini, INI_SECTION_ATOMCONFIG, tagName, &c->setDefaultVoltage[i]);

		if (c->setDefaultVoltage[i]) {
			sprintf (tagName, INI_TAG_ATOMCONFIG_killerDefaultVoltage, i);
			Ini_GetDouble (ini, INI_SECTION_ATOMCONFIG, tagName, &c->killerDefaultVoltage[i]);
		}
		else {
			sprintf (tagName, INI_TAG_ATOMCONFIG_killerDefaultDetuning, i);
			Ini_GetDouble (ini, INI_SECTION_ATOMCONFIG, tagName, &c->killerDefaultDetuning[i]);
		}
	}
}


/******************************************************************************/
/*
/*   FUNCTIONS: Ini_GetEvent (...)
/*			    Ini_PutEvent (...)
/*
/******************************************************************************/

void Ini_GetEvent (IniText ini, t_atom *a, int atomNr, int nr)
{
    t_atomEvent *new;
    char sectionName[30];
	
	sprintf (sectionName, INI_SECTION_EVENT, atomNr, nr);

    new = ATOMEVENT_new (a);
    ATOMEVENT_init (new);
    
	Ini_GetInt (ini, sectionName, INI_TAG_EVENT_active,
			    &new->active);
	Ini_GetInt (ini, sectionName, INI_TAG_EVENT_eventStyle,
			    &new->eventStyle);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_EVENT_name, 
					         new->name, MAX_EVENTNAME_LEN);
	Ini_GetInt (ini, sectionName, INI_TAG_EVENT_deviceType,
			    &new->deviceType);
	Ini_GetInt (ini, sectionName, INI_TAG_EVENT_digitalChannel,
			    &new->digitalChannel);
	Ini_GetInt (ini, sectionName, INI_TAG_EVENT_analogChannel,
			    &new->analogChannel);
	Ini_GetPosition (ini, sectionName, INI_TAG_EVENT_pulseStartReference,
			    &new->pulseStartReference);
	Ini_GetInt (ini, sectionName, INI_TAG_EVENT_pulseStartVary,
			    &new->pulseStartVary);
	Ini_GetDouble (ini, sectionName, INI_TAG_EVENT_pulseStartFirst,
			       &new->pulseStartFirst);
	Ini_GetDouble (ini, sectionName, INI_TAG_EVENT_pulseStartIncrement,
			       &new->pulseStartIncrement);
	Ini_GetInt (ini, sectionName, INI_TAG_EVENT_pulseDurationVary,
			    &new->pulseDurationVary);
	Ini_GetDouble (ini, sectionName, INI_TAG_EVENT_pulseDurationFirst,
			       &new->pulseDurationFirst);
	Ini_GetDouble (ini, sectionName, INI_TAG_EVENT_pulseDurationIncrement,
			       &new->pulseDurationIncrement);
	Ini_GetInt (ini, sectionName, INI_TAG_EVENT_voltageVary,
			    &new->voltageVary);
	Ini_GetDouble (ini, sectionName, INI_TAG_EVENT_voltageFirst,
			       &new->voltageFirst);
	Ini_GetDouble (ini, sectionName, INI_TAG_EVENT_voltageIncrement,
			       &new->voltageIncrement);
}



void Ini_PutEvent (IniText ini, t_atom *a, int atomNr, int nr)
{
    t_atomEvent *new;
    char sectionName[30];
	
	sprintf (sectionName, INI_SECTION_EVENT, atomNr, nr);

    new = ATOMEVENT_ptr (a, nr);
    
	Ini_PutInt (ini, sectionName, INI_TAG_EVENT_active,
			    new->active);
	Ini_PutInt (ini, sectionName, INI_TAG_EVENT_eventStyle,
			    new->eventStyle);
	Ini_PutString (ini, sectionName, INI_TAG_EVENT_name, 
				   new->name);
	Ini_PutInt (ini, sectionName, INI_TAG_EVENT_deviceType,
			    new->deviceType);
	Ini_PutInt (ini, sectionName, INI_TAG_EVENT_digitalChannel,
			    new->digitalChannel);
	Ini_PutInt (ini, sectionName, INI_TAG_EVENT_analogChannel,
			    new->analogChannel);
	Ini_PutPosition (ini, sectionName, INI_TAG_EVENT_pulseStartReference,
			    new->pulseStartReference);
	Ini_PutInt0 (ini, sectionName, INI_TAG_EVENT_pulseStartVary,
			    new->pulseStartVary);
	Ini_PutDouble (ini, sectionName, INI_TAG_EVENT_pulseStartFirst,
			       new->pulseStartFirst);
	Ini_PutDouble0 (ini, sectionName, INI_TAG_EVENT_pulseStartIncrement,
			       new->pulseStartIncrement);
	Ini_PutInt0 (ini, sectionName, INI_TAG_EVENT_pulseDurationVary,
			    new->pulseDurationVary);
	Ini_PutDouble (ini, sectionName, INI_TAG_EVENT_pulseDurationFirst,
			       new->pulseDurationFirst);
	Ini_PutDouble0 (ini, sectionName, INI_TAG_EVENT_pulseDurationIncrement,
			       new->pulseDurationIncrement);
	Ini_PutInt0 (ini, sectionName, INI_TAG_EVENT_voltageVary,
			    new->voltageVary);
	Ini_PutDouble (ini, sectionName, INI_TAG_EVENT_voltageFirst,
			       new->voltageFirst);
	Ini_PutDouble0 (ini, sectionName, INI_TAG_EVENT_voltageIncrement,
			       new->voltageIncrement);
}




/******************************************************************************/
/*
/*   FUNCTIONS: Ini_GetAtom (...)
/*			    Ini_PutAtom (...)
/*
/*    Reads/writes data for an atom in 
/*    in Section "[Atom...]" from/to "ini-style"-file
/*    --  called by function "loadSession(...), "saveSession(...)", 
/*	  --  uses datatype "IniText" defined in Libaray "inifile.c"
/*
/******************************************************************************/

void Ini_GetAtom_Killer (IniText ini, t_atom *a, int atomNr, int cavityNr)
{
	int i;
	char sectionName[50];
	
	sprintf (sectionName, INI_SECTION_ATOMS_KILLER, atomNr, cavityNr);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_killerTimeReference, 
				&a->killerTimeReference[cavityNr]);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_killerStartFirst, 
				   &a->killerStartFirst[cavityNr]);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_nKillerPoints, 
				&a->nKillerPoints[cavityNr]);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_killerActive, 
				&a->killerActive[cavityNr]);
				
	a->killerPoints[cavityNr] = (t_point *) malloc (sizeof (t_point) * a->nKillerPoints[cavityNr]);
	for (i = 0; i < a->nKillerPoints[cavityNr]; i++) {
		Ini_GetPoint (ini, sectionName, &a->killerPoints[cavityNr][i], i);
	}
	
}


void Ini_PutAtom_Killer (IniText ini, t_atom *a, int atomNr, int cavityNr)
{
	int i;
	char sectionName[50];
	
	sprintf (sectionName, INI_SECTION_ATOMS_KILLER, atomNr, cavityNr);
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_killerTimeReference, 
				a->killerTimeReference[cavityNr]);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_killerStartFirst, 
				   a->killerStartFirst[cavityNr]);
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_nKillerPoints, 
				a->nKillerPoints[cavityNr]);
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_killerActive, 
				a->killerActive[cavityNr]);
	for (i = 0; i < a->nKillerPoints[cavityNr]; i++) {
		Ini_PutPoint (ini, sectionName, &(a->killerPoints[cavityNr][i]), i);
	}
	
}




void Ini_GetAtom (IniText ini, t_session *s, int nr)
{
    t_atom *new;
    char sectionName[30];

    int i;
    int nEvents = 0;
	
	sprintf (sectionName, INI_SECTION_ATOMS, nr);

    new = ATOM_new (s);
    ATOM_init (new);
  
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_ATOM_name, new->name, MAX_ATOMNAME_LEN);

	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_active,
			  &new->active);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_hasMultiples,
			  &new->hasMultiples);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_nMultiples,
			  &new->nMultiples);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_delay,
			  &new->delay);

	// circularization
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_durationL1,
			  &new->durationL1);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_durationL2, &new->durationL2);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_timeL2,
		  		   &new->timeL2);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_timeOP,
			       &new->timeOP);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_durationOP,
			       &new->durationOP);
 
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_circTriggerRF,
			  &new->circTriggerRF);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_circTriggerRamp,
			  &new->circTriggerRamp);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_circ52dTime,
			  &new->circ52dTime);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_circ52dDuration,
			  &new->circ52dDuration);

			  

	// state preparation
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_state,
			  &new->state);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_purifStart_e,
			  &new->purifStart_e);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_purifDuration_e,
			  &new->purifDuration_e);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_purifStart_g,
			  &new->purifStart_g);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_purifDuration_g,
			  &new->purifDuration_g);

	// velocity selection
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_velocitySelection,
			  &new->velocitySelection);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_velocity,
			  &new->velocity);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_velocitySpread,
			  &new->velocitySpread);
	Ini_GetDouble(ini, sectionName,INI_TAG_ATOM_velocitySpreadDoppler,
			  &new->velocitySpreadDoppler);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_repumperFrequency,
			  &new->repumperFrequency);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_repumperPower,
			  &new->repumperPower);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_repumperDuration,
			  &new->repumperDuration);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_repumperTime,
			  &new->repumperTime);
	Ini_GetPosition (ini, sectionName, INI_TAG_ATOM_repumperTimeReference,
			  &new->repumperTimeReference);
//	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_repumperAlwaysOn,
//			  	&new->repumperAlwaysOn);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_depumperDuration,
			  &new->depumperAngleDuration);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_depumperTime,
			  &new->depumperAngleTime);
			  

	for (i = 0; i < N_CAVITIES; i++) {
		Ini_GetAtom_Killer (ini, new, nr, i);
	}


	
	// get events
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_nEvents, &nEvents);
	for (i = 1; i <= nEvents; i++) {
		Ini_GetEvent (ini, new, nr, i);
	}

	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_detectionParameters,
			  	&new->detectionParameters);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_detect, &new->detect);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_detectionLevel, 
				&new->detectionLevel);
	Ini_GetDouble (ini, sectionName, INI_TAG_ATOM_detectionTime, 
			    &new->detectionTime);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_detectionTimeReference, 
			    &new->detectionTimeReference);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_detectionUseLevelsOfTransfer, 
				&new->detectionUseLevelsOfTransfer);
	Ini_GetInt (ini, sectionName, INI_TAG_ATOM_detectionSetLevel, 
				&new->detectionSetLevel);
			    
	
	sprintf (sectionName, INI_SECTION_ATOMS_TIMES, nr);
	for (i = 0; i < N_POSITIONS; i++) {
//		sprintf (tagName, INI_TAG_ATOM_time, df(i)->positionName);
		Ini_GetDouble (ini, sectionName, df(i)->positionName, &new->time[i]);
	}
	
}

/******************************************************************************/


void Ini_PutAtom (IniText ini, t_session *s, int nr)
{
    
    t_atom *new;
    char sectionName[30];

    int i;

	sprintf (sectionName, INI_SECTION_ATOMS, nr);

    new = ATOM_ptr (s, nr);
 
	Ini_PutString (ini, sectionName, INI_TAG_ATOM_name, new->name);

	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_active,
			  new->active);
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_hasMultiples,
			  new->hasMultiples);
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_nMultiples,
			  new->nMultiples);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_delay,
			  new->delay);
	
	// circularization
 	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_circTriggerRF,
			  new->circTriggerRF);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_circTriggerRamp,
			  new->circTriggerRamp);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_circ52dTime,
			  new->circ52dTime);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_circ52dDuration,
			  new->circ52dDuration);

//	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_alwaysOnL1, 
//				new->alwaysOnL1);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_durationL1,
			  new->durationL1);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_timeL2,
			  new->timeL2);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_durationL2,
			  new->durationL2);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_timeOP,
			  new->timeOP);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_durationOP,
			  new->durationOP);
			  

	// state preparation
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_state,
			  new->state);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_purifStart_e,
			  new->purifStart_e);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_purifDuration_e,
			  new->purifDuration_e);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_purifStart_g,
			  new->purifStart_g);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_purifDuration_g,
			  new->purifDuration_g);

	// velocity selection
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_velocitySelection,
			  new->velocitySelection);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_velocity,
			  new->velocity);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_velocitySpread,
			  new->velocitySpread);
	Ini_PutDouble(ini, sectionName,INI_TAG_ATOM_velocitySpreadDoppler,
			  new->velocitySpreadDoppler);		  

	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_repumperFrequency,
			  new->repumperFrequency);
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_repumperPower,
			  new->repumperPower);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_repumperDuration,
			  new->repumperDuration);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_repumperTime,
			  new->repumperTime);
	Ini_PutPosition (ini, sectionName, INI_TAG_ATOM_repumperTimeReference,
			  new->repumperTimeReference);
//	Ini_PutInt0 (ini, sectionName, INI_TAG_ATOM_repumperAlwaysOn,
//			  	 new->repumperAlwaysOn);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_depumperDuration,
			  new->depumperAngleDuration);
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_depumperTime,
			  new->depumperAngleTime);
			  
			  

	// killer parameters
	for (i = 0; i < N_CAVITIES; i++) {
		Ini_PutAtom_Killer (ini, new, nr, i);
	}
			  
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_nEvents,
			  	ListNumItems (new->lAtomEvents));
	for (i = 1; i <= ListNumItems (new->lAtomEvents); i++) {
		Ini_PutEvent (ini, new, nr, i);
	}
	
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_detectionParameters,
			  	new->detectionParameters);
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_detect, new->detect);

	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_detectionLevel, 
				new->detectionLevel);

	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_detectionUseLevelsOfTransfer, 
				new->detectionUseLevelsOfTransfer);
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_detectionSetLevel, 
				new->detectionSetLevel);
				
				
	Ini_PutDouble (ini, sectionName, INI_TAG_ATOM_detectionTime, 
			    new->detectionTime);
	Ini_PutInt (ini, sectionName, INI_TAG_ATOM_detectionTimeReference, 
			    new->detectionTimeReference);
	
	sprintf (sectionName, INI_SECTION_ATOMS_TIMES, nr);
	for (i = 0; i < N_POSITIONS; i++) {
//		sprintf (tagName, INI_TAG_ATOM_time, df(i)->positionName);
		Ini_PutDouble (ini, sectionName, df(i)->positionName, new->time[i]);
	}
	
}




/******************************************************************************/
/*
/*   FUNCTIONS: Ini_GetDetectionParameters (...)
/*			    Ini_PutDetectionParameters (...)
/*
/******************************************************************************/

void Ini_GetDetectionParameters (IniText ini, t_session *s, int nr)
{
    t_detectionParameters *new;
    char sectionName[30];
	
	sprintf (sectionName, INI_SECTION_DETECTIONPAR, nr);

    new = DETECTIONPAR_new (s);
    DETECTIONPAR_init (new);
    
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_DETECTIONPAR_name, 
					         new->name, MAX_DETECTIONPARNAME_LEN);
	Ini_GetDataArrayEx (ini, sectionName, INI_TAG_DETECTIONPAR_detectorActive, 
						new->detectorActive, N_DETECTORS, VAL_INTEGER);
	Ini_GetDouble (ini, sectionName, INI_TAG_DETECTIONPAR_rampStart,
			       &new->det1_rampStartVoltage);
	Ini_GetDouble (ini, sectionName, INI_TAG_DETECTIONPAR_rampStop,
			       &new->det1_rampStopVoltage);
	Ini_GetDouble (ini, sectionName, INI_TAG_DETECTIONPAR_rampDuration,
			       &new->det1_rampDuration);
	Ini_GetDouble (ini, sectionName, INI_TAG_DETECTIONPAR_rampTrigger,
			       &new->det1_rampTrigger);
	Ini_GetPosition (ini, sectionName, INI_TAG_DETECTIONPAR_rampTriggerReference,
			         &new->det1_rampTriggerReference);
	// time windows e/g
	Ini_GetDataArrayEx (ini, sectionName, INI_TAG_DETECTIONPAR_timeStart1,
			       		new->det1_timeStart, MAX_LEVELS, VAL_DOUBLE);
	Ini_GetDataArrayEx (ini, sectionName, INI_TAG_DETECTIONPAR_timeEnd1,
			       		new->det1_timeEnd, MAX_LEVELS, VAL_DOUBLE);
	Ini_GetDataArrayEx  (ini, sectionName, INI_TAG_DETECTIONPAR_levelActive,
			       	  	new->det1_levelActive, MAX_LEVELS, VAL_INTEGER);
			       		
// detector 2 (roof);			    
//	Ini_GetInt (ini, sectionName, INI_TAG_DETECTIONPAR_useTimeWindow,
//			       &new->det2_useTimeWindow);
	Ini_GetDouble (ini, sectionName, INI_TAG_DETECTIONPAR_timeStart2,
			       &new->det2_timeStart);
	Ini_GetDouble (ini, sectionName, INI_TAG_DETECTIONPAR_timeEnd2,
			       &new->det2_timeEnd);
	Ini_GetPosition (ini, sectionName, INI_TAG_DETECTIONPAR_timeReference,
			         &new->det2_timeReference);
//	Ini_GetInt (ini, sectionName, INI_TAG_DETECTIONPAR_defaultLevel2, 
//				&new->det2_defaultLevel);
			         
}



void Ini_PutDetectionParameters (IniText ini, t_session *s, int nr)
{
    t_detectionParameters *new;
    char sectionName[30];
	
	sprintf (sectionName, INI_SECTION_DETECTIONPAR, nr);

    new = DETECTIONPAR_ptr (s, nr);
	Ini_PutDataArray (ini, sectionName, INI_TAG_DETECTIONPAR_detectorActive, 
					  new->detectorActive, N_DETECTORS, VAL_INTEGER);
	Ini_PutString (ini, sectionName, INI_TAG_DETECTIONPAR_name, 
				   new->name);
	Ini_PutDouble (ini, sectionName, INI_TAG_DETECTIONPAR_rampStart,
			       new->det1_rampStartVoltage);
	Ini_PutDouble (ini, sectionName, INI_TAG_DETECTIONPAR_rampStop,
			       new->det1_rampStopVoltage);
	Ini_PutDouble (ini, sectionName, INI_TAG_DETECTIONPAR_rampDuration,
			       new->det1_rampDuration);
	Ini_PutDouble (ini, sectionName, INI_TAG_DETECTIONPAR_rampTrigger,
			       new->det1_rampTrigger);
	Ini_PutPosition (ini, sectionName, INI_TAG_DETECTIONPAR_rampTriggerReference,
			         new->det1_rampTriggerReference);

	
	// time windows e/g
	Ini_PutDataArray (ini, sectionName, INI_TAG_DETECTIONPAR_timeStart1,
			       	  new->det1_timeStart, MAX_LEVELS, VAL_DOUBLE);
	Ini_PutDataArray (ini, sectionName, INI_TAG_DETECTIONPAR_timeEnd1,
			       	  new->det1_timeEnd, MAX_LEVELS, VAL_DOUBLE);
	Ini_PutDataArray (ini, sectionName, INI_TAG_DETECTIONPAR_levelActive,
			       	  new->det1_levelActive, MAX_LEVELS, VAL_INTEGER);

// detector 2 (roof);			    
//	Ini_PutInt (ini, sectionName, INI_TAG_DETECTIONPAR_useTimeWindow,
//			    new->det2_useTimeWindow);
	Ini_PutPosition (ini, sectionName, INI_TAG_DETECTIONPAR_timeReference,
			         new->det2_timeReference);
	Ini_PutDouble (ini, sectionName, INI_TAG_DETECTIONPAR_timeStart2,
			       new->det2_timeStart);
	Ini_PutDouble (ini, sectionName, INI_TAG_DETECTIONPAR_timeEnd2,
			       new->det2_timeEnd);
//	Ini_PutInt (ini, sectionName, INI_TAG_DETECTIONPAR_defaultLevel2, 
//				new->det2_defaultLevel);

}




/******************************************************************************/
/*
/*   FUNCTIONS: Ini_GetSweep (...)
/*			    Ini_PutSweep (...)
/*
/******************************************************************************/

void Ini_GetSweep (IniText ini, t_session *s, int nr)
{
    t_sweep *new;
    char sectionName[30];
	
	sprintf (sectionName, INI_SECTION_SWEEP, nr);
    new = SWEEP_new (s);
    SWEEP_init (new);
    
	Ini_GetInt (ini, sectionName, INI_TAG_SWEEP_type, 
				&new->type);
/*	if (new->type < 0) {
		SWEEP_delete (s, END_OF_LIST);
		return;
	}
*/	
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_SWEEP_name, 
				   			 new->name, MAX_SWEEPNAME_LEN);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_SWEEP_plotAxisName, 
				   			 new->plotAxisName, MAX_AXISNAME_LEN);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_SWEEP_units, 
				   			 new->units, MAX_UNIT_LEN);
	

	Ini_GetInt (ini, sectionName, INI_TAG_SWEEP_active, 
				&new->active);
	Ini_GetInt (ini, sectionName, INI_TAG_SWEEP_channel, 
				&new->channel);
/*	Ini_GetInt (ini, sectionName, INI_TAG_SWEEP_changeMode, 
				&new->changeMode);
*/	Ini_GetDouble (ini, sectionName, INI_TAG_SWEEP_from, 
				   &new->from);
	Ini_GetDouble (ini, sectionName, INI_TAG_SWEEP_to, 
				   &new->to);
	Ini_GetInt (ini, sectionName, INI_TAG_SWEEP_sweepOn, 
				&new->sweepOn);
	
	switch (new->type) {
		case SWEEP_TYPE_ANALOGCHANNEL:
			if (!new->active && (new->from == 0) && (new->to == 0) 
				&& (new->channel == 0)) {
					SWEEP_delete (s, END_OF_LIST);
			}
				
			break;
		case SWEEP_TYPE_SYNTHESIZER:
			Ini_GetDouble (ini, sectionName, INI_TAG_SWEEP_center, 
						   &new->center);
			Ini_GetDouble (ini, sectionName, INI_TAG_SWEEP_span, 
						   &new->span);
			Ini_GetInt (ini, sectionName, INI_TAG_SWEEP_rfOn, 
						&new->rfOn);
			Ini_GetInt (ini, sectionName, INI_TAG_SWEEP_pulseMode, 
						&new->pulseMode);
			Ini_GetInt (ini, sectionName, INI_TAG_SWEEP_harmonic, 
						&new->harmonic);
			Ini_GetDouble (ini, sectionName, INI_TAG_SWEEP_outputPower, 
						  &new->outputPower);
			break;		 
		case SWEEP_TYPE_POWERSUPPLY:
			Ini_GetInt (ini, sectionName, INI_TAG_SWEEP_deviceChannel, 
						&new->deviceChannel);
			Ini_GetDouble (ini, sectionName, INI_TAG_SWEEP_current, 
						  &new->current_mA);
			break;
			
	}
	new->nPoints = s->nSweepPoints;
				   
}


void Ini_PutSweep (IniText ini, t_session *s, int nr)
{
    t_sweep *new;
    char sectionName[30];
	
	sprintf (sectionName, INI_SECTION_SWEEP, nr);
    new = SWEEP_ptr (s, nr);
    
	Ini_PutString (ini, sectionName, INI_TAG_SWEEP_name, 
				   new->name);
	Ini_PutString (ini, sectionName, INI_TAG_SWEEP_plotAxisName, 
				   new->plotAxisName);
	Ini_PutString (ini, sectionName, INI_TAG_SWEEP_units, 
				   new->units);
	Ini_PutInt (ini, sectionName, INI_TAG_SWEEP_type, 
				new->type);
	Ini_PutInt (ini, sectionName, INI_TAG_SWEEP_active, 
				new->active);
	Ini_PutInt (ini, sectionName, INI_TAG_SWEEP_channel, 
				new->channel);
/*	Ini_PutInt (ini, sectionName, INI_TAG_SWEEP_changeMode, 
				new->changeMode);
*/	Ini_PutDouble (ini, sectionName, INI_TAG_SWEEP_from, 
				   new->from);
	Ini_PutDouble (ini, sectionName, INI_TAG_SWEEP_to, 
				   new->to);
	Ini_PutInt (ini, sectionName, INI_TAG_SWEEP_sweepOn, 
				new->sweepOn);
	switch (new->type) {
		case SWEEP_TYPE_SYNTHESIZER:
			Ini_PutDouble (ini, sectionName, INI_TAG_SWEEP_center, 
						   new->center);
			Ini_PutDouble (ini, sectionName, INI_TAG_SWEEP_span, 
						   new->span);
			Ini_PutInt (ini, sectionName, INI_TAG_SWEEP_rfOn, 
						new->rfOn);
			Ini_PutInt0 (ini, sectionName, INI_TAG_SWEEP_pulseMode, 
						new->pulseMode);
			Ini_PutInt (ini, sectionName, INI_TAG_SWEEP_harmonic, 
						new->harmonic);
			Ini_PutDouble (ini, sectionName, INI_TAG_SWEEP_outputPower, 
						   new->outputPower);
			break;
		case SWEEP_TYPE_POWERSUPPLY:
			Ini_PutInt (ini, sectionName, INI_TAG_SWEEP_deviceChannel, 
						new->deviceChannel);
			Ini_PutDouble (ini, sectionName, INI_TAG_SWEEP_current, 
						   new->current_mA);
			break;
			
	}
	
}





/*
int Ini_GetSequenceGenerationParameters (IniText ini, t_session *s)
{
	Ini_GetStringIntoBuffer (ini, INI_SECTION_SEQGEN, INI_TAG_SEQGEN_circUpper,
			s->gpibCommandCircUpper, MAX_GPIBCOMMANDNAME_LEN);
	Ini_GetStringIntoBuffer (ini, INI_SECTION_SEQGEN, INI_TAG_SEQGEN_circLower,
			s->gpibCommandCircLower, MAX_GPIBCOMMANDNAME_LEN);
	Ini_GetStringIntoBuffer (ini, INI_SECTION_SEQGEN, INI_TAG_SEQGEN_voltageRamp,
			s->gpibCommandVoltageRamp, MAX_GPIBCOMMANDNAME_LEN);
	Ini_GetStringIntoBuffer (ini, INI_SECTION_SEQGEN, INI_TAG_SEQGEN_voltageRamp,
			s->shortStr, MAX_SHORTSTR_LEN);
	return 0;
}


int Ini_PutSequenceGenerationParameters (IniText ini, t_session *s)
{
	Ini_PutString (ini, INI_SECTION_SEQGEN, INI_TAG_SEQGEN_circUpper, 
				  s->gpibCommandCircUpper);
	Ini_PutString (ini, INI_SECTION_SEQGEN, INI_TAG_SEQGEN_circLower,
				  s->gpibCommandCircLower);
	Ini_PutString (ini, INI_SECTION_SEQGEN, INI_TAG_SEQGEN_voltageRamp,
				  s->gpibCommandVoltageRamp);
	Ini_PutString (ini, INI_SECTION_SEQGEN, INI_TAG_SEQGEN_shortStr,
				  s->shortStr);
	return 0;
}
*/

void Ini_GetSession_RunParameters (IniText ini, t_session *s)
{
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_plotSweepParameter,
				    &s->plotSweepParameter);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_saveRunData,
				&s->saveRunData);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_saveArrivalTimes,
				&s->saveArrivalTimes);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_generateRandomCounterData,
				&s->generateRandomCounterData);
				
	if (Ini_GetDouble (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_curveStart,
				&s->curveStart_us) == 0) {
		// no entry of 'curveStart' found --> old program Version < 1.2
		Ini_GetDouble (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_curveDuration,
					&s->curveEnd_us);
		s->curveStart_us = 0.0;
	}
	else {
		Ini_GetDouble (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_curveEnd,
						&s->curveEnd_us);
	}

	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nAverages,
				&s->nAverages);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_killerActive,
				&s->transmitKillerCurves);
				
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_channel,
				&s->DIG_channel);
	Ini_GetDouble (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_voltageFrom,
				&s->DIG_voltageFrom);
	Ini_GetDouble (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_voltageTo,
				&s->DIG_voltageTo);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_nSteps,
				&s->DIG_nSteps);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_copiesPerStep,
				&s->DIG_copiesPerStep);
	if (Ini_GetStringIntoBuffer (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_windowName,
				             s->DIG_windowName, MAX_TITLE_LEN) <= 0) 
		strcpy (s->DIG_windowName, DEFAULT_DIG_WINDOWNAME);
				

	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_transferAtom,
				&s->transferAtom);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_transferOn,
				&s->transferOn);
	Ini_GetDataArrayEx (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_transferLevel,
						s->transferLevel, N_SESSION_TRANSFER_LEVELS, VAL_INTEGER);
}


void Ini_PutLevelInfo (IniText ini, t_session *s)
{
	int i;
	char tagName[30];
	
	Ini_PutInt (ini, INI_SECTION_LEVELS, INI_TAG_LEVELS_nLevels, s->nLevels);
	Ini_PutDataArray (ini, INI_SECTION_LEVELS, INI_TAG_LEVELS_voltages,
					  s->levelVoltages, MAX_LEVELS, VAL_DOUBLE);
	for (i = 0; i < MAX_LEVELS; i++) {
		sprintf (tagName, INI_TAG_LEVELS_name, i);
		Ini_PutString (ini, INI_SECTION_LEVELS,	tagName, s->levelNames[i]); 
	}
}					  

void Ini_GetLevelInfo (IniText ini, t_session *s)
{
	int i;
	char tagName[30];
	
	Ini_GetInt (ini, INI_SECTION_LEVELS, INI_TAG_LEVELS_nLevels, &s->nLevels);
	Ini_GetDataArrayEx (ini, INI_SECTION_LEVELS, INI_TAG_LEVELS_voltages,
					  	s->levelVoltages, MAX_LEVELS, VAL_DOUBLE);
	for (i = 0; i < MAX_LEVELS; i++) {
		sprintf (tagName, INI_TAG_LEVELS_name, i);
		Ini_GetStringIntoBuffer (ini, INI_SECTION_LEVELS, tagName, s->levelNames[i],
								 MAX_LEVELNAME_LEN); 
	}
}



void Ini_GetPlotItem (IniText ini, t_session *s, int nr)
{
	t_plotItem *p;
	char sectionName[30];
	char tagName[30];
	int i;
	int arr2[2];
	
	sprintf (sectionName, INI_SECTION_PLOTITEM, nr);
	p = PLOTITEM_new (s);
	
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_active,
		        &p->active);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_PLOTITEM_name,
							 p->name, MAX_PLOTITEMNAME_LEN-1);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_type,
				&p->type);
				
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_atom,
				&p->atomNr);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_multiple,
				&p->multiple);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_detector,
				&p->detector);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_excludeDoubleCounts,
				   &p->excludeDoubleCounts);		
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_dataFilterID,
				&p->dataFilterID);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_velocityNPoints,
				&p->velocityNPoints);
	Ini_GetDouble (ini, sectionName, INI_TAG_PLOTITEM_velocityStart,
				   &p->velocityStart);
	Ini_GetDouble (ini, sectionName, INI_TAG_PLOTITEM_velocityEnd,
				   &p->velocityEnd);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_velocityShowPositionAxis,
				   &p->velocityShowPositionAxis);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_velocityShowExperimentParts,
				   &p->velocityShowExperimentParts);
	Ini_GetDouble (ini, sectionName, INI_TAG_PLOTITEM_velocityTimeMultiply,
				   &p->velocityTimeMultiply_us);
				   
	
	Ini_GetDouble (ini, sectionName, INI_TAG_PLOTITEM_binsize,
				   &p->arrivalTimesBinSize_us);
	Ini_GetDouble (ini, sectionName, INI_TAG_PLOTITEM_binStart,
				   &p->arrivalTimesBinStart_us);
	Ini_GetDouble (ini, sectionName, INI_TAG_PLOTITEM_binEnd,
				   &p->arrivalTimesBinEnd_us);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_binAuto,
				   &p->arrivalTimesBinAuto);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_nBins,
				   &p->arrivalTimesNBins);
				   
		   

	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_transferShow,
				&p->transfer);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_plotItemTransfer1, &p->plotItemTransfer1);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_plotItemTransfer2, &p->plotItemTransfer2);

		// old version, prior to V 2.63, 13.02.2005
	if (Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_OLD_countsFixedInterval,
				&p->fixedIntervals) > 0) {
		Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_OLD_transfer_level1,
					&p->level);
//		Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_OLD_transfer_level2,
//					&p->level[1]);
		if ((p->detector == 1) && (p->transfer)){
			p->level = s->transferLevel[0];
//			p->level[1] = s->transferLevel[1];
			p->fixedIntervals = 0;
		}
		Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_OLD_countsInterval,
					&p->interval[0]);
		p->interval[1] = p->interval[0];
		if (!p->transfer) {
			Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_OLD_countsLevel,
						&p->level);
			// auto select intervals
			p->fixedIntervals = 0;
		}
	}
	else {
		Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_fixedIntervals,
					&p->fixedIntervals);
		if (s->programVersion < 2.80) {
		// version 2.63 - 2.79
			Ini_GetDataArrayEx (ini, sectionName, INI_TAG_PLOTITEM_level,
					            arr2, 2, VAL_INTEGER);
			p->level = arr2[0];
			for (i = 0; i < N_DETECTORS; i++) {
				sprintf (tagName, INI_TAG_PLOTITEM_interval, i);
				Ini_GetDataArrayEx (ini, sectionName, tagName,
						            arr2, 2, VAL_INTEGER);
				p->interval[i] = arr2[0];
			}					            
		}
		else {
			Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_level, &p->level);
			for (i = 0; i < N_DETECTORS; i++) {
				sprintf (tagName, INI_TAG_PLOTITEM_interval, i);
				Ini_GetInt (ini, sectionName, tagName, &p->interval[i]);
			}					            
		}
			
	}
								            
//	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_countsFixedInterval,
//				&p->countsFixedInterval);
//	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_countsLevel,
//				&p->countsLevel);
				
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_saveCurve,
				&p->saveCurve);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_saveTxt,
				&p->saveTxt);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_keepCurve,
				&p->keepCurve);
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_createPlot2D,
				&p->create2DPlot);
				
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_autoSetWindowName, &p->autoSetWindowName);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_PLOTITEM_panelTitle, p->panelTitle,
							 MAX_TITLE_LEN);
	
	
	
	// compatibility with version prior to 2.60
	if (p->type == OLD_PLOT_TYPE_TRANSFER) {
		p->type = PLOT_TYPE_NCOUNTS;
		p->transfer = 1;
	}
	if (p->type == PLOT_TYPE_NCOUNTS) p->create2DPlot = 0;

	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_plotColor, &p->plotColor);
	if (p->plotColor == GRAPH_BACKGOUND_COLOR) p->plotColor = CURVE_DEFAULT_COLOR;
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_plotStyle, &p->plotStyle);
	
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_plotColorCurrent, &p->plotColorCurrent);
	if (p->plotColorCurrent == GRAPH_BACKGOUND_COLOR) p->plotColorCurrent = CURVE_CURRENT_DEFAULT_COLOR;
	Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_plotStyleCurrent, &p->plotStyleCurrent);
	
	Ini_GetRect (ini, sectionName, INI_TAG_PLOTITEM_panelPos2D, &p->panelPos2D);
	Ini_GetRect (ini, sectionName, INI_TAG_PLOTITEM_panelPos, &p->panelPos);
	if (p->type == PLOT_TYPE_CORRELATIONS) {
		Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_correlationsNAtoms,
					&p->correlationsNAtoms);
		
		Ini_GetDataArrayEx (ini, sectionName, INI_TAG_PLOTITEM_correlationsAtomNumber,
					 p->correlationsAtomNumber, MAX_CORRELATION_ATOMS, VAL_INTEGER);
		Ini_GetDataArrayEx (ini, sectionName, INI_TAG_PLOTITEM_correlationsAtomMultiple,
					 p->correlationsAtomMultiple, MAX_CORRELATION_ATOMS, VAL_INTEGER);
					 
		Ini_GetDataArrayEx (ini, sectionName, INI_TAG_PLOTITEM_correlationsLevel1,
					 p->correlationsLevel[0], MAX_CORRELATION_ATOMS, VAL_INTEGER);
		Ini_GetDataArrayEx (ini, sectionName, INI_TAG_PLOTITEM_correlationsLevel2,
					 p->correlationsLevel[1], MAX_CORRELATION_ATOMS, VAL_INTEGER);
		Ini_GetDataArrayEx (ini, sectionName, INI_TAG_PLOTITEM_correlationsFilterID,
					 p->correlationsFilterID, MAX_CORRELATION_CURVES, VAL_INTEGER);
		PLOTITEM_getPtrToFilter (s, p);
		Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_correlationsFilterIDOneAtom,
					&p->correlationsFilterIDOneAtom);
		p->correlationsFilterOneAtom = FILTER_ptr (s, p->correlationsFilterIDOneAtom);
	}
	if (p->type == PLOT_TYPE_MULTIPLE_AS_INDEX) {
		Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_multipleAsIndexNBinAtoms,
					&p->multipleAsIndexNBinAtoms);
		Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_multipleAsIndexFilterForEachMultipleID,
					&p->multipleAsIndexFilterForEachMultipleID);
		Ini_GetInt (ini, sectionName, INI_TAG_PLOTITEM_multipleAsIndexSumAllRuns,
					&p->multipleAsIndexSumAllRuns);
					
	}
	
	
}


void Ini_PutPlotItem (IniText ini, t_session *s, int nr)
{
	char sectionName[30];
	char tagName[30];
	t_plotItem *p;
	int i;
	
	sprintf (sectionName, INI_SECTION_PLOTITEM, nr);
	p = PLOTITEM_ptr (s, nr);
	
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_active,
		        p->active);
	Ini_PutString (ini, sectionName, INI_TAG_PLOTITEM_name,
		           p->name);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_type,
				p->type);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_atom,
				p->atomNr);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_multiple,
				p->multiple);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_detector,
				p->detector);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_excludeDoubleCounts,
				   p->excludeDoubleCounts);		
	Ini_PutInt0 (ini, sectionName, INI_TAG_PLOTITEM_dataFilterID,
				p->dataFilterID);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_velocityNPoints,
				p->velocityNPoints);
	Ini_PutDouble (ini, sectionName, INI_TAG_PLOTITEM_velocityStart,
				   p->velocityStart);
	Ini_PutDouble (ini, sectionName, INI_TAG_PLOTITEM_velocityEnd,
				   p->velocityEnd);
	if (p->velocityShowPositionAxis) {				   
		Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_velocityShowPositionAxis,
					   p->velocityShowPositionAxis);
		Ini_PutInt0 (ini, sectionName, INI_TAG_PLOTITEM_velocityShowExperimentParts,
					   p->velocityShowExperimentParts);
		Ini_PutDouble (ini, sectionName, INI_TAG_PLOTITEM_velocityTimeMultiply,
					   p->velocityTimeMultiply_us);
	}

	
	Ini_PutDouble (ini, sectionName, INI_TAG_PLOTITEM_binsize,
				   p->arrivalTimesBinSize_us);
	Ini_PutDouble (ini, sectionName, INI_TAG_PLOTITEM_binStart,
				   p->arrivalTimesBinStart_us);
	Ini_PutDouble (ini, sectionName, INI_TAG_PLOTITEM_binEnd,
				   p->arrivalTimesBinEnd_us);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_binAuto,
				   p->arrivalTimesBinAuto);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_nBins,
				   p->arrivalTimesNBins);
				   
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_transferShow,
				p->transfer);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_fixedIntervals,
				p->fixedIntervals);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_level, p->level);
	for (i = 0; i < N_DETECTORS; i++) {
		sprintf (tagName, INI_TAG_PLOTITEM_interval, i);
		Ini_PutInt (ini, sectionName, tagName, p->interval[i]);
	}					            
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_plotItemTransfer1, p->plotItemTransfer1);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_plotItemTransfer2, p->plotItemTransfer2);
				
	Ini_PutInt0 (ini, sectionName, INI_TAG_PLOTITEM_saveCurve,
				p->saveCurve);
	Ini_PutInt0 (ini, sectionName, INI_TAG_PLOTITEM_saveTxt,
				 p->saveTxt);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_keepCurve,
				 p->keepCurve);
	Ini_PutInt0 (ini, sectionName, INI_TAG_PLOTITEM_createPlot2D,
				p->create2DPlot);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_autoSetWindowName, p->autoSetWindowName);
	Ini_PutString (ini, sectionName, INI_TAG_PLOTITEM_panelTitle, p->panelTitle);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_plotColor, p->plotColor);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_plotStyle, p->plotStyle);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_plotColorCurrent, p->plotColorCurrent);
	Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_plotStyleCurrent, p->plotStyleCurrent);
	if (p->panelPos2D.width >= 0) 
		Ini_PutRect (ini, sectionName, INI_TAG_PLOTITEM_panelPos2D, p->panelPos2D);
	if (p->panelPos.width >= 0) 
		Ini_PutRect (ini, sectionName, INI_TAG_PLOTITEM_panelPos, p->panelPos);
	// correlations
	if (p->type == PLOT_TYPE_CORRELATIONS) {
		Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_correlationsNAtoms,
					p->correlationsNAtoms);
		Ini_PutDataArray (ini, sectionName, INI_TAG_PLOTITEM_correlationsAtomNumber,
					 p->correlationsAtomNumber, MAX_CORRELATION_ATOMS, VAL_INTEGER);
		Ini_PutDataArray (ini, sectionName, INI_TAG_PLOTITEM_correlationsAtomMultiple,
					 p->correlationsAtomMultiple, MAX_CORRELATION_ATOMS, VAL_INTEGER);
					 
		Ini_PutDataArray (ini, sectionName, INI_TAG_PLOTITEM_correlationsLevel1,
					 p->correlationsLevel[0], MAX_CORRELATION_ATOMS, VAL_INTEGER);
		Ini_PutDataArray (ini, sectionName, INI_TAG_PLOTITEM_correlationsLevel2,
					 p->correlationsLevel[1], MAX_CORRELATION_ATOMS, VAL_INTEGER);
		Ini_PutDataArray (ini, sectionName, INI_TAG_PLOTITEM_correlationsFilterID,
					 p->correlationsFilterID, MAX_CORRELATION_CURVES, VAL_INTEGER);
		Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_correlationsFilterIDOneAtom,
					p->correlationsFilterIDOneAtom);
					 
	}
	if (p->type == PLOT_TYPE_MULTIPLE_AS_INDEX) {
		Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_multipleAsIndexNBinAtoms,
					p->multipleAsIndexNBinAtoms);
		Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_multipleAsIndexFilterForEachMultipleID,
					p->multipleAsIndexFilterForEachMultipleID);
		Ini_PutInt (ini, sectionName, INI_TAG_PLOTITEM_multipleAsIndexSumAllRuns,
					p->multipleAsIndexSumAllRuns);
	}
}


/*void Ini_PutGraphParameters (IniText ini, t_session *s, int nr)       
{
	t_graphParameters *p;
	char sectionName[30];

	sprintf (sectionName, INI_SECTION_GRAPHPAR, nr);
	
	p = GRAPHPARAMETERS_ptr (s, nr);
	Ini_PutString (ini, sectionName, INI_TAG_GRAPHPAR_panelTitle, p->panelTitle);
	Ini_PutInt (ini, sectionName, INI_TAG_GRAPHPAR_height, p->height);
	Ini_PutInt (ini, sectionName, INI_TAG_GRAPHPAR_width,  p->width);
	Ini_PutInt (ini, sectionName, INI_TAG_GRAPHPAR_top,    p->top);
	Ini_PutInt (ini, sectionName, INI_TAG_GRAPHPAR_left,   p->left);
}




void Ini_GetGraphParameters (IniText ini, t_session *s, int nr)       
{
	t_graphParameters *p;
	char sectionName[30];

	sprintf (sectionName, INI_SECTION_GRAPHPAR, nr);
	p = GRAPHPARAMETERS_new (s);
	GRAPHPARAMETERS_init (p);
	
	Ini_GetInt (ini, sectionName, INI_TAG_GRAPHPAR_height, &p->height);
	Ini_GetInt (ini, sectionName, INI_TAG_GRAPHPAR_width,  &p->width);
	Ini_GetInt (ini, sectionName, INI_TAG_GRAPHPAR_top,    &p->top);
	Ini_GetInt (ini, sectionName, INI_TAG_GRAPHPAR_left,   &p->left);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_GRAPHPAR_panelTitle, p->panelTitle,
							 MAX_TITLE_LEN);
}
*/

void Ini_GetSession (IniText ini, t_session *s)
{

    int nAtoms = 0;
    int nFilters = 0;
    int nDetectionParameters = 0;
    int nSweeps = 0;
    int nPlotItems = 0;
    int nGraphParemeters = 0;
    int i;
    char tagName[40];
	
	Ini_GetAtomConfig (ini, s->atomConfig);         
	// read atoms
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nAtoms,
				&nAtoms);
	for (i = 0; i < nAtoms; i++) Ini_GetAtom (ini, s, i+1);
	
	Ini_GetDataArrayEx (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_counterOn,
						s->counterOn, N_COUNTERS, VAL_INTEGER);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_lastStarted,
			    &s->lastStarted);
	Ini_GetDouble (ini, INI_SECTION_SESSIONINFO, 
		  	       INI_TAG_SESSIONINFO_Version, &s->programVersion);
	
	if (s->readOnly) {
		Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_startNr,
				    &s->startNr);
		Ini_GetStringIntoBuffer (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_date,
				           s->dateStr, MAX_DATESTR_LEN-1);
	} 
	else {
		s->startNr = -1;
		s->dateStr[0] = 0;
	}
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_updatePoints,
				&s->updatePoints);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_repumperAlwaysOn,
				&s->repumperAlwaysOn);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_repumperAlwaysOn,
				&s->repumperAlwaysOn);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_laser1AlwaysOn,
			    &s->laser1AlwaysOn);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_laser2AlwaysOn,
				 &s->laser2AlwaysOn);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_optPumpingAlwaysOn,
				 &s->optPumpingAlwaysOn);
			    
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_repumperPower,
			    &s->repumperPower);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_repumperFrequency,
			    &s->repumperFrequency);
						
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_mode,
				&s->mode);
				
//	Ini_GetStringIntoBuffer (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_shortStr, 
//		s->shortStr, MAX_SHORTSTR_LEN);
	Ini_GetStringCopy (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_comments,
					   &s->comments);


	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nRuns, 
				&s->nRuns);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nSweepPoints, 
				&s->nSweepPoints);
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nCurves, 
				&s->nCurves);

		
	Ini_GetLevelInfo (ini, s);
	
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nDetectionParameters,
				&nDetectionParameters);
	for (i = 1; i <= nDetectionParameters; i++) 
		Ini_GetDetectionParameters (ini, s, i);

	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nSweeps,
				&nSweeps);
	for (i = 1; i <= nSweeps; i++) 
		Ini_GetSweep (ini, s, i);
//	Ini_GetSequenceGenerationParameters (ini, s);

	Ini_GetSession_RunParameters (ini, s);
	
/*	for (i = 0; i < N_CAVITIES; i++) {
		sprintf (tagName, INI_TAG_SESSIONINFO_parametersTransferFunct, i);
		Ini_GetDataArrayEx (ini, INI_SECTION_SESSIONINFO, tagName,
						    s->parametersTransferFunct[i], N_PARAMETERS_TRANSFER_FUNCT, VAL_DOUBLE);	
		sprintf (tagName, INI_TAG_SESSIONINFO_killerDefaultVoltage, i);
		Ini_GetDouble (ini, INI_SECTION_SESSIONINFO, tagName, &s->killerDefaultVoltage[i]);
						    
	}
*/
	Ini_GetDataArrayEx_Comp (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_digitalOutputs_preset,
					  s->digitalOutputs_preset, N_DIO_CHANNELS, VAL_INTEGER);
	Ini_GetDataArrayEx_Comp (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_digitalOutputs_onOff,
					  s->digitalOutputs_onOff, N_DIO_CHANNELS, VAL_INTEGER);
					  
	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nFilters,
				&nFilters);
	for (i = 1; i <= nFilters; i++) 
		Ini_GetFilter (ini, s, i);


	Ini_GetInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nPlotItems,
				&nPlotItems);
	for (i = 1; i <= nPlotItems; i++) Ini_GetPlotItem (ini, s, i);
					  
 	

}


/******************************************************************************/
/*
/*    load Session ("*.ses"-file)
/*
/******************************************************************************/

void SESSION_getInfoOldVersion (const char *filename, t_session *s)
{
	char name[MAX_PATHNAME_LEN];
	char *startCh, *endCh;
	int l;
	
	getDateAndTimeFromFile 	(filename, s->dateStr, NULL);
	strcpy (name, extractDir (filename));
	l = strlen (name);
	if (l == 0) return;
	name[l-1] = 0;
	startCh = strrchr (name, '\\');
	if (startCh == NULL) return;
	endCh = strchr (startCh+1, '_');
	if (endCh == NULL) return;
	endCh[0] = 0;
	s->startNr = strtod (startCh+1, &endCh);  
	if (s->startNr <= 0) s->startNr = -1;
}


int SESSION_load (const char *filename, t_session *s)
{
    IniText ini;
    int err;
    int dummy;
    
	if ((ini = Ini_New (1)) == 0) return -1;
	
    SESSION_init (s);
    strcpy (s->filename, filename);

	if ((err = Ini_ReadFromFile (ini, filename)) != 0) goto END;
	GetFileAttrs (filename, &s->readOnly, &dummy, &dummy, &dummy);
	Ini_GetSession (ini, s);
	// check if read only and no info for startNr etc. read (version 1.01)
	// --> read manually
	if (s->readOnly && (s->startNr < 0)) SESSION_getInfoOldVersion (filename, s);

END:
	Ini_Dispose (ini);

	return displayIniFileError (filename, err);
}




void Ini_PutSession_RunParameters (IniText ini, t_session *s)
{
	int i;
	
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nSweeps,
				ListNumItems(s->lSweeps));
	for (i = 1; i <= ListNumItems(s->lSweeps); i++) 
		Ini_PutSweep (ini, s, i);

	if (s->plotSweepParameter> 0)
		Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_plotSweepParameter,
				    s->plotSweepParameter);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_saveRunData,
				s->saveRunData);
	Ini_PutInt0 (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_saveArrivalTimes,
				s->saveArrivalTimes);
	Ini_PutInt0 (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_generateRandomCounterData,
				s->generateRandomCounterData);
				
				

	Ini_PutDouble (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_curveStart,
				s->curveStart_us);
	Ini_PutDouble (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_curveEnd,
				s->curveEnd_us);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nAverages,
				s->nAverages);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_killerActive,
				s->transmitKillerCurves);

	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_channel,
				s->DIG_channel);
	Ini_PutDouble (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_voltageFrom,
				s->DIG_voltageFrom);
	Ini_PutDouble (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_voltageTo,
				s->DIG_voltageTo);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_nSteps,
				s->DIG_nSteps);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_copiesPerStep,
				s->DIG_copiesPerStep);
	if (strcmp (DEFAULT_DIG_WINDOWNAME, s->DIG_windowName) != 0) {
		Ini_PutString (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_DIG_windowName,
					   s->DIG_windowName);
	}
				
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_transferAtom,
				s->transferAtom);
	Ini_PutInt0 (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_transferOn,
				s->transferOn);
	Ini_PutDataArray (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_transferLevel,
					  s->transferLevel, N_SESSION_TRANSFER_LEVELS, VAL_INTEGER);
				
}

					  


void Ini_PutSession (IniText ini, t_session *s)
{
	int i;
	char tagName[40];

	Ini_PutDouble (ini, INI_SECTION_SESSIONINFO, 
			INI_TAG_SESSIONINFO_Version, ProgramVersion);

	Ini_PutAtomConfig (ini, s->atomConfig);         
	
	if (s->lastStarted >= 0) {
		Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_lastStarted,
				    s->lastStarted);
	}
	if (s->startNr >= 0) {
		Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_startNr,
				    s->startNr);
		Ini_PutString (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_date,
				       s->dateStr);
	}
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_updatePoints,
				s->updatePoints);
	
				
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nAtoms,
				ListNumItems (s->lAtoms));
	for (i = 0; i < ListNumItems (s->lAtoms); i++) 
		Ini_PutAtom (ini, s, i+1);

	Ini_PutDataArray (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_counterOn,
						s->counterOn, N_COUNTERS, VAL_INTEGER);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_repumperAlwaysOn,
				 s->repumperAlwaysOn);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_laser1AlwaysOn,
				 s->laser1AlwaysOn);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_laser2AlwaysOn,
				 s->laser2AlwaysOn);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_optPumpingAlwaysOn,
				 s->optPumpingAlwaysOn);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_repumperPower,
			    s->repumperPower);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_repumperFrequency,
			    s->repumperFrequency);
				 
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_mode,
				s->mode);
//	Ini_PutString (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_shortStr, 
//				s->shortStr);
				
	Ini_PutString (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_comments,
					s->comments);

	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nRuns, 
				s->nRuns);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nSweepPoints, 
				s->nSweepPoints);
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nCurves, 
				s->nCurves);

	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nFilters,
				ListNumItems(s->lFilters));
	for (i = 1; i <= ListNumItems(s->lFilters); i++) 
		Ini_PutFilter (ini, s, i);


	Ini_PutLevelInfo (ini, s);
	
	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nDetectionParameters,
				ListNumItems(s->lDetectionParameters));
	for (i = 1; i <= ListNumItems(s->lDetectionParameters); i++) 
		Ini_PutDetectionParameters (ini, s, i);

	Ini_PutInt (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_nPlotItems,
				ListNumItems(s->lPlotItems));
	for (i = 1; i <= ListNumItems(s->lPlotItems); i++) 
		Ini_PutPlotItem (ini, s, i);

	Ini_PutSession_RunParameters (ini, s);
	
	
	Ini_PutDataArray_Comp (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_digitalOutputs_preset,
					  s->digitalOutputs_preset, N_DIO_CHANNELS, VAL_INTEGER);
	Ini_PutDataArray_Comp (ini, INI_SECTION_SESSIONINFO, INI_TAG_SESSIONINFO_digitalOutputs_onOff,
					  s->digitalOutputs_onOff, N_DIO_CHANNELS, VAL_INTEGER);


}


/*******************************************************************************/
/*
/*    save session ("*.ses"-file)
/*
/******************************************************************************/

int SESSION_save (const char *filename, t_session *s)
{
    int err;
    IniText ini;
    
	ini = Ini_New (0);
	
	Ini_PutSession (ini, s);
//	Ini_PutSequenceGenerationParameters (ini, s);
	err = Ini_WriteToFile(ini, filename);
	s->readOnly = 0;
	
	Ini_Dispose (ini);
	if (err == 0) s->changes = 0;
	return displayIniFileError (filename, err);
}







void Ini_PutSmanagerConfig (IniText ini, t_smanagerConfig *c)
{
	char h[20];
	t_session *s;
	int i;

	Ini_PutString (ini, SCONF_GENERAL, SCONF_TAG_DEFAULT_PATH, 
		c->defaultPath);

	Ini_PutInt (ini, SCONF_GENERAL,  SCONF_TAG_DISPLAYED_SESSION_NO,
				c->activeSessionNr);

//=======================================================================
//    write names, repetitions, shortcuts of sequences
//=======================================================================
	Ini_PutInt (ini, SCONF_GENERAL, SCONF_TAG_NUMBER_OF_SESSIONS, 
		ListNumItems(c->listOfSessions));
	
    for (i = 1; i <= ListNumItems (c->listOfSessions); i++) {
    	s = SESSION_ptr(i);
		if (s != NULL) {
			if (strcmp (s->filename, SESSION_defaultFilename) != 0) {
				sprintf (h, SCONF_TAG_NAME_SESSION, i);
				Ini_PutString (ini, SCONF_GENERAL, h, s->filename);
			}
		}
	}
	
//	Ini_PutString (ini, SCONF_GENERAL, SCONF_TAG_MASTERSEQUENCE, c->masterSequenceFilename);
	Ini_PutString (ini, SCONF_GENERAL, SCONF_TAG_dataPath, c->dataPath);
	Ini_PutString (ini, SCONF_GENERAL, SCONF_TAG_dataPathToday, c->dataPathToday);
	
	Ini_PutString (ini, SCONF_GENERAL, SCONF_TAG_TCP_SERVER_NAME , c->TCPserverName);

	Ini_PutAtomConfig (ini, c->defaultAtomConfig);

}


int writeSessionManagerConfig (t_smanagerConfig *c)
{
	IniText ini;
	
	if ((ini = Ini_New (0)) == 0) return -1;
	Ini_PutSmanagerConfig (ini, c);

	Ini_WriteToRegistry_New (ini, ROOT_KEY, SCONF_REG_SUBKEY);
	Ini_Dispose (ini);
	
	return 0;
}





void Ini_GetSmanagerConfig (IniText ini, t_smanagerConfig *c)
{
	char *old;
	char h[20];
	t_session *new;
    int nSessions = 0;
	int i;
	char filename[MAX_PATHNAME_LEN];
	int err;

	Ini_GetStringIntoBuffer (ini, SCONF_GENERAL, SCONF_TAG_DEFAULT_PATH, 
							 c->defaultPath, MAX_PATHNAME_LEN);


	old = c->TCPserverName;
	Ini_GetStringCopy (ini, SCONF_GENERAL, SCONF_TAG_TCP_SERVER_NAME, 
		&c->TCPserverName);
	if (c->TCPserverName == NULL) c->TCPserverName = old;
	else free(old);

	
	Ini_GetInt (ini, SCONF_GENERAL, SCONF_TAG_NUMBER_OF_SESSIONS,     
		&nSessions);

	Ini_GetAtomConfig (ini, c->defaultAtomConfig);

    // load sessions
    for (i = 1; i <= nSessions; i++) {
		sprintf (h, SCONF_TAG_NAME_SESSION, i);
		if (Ini_GetStringIntoBuffer (ini, SCONF_GENERAL, h, filename, MAX_PATHNAME_LEN) > 0) {
	    	if (FileExists (filename, 0) && (!SESSION_filenameExists (filename))) {
		    	new = SESSION_new ();
			    if ((err = SESSION_load (filename, new)) == 0) {
	        		SESSION_appendToList (new);
	        		new->changes = 0;
			    }
			    else {  // error occured
			        free (new);
			    }
			}
		}
	}
	
	if (Ini_GetStringIntoBuffer (ini, SCONF_GENERAL, SCONF_TAG_dataPath, c->dataPath, MAX_PATHNAME_LEN) <= 0) {
		GetDir (c->dataPath);
	}	

	if (Ini_GetStringIntoBuffer (ini, SCONF_GENERAL, SCONF_TAG_dataPathToday, c->dataPathToday, MAX_PATHNAME_LEN) <= 0) {
		RUN_createTodaysDataPath (c);
	}	

	// get active session nummer 
	Ini_GetInt (ini, SCONF_GENERAL,  SCONF_TAG_DISPLAYED_SESSION_NO,     
				&c->activeSessionNr);
	if (c->activeSessionNr > ListNumItems (c->listOfSessions))
		c->activeSessionNr = ListNumItems (c->listOfSessions);

}


int readSessionManagerConfig (t_smanagerConfig *c)
{    

	IniText ini;

	if ((ini = Ini_New (0)) == 0) return -1;
	Ini_ReadFromRegistry (ini, ROOT_KEY, SCONF_REG_SUBKEY);
	Ini_GetSmanagerConfig (ini, c);
	
	writeSessionManagerConfig (c);
	
	Ini_Dispose (ini);
	return 0;
}







void Ini_PutRun_DataAcquisitionParams (IniText ini, t_run *r)
{
	int i;
	
//	Ini_PutInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_detector,
//				r->detector);
	
	Ini_PutInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nRuns,
				r->nRuns);
	Ini_PutInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nRepetitions,
				r->nRepetitionsPerRun);
	Ini_PutInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nCopies,
				r->nCopiesPerRepetition);
//	Ini_PutInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nSequenceDuplicates,
//				r->nSequenceDuplicates);
				

//	Ini_PutString (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_dataDirectory,
//				r->dataDirectory);

				

}



void Ini_PutRun (IniText ini, t_run *r)
{
	int c, i;
	int nDatasets;
	
	Ini_PutString (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_infoStr,
				r->infoStr);
	Ini_PutString (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_date,
				r->dateStr);
	Ini_PutString (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_time,
				r->timeStr);
	Ini_PutString (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_softwareVersion,
				r->softwareVersionStr);
	Ini_PutInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_startNr,
				r->startNr);
	Ini_PutString (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_sessionFilename,
				extractFilename (r->filenameSession));
	Ini_PutString (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_sequenceFilename,
				extractFilename (r->filenameSequence));
	
	Ini_PutRun_DataAcquisitionParams (ini, r);
	
	
	nDatasets = 0;
	for (c = 0; c < N_COUNTERS; c++) {
		for (i = 0; i < r->nData[c]; i++) {
			if (r->data[c][i] != NULL) {
				nDatasets++;
				Ini_PutCounterData (ini, r->data[c][i], nDatasets, 1);
				if (nDatasets % 500 == 0) RUN_SAVING_printf (".");   				
			}
		}
	}
	Ini_PutInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nDatasets,
				nDatasets);

}



void Ini_GetRun_DataAcquisitionParams (IniText ini, t_run *r)
{
}


void Ini_GetRun (IniText ini, t_run *r) 
{
	int i;

	t_counterData *data;
	int nDatasets = 0;
	char filename[MAX_PATHNAME_LEN];
	

	Ini_GetInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_startNr,
				&r->startNr);
	Ini_GetStringIntoBuffer (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_date,
				r->dateStr, MAX_DATESTR_LEN-1);
	Ini_GetStringIntoBuffer (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_time,
				r->timeStr, MAX_TIMESTR_LEN-1);
				
	Ini_GetStringIntoBuffer (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_infoStr,
							 r->infoStr, MAX_INFOSTR_LEN);
	Ini_GetStringIntoBuffer (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_softwareVersion,
				r->softwareVersionStr, MAX_DATESTR_LEN);
	Ini_GetStringIntoBuffer (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_sessionFilename,
				r->filenameSession, MAX_PATHNAME_LEN);
	Ini_GetStringIntoBuffer (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_sequenceFilename,
				r->filenameSequence, MAX_PATHNAME_LEN);
	Ini_GetInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nRuns,
				&r->nRuns);
	Ini_GetInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nRepetitions,
				&r->nRepetitionsPerRun);
	Ini_GetInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nCopies,
				&r->nCopiesPerRepetition);
//	Ini_GetInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nSequenceDuplicates,
//				&r->nSequenceDuplicates);

	// automatically create filename for session				
	strcpy (filename, extractDir (r->filenameRun));
	strcat (filename, extractFilename (r->filenameSession));
	if (FileExists (filename, 0)) {
		r->session = SESSION_new ();
		r->freeSession = 1;
		if (SESSION_load (filename, r->session) != 0) {
			SESSION_free (r->session);
			r->session = NULL;
		}
	}

	Ini_GetInt (ini, INI_SECTION_RUN_GENERAL, INI_TAG_RUN_nDatasets,
				&nDatasets);
	for (i = 1; i <= nDatasets; i++) {
		data = COUNTERDATA_new ();
		Ini_GetCounterData (ini, data, i);
		RUN_putCounterData (r, data);
	}
	
    if (r->session != NULL) {
		TIMEINTERVAL_calculateAll (r->session, 0,!TIMEINTERVAL_SPEEDMODE);
		for (i = 0; i < N_DETECTORS; i++) {
			TIMEINTERVAL_addIdStrings (r->session, i);
			TIMEINTERVAL_duplicateList (r->lTimeIntervals[i], r->session->lTimeIntervals[i], 1);
		}
	}
	
	RUN_addSweep (r);
	
}



/*******************************************************************************/
/*
/*    save results
/*
/******************************************************************************/


/******************************************************************************/
/*
/*    load RUN ("*.run"-file)
/*
/******************************************************************************/





t_run *RUN_load (const char *filename, int showProgress)
{
    IniText ini;
    int err;
    t_run *r = NULL;
    char sessionFilename[MAX_PATHNAME_LEN];
    int progressDialog = 0;
    
    
    if (showProgress) {
		progressDialog = CreateProgressDialog ("Loading Run data...",
											   extractFilename (filename),
											   1, VAL_NO_MARKERS, 0);
	}	
	ini = Ini_New (1);
	Ini_SetDuplicateChecking (ini, 0);

	err = Ini_ReadFromFileGen (ini, filename, "*.run");
	if (err != 0) goto ERROR;

	if (showProgress) UpdateProgressDialog (progressDialog, 20, 0);
	
	r = RUN_new ();	
    strcpy (r->filenameRun, filename);
	
    Ini_GetRun (ini, r);
	if (showProgress) UpdateProgressDialog (progressDialog, 70, 0);
	// free memory
	Ini_Dispose (ini);

	if (showProgress) DiscardProgressDialog (progressDialog);

	return r;

ERROR:
	// display error
	displayIniFileError (filename, err);
	// free memory
	RUN_free (r);
	Ini_Dispose (ini);
	if (showProgress) DiscardProgressDialog (progressDialog);
	return NULL;
}





int RUN_save (const char *filename, t_run *r, int zipFile)
{
	int err;
	IniText ini;
	char zipFilename[MAX_PATHNAME_LEN];
	char filenameTimes[MAX_PATHNAME_LEN];
	
	if (r == NULL) return 0;
	if (r->session == NULL) return 0;

	RUN_SAVING_printf  ("Run data '%s'...", extractFilename (filename));
	ini = Ini_New (0);
	Ini_SetDuplicateChecking (ini, 0);
	
	Ini_PutRun (ini, r);
	RUN_SAVING_printf ("....");

	if ((err = Ini_WriteToFile(ini, filename)) != 0) {
		displayIniFileError (filename, err);
	}
	RUN_SAVING_printf ("....");
	Ini_Dispose (ini);
	RUN_SAVING_printf (" Done.\n");
	
	if (zipFile) {
		changeSuffix (zipFilename, filename, "_run.zip");
		ZIPfile (filename, zipFilename, 1);
		
		strcpy (filenameTimes, r->dataDirectory);
		strcat (filenameTimes, "*.times");
		changeSuffix (zipFilename, filename, "_times.zip");
		ZIPfile (filenameTimes, zipFilename, 1);
	}		
	
	return err;
}




/******************************************************************************/
/*
/*    load and save CURVES ("*.curve"-file)
/*
/******************************************************************************/


void Ini_PutCurve (IniText ini, t_curve *c, t_graph *w, int nr)
{
	int i;
	
	char sectionName[30];
	char tagName[30];
	
	sprintf (sectionName, INI_SECTION_CURVE, nr);
	
	// ---------------------------------
	//    save info curve
	// ---------------------------------
	Ini_PutString (ini, sectionName, INI_TAG_CURVE_name, c->name);
//	Ini_PutString (ini, sectionName, INI_TAG_CURVE_session, sessionName);
	Ini_PutString (ini, sectionName, INI_TAG_CURVE_time, c->timeStr);
	Ini_PutString (ini, sectionName, INI_TAG_CURVE_date, c->dateStr);
	Ini_PutString (ini, sectionName, INI_TAG_CURVE_info, c->info);
	Ini_PutString (ini, sectionName, INI_TAG_CURVE_startNr, intToStr0 (N_STARTNR_DIGITS,c->startNr));
	// ---------------------------------
	//    save info plot window
	// ---------------------------------
	if ((c->title[0] == 0) && (w != NULL))  
		Ini_PutString (ini, sectionName, INI_TAG_CURVE_title, w->panelTitle);
	else 
		Ini_PutString (ini, sectionName, INI_TAG_CURVE_title, c->title);
		
	if ((c->xLabel[0] == 0) && (w != NULL)) 
		Ini_PutString (ini, sectionName, INI_TAG_CURVE_xLabel, w->xLabel);
	else 
		Ini_PutString (ini, sectionName, INI_TAG_CURVE_xLabel, c->xLabel);
	
	if ((c->yLabel[0] == 0) && (w != NULL)) 
		Ini_PutString (ini, sectionName, INI_TAG_CURVE_yLabel, w->yLabel);
	else 
		Ini_PutString (ini, sectionName, INI_TAG_CURVE_yLabel, c->yLabel);
	

	if ((c->plotType == -1) && (w != NULL)) 
		Ini_PutInt (ini, sectionName, INI_TAG_CURVE_plotType, w->plotType);
	else 
		Ini_PutInt (ini, sectionName, INI_TAG_CURVE_plotType, c->plotType);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_showCurrentCurve, c->showCurrentCurve);

	Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_xAsciiFileColumnLabel, c->xAsciiFileColumnLabel);
	Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_yAsciiFileColumnLabel, c->yAsciiFileColumnLabel);
	Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_xAsciiFileColumnLabel2, c->xAsciiFileColumnLabel2);
	Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_yAsciiFileColumnLabel2, c->yAsciiFileColumnLabel2);
		
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_xDigits, c->xDigits);		
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_yDigits, c->yDigits);
	Ini_PutInt0 (ini, sectionName, INI_TAG_CURVE_averagedOnTop, c->averagedOnTop);		
	

    // ---------------------------------
	//    save curve
	// ---------------------------------
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_nValues, c->nValues);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_nValuesVisibleAvg, c->nValuesVisibleAvg);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_divideAveraged, c->divideAveraged);		

	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_nAveraged, c->nAveraged);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_plotStyle, c->plotStyle);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_plotColor, c->plotColor);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_pointStyle, c->pointStyle);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_plotNumbers, c->plotNumbers);
	
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_lineStyle, c->lineStyle);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_visible2D, c->visible2D);
	
	if ((c->xUnits[0] == 0) && (w != NULL)) 
		Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_xUnits, w->xUnits);
	else 
		Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_xUnits, c->xUnits);
	

	if (c->xFrom == NO_VALUE) {
		Ini_PutDataArray (ini, sectionName, INI_TAG_CURVE_xValues, c->xValues, c->nValues, VAL_DOUBLE);
	}
	else {
		Ini_PutDouble (ini, sectionName, INI_TAG_CURVE_xFrom, c->xFrom);
		Ini_PutDouble (ini, sectionName, INI_TAG_CURVE_xTo, c->xTo);
	}
	
	if ((c->yUnits[0] == 0) && (w != NULL)) 
		Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_yUnits, w->yUnits);
	else 
		Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_yUnits, c->yUnits);
	

	if (w != NULL) {
		Ini_PutRect (ini, sectionName, INI_TAG_CURVE_panelPos, getPanelBounds (w->panelHandle));
	}
	else {
		Ini_PutRect (ini, sectionName, INI_TAG_CURVE_panelPos, c->panelPos);
	}

	// put averaged value	
	Ini_PutDataArray (ini, sectionName, INI_TAG_CURVE_yValuesAveraged, c->yValuesAveraged, c->nValuesVisibleAvg, VAL_DOUBLE);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_hasErrorBars, c->hasErrorBars);
	if (c->hasErrorBars) {
		Ini_PutDataArray (ini, sectionName, INI_TAG_CURVE_yErrPosAveraged, c->yErrPosAveraged, c->nValuesVisibleAvg, VAL_DOUBLE);
		if (c->yErrNegAveraged != NULL) 
			Ini_PutDataArray (ini, sectionName, INI_TAG_CURVE_yErrNegAveraged, c->yErrNegAveraged, c->nValuesVisibleAvg, VAL_DOUBLE);
	}
	
	// put values of all runs
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_nCurves, c->nCurves);
	Ini_PutInt (ini, sectionName, INI_TAG_CURVE_hasErrorBarsCurrent, c->hasErrorBarsCurrent);
	for (i = 0; i < c->nCurves; i++) {
		sprintf (tagName, INI_TAG_CURVE_yValues, i);
		Ini_PutDataArray (ini, sectionName, tagName, c->yValues[i], c->yValuesVisible[i], VAL_DOUBLE);
		if (c->hasErrorBarsCurrent) {
			sprintf (tagName, INI_TAG_CURVE_yErrPos, i);
			Ini_PutDataArray (ini, sectionName, tagName, c->yErrPos[i], c->yValuesVisible[i], VAL_DOUBLE);
			sprintf (tagName, INI_TAG_CURVE_yErrNeg, i);
			Ini_PutDataArray (ini, sectionName, tagName, c->yErrNeg[i], c->yValuesVisible[i], VAL_DOUBLE);
		}
	}

	if (c->yShowSecondAxis) {
		Ini_PutInt (ini, sectionName, INI_TAG_CURVE_yShowSecondAxis, c->yShowSecondAxis);
		Ini_PutDouble (ini, sectionName, INI_TAG_CURVE_yAxis2Multiply, c->yAxis2Multiply);
		if ((c->yLabel2[0] == 0) && (w != NULL)) 
			Ini_PutString (ini, sectionName, INI_TAG_CURVE_yLabel2, w->yLabel2);
		else 
			Ini_PutString (ini, sectionName, INI_TAG_CURVE_yLabel2, c->yLabel2);
		if ((c->yUnits2[0] == 0) && (w != NULL)) 
			Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_yUnits2, w->yUnits2);
		else 
			Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_yUnits2, c->yUnits2);
		Ini_PutInt (ini, sectionName, INI_TAG_CURVE_yDigits, c->yDigits2);
			
		
	}


	
	if (c->xShowSecondAxis) {
		Ini_PutInt (ini, sectionName, INI_TAG_CURVE_xShowSecondAxis, c->xShowSecondAxis);
		Ini_PutDouble (ini, sectionName, INI_TAG_CURVE_xAxis2Multiply, c->xAxis2Multiply);
		if ((c->xLabel2[0] == 0) && (w != NULL)) 
			Ini_PutString (ini, sectionName, INI_TAG_CURVE_xLabel2, w->xLabel2);
		else 
			Ini_PutString (ini, sectionName, INI_TAG_CURVE_xLabel2, c->xLabel2);
	
		if ((c->xUnits2[0] == 0) && (w != NULL)) 
			Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_xUnits2, w->xUnits2);
		else 
			Ini_PutString0 (ini, sectionName, INI_TAG_CURVE_xUnits2, c->xUnits2);

		
	}
	
	if (c->n2Dcurves != 0) {
		Ini_PutRect (ini, sectionName, INI_TAG_CURVE_panelPos2D, c->panelPos2D);
		Ini_PutDataArray (ini, sectionName, INI_TAG_CURVE_values2D, 
						  c->values2D, c->nValues2D, VAL_DOUBLE);
		Ini_PutString (ini, sectionName, INI_TAG_CURVE_xLabel2D, c->xLabel2D);
//		Ini_PutString (ini, sectionName, INI_TAG_CURVE_yLabel2D, c->yLabel2D);
		Ini_PutString (ini, sectionName, INI_TAG_CURVE_xUnits2D, c->xUnits2D);
		Ini_PutDataArray (ini, sectionName, INI_TAG_CURVE_xValues2D, 
						  c->xValues2D, c->n2Dcurves, VAL_DOUBLE);
		Ini_PutInt (ini, sectionName, INI_TAG_CURVE_interpolate2D, c->interpolate2D);
	}
	
	if (c->nComponentsPositions > 0) {
		Ini_PutInt (ini, sectionName, INI_TAG_CURVE_componentsVisible, c->componentsVisible);
		Ini_PutInt (ini, sectionName, INI_TAG_CURVE_nComponentsPositions, c->nComponentsPositions);
		Ini_PutDataArray (ini, sectionName, INI_TAG_CURVE_componentsPositions, c->componentsPositions,
						  c->nComponentsPositions, VAL_DOUBLE);
		Ini_PutDataArray (ini, sectionName, INI_TAG_CURVE_componentsColors, c->componentsColors,
						  c->nComponentsPositions, VAL_INTEGER);
		for (i = 0; i < c->nComponentsPositions; i++) {
			if (c->componentsNames[i][0] != 0) {
				sprintf (tagName, INI_TAG_CURVE_componentsNames, i);
				Ini_PutString (ini, sectionName, tagName, c->componentsNames[i]);
			}
		}
		
		
	}
}
	
		
void Ini_GetCurve (IniText ini, t_curve *c, int nr)
{
	char sectionName[30];
	char tagName[30];
	int i;
	unsigned nValues = 100;
	int nCurves = 0;
	unsigned dummy;
	
	sprintf (sectionName, INI_SECTION_CURVE, nr);
	
	// ---------------------------------
	//    save info curve
	// ---------------------------------
	CURVE_init (c);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_name, c->name, MAX_CURVENAME_LEN);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_info, c->info, MAX_CURVEINFO_LEN);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_startNr, &c->startNr);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_time, c->timeStr, MAX_TIMESTR_LEN);
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_date, c->dateStr, MAX_DATESTR_LEN);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_plotType, &c->plotType);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_showCurrentCurve, &c->showCurrentCurve);
	
	Ini_GetUInt (ini, sectionName, INI_TAG_CURVE_nValues, &nValues);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_nValuesVisibleAvg, &c->nValuesVisibleAvg);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_visible2D, &c->visible2D);

	
	Ini_GetDouble (ini, sectionName, INI_TAG_CURVE_xFrom, &c->xFrom);
	Ini_GetDouble (ini, sectionName, INI_TAG_CURVE_xTo, &c->xTo);
	CURVE_allocateMemory (c, nValues);	
	if (c->xFrom == NO_VALUE) {
		c->xValues = Ini_GetDataArray (ini, sectionName, INI_TAG_CURVE_xValues, &dummy, VAL_DOUBLE);
	}
	
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_hasErrorBars, &c->hasErrorBars);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_hasErrorBarsCurrent, &c->hasErrorBarsCurrent);

	if (Ini_GetDataArrayEx (ini, sectionName, INI_TAG_CURVE_yValues_OLD, 
				            c->yValuesAveraged, c->nValues, VAL_DOUBLE) == 0) {
		// old format (prior to 06/05/05) 
		if (c->hasErrorBars) {
			Ini_GetDataArrayEx (ini, sectionName, INI_TAG_CURVE_yErrPos_OLD, c->yErrPosAveraged, c->nValues, VAL_DOUBLE);
			c->yErrNegAveraged = (double *) Ini_GetDataArray (ini, sectionName, INI_TAG_CURVE_yErrNeg_OLD, &nValues, VAL_DOUBLE);
		}
	}
	else {
		// new format
		Ini_GetDataArrayEx (ini, sectionName, INI_TAG_CURVE_yValuesAveraged, c->yValuesAveraged , c->nValues, VAL_DOUBLE);
		if (c->hasErrorBars) {
			Ini_GetDataArrayEx (ini, sectionName, INI_TAG_CURVE_yErrPosAveraged, c->yErrPosAveraged , c->nValues, VAL_DOUBLE);
			c->yErrNegAveraged = (double *) Ini_GetDataArray (ini, sectionName, INI_TAG_CURVE_yErrNegAveraged, &nValues, VAL_DOUBLE);
		}
		Ini_GetInt (ini, sectionName, INI_TAG_CURVE_nCurves, &nCurves);
		CURVE_allocateMemoryRun (c, nCurves); 
		for (i = 0; i < c->nCurves; i++) {
			sprintf (tagName, INI_TAG_CURVE_yValues, i);
			c->yValues[i] = (double *) Ini_GetDataArray (ini, sectionName, tagName, &c->yValuesArrSize[i], VAL_DOUBLE);
//			sprintf (tagName, INI_TAG_CURVE_yValuesVisible, i);
//			c->yValuesVisible[i] = (double *) Ini_GetDataArray (ini, sectionName, tagName, &c->yValuesArrSize[i], VAL_DOUBLE);
			if (c->hasErrorBarsCurrent) {
				sprintf (tagName, INI_TAG_CURVE_yErrPos, i);
				c->yErrPos[i] = (double *) Ini_GetDataArray (ini, sectionName, tagName, &c->yValuesArrSize[i], VAL_DOUBLE);
				sprintf (tagName, INI_TAG_CURVE_yErrNeg, i);
				c->yErrNeg[i] = (double *) Ini_GetDataArray (ini, sectionName, tagName, &c->yValuesArrSize[i], VAL_DOUBLE);
			}
			c->yValuesVisible[i] = c->yValuesArrSize[i];
		}
	}
	
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_nAveraged, &c->nAveraged);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_plotStyle, &c->plotStyle);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_plotColor, &c->plotColor);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_pointStyle, &c->pointStyle);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_lineStyle, &c->lineStyle);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_plotNumbers, &c->plotNumbers);
	
	// ---------------------------------
	//      get axis names etc
	// ---------------------------------
	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_title, c->title, MAX_TITLE_LEN);
	Ini_GetStringIntoBuffer  (ini, sectionName, INI_TAG_CURVE_xLabel, c->xLabel, MAX_AXISNAME_LEN);
	Ini_GetStringIntoBuffer  (ini, sectionName, INI_TAG_CURVE_yLabel, c->yLabel, MAX_AXISNAME_LEN);
	Ini_GetStringIntoBuffer  (ini, sectionName, INI_TAG_CURVE_xUnits, c->xUnits, MAX_UNIT_LEN);
	Ini_GetStringIntoBuffer  (ini, sectionName, INI_TAG_CURVE_yUnits, c->yUnits, MAX_UNIT_LEN);
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_xDigits, &c->xDigits);		
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_yDigits, &c->yDigits);		
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_divideAveraged, &c->divideAveraged);		
	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_averagedOnTop, &c->averagedOnTop);		
	
	
	Ini_GetStringIntoBuffer  (ini, sectionName, INI_TAG_CURVE_xAsciiFileColumnLabel, c->xAsciiFileColumnLabel, MAX_AXISNAME_LEN);
	Ini_GetStringIntoBuffer  (ini, sectionName, INI_TAG_CURVE_yAsciiFileColumnLabel, c->yAsciiFileColumnLabel, MAX_AXISNAME_LEN);
	Ini_GetStringIntoBuffer  (ini, sectionName, INI_TAG_CURVE_xAsciiFileColumnLabel2, c->xAsciiFileColumnLabel2, MAX_AXISNAME_LEN);

	// ---------------------------------
	//      get 2D curve
	// ---------------------------------
	Ini_GetRect (ini, sectionName, INI_TAG_CURVE_panelPos2D, &c->panelPos2D);
	Ini_GetRect (ini, sectionName, INI_TAG_CURVE_panelPos, &c->panelPos);
	
	c->n2Dcurves = 0;
	c->xValues2D = (double *) Ini_GetDataArray (ini, sectionName, INI_TAG_CURVE_xValues2D, 
					  					        &c->n2Dcurves, VAL_DOUBLE);
	if (c->n2Dcurves != 0) {
		c->values2D = (double *)Ini_GetDataArray (ini, sectionName, INI_TAG_CURVE_values2D, 
						  						  &c->nValues2D, VAL_DOUBLE);
/*		Ini_GetDouble (ini, sectionName, INI_TAG_CURVE_xFrom2D, &c->xFrom2D);
		Ini_GetDouble (ini, sectionName, INI_TAG_CURVE_yFrom2D, &c->yFrom2D);
		Ini_GetDouble (ini, sectionName, INI_TAG_CURVE_xTo2D, &c->xTo2D);
		Ini_GetDouble (ini, sectionName, INI_TAG_CURVE_yTo2D, &c->yTo2D);
*/		Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_xLabel2D, c->xLabel2D, MAX_AXISNAME_LEN);
//		Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_yLabel2D, c->yLabel2D, MAX_AXISNAME_LEN);
		Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_xUnits2D, c->xUnits2D, MAX_UNIT_LEN);
		Ini_GetInt (ini, sectionName, INI_TAG_CURVE_interpolate2D, &c->interpolate2D);

		Ini_GetInt (ini, sectionName, INI_TAG_CURVE_xShowSecondAxis, &c->xShowSecondAxis);
		if (c->xShowSecondAxis) {
			Ini_GetDouble (ini, sectionName, INI_TAG_CURVE_xAxis2Multiply, &c->xAxis2Multiply);
			Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_xLabel2, c->xLabel2, MAX_AXISNAME_LEN);
			Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_CURVE_xUnits2, c->xUnits2, MAX_UNIT_LEN);
		}

	}


	Ini_GetInt (ini, sectionName, INI_TAG_CURVE_nComponentsPositions, &c->nComponentsPositions);
	if (c->nComponentsPositions > CURVES_MAX_POSITIONS) c->nComponentsPositions = CURVES_MAX_POSITIONS;
	if (c->nComponentsPositions > 0) {
		Ini_GetInt (ini, sectionName, INI_TAG_CURVE_componentsVisible, &c->componentsVisible);
		Ini_GetDataArrayEx (ini, sectionName, INI_TAG_CURVE_componentsPositions, c->componentsPositions,
						  CURVES_MAX_POSITIONS, VAL_DOUBLE);
		Ini_GetDataArrayEx (ini, sectionName, INI_TAG_CURVE_componentsColors, c->componentsColors,
						  CURVES_MAX_POSITIONS, VAL_INTEGER);
						  
		for (i = 0; i < c->nComponentsPositions; i++) {
			sprintf (tagName, INI_TAG_CURVE_componentsNames, i);
			Ini_GetStringIntoBuffer (ini, sectionName, tagName, c->componentsNames[i], MAX_COMPONENT_NAME);
		}
	}

	
	CURVE_getMinMax (c);
	
}
	
		


t_curve *CURVE_load (const char *filename)
{
    IniText ini;
    int err;
    t_curve *c = NULL;
    
	SetWaitCursor (1);
	ini = Ini_New (1);
//	Ini_SetDuplicateChecking (ini, 0);
	if ((err = Ini_ReadFromFile (ini, filename)) != 0) goto ERROR;
	
	c = CURVE_new ();	
    Ini_GetCurve (ini, c, 0);
	
	// free memory
	SetWaitCursor (0);
	Ini_Dispose (ini);
	return c;

ERROR:
	// display error
	SetWaitCursor (0);
	displayIniFileError (filename, err);
	// free memory
	Ini_Dispose (ini);
	return NULL;
}
		



int CURVE_save (const char *filename, t_curve *c, t_graph *g)
{
    int err;
    IniText ini;
    
	if (c == NULL) return 0;
	ini = Ini_New (0);
	Ini_DisableInternalSorting (ini);
	
	SetWaitCursor (1);
	Ini_PutCurve (ini, c, g, 0);
//	Ini_PutSequenceGenerationParameters (ini, s);
	err = Ini_WriteToFile(ini, filename);
	
	SetWaitCursor (0);
	Ini_Dispose (ini);
	return displayIniFileError (filename, err);
}




t_counterData *COUNTERDATA_loadFilter (const char *filename)
{
    t_counterData *data = NULL;

	data = COUNTERDATA_load (filename);
	return data;
}




/******************************************************************************/
/*
/*   FUNCTIONS: Ini_GetFilter (...)
/*			    Ini_PutFilter (...)
/*
/*    Reads/writes data for a "data filter" in 
/*    in Section "[Filter...]" from/to "ini-style"-file
/*    --  called by function "loadSequence(...), "saveSequence(...)", 
/*
/******************************************************************************/

void Ini_GetFilterCriterion (IniText ini, const char *sectionName, 
						     t_filterCriterion *fc, int nr)
{
	char tagName[50];
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_active, nr);
	Ini_GetInt (ini, sectionName, tagName, &fc->active);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_logic, nr);
	Ini_GetInt (ini, sectionName, tagName, &fc->logic);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_detector, nr);
	Ini_GetInt (ini, sectionName, tagName, &fc->detector);

	sprintf (tagName, INI_TAG_FILTERCRITERION_timeIntervalFrom1, nr);
	Ini_GetInt (ini, sectionName, tagName, &fc->timeIntervalFrom[0]);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_timeIntervalFrom2, nr);
	Ini_GetInt (ini, sectionName, tagName, &fc->timeIntervalFrom[1]);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_hasTimeIntervalTo, nr);
	Ini_GetInt (ini, sectionName, tagName, &fc->hasTimeIntervalTo);
	if (fc->hasTimeIntervalTo) {
		sprintf (tagName, INI_TAG_FILTERCRITERION_timeIntervalTo1, nr);
		Ini_GetInt (ini, sectionName, tagName, &fc->timeIntervalTo[0]);
		sprintf (tagName, INI_TAG_FILTERCRITERION_timeIntervalTo2, nr);
		Ini_GetInt (ini, sectionName, tagName, &fc->timeIntervalTo[1]);
	}
	else {
	    fc->timeIntervalTo[0] = fc->timeIntervalFrom[0];
	    fc->timeIntervalTo[1] = fc->timeIntervalFrom[1];
	}
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_minCounts, nr);
	Ini_GetUInt (ini, sectionName, tagName, &fc->minCounts);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_maxCounts, nr);
	Ini_GetUInt (ini, sectionName, tagName, &fc->maxCounts);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_hasAdditionalTimeIntervals, nr);
	Ini_GetInt (ini, sectionName, tagName, &fc->hasAdditionalTimeIntervals);
	
	fc->nAdditionalTimeIntervals = 0;
	if (fc->hasAdditionalTimeIntervals) {
		sprintf (tagName, INI_TAG_FILTERCRITERION_nAdditionalTimeIntervals, nr);
		Ini_GetInt (ini, sectionName, tagName, &fc->nAdditionalTimeIntervals);
		if (fc->nAdditionalTimeIntervals > MAX_ADDITIONAL_TIMEINTERVALS)
			fc->nAdditionalTimeIntervals = MAX_ADDITIONAL_TIMEINTERVALS;
		sprintf (tagName, INI_TAG_FILTERCRITERION_additionalTimeIntervals, nr);
		Ini_GetDataArrayEx (ini, sectionName, tagName, fc->additionalTimeIntervals,
						  	MAX_ADDITIONAL_TIMEINTERVALS, VAL_INTEGER);
	}						  
	else fc->nAdditionalTimeIntervals = 0;
	
	
}


void Ini_GetFilter (IniText ini, t_session *s, int nr)
{
  
    char sectionName[30];
    t_filter *f;
    int i;
    
	f = FILTER_new (s);

	sprintf (sectionName, INI_SECTION_FILTER, nr);

	Ini_GetStringIntoBuffer (ini, sectionName, INI_TAG_FILTER_name, f->name, MAX_FILTERNAME_LEN);
	Ini_GetInt (ini, sectionName, INI_TAG_FILTER_nCriteria, &f->nFilterCriteria);
	Ini_GetInt (ini, sectionName, INI_TAG_FILTER_otherFilter, &f->otherFilterID);
	
	for (i = 0; i < f->nFilterCriteria; i++) {
		Ini_GetFilterCriterion (ini, sectionName, &f->criterion[i], i);
	}
	
	
}

/******************************************************************************/

void Ini_PutFilterCriterion (IniText ini, const char *sectionName, 
						     t_filterCriterion *fc, int nr)
{
	char tagName[50];
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_active, nr);
	Ini_PutInt (ini, sectionName, tagName, fc->active);

	sprintf (tagName, INI_TAG_FILTERCRITERION_logic, nr);
	Ini_PutInt (ini, sectionName, tagName, fc->logic);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_detector, nr);
	Ini_PutInt (ini, sectionName, tagName, fc->detector);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_timeIntervalFrom1, nr);
	Ini_PutInt (ini, sectionName, tagName, fc->timeIntervalFrom[0]);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_timeIntervalFrom2, nr);
	Ini_PutInt (ini, sectionName, tagName, fc->timeIntervalFrom[1]);
	
	if (fc->hasTimeIntervalTo) {
		sprintf (tagName, INI_TAG_FILTERCRITERION_hasTimeIntervalTo, nr);
		Ini_PutInt (ini, sectionName, tagName, fc->hasTimeIntervalTo);
	
		sprintf (tagName, INI_TAG_FILTERCRITERION_timeIntervalTo1, nr);
		Ini_PutInt (ini, sectionName, tagName, fc->timeIntervalTo[0]);
	
		sprintf (tagName, INI_TAG_FILTERCRITERION_timeIntervalTo2, nr);
		Ini_PutInt (ini, sectionName, tagName, fc->timeIntervalTo[1]);
	}
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_minCounts, nr);
	Ini_PutInt (ini, sectionName, tagName, fc->minCounts);
	
	sprintf (tagName, INI_TAG_FILTERCRITERION_maxCounts, nr);
	Ini_PutInt (ini, sectionName, tagName, fc->maxCounts);
	
	if (fc->hasAdditionalTimeIntervals) {
		sprintf (tagName, INI_TAG_FILTERCRITERION_hasAdditionalTimeIntervals, nr);
		Ini_PutInt (ini, sectionName, tagName, fc->hasAdditionalTimeIntervals);
		sprintf (tagName, INI_TAG_FILTERCRITERION_nAdditionalTimeIntervals, nr);
		Ini_PutInt (ini, sectionName, tagName, fc->nAdditionalTimeIntervals);
		
		sprintf (tagName, INI_TAG_FILTERCRITERION_additionalTimeIntervals, nr);
		Ini_PutDataArray (ini, sectionName, tagName, fc->additionalTimeIntervals,
						  fc->nAdditionalTimeIntervals, VAL_INTEGER);
	}						  
	
}


void Ini_PutFilter (IniText ini, t_session *s, int nr)
{
    char sectionName[30];
    t_filter *f;
    int i;
	
	f = FILTER_ptr (s, nr);
	sprintf (sectionName, INI_SECTION_FILTER, nr);
  
	Ini_PutString (ini, sectionName, INI_TAG_FILTER_name, f->name);
	Ini_PutInt0 (ini, sectionName, INI_TAG_FILTER_otherFilter, f->otherFilterID);
	Ini_PutInt (ini, sectionName, INI_TAG_FILTER_nCriteria, f->nFilterCriteria);
	for (i = 0; i < f->nFilterCriteria; i++) {
		Ini_PutFilterCriterion (ini, sectionName, &f->criterion[i], i);
	}
}



