#include <userint.h>
#include "UIR_SessionManager.h"

#include "INCLUDES_SESSIONMANAGER.h"

#include "SESSIONMANAGER_CreateSequence.h"



int panelRun;

int subPanelSaveData    = -1;
//int subPanelAcquisition = -1;
int subPanelDig = -1;
int subPanelStd = -1;
int subPanelResume = -1;


int panelTimeIntervals = -1;
int ctrlTimeIntervals  = -1;

static int startNrRUN = -1;

extern t_run* activeRun;
extern int panelSMain;
extern int panelPlotItems;
int panelSaving = 0;

int RUN_subPanelResume (void)
{
	return subPanelResume;
}

int RUN_subPanelStd (void)
{
	return subPanelStd;
}

int panelDig(void) 
{
	return subPanelDig;
}

void RUN_protocolCls (void)
{
	cls (panelRun, RUN_TEXTBOX_protocol);
}


void RUN_printf (char* format, ... )
{
	va_list arg;

	va_start( arg, format );
    vpprintf(panelRun, RUN_TEXTBOX_protocol, format, arg  );
    va_end( arg );
}




int RUN_initPanel (void)
{
	Rect bounds;
	
	EasyTab_ConvertFromCanvas (panelRun,
							   RUN_CANVAS);
	if (EasyTab_LoadPanels (panelRun, RUN_CANVAS, 1, SESSIONMANAGER_uirFile,
						__CVIUserHInst,
						RUN_STD, &subPanelStd, 						
						RUN_DIG, &subPanelDig, 
						RUN_SAVE,  &subPanelSaveData, 
						RUN_RESUME, &subPanelResume,
						0) < 0) return -1;

	ChainCtrlCallback (subPanelStd, RUN_STD_LISTBOX_sweeps, listboxCheckOnlyOneItem_callback,
			           NULL, "listboxCheckOnlyOneItem");

	RUN_SAVE_initPanel();
	
	TIMEINTERVAL_initTree (panelRun, RUN_TREE_timeIntervals);
	EasyTab_GetBounds (panelRun, RUN_CANVAS , VAL_EASY_TAB_INTERIOR_BOUNDS, &bounds);
	SetPanelAttribute (subPanelStd, ATTR_WIDTH, bounds.width);
//	SetCtrlAttribute (subPanelStd, RUN_STD_TREE_plotItems, ATTR_WIDTH,
//					  bounds.width);
	SetCtrlAttribute (subPanelStd, RUN_STD_LISTBOX_sweeps, ATTR_WIDTH, 
					  bounds.width);

//	PLOTITEM_initTree (subPanelStd, RUN_STD_TREE_plotItems);    
	SetCtrlAttribute (panelRun, RUN_TEXTBOX_protocol, ATTR_HEIGHT,
					  panelHeight(panelRun) 
					  - ctrlTop (panelRun, RUN_TEXTBOX_protocol));

	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_currentRun,
					  ATTR_PADDING, N_STARTNR_DIGITS);
	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_nextRun,
					  ATTR_PADDING, N_STARTNR_DIGITS);
 	SWEEP_fillAnalogChannelNamesToRing (subPanelDig, RUN_DIG_RING_channel);
					  
	
	return 0;
}




void RUN_setParameters (t_session *s, int updateRunNr)
{
	int panel;
	t_run *r;
	
	panel = panelRun;
	TIMEINTERVAL_calculateAll (s, 1,TIMEINTERVAL_SPEEDMODE);
	r = activeRun;
	
//	SetCtrlVal (panel , RUN_RADIOBUTTON_auto,     
//				s->counterAuto);
	SetCtrlVal (panel , RUN_RADIOBUTTON_CTR0,     
				s->counterOn[0]);
	SetCtrlVal (panel, RUN_RADIOBUTTON_CTR1,       
				s->counterOn[1]);
	SetCtrlVal (panel, RUN_RADIOBUTTON_CTR6,     
				s->counterOn[6]);
	SetCtrlVal (panel, RUN_RADIOBUTTON_CTR7,     
				s->counterOn[7]);
//	CallCtrlCallback (panel, RUN_LISTBOX_sweeps, EVENT_COMMIT, 
//					  0, 0, NULL);

	SetCtrlVal (panel, RUN_RINGSLIDE_acqMode, s->mode);
	EasyTab_SetTabAttribute (panel, RUN_CANVAS,
							 subPanelStd, ATTR_EASY_TAB_DIMMED,
							 s->mode != SESSIONMODE_STANDARD);
	EasyTab_SetTabAttribute (panel, RUN_CANVAS,
							 subPanelDig, ATTR_EASY_TAB_DIMMED,
							 s->mode != SESSIONMODE_DIG);
	// --------------------------------
	//    transfer
	// --------------------------------
	SetCtrlAttribute (panel, RUN_RADIOBUTTON_transfer, ATTR_DIMMED,
					  s->mode == SESSIONMODE_DIG);
	SetCtrlAttribute (panel, RUN_TEXTMSG_transfDet2, ATTR_DIMMED,
					  s->mode == SESSIONMODE_DIG);
	EasyTab_SetTabAttribute (panelSMain, SMAN_CANVAS_tabCtrl, panelPlotItems,
							 ATTR_EASY_TAB_DIMMED, s->mode == SESSIONMODE_DIG);
	
	
	SetCtrlAttribute (panel, RUN_RING_transferAtom, ATTR_DIMMED, 
						      (s->mode == SESSIONMODE_DIG) || !s->transferOn);
	SetAttributeForCtrls (panel, ATTR_DIMMED,
	    				  (s->mode == SESSIONMODE_DIG) || !s->transferOn || (s->transferAtom < 1), 0,				   
						  RUN_RING_transferLevel1,
						  RUN_RING_transferLevel2, 0);
/*//	SetAttributeForCtrls (panel, ATTR_VISIBLE, 
						  (s->mode != SESSIONMODE_DIG) && s->transferOn 
						   && s->counterOn[COUNTER_NCOUNTS_DET2] && (s->transferAtom >= 1), 0,
						  RUN_TEXTMSG_note2,
						  RUN_TEXTMSG_note3, 0);	  */
	SetCtrlVal (panel, RUN_RADIOBUTTON_transfer, s->transferOn);
	SetCtrlVal (panel, RUN_RING_transferAtom, s->transferAtom);
	SetCtrlVal (panel, RUN_RING_transferLevel1, s->transferLevel[0]);
	SetCtrlVal (panel, RUN_RING_transferLevel2, s->transferLevel[1]);
	switch (s->mode) {
		case SESSIONMODE_DIG:
			EasyTab_SetAttribute (panelRun, RUN_CANVAS,
								  ATTR_EASY_TAB_ACTIVE_PANEL, subPanelDig);
			break;
		case SESSIONMODE_STANDARD:
			EasyTab_SetAttribute (panelRun, RUN_CANVAS,
								  ATTR_EASY_TAB_ACTIVE_PANEL, subPanelStd);
			break;
		
	}
/*
	SetAttributeForCtrls (subPanelAcquisition, ATTR_DIMMED,
						  s->mode != SESSIONMODE_DIG, 0, 
						  RUN_ACQ_TEXTMSG_totalSweepDur,
						  RUN_ACQ_NUMERIC_sweepDuration,
						  -1);
*/


	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_currentRun, ATTR_DIMMED, r == NULL);
	SetCtrlAttribute (panelSMain, SMAN_NUMERIC_nextRun, ATTR_DIMMED, RUN_getState() != RUN_STATE_INACTIVE);
	SetCtrlAttribute (panelSMain, SMAN_BUTTON_saveLast, ATTR_DIMMED, r == NULL);
	SetCtrlAttribute (panelSMain, SMAN_BUTTON_deleteLast, ATTR_DIMMED, (r == NULL) || (!r->dataSaved));


//	SetCtrlAttribute (panelRun, RUN_NUMERIC_sweepDuration, 
//					  ATTR_MAX_VALUE, KILLER_MAX_DURATION_us);
	SetCtrlVal (panelRun, RUN_NUMERIC_curveStart, s->curveStart_us);
	SetCtrlVal (panelRun, RUN_NUMERIC_curveEnd, s->curveEnd_us);
	SetCtrlVal (panelRun, RUN_RADIOBUTTON_saveTimes, s->saveArrivalTimes);
	SetCtrlVal (panelRun, RUN_RADIOBUTTON_testData, s->generateRandomCounterData);
	 
	SetCtrlVal (panelSMain, SMAN_BTN_saveRunData, s->saveRunData);
	SetCtrlAttribute (panelRun, RUN_RADIOBUTTON_saveTimes, ATTR_DIMMED, s->mode == SESSIONMODE_DIG);
	SetCtrlAttribute (panelRun, RUN_RADIOBUTTON_saveTimes, ATTR_DIMMED, !s->saveRunData);
	
	SetCtrlAttribute (panelRun, RUN_TEXTMSG_times, ATTR_DIMMED, !s->saveRunData);
    if (r != NULL) {
		SetCtrlVal (panelSMain, SMAN_NUMERIC_currentRun, r->startNr);
		startNrRUN =  r->startNr;
		if (r->dataSaved) startNrRUN++;
	}
	else {
		if (updateRunNr) startNrRUN = RUN_getCurrentStartNumber (NULL); 
		if (startNrRUN == -1) startNrRUN = RUN_getCurrentStartNumber (NULL); 
//		else SetCtrlVal (panelRun, RUN_NUMERIC_nextRun, startNrRUN);
	}
	SetCtrlVal (panelSMain, SMAN_NUMERIC_nextRun, startNrRUN);
	SetCtrlVal (panelRun, RUN_RINGSLIDE_killerCh, s->transmitKillerCurves);

	RUN_STD_setParameters (s);
	RUN_DIG_setParameters (s);
	RUN_SAVE_setParameters (s);  

}





void RUN_getParameters (t_session *s)
{
	int panel;
	
	panel = panelRun;
	GetCtrlVal (panel, RUN_RADIOBUTTON_CTR0,     
				&s->counterOn[0]);
	GetCtrlVal (panel, RUN_RADIOBUTTON_CTR1,     
				&s->counterOn[1]);
	GetCtrlVal (panel, RUN_RADIOBUTTON_CTR6,     
				&s->counterOn[6]);
	GetCtrlVal (panel, RUN_RADIOBUTTON_CTR7,     
				&s->counterOn[7]);
	GetCtrlVal (panel, RUN_RADIOBUTTON_transfer, &s->transferOn);
	GetCtrlVal (panel, RUN_RING_transferAtom, &s->transferAtom);
	GetCtrlVal (panel, RUN_RING_transferLevel1, &s->transferLevel[0]);
	GetCtrlVal (panel, RUN_RING_transferLevel2, &s->transferLevel[1]);
	
	GetCtrlVal (panel, RUN_RINGSLIDE_acqMode, &s->mode);
	GetCtrlVal (panel, RUN_NUMERIC_curveStart, &s->curveStart_us);
	s->curveStart_us = roundTimeAnalogBoard (s->curveStart_us);
	
	GetCtrlVal (panel, RUN_NUMERIC_curveEnd, &s->curveEnd_us);
	s->curveEnd_us = roundTimeAnalogBoard (s->curveEnd_us);

	GetCtrlVal (panelSMain, SMAN_BTN_saveRunData, &s->saveRunData);
	GetCtrlVal (panel, RUN_RADIOBUTTON_saveTimes, &s->saveArrivalTimes);
	GetCtrlVal (panel, RUN_RADIOBUTTON_testData, &s->generateRandomCounterData);
	
	
	GetCtrlVal (panel, RUN_RINGSLIDE_killerCh, &s->transmitKillerCurves);
	
	RUN_STD_getParameters (s);
	RUN_DIG_getParameters (s);
}

void RUN_calculateIntervalsTransfer (t_session *s)
{
	
}





int CVICALLBACK RUN_parametersEdited (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			RUN_getParameters (s);
/*			if (panel == subPanelStd) {
				switch (control) {
					case RUN_STD_BTN_getTransfer:
					case RUN_STD_RING_transfer_atom:
					case RUN_STD_RING_level1:
					case RUN_STD_RING_level2:
						RUN_calculateIntervalsTransfer (s);
						break;
				}
			}
*/
			if ((panel == subPanelStd) && (control == RUN_STD_NUMERIC_nSweepPoints))
				SWEEP_displayListOfSweeps (s, subPanelStd, RUN_STD_LISTBOX_sweeps);
			
			RUN_setParameters (s, 0);
//			RUN_parametersError (s);
			TIMEINTERVAL_calculateAll (s, 1,TIMEINTERVAL_SPEEDMODE);				
			SESSION_setChanges (s, 1);
			PLOTITEM_checkAllForError (s,0);
//			PLOTITEM_displayTree (RUN_subPanelStd(), RUN_STD_TREE_plotItems, s);

			break;
	}
	return 0;
}


int CVICALLBACK SESSIONMANAGER_resumeRun (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_run *r;
	
	switch (event) {
		case EVENT_COMMIT:
			switch (RUN_getState()) {
				case RUN_STATE_ACTIVE:
					r = activeRun;
					if (r->lastData != NULL) {
						SetCtrlVal (subPanelResume, RUN_RESUME_NUMERIC_nRun_R, r->lastData->run+1);
						SetCtrlVal (subPanelResume, RUN_RESUME_NUMERIC_nRepetition_R, r->lastData->repetition+1);
					}
					RUN_setState (RUN_STATE_PAUSED);
					break;
				case RUN_STATE_PAUSED:
					break;
			}
			break;
	}
	return 0;
}


int CVICALLBACK BTN_browseDataDirectory (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_smanagerConfig *c;

	switch (event) {
		case EVENT_COMMIT:
		    c = smanagerConfig;
		    if (DirSelectPopup (c->dataPath, "Select data directory", 1, 1,
								c->dataPath) != 1) return 0;
			RUN_SAVE_setParameters (activeSession());
			startNrRUN = RUN_getCurrentStartNumber (activeRun);			
			break;
	}
	return 0;
}

//==============================================================================
//==============================================================================



void RUN_SAVE_initPanel (void)
{

}

void RUN_SAVE_setParameters (t_session *s)
{
//	SetCtrlVal (subPanelSaveData, RUN_SAVE_STRING_shortStr,     
//				s->shortStr);
	DeleteTextBoxLines (subPanelSaveData, RUN_SAVE_TEXTBOX_comments, 0, -1);
    if (s->comments == NULL) 
    	SetCtrlVal (subPanelSaveData, RUN_SAVE_TEXTBOX_comments, "");
    else SetCtrlVal (subPanelSaveData, RUN_SAVE_TEXTBOX_comments, s->comments);
	SetCtrlAttribute (subPanelSaveData, RUN_SAVE_TEXTBOX_comments, ATTR_FIRST_VISIBLE_LINE, 0);
	SetCtrlVal (subPanelSaveData, RUN_SAVE_STRING_dataPath, smanagerConfig->dataPath);
	RUN_createTodaysDataPath (smanagerConfig);
	SetCtrlVal (subPanelSaveData, RUN_SAVE_STRING_dataPathToday, smanagerConfig->dataPathToday);

}

void RUN_SAVE_getParameters (t_session *s)
{
//	GetCtrlVal (subPanelSaveData, RUN_SAVE_STRING_shortStr,     
//				s->shortStr);
    textboxToBuffer (subPanelSaveData, RUN_SAVE_TEXTBOX_comments,
    			&s->comments);

		
}

int CVICALLBACK RUN_SAVE_parametersEdited (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			RUN_SAVE_getParameters (activeSession());
			SESSION_setChanges (activeSession(), 1);
			break;
	}
	return 0;
}


//==============================================================================
//==============================================================================








void RUN_DIG_setParameters (t_session *s)
{
	double stepSize;
	
	SetCtrlVal (subPanelDig, RUN_DIG_RING_channel, 
				s->DIG_channel);	
	SetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_from, 
				s->DIG_voltageFrom);	
	SetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_to, 
				s->DIG_voltageTo);	
	if (s->DIG_nSteps < 2) s->DIG_nSteps = 2;
	SetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_nSteps, 
				s->DIG_nSteps);	
				
	stepSize = (s->DIG_voltageTo - s->DIG_voltageFrom) / (s->DIG_nSteps-1);
	SetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_stepsize, 
				stepSize);	
	SetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_nCopies, 
				s->DIG_copiesPerStep);	
	SetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_nAverages, s->nAverages);
	SetCtrlVal (subPanelDig, RUN_DIG_STRING_windowName, s->DIG_windowName);
	
	
}


void RUN_DIG_getParameters (t_session *s)
{
	GetCtrlVal (subPanelDig, RUN_DIG_RING_channel, 
				&s->DIG_channel);	
	GetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_from, 
				&s->DIG_voltageFrom);	
	GetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_to, 
				&s->DIG_voltageTo);	
	GetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_nSteps, 
				&s->DIG_nSteps);	
	GetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_nCopies, 
				&s->DIG_copiesPerStep);	
	GetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_nAverages, &s->nAverages);

	GetCtrlVal (subPanelDig, RUN_DIG_STRING_windowName, s->DIG_windowName);
	
	if (s->DIG_nSteps < 2) s->DIG_nSteps = 2;
	
}



void RUN_STD_setParameters (t_session *s)
{
	int nItems;
	
	SetCtrlVal (subPanelStd, RUN_STD_NUMERIC_nRuns, 		  
				s->nRuns);
	SetCtrlVal (subPanelStd, RUN_STD_NUMERIC_nSweepPoints, 
				s->nSweepPoints);
	SetCtrlVal (subPanelStd, RUN_STD_NUMERIC_nCurves,      
				s->nCurves);
				
	
	if (s->plotSweepParameter == 0) {
		GetNumListItems (subPanelStd, RUN_STD_LISTBOX_sweeps, &nItems);
		if (nItems > 0) s->plotSweepParameter = 1;
	}

	SetCtrlVal (subPanelStd, RUN_STD_LISTBOX_sweeps, s->plotSweepParameter);
	listboxCheckOnlyActiveItem (subPanelStd, RUN_STD_LISTBOX_sweeps);

	
}

void RUN_STD_getParameters (t_session *s)
{
	int nItems;
	
	GetCtrlVal (subPanelStd, RUN_STD_NUMERIC_nRuns, 		  
				&s->nRuns);
	GetCtrlVal (subPanelStd, RUN_STD_NUMERIC_nSweepPoints, 
				&s->nSweepPoints);
	GetCtrlVal (subPanelStd, RUN_STD_NUMERIC_nCurves,      
				&s->nCurves);
				
	GetNumListItems (subPanelStd, RUN_STD_LISTBOX_sweeps, &nItems);
	if (nItems > 0) 
		GetCtrlVal (subPanelStd, RUN_STD_LISTBOX_sweeps, &s->plotSweepParameter);
	else 
		s->plotSweepParameter= 0;
}








int CVICALLBACK BTN_startAveraging (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_run *r;
	
	switch (event) {
		case EVENT_COMMIT:
			r = activeRun;
			// negative number of averages --> restart averaging
			if (r == NULL) return 0;
			r->nAveragesToDo =  - activeSession()->nAverages;
			
			SetCtrlVal (subPanelDig, RUN_DIG_NUMERIC_nAveragesDone, abs(r->nAveragesToDo));
			break;
	}
	return 0;
}


int CVICALLBACK RUN_panelCallback (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	t_run *r;
	t_graph *w;
	
	switch (event) {
		case EVENT_GOT_FOCUS:

			break;
		case EVENT_LOST_FOCUS:

			break;
		case EVENT_CLOSE:

			break;
		case EVENT_KEYPRESS:
			switch (eventData1) {
				case ('A' + VAL_MENUKEY_MODIFIER):
					r = activeRun;
					if (r != NULL) w = r->plotWindow;
					GRAPH_autoScale (w);
					GRAPH_setWindowParameters (w, NULL);
					return 1;
				case ('M' + VAL_MENUKEY_MODIFIER):
					CallCtrlCallback (subPanelDig,
									  RUN_DIG_BTN_startAveraging, EVENT_COMMIT, 0,
									  0, 0);
					return 1;
			}
			break;
	}
	return 0;
}



int CVICALLBACK DIG_parameterChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			RUN_DIG_getParameters (s);
			RUN_DIG_setParameters (s);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
			
}




/*
void CVICALLBACK MENU_displayEventList (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	EVENT_displayPanel (activeSeq());   
}
*/


/*
int CVICALLBACK RUN_callback_editPlotItems (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			if (RUN_getState() != RUN_STATE_INACTIVE) return 0;
			PLOTITEM_displayPanel (activeSession()) ;
			break;
	}
	return 0;
}
*/

void RUN_displayAll (t_session *s)
{
//	RUN_protocolCls ();	
	SWEEP_displayListOfSweeps (s, subPanelStd, RUN_STD_LISTBOX_sweeps);
	TIMEINTERVAL_calculateAll (s, 1,TIMEINTERVAL_SPEEDMODE);
	
	PLOTITEM_checkAllForError (s,0);
//	PLOTITEM_displayTree (RUN_subPanelStd (),RUN_STD_TREE_plotItems, s);
	ATOMS_fillAtomNamesToRing (panelRun, RUN_RING_transferAtom, s, 1, 0);
	ATOMS_fillLevelsToRing (panelRun, RUN_RING_transferLevel1, s, 1);
	ATOMS_fillLevelsToRing (panelRun, RUN_RING_transferLevel2, s, 1);
	RUN_setParameters (s, 1);
	RUN_parametersError (s);
}


void RUN_initGraphWindows (t_run *r)
{
	t_plotItem *p;
	t_graph *g;
	t_session *s;
	int i;
	
	GRAPH_resetUsedByActiveSession ();
	s = r->session;
	if (s->mode == SESSIONMODE_DIG) {
		// DIG
		p = PLOTITEM_dig(s);
		g = GRAPH_getFromTitle (p->panelTitle, p->type);
		if (g != NULL) g->usedByActiveSession = 1;
	}
	else {
		// normal session
		for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
			p = PLOTITEM_ptr (s, i);
			if (p->active) {
				PLOTITEM_getPanelTitle (s, p, r->sweep->plotAxisName);
				g = GRAPH_getFromTitle (p->panelTitle, -1);
				if (g != NULL) g->usedByActiveSession = 1;
			}
		}
	}
	
	GRAPH_displayOnlyUsedPanels ();
}



int CVICALLBACK RUN_deleteLastRunData (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_run *r;
	
	switch (event) {
		case EVENT_COMMIT:
			r = activeRun;
			if (!r->dataSaved) return 0;
			if (!ConfirmPopupf ("Delete last run data", 
							    "Do you really want to delete the data of start no. %04d?\n\n"
							    "This action will delete the subdirectory\n'%s'"
							    "\nand all files therein.", r->startNr, r->dataDirectory)) return 0;
			if (deleteDirContents (r->dataDirectory) != 0) return 0;
			if (deleteDir (r->dataDirectory) != 0) return 0;			
			r->dataSaved = 0;
			PLOTITEM_deleteAllCurves (r->session);
			RUN_setParameters (activeSession(), 1);
			break;
	}
	return 0;
}



int CVICALLBACK RUN_saveLastRunData (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			RUN_saveAll (activeRun, RUN_getState() == RUN_STATE_ACTIVE);
			RUN_setParameters (activeSession(), 1);
			break;
	}
	return 0;
}



void CVICALLBACK GRAPH_close_menuCB (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	t_graph *w;

	w = GRAPH_getWindowFromPanelHandle (panel, NULL);
	if ((activeRun != NULL) && (activeRun->plotWindow == w)) activeRun->plotWindow = NULL;
	GRAPH_discard (&w);
//			QuitUserInterface (0);
}

void CVICALLBACK CURVES_close (int menuBar, int menuItem, void *callbackData,
		int panel)
{
	t_graph *w;

	w = GRAPH_getWindowFromPanelHandle (panel, NULL);
	if ((activeRun != NULL) && (activeRun->plotWindow == w)) activeRun->plotWindow = NULL;
	GRAPH_discard (&w);
//			QuitUserInterface (0);
}





void RUN_SAVING_progress (double percent)
{
	if (panelSaving <= 0) return;
//	SetCtrlVal (panelSaving, SAVING_NUMERICSLIDE_progress, percent);
}


void RUN_SAVING_displayPanel (void)
{
	if (panelSaving <= 0) {
		panelSaving = LoadPanel (0, SESSIONMANAGER_uirFile, SAVING);
	}
	cls (panelSaving, SAVING_TEXTBOX);
	RUN_SAVING_progress (0);
	InstallPopup (panelSaving);
}

void RUN_SAVING_removePanel (void)
{
	RemovePopup (1);
}


void RUN_SAVING_printf (char* format, ... )
{
	va_list arg;
	int visible;
	
	if (panelSaving <= 0) return;
	GetPanelAttribute (panelSaving, ATTR_VISIBLE, &visible);
	if (!visible) return;

	va_start( arg, format );
    vpprintf(panelSaving, SAVING_TEXTBOX, format, arg  );
    va_end( arg );
    ProcessDrawEvents();
}


void TIMEINTERVALS_copyTree (void)
{
	int newTree;
	
	newTree = DuplicateCtrl (panelRun,
			  			     RUN_TREE_timeIntervals,
							 panelTimeIntervals, 0, 0, 0);
	DiscardCtrl (panelTimeIntervals, ctrlTimeIntervals);
    ctrlTimeIntervals = newTree;	
}


void TIMEINTERVALS_resizePanel (void)
{
	SetCtrlAttribute (panelTimeIntervals, TIMEINT_COMMANDBUTTON_close,
					  ATTR_TOP, 
					  panelHeight (panelTimeIntervals) -
					  ctrlHeight (panelTimeIntervals, TIMEINT_COMMANDBUTTON_close) - 10);
	SetCtrlAttribute (panelTimeIntervals, ctrlTimeIntervals,
					  ATTR_HEIGHT, 
					  ctrlTop (panelTimeIntervals, TIMEINT_COMMANDBUTTON_close) - 10);
	SetPanelAttribute (panelTimeIntervals, ATTR_WIDTH, 
		 			   ctrlWidth (panelTimeIntervals, ctrlTimeIntervals));
					  
}


void TIMEINTERVALS_initPanel (void)
{
	if (panelTimeIntervals <= 0) {
		panelTimeIntervals = LoadPanel (0, SESSIONMANAGER_uirFile, TIMEINT);
		ctrlTimeIntervals = DuplicateCtrl (panelRun,
										   RUN_TREE_timeIntervals,
										   panelTimeIntervals, 0, 0, 0);
		SetPanelSize (panelTimeIntervals, 
					  ctrlHeight (panelTimeIntervals, ctrlTimeIntervals) + 30,
					  ctrlWidth (panelTimeIntervals, ctrlTimeIntervals));
		SetCtrlAttribute (panelTimeIntervals, TIMEINT_COMMANDBUTTON_close,
						  ATTR_LEFT, 
						  ctrlWidth (panelTimeIntervals, ctrlTimeIntervals) -
						  ctrlWidth (panelTimeIntervals, TIMEINT_COMMANDBUTTON_close) - 10);
					  
		TIMEINTERVALS_resizePanel ();
	}
}


void RUN_displayListOfTimeIntervalsInNewWindow (t_session *s)
{
	TIMEINTERVALS_initPanel ();
	DisplayPanel (panelTimeIntervals);
}


int CVICALLBACK TIMEINTERVALS_close_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			HidePanel (panel);
			break;
	}
	return 0;
}


int CVICALLBACK TIMEINTERVALS_panel_CB (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_GOT_FOCUS:
			break;
		case EVENT_LOST_FOCUS:
			break;
		case EVENT_CLOSE:
			break;
		case EVENT_PANEL_SIZE:
			TIMEINTERVALS_resizePanel ();
			break;
	}
	return 0;
}
