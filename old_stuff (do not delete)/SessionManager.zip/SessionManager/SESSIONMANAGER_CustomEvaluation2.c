#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"


int abortFlag = 0;
int evaluationRunning = 0;

enum {
	I_ee = 0,
	I_eg,
	I_ge,
	I_gg
};


#define MAX_COUNTS_PER_WINDOW 15

typedef struct {
	char name[MAX_PATHNAME_LEN];
	int **counts_g;
	int **counts_e;
	int *countsSum_g;
	int *countsSum_e;

	int *sumAllCountsPerCurve_g;
	int *sumAllCountsPerCurve_e;
	int sumAllCountsAllCurves_e;
	int sumAllCountsAllCurves_g;
	t_curve *c_g, *c_e;
	t_curve *c_COND;
	int nRuns;
	int nPointsPerCurve;
	double delay_ms;
	int **resultsMajVote;
	
	int **filtered_g;
	int **filtered_e;
	
	int nSum_g[MAX_COUNTS_PER_WINDOW];
	int *histogramWindowSizes;
	int nDatasetsCOND;
} t_QNDdataset;	



ListType lDatasets = NULL;




int *MULTIPLES_getDatasetIntAndSum (t_curve *c, int curveNr, int *sum, int *sumArray)
{
	int nElements;
	int *newArray;
	int i;
	int s;
	
	s = 0;
	if (c == NULL) return NULL;
	if (curveNr > c->nCurves) return NULL;
	nElements = MULTIPLES_nPointsPerCurve (c);
	
	newArray = (int *) malloc (sizeof (int)* nElements);
	for (i = 0; i < nElements; i++) {
		newArray[i] = c->yValues[curveNr][i];
		s += newArray[i];
		sumArray[i] += newArray[i];
	}
	if (sum != NULL) *sum = s;
	return newArray;
}



void QND_DATASET_init (t_QNDdataset *q)
{
	int i;
	
	q->name[0] = 0;
	q->counts_g = NULL;
	q->counts_e = NULL;
	q->countsSum_g = NULL;
	q->countsSum_e = NULL;
	q->c_e = NULL;
	q->c_g = NULL;
	q->c_COND = NULL;
	q->nRuns = 0;
	q->nPointsPerCurve = 0;
	q->delay_ms = 0;
	q->resultsMajVote = NULL;
	q->sumAllCountsPerCurve_g = NULL;
	q->sumAllCountsPerCurve_e = NULL;
	q->sumAllCountsAllCurves_e = 0;
	q->sumAllCountsAllCurves_g = 0;
	q->filtered_g = NULL;
	q->filtered_e = NULL;
	q->histogramWindowSizes = NULL;
	q->nDatasetsCOND = 0;
	for (i = 0; i < MAX_COUNTS_PER_WINDOW; i++) q->nSum_g[i] = 0;

}



void QND_DATASET_free (t_QNDdataset *data)
{
	int i;
	
	free (data->sumAllCountsPerCurve_e);
	free (data->sumAllCountsPerCurve_g);
	
	free (data->countsSum_g);
	free (data->countsSum_e); 
	
	free (data->histogramWindowSizes);

	
	for (i = 0; i < data->nRuns; i++) {
		if (data->resultsMajVote) free (data->resultsMajVote[i]);
		if (data->counts_g)       free (data->counts_g[i]);
		if (data->counts_e)       free (data->counts_e[i]);
		if (data->filtered_g)     free (data->filtered_g[i]);
		if (data->filtered_e)     free (data->filtered_e[i]);
	}
	free (data->counts_e);
	free (data->counts_g);
	free (data->resultsMajVote);
	free (data->filtered_g);
	free (data->filtered_e);
	
	
	CURVE_free (data->c_e);
	CURVE_free (data->c_g);
	
	QND_DATASET_init (data);
}



void QND_DATASET_freeAll (void)
{
	int i;
	t_QNDdataset *q;
	
	if (lDatasets == NULL) return;
	for (i = 1; i <= ListNumItems (lDatasets); i++) {
		ListGetItem (lDatasets, &q, i);
		QND_DATASET_free (q);
		free (q);
	}
	ListDispose (lDatasets);
	lDatasets = NULL;
}




t_QNDdataset *QND_DATASET_new (void)
{
	t_QNDdataset *q;
	
	q = (t_QNDdataset *) malloc (sizeof (t_QNDdataset));
	QND_DATASET_init (q);
	return q;
	
}


void QND_DATASET_addToList (t_QNDdataset *q)
{
	if (lDatasets == NULL) {
		lDatasets = ListCreate (sizeof (t_QNDdataset *));
	}		
	ListInsertItem (lDatasets, &q, END_OF_LIST);
}



/*
void QND_DATASET_filterSingleEvents (t_QNDdataset *q, int nRun)
{
	int i;
	int last_e, last_g;
	
	if (q == NULL) return;
	if (nRun >= q->nRuns) return;
	
	if (nRun == 3) {
		nRun = nRun;
	}
	
	if (q->filtered_g == NULL) {
		q->filtered_g  = (int **) malloc (sizeof(int*) * q->nRuns);
		q->filtered_e  = (int **) malloc (sizeof(int*) * q->nRuns);
		for (i = 0; i < q->nRuns; i++) {
			q->filtered_g[i] = (int *) calloc (sizeof (int), q->nPointsPerCurve);
			q->filtered_e[i] = (int *) calloc (sizeof (int), q->nPointsPerCurve);
		}
	}

	
	last_e = -1;
	last_g = -1;
	for (i = 0; i < q->nPointsPerCurve; i++) {
		q->filtered_g[nRun][i] = q->counts_g[nRun][i];
		q->filtered_e[nRun][i] = q->counts_e[nRun][i];
		if (q->counts_e[nRun][i] == 1) {
			if ((last_e >= 0) && (last_g < i) && (last_g > last_e)) {
				
				q->filtered_g[nRun][last_g] = 0;
//				last_g = -1;
			}
			last_e = i;
		}
		if (q->counts_g[nRun][i] == 1) {
			if ((last_g >= 0) && (last_e < i) && (last_e > last_g)) {
				
				q->filtered_e[nRun][last_e] = 0;
				
//				last_e = -1;
			}
			last_g = i;
		}
	}
	
}
*/



void QND_DATASET_getCountsFromCurve (t_QNDdataset *data)
{
	int i;
	
	data->nRuns = MULTIPLES_nRuns (data->c_e);
	data->nPointsPerCurve = MULTIPLES_nPointsPerCurve (data->c_e);  
	
	
	data->counts_g = (int **) malloc (sizeof(int*) * (data->nRuns ));
	data->counts_e = (int **) malloc (sizeof(int*) * (data->nRuns ));
	data->sumAllCountsPerCurve_e = (int *) malloc (sizeof(int) * (data->nRuns ));
	data->sumAllCountsPerCurve_g = (int *) malloc (sizeof(int) * (data->nRuns ));
	
	data->countsSum_g = (int *) calloc (sizeof(int), data->nPointsPerCurve);
	data->countsSum_e = (int *) calloc (sizeof(int), data->nPointsPerCurve);
	
	
	data->sumAllCountsAllCurves_g = 0;
	data->sumAllCountsAllCurves_e = 0;
	for (i = 0; i < data->nRuns; i++) {
		data->counts_g[i] = MULTIPLES_getDatasetIntAndSum (data->c_g, i, &(data->sumAllCountsPerCurve_g[i]), data->countsSum_g);
		data->sumAllCountsAllCurves_g += data->sumAllCountsPerCurve_g[i];
		data->counts_e[i] = MULTIPLES_getDatasetIntAndSum (data->c_e, i, &(data->sumAllCountsPerCurve_e[i]), data->countsSum_e);
		data->sumAllCountsAllCurves_e += data->sumAllCountsPerCurve_e[i];
//		QND_DATASET_filterSingleEvents	(data, i);
	}

//	data->nPointsPerCurve = 100;

}




void QND_DATASET_getCountsFromCurve_COND (t_QNDdataset *data, int nAtomsCond)
{
	int i;
	
	data->nRuns = MULTIPLES_nRuns (data->c_e);
	data->nPointsPerCurve = MULTIPLES_nPointsPerCurve (data->c_e);  
	
	
	
	data->counts_g = (int **) malloc (sizeof(int*) * (data->nRuns ));
	data->counts_e = (int **) malloc (sizeof(int*) * (data->nRuns ));
	data->sumAllCountsPerCurve_e = (int *) malloc (sizeof(int) * (data->nRuns ));
	data->sumAllCountsPerCurve_g = (int *) malloc (sizeof(int) * (data->nRuns ));
	
	data->countsSum_g = (int *) calloc (sizeof(int), data->nPointsPerCurve);
	data->countsSum_e = (int *) calloc (sizeof(int), data->nPointsPerCurve);
	
	
	data->sumAllCountsAllCurves_g = 0;
	data->sumAllCountsAllCurves_e = 0;
	data->nDatasetsCOND = 0;
	for (i = 0; i < data->nRuns; i++) {
		data->counts_g[i] = NULL;
		data->counts_e[i] = NULL;
		if ((data->c_COND != NULL) && (data->c_COND->yValues[i][0] == nAtomsCond)) {
			data->counts_g[i] = MULTIPLES_getDatasetIntAndSum (data->c_g, i, &(data->sumAllCountsPerCurve_g[i]), data->countsSum_g);
			data->sumAllCountsAllCurves_g += data->sumAllCountsPerCurve_g[i];
			data->counts_e[i] = MULTIPLES_getDatasetIntAndSum (data->c_e, i, &(data->sumAllCountsPerCurve_e[i]), data->countsSum_e);
			data->sumAllCountsAllCurves_e += data->sumAllCountsPerCurve_e[i];
			data->nDatasetsCOND ++;
		}
//		QND_DATASET_filterSingleEvents	(data, i);
	}

//	data->nPointsPerCurve = 100;

}




t_QNDdataset *QND_DATASET_load (const char *path, const char *filename_g, const char *filename_e, double delay)
{
	char filename[MAX_PATHNAME_LEN];
	t_curve *c;
	t_QNDdataset *data;
	

	CUSTOM2_printf ("Loading %s.    ",filename_g);
	
	data = QND_DATASET_new ();
	// load g
	strcpy (filename, path);
	strcat (filename, filename_g);
	data->c_g = CURVE_load (filename);
	if (data->c_g == NULL) return NULL;
	
	// load e
	CUSTOM2_printf ("Loading %s.",filename_e);
	strcpy (filename, path);
	strcat (filename, filename_e);
	data->c_e = CURVE_load (filename);
	if (data->c_e == NULL) return NULL;
	
	
	
	QND_DATASET_getCountsFromCurve (data);
	data->delay_ms = delay;	
	
	sprintf (data->name, "%04d %s", data->c_g->startNr, data->c_g->dateStr);

	CUSTOM2_printf ("   %s: %d runs, %d points.\n", data->name, data->nRuns, data->nPointsPerCurve);
	
	
	QND_DATASET_addToList (data);
	return  data;
}



t_QNDdataset *QND_DATASET_load_COND (const char *path, const char *filename_g, const char *filename_e, 
										 const char *filenameCond, double delay, int nAtomsCond)
{
	char filename[MAX_PATHNAME_LEN];
	t_curve *c;
	t_QNDdataset *data;
	int nDatasetsFound;
	

	data = QND_DATASET_new ();

	// load dataset QND
	CUSTOM2_printf ("Loading %s.    ",filenameCond);
	strcpy (filename, path);
	strcat (filename, filenameCond);
	data->c_COND = CURVE_load (filename);
	
	
	
	// load curve of first atom
	CUSTOM2_printf ("Loading %s.",filenameCond);
	strcpy (filename, path);
	strcat (filename, filename_e);
	data->c_e = CURVE_load (filename);
	if (data->c_e == NULL) return NULL;

	
	// load g
	strcpy (filename, path);
	strcat (filename, filename_g);
	data->c_g = CURVE_load (filename);
	if (data->c_g == NULL) return NULL;
	
	// load e
	CUSTOM2_printf ("Loading %s.",filename_e);
	strcpy (filename, path);
	strcat (filename, filename_e);
	data->c_e = CURVE_load (filename);
	if (data->c_e == NULL) return NULL;
	

	QND_DATASET_getCountsFromCurve_COND (data, nAtomsCond);
	data->delay_ms = delay;	
	sprintf (data->name, "%04d %s", data->c_g->startNr, data->c_g->dateStr);


	CUSTOM2_printf ("   %s: %d runs, %d points, %d COND.\n", data->name, data->nRuns, data->nPointsPerCurve, data->nDatasetsCOND);
	
	QND_DATASET_addToList (data);
	return  data;
	
}




void QND_DATASET_calculateMajorityVote (t_QNDdataset *q, int nRun, int windowSize, int minCounts)
{
	int i, k;
	int index, previous;
	int sum_e, sum_g;
	
	if (q == NULL) return;
	if (nRun >= q->nRuns) return;
	
	if (q->resultsMajVote == NULL) {
		q->resultsMajVote  = (int **) malloc (sizeof(int*) * q->nRuns);
		for (i = 0; i < q->nRuns; i++) {
			q->resultsMajVote[i] = (int *) calloc (sizeof (int), q->nPointsPerCurve);
		}
	}

	
	previous = -1;
	for (i = 0; i < q->nPointsPerCurve-windowSize; i++) {
		sum_e = 0;
		sum_g = 0;
		for (k = 0; k < windowSize; k++) {
			sum_e += q->counts_e[nRun][i+k];
			sum_g += q->counts_g[nRun][i+k];
		}
		index = i + windowSize / 2;
		if (sum_e + sum_g < minCounts) q->resultsMajVote[nRun][index] = previous;
		else if (sum_e > sum_g) q->resultsMajVote[nRun][index] = 0;
		else if (sum_e < sum_g) q->resultsMajVote[nRun][index] = 1;
		else q->resultsMajVote[nRun][index] = previous;
		
		previous = q->resultsMajVote[nRun][index];
		
	}
	
}






void QND_DATASET_calculateMajorityVoteInMovingWindow (t_QNDdataset *q, int nCounts, int maxCountsPerAtom)
{
	int i, k;
	int index, previous;
	int sum_e, sum_g;
	int middle,middleLast;
	int nRun;
	int counts;
	
	middleLast=0;
	
	if (q == NULL) return;
	
	if (q->resultsMajVote == NULL) {
		q->resultsMajVote  = (int **) malloc (sizeof(int*) * q->nRuns);
		for (i = 0; i < q->nRuns; i++) {
			q->resultsMajVote[i] = (int *) malloc (sizeof (int) * q->nPointsPerCurve);
		}
	}
	if (q->histogramWindowSizes == NULL) q->histogramWindowSizes = (int *) malloc (sizeof (int)*q->nPointsPerCurve);

	
	for (i = 0; i < MAX_COUNTS_PER_WINDOW; i++) q->nSum_g[i] = 0;
	memset (q->histogramWindowSizes, 0, sizeof (int) * q->nPointsPerCurve);

	for (nRun = 0; nRun < q->nRuns; nRun++) {
		memset (q->resultsMajVote[nRun], 0, sizeof (int) * q->nPointsPerCurve);
		if (q->counts_e[nRun] != NULL) {
			for(index=0;index<q->nPointsPerCurve;index++) {
				counts = q->counts_e[nRun][index] + q->counts_g[nRun][index];
	//			if((q->counts_e[nRun][index]==1)||(q->counts_g[nRun][index]==1))  {
				if((counts > 0) && (counts <= maxCountsPerAtom)) {
					k=index;
					sum_g=0;
					sum_e=0;
					while((sum_e+sum_g < nCounts)&&(k<q->nPointsPerCurve))  {
						sum_e += q->counts_e[nRun][k];
						sum_g += q->counts_g[nRun][k];
						k++; 
					}
						
					if (sum_e + sum_g >= nCounts) {
						if (k-index < q->nPointsPerCurve) q->histogramWindowSizes[k-index]++;
						if ((sum_g < MAX_COUNTS_PER_WINDOW) && (sum_e + sum_g == nCounts)) q->nSum_g[sum_g] ++;
						middle = (index+k)/2;
						q->resultsMajVote[nRun][middle] = (sum_e<sum_g);
						if((q->resultsMajVote[nRun][middleLast]==1)||(index==0)) {
								for(k=middleLast;k<middle;k++) {
									 q->resultsMajVote[nRun][k]=1;
								}
							}
						middleLast=middle;	
					}	
				}
			
			}
		}
	}
	
}

void QND_DATASET_calculateCountsPerWindowForAll (int windowSize)
{

	int i;
	t_QNDdataset *q;
	double countsPerWindow;
	
	for (i = 1; i <= ListNumItems (lDatasets); i++)	{
		ListGetItem (lDatasets, &q, i);
		countsPerWindow = (1.0*(q->sumAllCountsAllCurves_g+q->sumAllCountsAllCurves_e)* windowSize) / (1.0*q->nPointsPerCurve * q->nRuns);
//		CUSTOM2_printf ("%s: %1.3f counts/window\n", q->name, countsPerWindow);;
	}
}



void QND_DATASET_display (t_QNDdataset *q, int nRun)
{
	double *xArray;
	int *yArray;
	int i;
	
	if (q == NULL) return;
	if (nRun >= q->nRuns) return;
	
	xArray = (double *) malloc (sizeof(double) * q->nPointsPerCurve);
	yArray = (int *) malloc (sizeof(int) * q->nPointsPerCurve);
	for (i = 0; i < q->nPointsPerCurve; i++) xArray[i] = q->delay_ms * i;


	if (q->counts_g[nRun] == NULL) return;
	DeleteGraphPlot (panelCustom(2), CUSTOM2_GRAPH1, -1,
					 VAL_IMMEDIATE_DRAW);
	PlotXY (panelCustom(2), CUSTOM2_GRAPH1, xArray, q->counts_g[nRun],
			q->nPointsPerCurve, VAL_DOUBLE, VAL_INTEGER, VAL_FAT_LINE,
			VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_BLUE);
/*
	for (i = 0; i < q->nPointsPerCurve; i++) yArray[i] = q->filtered_g[nRun][i] + 2;
	PlotXY (panelCustom(2), CUSTOM2_GRAPH1, xArray, yArray,
			q->nPointsPerCurve, VAL_DOUBLE, VAL_INTEGER, VAL_FAT_LINE,
			VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_CYAN);
*/
	
	for (i = 0; i < q->nPointsPerCurve; i++) yArray[i] = -q->counts_e[nRun][i];
	PlotXY (panelCustom(2), CUSTOM2_GRAPH1, xArray, yArray,
			q->nPointsPerCurve, VAL_DOUBLE, VAL_INTEGER, VAL_FAT_LINE,
			VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);

/*
	for (i = 0; i < q->nPointsPerCurve; i++) yArray[i] = - (q->filtered_e[nRun][i] + 2);
	PlotXY (panelCustom(2), CUSTOM2_GRAPH1, xArray, yArray,
			q->nPointsPerCurve, VAL_DOUBLE, VAL_INTEGER, VAL_FAT_LINE,
			VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_DK_YELLOW);
*/
	if (q->resultsMajVote) {
		DeleteGraphPlot (panelCustom(2), CUSTOM2_GRAPH3, -1,
						 VAL_IMMEDIATE_DRAW);
		PlotXY (panelCustom(2), CUSTOM2_GRAPH3, xArray, q->resultsMajVote[nRun],
				q->nPointsPerCurve, VAL_DOUBLE, VAL_INTEGER, VAL_FAT_LINE,
				VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_BLUE);
	}
	
	DeleteGraphPlot (panelCustom(2), CUSTOM2_GRAPH4, -1,
					 VAL_IMMEDIATE_DRAW);
	PlotXY (panelCustom(2), CUSTOM2_GRAPH4, xArray, q->countsSum_g,
			q->nPointsPerCurve, VAL_DOUBLE, VAL_INTEGER, VAL_FAT_LINE,
			VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_BLUE);
	for (i = 0; i < q->nPointsPerCurve; i++) yArray[i] = - q->countsSum_e[i];
	PlotXY (panelCustom(2), CUSTOM2_GRAPH4, xArray, yArray,
			q->nPointsPerCurve, VAL_DOUBLE, VAL_INTEGER, VAL_FAT_LINE,
			VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_RED);

	free (xArray);
	free (yArray);
}



void QND_fillDatasetsToRing (void)
{
	int i;
	t_QNDdataset *q;
	
	DeleteListItem (panelCustom(2), CUSTOM2_RING_dataSet, 0, -1);
	for (i = 1; i <= ListNumItems (lDatasets); i++) {
		ListGetItem (lDatasets, &q, i);
		InsertListItem (panelCustom(2), CUSTOM2_RING_dataSet,  -1, 
						q->name, i);
	}
}





void QND_DATASET_calculateMajorityVoteInMovingWindow_allDatasets (int nCounts, int maxCountsPerAtom)
{
	t_QNDdataset *q;
	int i;
	
	for (i = 1; i <= ListNumItems (lDatasets); i++) {
		ListGetItem (lDatasets, &q, i);
		QND_DATASET_calculateMajorityVoteInMovingWindow (q, nCounts, maxCountsPerAtom);
		
	}
}


void QND_DATASET_addDurationsToHistogram (t_QNDdataset* q, int* histogram,int nPointsPerCurve, int photonState) 
{
	int i,length,nRun;
	int first;

	for (nRun = 0; nRun < q->nRuns; nRun++) { 
		length = 0;
		first = 1;
		for(i=0;i<q->nPointsPerCurve;i++) {
		 	if(q->resultsMajVote[nRun][i]==photonState) length++;
		 	else {
		 		if((length!=0)&&(length< nPointsPerCurve)&&(!first)) histogram[length]++;
		 		length = 0;
		 		first = 0;
		 	}
		 }
	}
}



void QND_DATASET_saveArray2D (const char *fileName,int** histogram,int nPointsPerCurve, double delay_ms, int indexStart, int indexEnd,
							  const char *firstLine) 
{
	FILE *file;
	int i,u;
	 
	 
	CUSTOM2_printf ("Saving %s...\n", fileName);
	 
	file = fopen (fileName, "w");
	 
 	if (firstLine != NULL) fprintf (file, firstLine);
 	else {
	 	fprintf (file, "timeMs");
	 	for(u = indexStart; u <= indexEnd;u++)
	 		fprintf (file, "\tS%d", u);
	 	fprintf (file,"\n");
	 }

	 
	 for (i = 0; i < nPointsPerCurve; i++) {
	 	fprintf (file, "%1.3f", delay_ms * i);
	 	for(u = indexStart; u <= indexEnd;u++)
	 		fprintf (file, "\t%d", histogram[u][i]);
	 	fprintf (file,"\n");
	 }
	 fclose (file);
	 
}





void QND_DATASET_autoCorrelationToHistogram (t_QNDdataset *q, int nRun, int **autoCorrelation, int maxAutoCorrTime)
{
	int i, j;
	int end;
	
	if (q->counts_e[nRun] == NULL) return;
	if (q->counts_g[nRun] == NULL) return;

	for (i = 0; i < q->nPointsPerCurve-maxAutoCorrTime; i++) {
		if (q->counts_e[nRun][i] + q->counts_g[nRun][i] == 1) {
			end = i+maxAutoCorrTime;
			for (j = i; j < end; j++) {
				if (q->counts_e[nRun][j] + q->counts_g[nRun][j] == 1) {
					if ((q->counts_e[nRun][i] == 1) && (q->counts_e[nRun][j] == 1)) autoCorrelation[I_ee][j-i]++;
					if ((q->counts_e[nRun][i] == 1) && (q->counts_g[nRun][j] == 1)) autoCorrelation[I_eg][j-i]++;
					if ((q->counts_g[nRun][i] == 1) && (q->counts_e[nRun][j] == 1)) autoCorrelation[I_ge][j-i]++;
					if ((q->counts_g[nRun][i] == 1) && (q->counts_g[nRun][j] == 1)) autoCorrelation[I_gg][j-i]++;
				}
			}
		}
	}
}



void calculateAutoCorrelationHistogram (const char *filename,int maxAutoCorrTime)
{
	int *autoCorrelation[4];

	
	int i;
	t_QNDdataset *q;
	int nRun;
	
	if (ListNumItems (lDatasets) == 0) return;
	if (abortFlag) return;
	
	
	
	CUSTOM2_printf ("Calculating autocorrelation function.\n");

		
	if (maxAutoCorrTime < 0) {
		ListGetItem (lDatasets, &q, 1);
		maxAutoCorrTime = q->nPointsPerCurve;
	}
	
	for (i = 0; i < 4; i++) {
		autoCorrelation[i] = (int *) calloc (sizeof(int), maxAutoCorrTime);
	}
	
	for (i = 1; i <= ListNumItems (lDatasets); i++) {
		ListGetItem (lDatasets, &q, 1);
		
		for (nRun = 0; nRun < q->nRuns; nRun++) { 
			QND_DATASET_autoCorrelationToHistogram (q, nRun, autoCorrelation, maxAutoCorrTime);
		}
		ProcessSystemEvents();
		if (abortFlag) return;
	}
	
	QND_DATASET_saveArray2D (filename, autoCorrelation, maxAutoCorrTime, q->delay_ms, 0, 3, "\ntimeMS\tPee\tPeg\tPge\tPgg\n");
	
	
	for (i = 0; i < 4; i++) free (autoCorrelation[i]);

}
	


void calculateDurationHistogram (const char *fileNameHistogram_0, 
								 const char *fileNameHistogram_1, 
								 const char *fileNameHistogramWindowSizes, 
								 const char *filenamenN_g, 
								 int maxCountsPerAtom)
{
	int nCounts;
	t_QNDdataset *q;
	int i,u;
	int **histogram_0, **histogram_1;
	int nPointsPerCurve;
	char fileName[MAX_PATHNAME_LEN];
	int **nSum_g_all;
	int **histogramWindowSizes = NULL;
	

	if (ListNumItems (lDatasets) == 0) return;
	
	CUSTOM2_printf ("Creating histogram of delays (max. counts per Window %d): ", MAX_COUNTS_PER_WINDOW);

	ListGetItem (lDatasets, &q, 1);
	nPointsPerCurve = q->nPointsPerCurve;
	if (abortFlag) return;

	histogram_1 = (int **) malloc (sizeof (int*) * MAX_COUNTS_PER_WINDOW);
	histogram_0 = (int **) malloc (sizeof (int*) * MAX_COUNTS_PER_WINDOW);
	histogramWindowSizes = (int **) malloc (sizeof (int*) * MAX_COUNTS_PER_WINDOW);
	nSum_g_all = (int **) malloc (sizeof (int*) * MAX_COUNTS_PER_WINDOW);
    for(u=0;u<MAX_COUNTS_PER_WINDOW;u++) {
		histogram_0[u] = (int *) malloc (sizeof (int)*nPointsPerCurve);
		histogram_1[u] = (int *) malloc (sizeof (int)*nPointsPerCurve);
		nSum_g_all[u] = (int *) malloc (sizeof (int)*MAX_COUNTS_PER_WINDOW);
		histogramWindowSizes [u] = (int *) malloc (sizeof (int)*nPointsPerCurve);
	}
	
	for (nCounts = 1; nCounts < MAX_COUNTS_PER_WINDOW; nCounts++) {
		// ini arrays
		for (i = 0; i < MAX_COUNTS_PER_WINDOW; i++) nSum_g_all[nCounts][i] = 0;
		memset (histogramWindowSizes[nCounts], 0, sizeof (int)*nPointsPerCurve);

		QND_DATASET_calculateMajorityVoteInMovingWindow_allDatasets (nCounts, maxCountsPerAtom);	
		
		memset (histogram_0[nCounts], 0, sizeof (int)*nPointsPerCurve);
		memset (histogram_1[nCounts], 0, sizeof (int)*nPointsPerCurve);
		for (i = 1; i <= ListNumItems (lDatasets); i++) {
			ListGetItem (lDatasets, &q, 1);
			
			QND_DATASET_addDurationsToHistogram (q, histogram_0[nCounts], nPointsPerCurve, 0);
			QND_DATASET_addDurationsToHistogram (q, histogram_1[nCounts], nPointsPerCurve, 1);
			for (u = 0; u < MAX_COUNTS_PER_WINDOW; u++) nSum_g_all[nCounts][u]  += q->nSum_g[u];
			for (u = 0; u < q->nPointsPerCurve; u++) histogramWindowSizes[nCounts][u] += q->histogramWindowSizes[u]; 
			ProcessSystemEvents();
			if (abortFlag) return;
		}
		CUSTOM2_printf ("%d ",nCounts);
	}
	CUSTOM2_printf ("\n");
	
	QND_DATASET_saveArray2D (fileNameHistogram_0, histogram_0, nPointsPerCurve,q->delay_ms, 1, MAX_COUNTS_PER_WINDOW-1, 0);
	QND_DATASET_saveArray2D (fileNameHistogram_1, histogram_1, nPointsPerCurve,q->delay_ms, 1, MAX_COUNTS_PER_WINDOW-1, 0);
	QND_DATASET_saveArray2D (fileNameHistogramWindowSizes, histogramWindowSizes, nPointsPerCurve, q->delay_ms, 1, MAX_COUNTS_PER_WINDOW-1, 0);
	QND_DATASET_saveArray2D (filenamenN_g, nSum_g_all, MAX_COUNTS_PER_WINDOW, 1, 1, MAX_COUNTS_PER_WINDOW-1, 0);
	
	for(u = 1; u < MAX_COUNTS_PER_WINDOW; u++) {
		free(histogram_0[u]);
		free(histogram_1[u]);
		free(nSum_g_all[u]);
		free(histogramWindowSizes [u]);
	}
	free(histogram_0);
	free(histogram_1);
	free(nSum_g_all);
	free (histogramWindowSizes);
	
	
}




int CVICALLBACK CUSTOM2_nCurve_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int datasetNr;
	int runNr;
	t_QNDdataset *q;
	int windowSize;
	int minCounts;
	
	switch (event)
		{
		case EVENT_COMMIT:
			GetCtrlVal (panelCustom(2), CUSTOM2_RING_dataSet, &datasetNr);
			ListGetItem (lDatasets, &q, datasetNr);
			SetCtrlAttribute (panelCustom(2), CUSTOM2_NUMERIC_nCurve, ATTR_MAX_VALUE,
							  q->nRuns);
			GetCtrlVal (panelCustom(2), CUSTOM2_NUMERIC_nCurve, &runNr);
			if (runNr > q->nRuns) runNr = q->nRuns;
			
			GetCtrlVal (panelCustom(2), CUSTOM2_NUMERIC_windowSize, &windowSize);
			GetCtrlVal (panelCustom(2), CUSTOM2_NUMERIC_minCounts, &minCounts);
			QND_DATASET_calculateCountsPerWindowForAll (windowSize);
			QND_DATASET_calculateMajorityVoteInMovingWindow (q,  minCounts, 1);
			
			
			QND_DATASET_display (q, runNr-1);
			
			
			break;
		}
	return 0;
}


void QND_datasetSumAll (t_QNDdataset *q, int maxNAtoms, int binsize)
{
	int nRun;
	int i;
	
	memset (q->countsSum_g, 0, sizeof(int)*q->nPointsPerCurve);
	memset (q->countsSum_e, 0, sizeof(int)*q->nPointsPerCurve);
	for (nRun = 0; nRun < q->nRuns; nRun++) { 
		if (q->counts_g[nRun] != NULL) {
			for (i = 0; i < q->nPointsPerCurve; i++) {
				if (q->counts_g[nRun][i] <= maxNAtoms) q->countsSum_g[i/binsize]+=q->counts_g[nRun][i];
				if (q->counts_e[nRun][i] <= maxNAtoms) q->countsSum_e[i/binsize]+=q->counts_e[nRun][i];
			}
		}
	}
}



void saveSumAll (const char *filename, int maxNAtoms, int binsize)
{
	int i, k;
	t_QNDdataset *q;
	int *sumAll[3] = {NULL, NULL};
	int nPoints;

	if (lDatasets == NULL) return;


	for (k = 1; k <= ListNumItems (lDatasets); k++) {
		ListGetItem (lDatasets, &q, k);
		QND_datasetSumAll (q, maxNAtoms, binsize);
		if (sumAll[0] == NULL) {
			nPoints = q->nPointsPerCurve / binsize;
			sumAll[0] = (int *) calloc (sizeof(int), nPoints );
			sumAll[1] = (int *) calloc (sizeof(int), nPoints );
			sumAll[2] = (int *) calloc (sizeof(int), nPoints );
		}
		if (q->nPointsPerCurve / binsize != nPoints) {
			CUSTOM1_printf ("\nWARNING: trying to sum datasets of different lengths!\n");
			goto theEnd;
		}
		for (i = 0; i < nPoints; i++) {
			sumAll[0][i]+= q->countsSum_g[i];	
			sumAll[1][i]+= q->countsSum_e[i];	
			sumAll[2][i]+= (q->countsSum_e[i]+q->countsSum_g[i]);	
		}
	}
	
	QND_DATASET_saveArray2D (filename, sumAll, nPoints, q->delay_ms * binsize, 0, 2, "timeMs\tsumG\tsumE\tsumEG\n");
	
theEnd:	
	free (sumAll[0]);
	free (sumAll[1]);
	free (sumAll[2]);
}




void CUSTOM2_startEvaluation (void)
{
	
	#define PATH_ROOT "D:\\USER\\Stefan\\data\\"
//	#define PATH_ROOT "D:\\DATA\\"
	#define PATH_1109 PATH_ROOT"2006\\September\\11\\"
	#define PATH_1209 PATH_ROOT"2006\\September\\12\\"
	#define PATH_1309 PATH_ROOT"2006\\September\\13\\"
	#define PATH_1509 PATH_ROOT"2006\\September\\15\\"

	
	

	if (evaluationRunning) return;
	evaluationRunning = 1;
	abortFlag = 0;
	QND_DATASET_freeAll ();
	

	
	//=====================================================
	//
	//   12/09/06:   0125,0127,0129,0130,0131 
	//
	//=====================================================
/*	
	#define SAVE_RUN_ID  "0125-0132"
	#define RESULTS_DIR  "0000_RESULTS\\"SAVE_RUN_ID"\\"
	
	#define DELAY_MS 	 0.200
	#define WORKING_DIR  PATH_1109

	#define NATOMSCOND 1


	#define DATASETNR "0125"
		if (QND_DATASET_load_COND (WORKING_DIR DATASETNR "_QND D1 2 serp + atom e\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DATASETNR "_g atom rabi.curve", DELAY_MS, NATOMSCOND) == NULL) goto error;
	#undef DATASETNR

	#define DATASETNR "0127"
		if (QND_DATASET_load_COND (WORKING_DIR DATASETNR "_QND D1 2 serp + atom e\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DATASETNR "_g atom rabi.curve", DELAY_MS, NATOMSCOND) == NULL) goto error;
	#undef DATASETNR
	
	#define DATASETNR "0129"
		if (QND_DATASET_load_COND (WORKING_DIR DATASETNR "_QND D1 2 serp + atom e\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DATASETNR "_g atom rabi.curve", DELAY_MS, NATOMSCOND) == NULL) goto error;
	#undef DATASETNR
	
	#define DATASETNR "0131"
		if (QND_DATASET_load_COND (WORKING_DIR DATASETNR "_QND D1 2 serp + atom e\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DATASETNR "_g atom rabi.curve", DELAY_MS, NATOMSCOND) == NULL) goto error;
	#undef DATASETNR
	
	#define DATASETNR "0132"
		if (QND_DATASET_load_COND (WORKING_DIR DATASETNR "_QND D1 2 serp + atom e\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DATASETNR "_g atom rabi.curve", DELAY_MS, NATOMSCOND) == NULL) goto error;
	#undef DATASETNR

*/	
	
/*	QND_DATASET_load (PATH_1109"0123_QND D1 2 serp + atom e\\", "0123_multiples g.curve", "0123_multiples e.curve", 0.200);
	QND_DATASET_load (PATH_1109"0131_QND D1 2 serp + atom e\\", "0131_multiples g.curve", "0131_multiples e.curve", 0.200);
	QND_DATASET_load (PATH_1109"0132_QND D1 2 serp + atom e\\", "0132_multiples g.curve", "0132_multiples e.curve", 0.200);
	*/


/*
	//=====================================================
	//
	//   0136 + 0137 13/09/06
	//
	//=====================================================
	
	#define SAVE_RUN_ID  "0137+0136"
	#define RESULTS_DIR  "0000_RESULTS\\"SAVE_RUN_ID"\\"
	
	#define DELAY_MS 	 0.100
	#define WORKING_DIR  PATH_1309

	#define DATASETNR "0137"
		if (QND_DATASET_load (WORKING_DIR DATASETNR "_QND D1 2 serp x 1000\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DELAY_MS) == NULL) goto error;
	#undef DATASETNR
	

	#define DATASETNR "0136"
		if (QND_DATASET_load (WORKING_DIR DATASETNR "_QND D1 2 serp x 1000\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DELAY_MS) == NULL) goto error;
	#undef DATASETNR

*/	
	
//=====================================================
//
//   0044 + 0046  12/09/06
//
//=====================================================
/*	
	#define SAVE_RUN_ID  "0044+0045"
	#define RESULTS_DIR  "0000_RESULTS\\"SAVE_RUN_ID"\\"
	
	#define DELAY_MS 	 0.200
	#define WORKING_DIR  PATH_1209

	#define DATASETNR "0044"
		if (QND_DATASET_load (WORKING_DIR DATASETNR "_QND D1 2 serp x 1000\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DELAY_MS) == NULL) goto error;
	#undef DATASETNR
	

	#define DATASETNR "0045"
		if (QND_DATASET_load (WORKING_DIR DATASETNR "_QND D1 2 serp x 1000\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DELAY_MS) == NULL) goto error;
	#undef DATASETNR
*/
	


//=====================================================
//
//   0074  15/09/06
//
//=====================================================
	
	#define SAVE_RUN_ID  "0088"
	#define RESULTS_DIR  "0000_RESULTS\\"SAVE_RUN_ID"\\"
	
	#define DELAY_MS 	 0.300
	#define WORKING_DIR  PATH_1509

	#define DATASETNR "0088"
		if (QND_DATASET_load (WORKING_DIR DATASETNR "_test fond QND\\", DATASETNR "_multiples g.curve", DATASETNR "_multiples e.curve", DELAY_MS) == NULL) goto error;
	#undef DATASETNR
	


/// ==========================================================================
/// ==========================================================================
/// ==========================================================================

	QND_fillDatasetsToRing ();
	
	#define SAVE_DIR	WORKING_DIR RESULTS_DIR
	mkDirs (SAVE_DIR);

	#define SAVE_PREFIX SAVE_DIR SAVE_RUN_ID"_"
	
	saveSumAll (SAVE_PREFIX "sumAll.txt", 10000, 1);
	saveSumAll (SAVE_PREFIX "sumAll_1atom.txt", 1, 1);
	saveSumAll (SAVE_PREFIX "sumAll_bin5.txt", 10000, 5);
	saveSumAll (SAVE_PREFIX "sumAll_1atom_bin5.txt", 1, 5);

	calculateAutoCorrelationHistogram (SAVE_PREFIX "AutoCorrelation.txt", 500);								

	
	calculateDurationHistogram (SAVE_PREFIX "histogram_duration_0ph_max1at.txt",
							    SAVE_PREFIX "histogram_duration_1ph_max1at.txt",
								SAVE_PREFIX "histogramWindowSizes_max1at.txt",
								SAVE_PREFIX "histogram_n_g_max1at.txt", 1);
	
	
	calculateDurationHistogram (SAVE_PREFIX "histogram_duration_0ph_max2at.txt",
								SAVE_PREFIX "histogram_duration_1ph_max2at.txt",
								SAVE_PREFIX "histogramWindowSizes_max2at.txt",
								SAVE_PREFIX "histogram_n_g_max2at.txt", 2);
	
	calculateDurationHistogram (SAVE_PREFIX "histogram_duration_0ph_max3at.txt",
								SAVE_PREFIX "histogram_duration_1ph_max3at.txt",
								SAVE_PREFIX "histogramWindowSizes_max3at.txt",
								SAVE_PREFIX "histogram_n_g_max3at.txt", 3);

	CUSTOM2_nCurve_callback (panelCustom(2), 0, EVENT_COMMIT, 0,0,0);
	evaluationRunning = 0;
	
	if (abortFlag) {
		QND_DATASET_freeAll ();
		HidePanel (panelCustom(2));
	}
	return;
	
error:
	evaluationRunning = 0;
	QND_DATASET_freeAll ();
	return;
}


int CVICALLBACK CUSTOM2_abortEvaluation_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			abortFlag = 1;
			CUSTOM2_printf ("ABORTED\n");
			if (!evaluationRunning) HidePanel (panelCustom(2));
			break;
		}
	return 0;
}
