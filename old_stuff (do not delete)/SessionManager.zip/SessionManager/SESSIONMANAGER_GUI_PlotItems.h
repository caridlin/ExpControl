#if !defined (SESSIOMANAGER_GUI_PLOTITEMS)
#define SESSIOMANAGER_GUI_PLOTITEMS




//int PLOTITEM_calculateIntervalNCounts (t_session *s, t_plotItem *p);

//int PLOTITEM_calculateIntervalsTransfer (t_session *s, t_plotItem *p);

int PLOTITEM_calculateTimeIntervals (t_session *s, t_plotItem *p);

const char *PLOTITEM_typeStr (t_plotItem  *p);

void PLOTITEM_setValues (t_session *s, t_plotItem *p);
void PLOTITEM_getValues (int panel, t_session *s, t_plotItem *p);

void PLOTITEM_getCounter (t_plotItem *p);

const char*PLOTITEM_errStr (int err, t_session *s, t_plotItem *p) ;

t_plotItem *PLOTITEM_dig (t_session *s);


int PLOTITEM_initPanel (void); 
void PLOTITEM_displayAll (t_session *s);


void PLOTITEM_initTree (int panel, int ctrl);
void PLOTITEM_displayTree (int panel, int ctrl, t_session *s);

int PLOTITEM_isOneActive (t_session *s);


int PLOTITEM_saveAllCurves (const char *dir, t_session *s, int checkForDuplicates);

void PLOTITEM_getBinStartEnd (t_session *s, t_plotItem *p);


int PLOTITEM_checkForError (t_session *s, t_plotItem *p);

int PLOTITEM_checkAllForError (t_session *s, int displayInTree);

int PLOTITEM_hasError (t_session *s, t_plotItem **p);

void PLOTITEM_getPanelTitle (t_session *s, t_plotItem *p, const char *axisName);

int PLOTITEM_checkAllForDifferentPlotRanges (t_session *s);


void PLOTITEM_fillNamesToRing (int panel, int control, t_session *s, int type, int onlyActive);

void PLOTITEM_deleteAllCurves (t_session *s);






#endif
