
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"

#define SESSIONMANAGER 1
#include <userint.h>  


t_dataField *DF = NULL;

extern int panelAtoms;

const char SESSIONMANAGER_uirFile[] = "UIR_SessionManager.uir";
const char SESSION_defaultFilename[] = "untitled.ses";
const char SESSION_fileSuffix[] = "*.ses";
const char RUN_fileSuffix[] = "*.run";

t_smanagerConfig *smanagerConfig;


t_dataField *df (int i) 
{
	return &DF[i];
}


void DATAFIELD_initAll (void)
{
	int ID;
	t_dataField *f;
	t_atom a;
	
	// init all data fields
	if (DF == NULL) {
		DF = (t_dataField *) malloc (sizeof (t_dataField) * N_DATAFIELDS);
		for (ID = 0; ID < N_DATAFIELDS; ID++) DATAFIELD_init (df(ID));
	}
	DisableBreakOnLibraryErrors ();
	
// atom number
	f = df( DF_NR);
	f->active          		= 1;               // active
	f->idName          		= "NR";            // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "Nr.";  		//  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType	    = VAL_STRING;
	f->isEditable      		= 0;
	f->panelID				= panelAtoms;
	f->controlID        	= ATOMS_NUMERIC_number;

// atom active	
	f = df( DF_ACTIVE);
	f->active          		= 1;      // active
	f->idName          		= "ACTIVE";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "active";  //  
	f->tableColumnWidth 	= 50;
	f->dataType        		= VAL_YES_NO;
	f->tableCellType	    = VAL_YES_NO;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.active) - (unsigned) (&a)); // reference Content
	f->panelID				= panelAtoms;
	f->controlID        	= ATOMS_RADIOBUTTON_active;
	
// atom active	
	f = df( DF_NAME);
	f->active          		= 1;      // active
	f->idName          		= "NAME";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "name";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_STRING;
	f->tableCellType        = VAL_STRING;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (a.name) - (unsigned) (&a)); // reference Content
	f->panelID				= panelAtoms;
	f->controlID        	= ATOMS_STRING_name;


	f = df( DF_VELOCITY_SELECTION);
	f->active          		= 1;      // active
	f->idName          		= "VEL_SELECTION";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "vel. selection";  //  
	f->tableColumnWidth 	= 50;
	f->dataType        		= VAL_YES_NO;
	f->tableCellType	    = VAL_YES_NO;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.velocitySelection) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_BTN_velocitySelection;
	

	f = df( DF_VELOCITY);
	f->active          		= 1;      // active
	f->idName          		= "VELOCITY";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "velocity [m/s]";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.velocity) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_NUMERIC_velocity;

	f = df( DF_VELOCITY_SPREAD);
	f->active          		= 1;      // active
	f->idName          		= "VELOCITY_SPREAD";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "velocity spread [m/s]";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.velocitySpread) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_NUMERIC_spread;
	
// frequency repumper 
	f = df( DF_REPUMPER_FREQ);
	f->active          		= 1;      // active
	f->idName          		= "REPUMPER_FREQ";   
	f->tableColumnName 		= "repumper freq.";    
	f->tableColumnWidth 	= 50;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_INTEGER;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.repumperFrequency) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_RING_frequency;

// duration  repumper 
	f = df( DF_REPUMPER_POWER);
	f->active          		= 1;      // active
	f->idName          		= "REPUMPER_POWER";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "repumper power";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_INTEGER;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.repumperPower) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_RING_power;

// duration  repumper 
	f = df( DF_REPUMPER_DURATION);
	f->active          		= 1;      // active
	f->idName          		= "REPUMPER_DURATION";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "repumper duration [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.repumperDuration) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_NUMERIC_durationRep;

// duration  repumper 
	f = df( DF_REPUMPER_TIME);
	
	f->active          		= 1;      // active
	f->idName          		= "REPUMPER_TIME";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "repumper start [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.repumperTime) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_NUMERIC_repStart;


	f = df( DF_REPUMPER_TIME_REFERENCE);
	
	f->active          		= 1;      // active
	f->idName          		= "REPUMPER_TIME_REFERENCE";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "repumper reference [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_INTEGER;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.repumperTimeReference) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_RING_referencePos;


// duration  depumper 
	f = df( DF_DEPUMPER_DURATION);
	f->active          		= 1;      // active
	f->idName          		= "DEPUMPER_ANGLE_DURATION";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "depumper (angle) duration [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.depumperAngleDuration) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_NUMERIC_durationDep;

// time depumper 
	f = df( DF_DEPUMPER_TIME);
	
	f->active          		= 1;      // active
	f->idName          		= "DEPUMPER_TIME";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "depumper start [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.depumperAngleTime) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_NUMERIC_depStart;



// laser 1 always on?
/*	f = df( DF_REPUMPER_ALWAYS_ON);
	f->active          		= 1;      // active
	f->idName          		= "ALWAYS_ON_REPUMPER";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "repumper always on [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_YES_NO;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.repumperAlwaysOn) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->controlID        	= ATOMS_VEL_RADIOBUTTON_always;


// laser 1 always on?
	f = df( DF_ALWAYS_ON_LASER1);
	f->active          		= 1;      // active
	f->idName          		= "ALWAYS_ON_LASER1";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "laser1 always on [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_YES_NO;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.alwaysOnL1) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_RADIOBUTTON_always;
*/
// duration  laser 1
	f = df( DF_DURATION_LASER1);
	f->active          		= 1;      // active
	f->idName          		= "DURATION_LASER1";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "duration laser1 [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.durationL1) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_NUMERIC_durationL1;


	f = df( DF_TIME_L2);
	f->active          		= 1;      // active
	f->idName          		= "TIME_LASER2";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "time laser2 [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.timeL2) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_NUMERIC_timeLaser2;

	f = df( DF_TIME_OP);
	f->active          		= 1;      // active
	f->idName          		= "TIME_OP";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "time opt. pump. [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.timeOP) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_NUMERIC_timeLaserOP;

		f = df( DF_DURATION_L2);
	f->active          		= 1;      // active
	f->idName          		= "DURATION_LASER2";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "duration laser2 [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.durationL2) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_NUMERIC_durationL2;

	f = df( DF_DURATION_OP);
	f->active          		= 1;      // active
	f->idName          		= "DURATION_OP";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "duration opt. pump. [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.durationOP) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_NUMERIC_durationOP;

// 
	f = df( DF_CIRC_TRIGGER_RF);
	f->active          		= 1;      // active
	f->idName          		= "CIRC_TRIGGER_RF";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "trigger RF circ. [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.circTriggerRF) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_NUMERIC_trigRFcirc;

// duration  laser 1
	f = df( DF_CIRC_TRIGGER_RAMP);
	f->active          		= 1;      // active
	f->idName          		= "CIRC_TRIGGER_RAMP";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "trigger circ. ramp [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.circTriggerRamp) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_NUMERIC_trigCircRamp;


// time MW pulse 52d --> 52f
	f = df( DF_CIRC_52D_TIME);
	f->active          		= 1;      // active
	f->idName          		= "CIRC_52D_TIME";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "time MW pulse 52d-->52f [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.circ52dTime) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_NUMERIC_time52d;

// duration MW pulse 52d --> 52f
	f = df( DF_CIRC_52D_DURATION);
	f->active          		= 1;      // active
	f->idName          		= "CIRC_52D_DURATION";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "duration MW pulse 52d-->52f [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.circ52dDuration) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCirc();
	f->controlID        	= ATOMS_CIRC_NUMERIC_duration52d;




// state
	f = df( DF_STATE);
	f->active          		= 1;      // active
	f->idName          		= "STATE";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "state";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_STRING;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.state) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelState();
	f->controlID        	= ATOMS_STAT_RING_state;

// purif start
	f = df( DF_PURIF_START_G);
	f->active          		= 1;      // active
	f->idName          		= "PURIF_START_G";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "purif start |g> [�s]";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.purifStart_g) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelState();
	f->controlID        	= ATOMS_STAT_NUMERIC_purifStart_g;

// purif end
	f = df( DF_PURIF_END_G);
	f->active          		= 1;      
	f->idName          		= "PURIF_DURATION_G"; 
	f->tableColumnName 		= "purif duration |g> [�s]";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.purifDuration_g) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelState();
	f->controlID        	= ATOMS_STAT_NUMERIC_purifDur_g;

// purif start
	f = df( DF_PURIF_START_E);
	f->active          		= 1;      // active
	f->idName          		= "PURIF_START_E";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "purif start |e> [�s]";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.purifStart_e) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelState();
	f->controlID        	= ATOMS_STAT_NUMERIC_purifStart_e;

// purif end
	f = df( DF_PURIF_END_E);
	f->active          		= 1;      
	f->idName          		= "PURIF_DURATION_E"; 
	f->tableColumnName 		= "purif duration |e> [�s]";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.purifDuration_e) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelState();
	f->controlID        	= ATOMS_STAT_NUMERIC_purifDur_e;


	f = df( DF_KILLER1_TIME_REFERENCE);
	f->active          		= 1;      
	f->idName          		= "KILLER1_TIME_REFERENCE"; 
	f->tableColumnName 		= "killer 1 time ref.";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_INTEGER;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.killerTimeReference[0]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(1);
	f->controlID        	= ATOMS_CAV_RING_referencePos;


	f = df( DF_KILLER1_START_FIRST);
	f->active          		= 1;      
	f->idName          		= "KILLER1_START_FIRST"; 
	f->tableColumnName 		= "killer 1 start";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.killerStartFirst[0]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(0);
	f->controlID        	= ATOMS_CAV_NUMERIC_killerStart;

	f = df( DF_KILLER1_ACTIVE);
	f->active          		= 1;      
	f->idName          		= "KILLER1_ACTIVE"; 
	f->tableColumnName 		= "killer 1 active";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_YES_NO;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.killerActive[0]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(0);
	f->controlID        	= ATOMS_CAV_RADIOBUTTON_active;


// killer cavity 2
	f = df( DF_KILLER2_TIME_REFERENCE);
	f->active          		= 1;      
	f->idName          		= "KILLER2_TIME_REFERENCE"; 
	f->tableColumnName 		= "killer 2 time ref.";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_INTEGER;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.killerTimeReference[1]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(1);
	f->controlID        	= ATOMS_CAV_RING_referencePos;


	f = df( DF_KILLER2_START_FIRST);
	f->active          		= 1;      
	f->idName          		= "KILLER2_START_FIRST"; 
	f->tableColumnName 		= "killer 2 start";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.killerStartFirst[1]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(1);
	f->controlID        	= ATOMS_CAV_NUMERIC_killerStart;

	f = df( DF_KILLER2_ACTIVE);
	f->active          		= 1;      
	f->idName          		= "KILLER2_ACTIVE"; 
	f->tableColumnName 		= "killer 2 active";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_YES_NO;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.killerActive[1]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(1);
	f->controlID        	= ATOMS_CAV_RADIOBUTTON_active;



	f = df( DF_DETECT);
	f->active          		= 1;      
	f->idName          		= "DETECT"; 
	f->tableColumnName 		= "detect atom";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_YES_NO;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.detect) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelDetection();
	f->controlID        	= ATOMS_DET_CHECKBOX_detectAtom;


	f = df( DF_VOLTAGE_DETECTOR2);
	f->active          		= 1;      
	f->idName          		= "VOLT_DET2"; 
	f->tableColumnName 		= "volt. det. 2";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_LEVEL;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.detectionLevel) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelDetection();
	f->controlID        	= ATOMS_DET_RING_voltDet2;

	f = df( DF_VOLTAGE_DETECTOR2_TIME);
	f->active          		= 1;      
	f->idName          		= "DET2_TIME"; 
	f->tableColumnName 		= "det. 2 time";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.detectionTime) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelDetection();
	f->controlID        	= ATOMS_DET_NUMERIC_time;
	f->timebase 			= TIMEBASE_ANALOG;

	f = df( DF_VOLTAGE_DETECTOR2_TIME_REFERENCE);
	f->active          		= 1;      
	f->idName          		= "DET2_TIME_REFERENCE"; 
	f->tableColumnName 		= "det. 2 time reference";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_INTEGER;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.detectionTimeReference) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelDetection();
	f->controlID        	= ATOMS_DET_RING_referencePos;
	

// purif start
	f = df( DF_HASMULTIPLES);
	f->active          		= 1;      // active
	f->idName          		= "MULTIPLE";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "multiple";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_YES_NO;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.hasMultiples) - (unsigned) (&a)); // reference Content
	f->panelID				= panelAtoms;
	f->controlID        	= ATOMS_CHECKBOX_multiple;

	f = df( DF_NMULTIPLES);
	f->active          		= 1;      // active
	f->idName          		= "MULTIPLICITY";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "multiplicity";  //  
	f->tableColumnWidth 	= 80;
	f->dataType        		= VAL_INTEGER;
	f->tableCellType        = VAL_INTEGER;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.nMultiples) - (unsigned) (&a)); // reference Content
	f->panelID				= panelAtoms;
	f->controlID        	= ATOMS_NUMERIC_multiplicity;
	
	f = df( DF_MULTIPLE_DELAY);
	f->active          		= 1;      // active
	f->idName          		= "DELAY";   // identifier name (for use in *.SES files) 
	f->tableColumnName 		= "delay";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.delay) - (unsigned) (&a)); // reference Content
	f->panelID				= panelAtoms;
	f->controlID        	= ATOMS_NUMERIC_delai;	

// purif end
/*	f = df( DF_AUTO_CALCULATE_TIMES);
	f->active          		= 1;      
	f->idName          		= "AUTO_CALC_TIMES"; 
	f->tableColumnName 		= "auto calculate times";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_YES_NO;
	f->tableCellType        = VAL_YES_NO;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.autoCalculateTimes) - (unsigned) (&a)); // reference Content
	f->panelID				= panelAtoms;
	f->controlID        	= ATOMS_TOGGLEBUTTON_autoCalc;
*/

// ---------------------------------------------
//     initialize position data fields
// ---------------------------------------------
//  repumper
	f = df( POS_REPUMPER);
	f->active          		= 1;      
	f->idName          		= "REPUMPER"; 
	f->tableColumnName 		= "abs. time repumper [�s]";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->controlID        	= ATOMS_VEL_NUMERIC_timeRep;
	f->contentOffset        = ((unsigned) (&a.time[POS_REPUMPER]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelVelocity();
	f->positionName    		= "repumper";

// time laser 1
	f = df( POS_LASER1);
	f->active          		= 1;      
	f->idName          		= "LASER1"; 
	f->graphDisplayName 	= "Laser 1";
	f->tableColumnName 		= "abs. time laser 1 [�s]";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.time[POS_LASER1]) - (unsigned) (&a)); // reference Content
	f->controlID        	= ATOMS_CIRC_NUMERIC_timeLaser1;
	f->panelID				= subPanelCirc();
	f->positionName    		= "laser 1 (circ.)";

// time purif 1
	f = df( POS_PURIF);
	f->active          		= 1;      
	f->idName          		= "PURIF"; 
	f->tableColumnName 		= "time purif [�s]";  //  
	f->tableColumnWidth 	= 60;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.time[POS_PURIF]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelState();
	f->controlID        	= ATOMS_STAT_NUMERIC_purifStart_a;
	f->positionName    		= "purif";

									
// time Ramsey 1
	f = df( POS_RAMSEY1);
	f->active          		= 1;      
	f->idName          		= "RAMSEY1"; 
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_RAMSEY;
	f->graphDisplayName 	= "R1";
	f->tableColumnName 		= "time Ramsey1 [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.time[POS_RAMSEY1]) - (unsigned) (&a)); // reference Content
	f->controlID        	= -1;
	f->panelID				= -1;
	f->positionName    		= "Ramsey zone 1";
	
	
// time Ring 1
	f = df( POS_RING1_C1);
	f->active          		= 1;      
	f->idName          		= "RING1_C1"; 
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_CAVITYRING;
//	f->graphDisplayName 	= "";

	f->tableColumnName 		= "time ring1 (C1) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_RING1_C1]) - (unsigned) (&a)); // reference Content
	f->panelID				= -1;
	f->controlID        	= -1;
	f->positionName    		= "ring 1 (C1)";
	
// time Ring 2
	f = df( POS_RING2_C1);
	f->active          		= 1;      
	f->idName          		= "RING2_C1"; 
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_CAVITYRING;
//	f->graphDisplayName 	= "";
	f->tableColumnName 		= "time ring2 (C1) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_RING2_C1]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(0);
	f->controlID        	= -1;
	f->positionName    		= "ring 2 (C1)";

// time cavity 1
	f = df( POS_START_CAVITY1);
	f->active          		= 1;      
	f->idName          		= "START_CAVITY1"; 
	f->graphDisplay			= DISPLAY_2DGRAPH_CAVITYMODE;
	f->graphDisplayColor	= VAL_COLOR_CAVITYMODE;
	f->tableColumnName 		= "time start of mode (C1) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_START_CAVITY1]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(0);
	f->controlID        	= ATOMS_CAV_NUMERIC_startCavity;
	f->positionName    		= "start of mode (C1)";

// time cavity 1
	f = df( POS_CENTER_CAVITY1);
	f->active          		= 1;      
	f->idName          		= "CENTER_CAVITY1"; 
	f->graphDisplay			= 1;
	f->graphDisplayName 	= "C1";
	f->graphDisplayColor	= VAL_COLOR_CAVITY ;
	f->tableColumnName 		= "time center of mode (C1) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_CENTER_CAVITY1]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(0);
	f->controlID        	= ATOMS_CAV_NUMERIC_centerCavity;
	f->positionName    		= "center of mode (C1)";

// time cavity 1
	f = df( POS_END_CAVITY1);
	f->active          		= 1;      
	f->idName          		= "END_CAVITY1"; 
	f->graphDisplay			= DISPLAY_2DGRAPH_CAVITYMODE;
	f->graphDisplayColor	= VAL_COLOR_CAVITYMODE;
	f->tableColumnName 		= "time end of mode (C1) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_END_CAVITY1]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(0);
	f->controlID        	= ATOMS_CAV_NUMERIC_endCavity;
	f->positionName    		= "end of mode (C1)";

// time Ramsey 2
	f = df( POS_RAMSEY2);
	f->active          		= 1;      
	f->idName          		= "RAMSEY2"; 
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_RAMSEY;
	f->graphDisplayName 	= "R2";
	f->tableColumnName 		= "time Ramsey2 [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.time[POS_RAMSEY2]) - (unsigned) (&a)); // reference Content
	f->panelID				= -1;
	f->controlID        	= -1;
	f->positionName    		= "Ramsey zone 2";
	
	
// time Ring 2
	f = df( POS_RING1_C2);
	f->active          		= 1;      
	f->idName          		= "RING1_C2"; 
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_CAVITYRING;
//	f->graphDisplayName 	= "";
	f->tableColumnName 		= "time ring1 (C2) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_RING1_C2]) - (unsigned) (&a)); // reference Content
	f->panelID				= -1;
	f->controlID        	= -1;
	f->positionName    		= "ring 1 (C2)";
	f->cavity 				= 2;
	
// time Ring 2
	f = df( POS_RING2_C2);
	f->active          		= 1;      
	f->idName          		= "RING2_C2"; 
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_CAVITYRING;
//	f->graphDisplayName 	= "";
	f->tableColumnName 		= "time ring2 (C2) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_RING2_C2]) - (unsigned) (&a)); // reference Content
	f->panelID				= -1;
	f->controlID        	= -1;
	f->positionName    		= "ring 2 (C2)";
	f->cavity 				= 2;

// time cavity 2
	f = df( POS_START_CAVITY2);
	f->active          		= 1;      
	f->idName          		= "START_CAVITY2"; 
	f->graphDisplay			= DISPLAY_2DGRAPH_CAVITYMODE;
	f->graphDisplayColor	= VAL_COLOR_CAVITYMODE;
	f->tableColumnName 		= "time start of mode (C2) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_START_CAVITY2]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(1);
	f->controlID        	= ATOMS_CAV_NUMERIC_startCavity;
	f->positionName    		= "start of mode (C2)";
	f->cavity 				= 2;

// time cavity 2
	f = df( POS_CENTER_CAVITY2);
	f->active          		= 1;      
	f->idName          		= "CENTER_CAVITY2"; 
	f->graphDisplay			= 1;
	f->graphDisplayName 	= "C2";
	f->graphDisplayColor	= VAL_COLOR_CAVITY ;
	f->tableColumnName 		= "time center of mode (C2) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_CENTER_CAVITY2]) - (unsigned) (&a)); // reference Content
	f->panelID				= subPanelCavity(1);
	f->controlID        	= ATOMS_CAV_NUMERIC_centerCavity;
	f->positionName    		= "center of mode (C2)";
	f->cavity 				= 2;

// time cavity 2
	f = df( POS_END_CAVITY2);
	f->active          		= 1;      
	f->idName          		= "END_CAVITY2"; 
	f->graphDisplay			= DISPLAY_2DGRAPH_CAVITYMODE;
	f->graphDisplayColor	= VAL_COLOR_CAVITYMODE;
	f->tableColumnName 		= "time end of mode (C2) [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->contentOffset        = ((unsigned) (&a.time[POS_END_CAVITY2]) - (unsigned) (&a)); // reference Content
	f->isEditable      		= 0;
	f->panelID				= subPanelCavity(1);
	f->controlID        	= ATOMS_CAV_NUMERIC_endCavity;
	f->positionName    		= "end of mode (C2)";
	f->cavity 				= 2;

// time Ramsey 3
	f = df( POS_RAMSEY3);
	f->active          		= 1;      
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_RAMSEY;
	f->graphDisplayName 	= "R3";
	f->idName          		= "RAMSEY3"; 
	f->tableColumnName 		= "time Ramsey3 [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.time[POS_RAMSEY2]) - (unsigned) (&a)); // reference Content
	f->panelID				= -1;
	f->controlID        	= -1;
	f->positionName    		= "Ramsey zone 3";
	f->cavity 				= 2;

// time detector 1
	f = df( POS_DETECTOR1);
	f->active          		= 1;      
	f->idName          		= "DETECTOR1"; 
	f->tableColumnName 		= "time det.1 [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_DETECTOR1]) - (unsigned) (&a)); // reference Content
//	f->panelID				= subPanelDetection();
//	f->controlID        	= ATOMS_DET_NUMERIC_detector1;
	f->positionName    		= "detector 1";
	
	

// time detector 2
	f = df( POS_DETECTOR2);
	f->active          		= 1;      
	f->idName          		= "DETECTOR2"; 
	f->tableColumnName 		= "time det.2 [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 0;
	f->contentOffset        = ((unsigned) (&a.time[POS_DETECTOR2]) - (unsigned) (&a)); // reference Content
//	f->panelID				= subPanelDetection();
//	f->controlID        	= ATOMS_DET_NUMERIC_detector2;
	f->positionName    		= "detector 2";
	

	f = df( POS_SHIELDINGBOX_ENTRANCE);
	f->active          		= 1;      
	f->idName          		= "ENTRY_SHIELDINGBOX"; 
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_SHIELDINGBOX;
	f->graphDisplayName 	= "entrance shileding box";
	f->tableColumnName 		= "time entry shieldingbox [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.time[POS_SHIELDINGBOX_ENTRANCE]) - (unsigned) (&a)); // reference Content
	f->panelID				= -1;
	f->controlID        	= -1;
	f->positionName    		= "shielding box entrance";
	
	f = df( POS_SHIELDINGBOX_EXIT);
	f->active          		= 1;      
	f->idName          		= "EXIT_SHIELDINGBOX"; 
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_SHIELDINGBOX;
	f->graphDisplayName 	= "exit shileding box";
	f->tableColumnName 		= "time exit shieldingbox [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.time[POS_SHIELDINGBOX_EXIT]) - (unsigned) (&a)); // reference Content
	f->panelID				= -1;
	f->controlID        	= -1;
	f->positionName    		= "shielding box exit";

	f = df( POS_HOLE_CIRC_BOX);
	f->active          		= 1;      
	f->idName          		= "HOLE_CIRC_BOX"; 
	f->graphDisplay			= 1;
	f->graphDisplayColor	= VAL_COLOR_CIRCBOX_HOLE;
	f->graphDisplayName 	= "hole circ box";
	f->tableColumnName 		= "time hole circ box [�s]";  //  
	f->tableColumnWidth 	= 70;
	f->dataType        		= VAL_DOUBLE;
	f->tableCellType        = VAL_DOUBLE;
	f->isEditable      		= 1;
	f->contentOffset        = ((unsigned) (&a.time[POS_HOLE_CIRC_BOX]) - (unsigned) (&a)); // reference Content
	f->panelID				= -1;
	f->controlID        	= -1;
	f->positionName    		= "hole circ box";

};





void DATAFIELD_init  (t_dataField *f)
{
	f->active          = 0;
	f->idName          = "?";
	f->graphDisplay = 0;
	f->graphDisplayName = "";
	f->graphDisplayColor = VAL_BLACK;
	f->tableColumnName = "";
	f->tableColumnWidth 	   = 70;
	f->dataType        = VAL_DOUBLE;
	f->tableCellType   = VAL_DOUBLE;
	f->isEditable      = 0;
	f->panelID         = -1;
	f->controlID       = -1;
	f->contentOffset   = ULONG_MAX;
	f->controlIDposition = -1;
	f->controlIDlabel = -1;
	f->positionName = "";
	f->cavity        = 1;
	f->timebase 	 = TIMEBASE_DIGITAL;
};


const char *DATAFIELD_graphDisplayName (int datafieldID)
{
	t_dataField *d;
	
	d = df(datafieldID);
	if (d == NULL) return "";
	return d->graphDisplayName;
}


int DATAFIELD_fromName (char *name)
{
	int i;

	if (name == NULL) return -1;
	if (name[0] == 0) return -1;
	for (i = 0; i < N_DATAFIELDS; i++) {
		if (strcmp (DF[i].idName, name) == 0) return i;
	}

	return -1;
}


int dataFieldIDfromTableColumn (t_smanagerConfig *c, int tableCol)
{
	int i;
/*	
	for (i = 0; i < N_DATA_FIELDS; i++)
	   if (f->tableColumnNr == tableCol) return i;
	return -1;
*/
	return 0;
}


int nTableColumns ()
{
/*	static int firstCall = 1,
	
	if (firstcall) {
	
	}
	else return nTableColumns;
*/
	return 0;
}




/***************************************************************************

     t_SessionConfig
            
****************************************************************************/




void initSessionManagerConfig (t_smanagerConfig *c)
{
	c->defaultPath[0] = 0;

	c->defaultAtomConfig = (t_atomConfig *) malloc (sizeof(t_atomConfig));
	ATOMCONFIG_init (c->defaultAtomConfig, NULL);
	
	// determine all datafields that contain positions
	c->listOfSessions = ListCreate(sizeof (t_session*));
    c->activeSessionNr = -1;
    
    c->TCPserverName = strnewcopy (NULL, "lucy");
    
    
	GetDir (c->dataPath);
	RUN_createTodaysDataPath (c);
}




/***************************************************************************

     t_atomConfig
            
****************************************************************************/



void ATOMCONFIG_init (t_atomConfig *c, t_atomConfig *defaultc)
{
	int i, n, k;
	
	
	int defaultT[N_DATAFIELDS] = {
	    DF_NR,
		DF_ACTIVE,         
		DF_NAME,          
		DF_VELOCITY,
		POS_LASER1,           
		POS_START_CAVITY1,
		POS_CENTER_CAVITY1,
		POS_END_CAVITY1,
		POS_DETECTOR1,
		POS_DETECTOR2,

		-1
	};
	
	if (defaultc != NULL) {
		memcpy (c, defaultc, sizeof (t_atomConfig));
	}
	else {
		for (i = 0; i < N_RF_CHANNELS; i++) {
			c->rfMultiplexerFrequency[i] = 100;
			c->rfMultiplexerVelocity [i] = 100;
			c->rfMultiplexerPower    [i] = 0;
		}
		for (i = 0; i < N_POSITIONS; i++) {
			c->position[i] = 0;
		}
		c->positionReference = POS_LASER1;
	}
	c->activeConfig = 0;
	
	n = 0;
	while (defaultT[n] != -1) n++;
	for (i = 0; i < N_TABLE_CONFIGS; i++) {
		c->tableConfigName[i][0] = 0;
		c->nTableColumns[i] = n;
		memcpy (c->tableColumns[i], defaultT, sizeof(int)*n);
	}

	c->referenceAtom   = 1;
    c->referenceAtomPosition = POS_LASER1;
    
    for (i = 0; i < N_CAVITIES; i++) {
    	c->transferFunct[i] = TRANSFERFUNCT_TYPE_ABC_FORMULA;
    	for (k = 0; k < N_PARAMETERS_TRANSFER_FUNCT; k++) {
			c->parametersTransferFunct[i][k] = 0;
		}
		c->parametersTransferFunct[i][1] = 1.0;
		c->setDefaultVoltage[i] = 1; 
		c->killerDefaultVoltage[i] = 1.0;
		c->killerDefaultDetuning[i] = 0;
	}    
}


/*******************************************************************************
/*******************************************************************************

      Data structure "t_session" 
      
/*******************************************************************************
********************************************************************************/


t_session *SESSION_duplicate (t_session *s)
{
	t_session *new;
	int i;
	
	
	Breakpoint();


	new = SESSION_new ();
	memcpy (new, s, sizeof (t_session));
	

	new->sequence = NULL;
	new->comments = strnewcopy (NULL, s->comments);
	new->lAtoms				  = ATOM_listDuplicate (s->lAtoms);
	new->lFilters             = FILTER_listDuplicate (s->lFilters);
	new->lDetectionParameters = DETECTIONPAR_listDuplicate (s->lDetectionParameters);
	new->lSweeps 			  = SWEEP_listDuplicate (s->lSweeps);
	new->lEvents			  = EVENT_listDuplicate (s->lEvents);
	for (i = 0; i < N_DETECTORS; i++) {
		new->lTimeIntervals[i] = TIMEINTERVAL_listDuplicate (s->lTimeIntervals[i]);
	}
	new->lPlotItems  = PLOTITEM_listDuplicate (s->lPlotItems);
	
	return new;

}


void SESSION_init (t_session *s)
{
    int i;
    
    s->filename[0]  = 0;
    s->programVersion = 0.0;
    s->shortcut		= -1;
    s->changes		= 0;
    s->readOnly     = 0;
    s->startNr      = -1;
    s->lastStarted  = -1;
    s->dateStr[0]   = 0;
    s->updatePoints = 1;
    
	s->activeAtomNo = 1;

	s->atomConfig = (t_atomConfig *) malloc (sizeof(t_atomConfig));
	ATOMCONFIG_init (s->atomConfig, smanagerConfig->defaultAtomConfig);
	s->lAtoms   = ListCreate (sizeof(t_atom *));
	s->laser1AlwaysOn = 0;
	s->laser2AlwaysOn = 1;
    s->optPumpingAlwaysOn = 1;

    s->repumperAlwaysOn = 0;
    s->repumperFrequency = 0;
	s->repumperPower = 0;
	 
    s->sequence         = NULL;
    s->saveRunData      = 0;
    s->saveArrivalTimes = 0;
    s->generateRandomCounterData = 0;


    s->comments     = NULL;

	s->lFilters = ListCreate (sizeof(t_filter *));
	s->lDetectionParameters = ListCreate (sizeof(t_detectionParameters *));
	s->lSweeps =  ListCreate (sizeof(t_sweep *));
	s->lEvents =  ListCreate (sizeof(t_event *));
	s->plotSweepParameter = 0;

	s->mode         = SESSIONMODE_STANDARD;

	s->curveEnd_us   = 1000.0;
	s->curveStart_us = 0.0;
	s->nAverages    = 10;


	s->nRuns = 1;
	s->nSweepPoints = 1;
	s->nCurves = 1;
	
	s->transferAtom = 0;
	s->transferOn   = 0;
	for (i = 0; i < N_SESSION_TRANSFER_LEVELS; i++) {
		s->transferLevel[i] = 0;
//		s->transferInterval[i] = 1;
	}
	
	s->DIG_voltageFrom = 0;
	s->DIG_voltageTo   = 3;
	s->DIG_nSteps = 50;
	s->DIG_channel = A_CH_VOLTAGE_DETECTOR;
	s->DIG_copiesPerStep = 1;
	strcpy (s->DIG_windowName, DEFAULT_DIG_WINDOWNAME);
	
	s->nLevels = 2;
	for (i = 0; i < MAX_LEVELS; i++) {
		s->levelNames[i][0] = 0;
		s->levelVoltages[i] = 0;
	}
	strcpy (s->levelNames[0], "|e>");
	strcpy (s->levelNames[1], "|g>");
	strcpy (s->levelNames[2], "52f");
	strcpy (s->levelNames[3], "52d_5/2");
	
	for (i = 0; i < N_COUNTERS; i++) {
		s->counterOn[i] = 0;
	}
//	s->counterAuto = 1;

	
	for (i = 0; i < N_DETECTORS; i++) {
		s->lTimeIntervals[i] = ListCreate (sizeof(t_timeInterval *));
	}
	
	s->lPlotItems = ListCreate (sizeof(t_plotItem *));   
	
/*	s->smallestTime = 0;
	s->largestTime  = 0;
	s->dSmallestTime_us = 0.0;
	s->dLargestTime_us = 0.0;

*/	
/*
	for (i = 0; i < N_CAVITIES; i++) {
		s->parametersTransferFunct[i][0] = 49.5;
		s->parametersTransferFunct[i][1] = 0.62;
		s->parametersTransferFunct[i][2] = 0;
		s->killerDefaultVoltage[i]      = 0;
	}
*/

	s->transmitKillerCurves = 1;
	s->selectedPlotItem = -1;
	
	for (i = 0; i < N_SWEEPTYPES; i++) s->nSweeps[i] = 0;
	
	for (i = 0; i < N_DIO_CHANNELS; i++) {
		s->digitalOutputs_preset[i] = 0;
		s->digitalOutputs_onOff[i] = 0;
	}

	s->loadedWithRunData = 0;
	s->run = NULL;
	s->FIRST_KILLER_CHANNEL=0;
    s->waveformDet2 = NULL;
	
}; 



// ---------------------------------------------
//   free session
// ---------------------------------------------
void SESSION_free (t_session *s)
{
    int i, n;

    t_atom *a;
    t_detectionParameters *d;
    t_sweep *sw;
    t_event *e;
    t_plotItem *p;
    t_filter *f;

	if (s == NULL) return;
	// ---------------------------------------------
	//   free atoms 
	// ---------------------------------------------
    for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
		a = ATOM_ptr (s, i);
		ATOM_free (a);
		free (a);
	}
	ListDispose (s->lAtoms);
	s->lAtoms = NULL;

	
	free (s->atomConfig);
	s->atomConfig = NULL;
	
	SEQUENCE_free (s->sequence);
	s->sequence = NULL;

	// ---------------------------------------------
	//   free detection parameters
	// ---------------------------------------------
    for (i = 1; i <= ListNumItems (s->lDetectionParameters); i++) {
		d = DETECTIONPAR_ptr (s, i);
		DETECTIONPAR_free (d);
		free (d);
	}
	ListDispose (s->lDetectionParameters);
	s->lDetectionParameters = NULL;
	
	free (s->comments);
	
	SWEEP_freeAll (s);
	ListDispose (s->lSweeps);
	s->lSweeps = NULL;

	EVENT_freeAll (s->lEvents);
	ListDispose (s->lEvents);
	s->lEvents = NULL;
	
	for (i = 0; i < N_DETECTORS; i++) {
		TIMEINTERVAL_freeList (s->lTimeIntervals[i]);
		ListDispose (s->lTimeIntervals[i]);
		s->lTimeIntervals[i] = NULL;
	}

	// ---------------------------------------------
	//   free plot Items
	// ---------------------------------------------
    for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		p = PLOTITEM_ptr (s, i);
		PLOTITEM_free (p);
		free (p);
	}
	ListDispose (s->lPlotItems);
	s->lPlotItems = NULL;
	

	// ---------------------------------------------
	//   free filters
	// ---------------------------------------------
	n = ListNumItems (s->lFilters);
    for (i = 1; i <= n; i++) {
		ListGetItem (s->lFilters, &f, i);
		FILTER_free (f);
	}
	ListDispose (s->lFilters);
	s->lFilters = NULL;
}


// ---------------------------------------------
//   create new session 
// ---------------------------------------------
t_session *SESSION_new (void)
{
    t_session *new;
    
    new = (t_session *) malloc (sizeof(t_session));
    return new;
}




// ---------------------------------------------
//    get sequence 'nr' from list
// ---------------------------------------------
t_session *SESSION_ptr (int nr)
{
	t_session *s;
	if ((nr < 1) || (nr > ListNumItems (smanagerConfig->listOfSessions))) return NULL;
	ListGetItem (smanagerConfig->listOfSessions, &s, nr);
	return s;
}    



// -----------------------------------------------------
//    chekc if session with identical filename exists
// -----------------------------------------------------
int SESSION_filenameExists (const char *filename)
{
	int i;
	t_session *s;
	
	for (i = ListNumItems (smanagerConfig->listOfSessions); i > 0; i--) {
		ListGetItem (smanagerConfig->listOfSessions, &s, i);
		if (CompareStrings (s->filename, 0, filename, 0, 0) == 0) return 1;
	}
	return 0;
}


int SESSION_getTransferLevelNr (t_session *s, int level)
{
	int i;
	
	for (i = 0; i < N_SESSION_TRANSFER_LEVELS; i++) {
		if (s->transferLevel[i] == level) return i;
	}
	
	return -1;
}



int SESSION_nTotalAtoms (t_session *s)
{
	int i, nAtoms;
	t_atom *a;
	
	nAtoms = 0;
	for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
		a = ATOM_ptr (s, i);
		if (a->active) {
			if (a->hasMultiples) nAtoms += a->nMultiples;
			else nAtoms++;
		}
	}
	return nAtoms;
}

/***************************************************************************
/*******************************************************************************

     functions t_atom

/*******************************************************************************
****************************************************************************/

double ATOM_time(t_atom* a, double position) 
{
	return 1000*position/a->velocity;  
}


void ATOM_resetAbsoluteTimes  (t_atom *a)
{
	int i;
	
	for (i = 0; i < N_POSITIONS; i++)
		a->time[i] = 0;
}



void ATOM_init (t_atom *a)
{
	int i;

  	a->name[0]    = 0;
	a->active     = 1;
	a->hasMultiples	  = 0;
	a->nMultiples = 2;
	a->delay	  = 5000;
	
// parameters circularization	
//	a->alwaysOnL1			= 0;
	a->durationL1 			= 0;
	a->timeL2 = 0;
	a->durationL2 = 0;
	a->timeOP = 0;
	a->durationOP = 0;

	a->circTriggerRF        = 0;
	a->circTriggerRamp      = 0;
	a->circ52dTime		    = 0;
	a->circ52dDuration        = 0;
	
	// state preparation
	a->state      			= STATE_G;
	a->purifStart_e 		= 0;
	a->purifDuration_e   		= 0;
	a->purifStart_g 		= 0;
	a->purifDuration_g   		= 0;
	//  velocity selection
	a->velocitySelection	= 0;
	a->velocity				= 300;
	a->velocitySpread       = 10;
	a->velocitySpreadDoppler= 20;
	a->repumperFrequency	= 0;
	a->repumperPower		= 0;
	a->repumperDuration		= 0;
	a->repumperTime			= 0;
	a->repumperTimeReference = POS_REPUMPER;
//	a->repumperAlwaysOn     = 0;	
	a->depumperAngleDuration     = 0;
	a->depumperAngleTime	= 0;
	a->lAtomEvents = ListCreate (sizeof (t_atomEvent *));
	
	// killer
	a->killerTimeReference[0]  = POS_CENTER_CAVITY1;
	a->killerTimeReference[1]  = POS_CENTER_CAVITY2;
	for (i = 0; i < N_CAVITIES; i++) {
		a->killerStartFirst[i]     = 0;
		a->nKillerPoints[i]        = 0;
		a->killerPoints[i]     = NULL;
		a->killerActive[i] = 0;

	}

	a->detect				= 1;
	a->detectionParameters  = 0;
	a->detectionLevel = 0;
	a->detectionTime = 0;
	a->detectionTimeReference = POS_LASER1;
	a->detectionUseLevelsOfTransfer = 1;
	a->detectionSetLevel     = 0;

	ATOM_resetAbsoluteTimes  (a);
}


// free all contents of t_atom
void ATOM_free (t_atom *a)
{
	int i;
	t_atomEvent *e;
	
	for (i = 1; i <= ListNumItems (a->lAtomEvents); i++) {
		e = ATOMEVENT_ptr (a, i);
		ATOMEVENT_free (e);
		free (e);
	}
	ListDispose (a->lAtomEvents);
	a->lAtomEvents = NULL;

	for (i = 0; i < N_CAVITIES; i++) {
		free (a->killerPoints[i]);
		a->killerPoints[i] = NULL;
	}
}



t_atom *ATOM_new (t_session *s)
{
	t_atom *new;

    new = (t_atom *) malloc (sizeof (t_atom));
    ListInsertItem (s->lAtoms, &new, END_OF_LIST);
    
    return new;
}



void ATOM_delete (t_session *session, int nr)
{
	t_atom *old;
	int i;
	
	ListRemoveItem (session->lAtoms, &old, nr);
	ATOM_free (old);
	free (old);
}



void ATOM_duplicate (t_atom *dest, t_atom *source)
{
 	
 	int i;
 	t_atomEvent *old, *new;
 	
 	memcpy (dest, source, sizeof (t_atom));
    
	// copy killer points
	for (i = 0; i < N_CAVITIES; i++) {
		dest->killerPoints[i] = (t_point *) malloc (dest->nKillerPoints[i] * sizeof (t_point));
		memcpy (dest->killerPoints[i], source->killerPoints[i], dest->nKillerPoints[i] * sizeof (t_point));
	}
	
	// copy events
	dest->lAtomEvents = ListCreate (sizeof (t_atomEvent *));
	for (i = 1; i <= ListNumItems (source->lAtomEvents); i++) {
		new = ATOMEVENT_new (dest);
		old = ATOMEVENT_ptr (source, i);
		ATOMEVENT_duplicate (new, old);
	}
	

}


t_atom *ATOM_ptr (t_session *session, int nr)
{
    t_atom *a;
    
	if ((nr > ListNumItems (session->lAtoms)) || (nr < 1))  return NULL;
	ListGetItem (session->lAtoms, &a, nr);
	return a;
}


ListType ATOM_listDuplicate (ListType list)
{
	ListType newList;
	t_atom *a, *new;
	int i, n;
	
	n = ListNumItems (list);
	newList = ListCreate (sizeof(t_atom *));
	for (i = 1; i <= n; i++) {
		ListGetItem (list, &a, i);
		new = (t_atom *) malloc (sizeof (t_atom));
		ATOM_duplicate (new, a);
		ListInsertItem (newList, &new, END_OF_LIST);
	}

	return newList;

}



//=======================================================================
//
//
//=======================================================================


t_atomEvent *ATOMEVENT_ptr (t_atom *a, int nr)
{
    t_atomEvent *e;
    
	if ((nr > ListNumItems (a->lAtomEvents)) || (nr < 1)) return NULL;
	ListGetItem (a->lAtomEvents, &e, nr);
	return e;
}


void ATOMEVENT_init (t_atomEvent *e)
{
	e->name[0]               = 0; 
	e->active				 = 1;
	e->eventStyle			 = 0;
	e->deviceType 			 = 0;
	e->digitalChannel        = 0;
	e->analogChannel         = 0;
	e->pulseStartReference   = POS_LASER1;
	e->pulseStartVary		 = 0;
	e->pulseStartFirst		 = 0;
	e->pulseStartIncrement	 = 0;
	e->pulseDurationVary	 = 0;
	e->pulseDurationFirst    = 0;
	e->pulseDurationIncrement= 0;
	e->voltageVary 			 = 0;
	e->voltageFirst			 = 0;
	e->voltageIncrement		 = 0;
}



t_atomEvent *ATOMEVENT_new (t_atom *a)
{
	t_atomEvent *new;

    new = (t_atomEvent *) malloc (sizeof (t_atomEvent));
    ListInsertItem (a->lAtomEvents, &new, END_OF_LIST);
    
    return new;
}

void ATOMEVENT_free (t_atomEvent *e)
{
	
}



void ATOMEVENT_delete (t_atom *a, int nr)
{
	t_atomEvent *old;
	
	ListRemoveItem (a->lAtomEvents, &old, nr);
	ATOMEVENT_free (old);
	free (old);
}


void ATOMEVENT_duplicate (t_atomEvent *dest, t_atomEvent *source)
{
 	// copy all data
 	memcpy (dest, source, sizeof (t_atomEvent));
}

//=======================================================================
//
//
//=======================================================================



void RUN_init (t_run *r, t_graph *w)
{
	int i;
	
	strcpy (r->dateStr, "??/??/????");
	strcpy (r->timeStr, "??:??");
	r->softwareVersionStr[0]= 0;
	r->startNr 				= 0;
	r->infoStr[0]           = 0;

	r->dataDirectory[0] 	= 0;
	r->filenameSession[0] 	= 0;
	r->filenameSequence[0] 	= 0;
	r->filenameRun[0] 		= 0;
	r->filenameData[0]    	= 0;

	r->nRuns         	  	= 0;
	r->nRepetitionsPerRun 	= 0;
	r->nCopiesPerRepetition = 0;
	r->nAveragesToDo 		= 0;
	r->mode					= SESSIONMODE_STANDARD;

    r->lastData = NULL;
	for (i = 0; i < N_COUNTERS; i++) {
		r->nData[i] = 0;
		r->data[i]  = NULL;
	}

	r->dataSum	= (t_counterData *)  malloc (sizeof (t_counterData));
	COUNTERDATA_init (r->dataSum, 0, 0);		
	
	r->plotWindow   = w;
    r->sweep 		= NULL;
    r->freeSession  = 0;
    r->session 		= NULL;
    
    for (i = 0; i < N_DETECTORS; i++) {
    	r->lTimeIntervals[i] = ListCreate (sizeof (t_timeInterval*));
    }
    r->panelCounts = -1;
   	r->seqIni      = Ini_New (0);
   	r->dataSaved   = 0;
   	
   	for (i = 0; i < N_DIO_CHANNELS; i++) r->lastStateDigitalLine[i] = 0;
}


t_run *RUN_new (void)
{
	t_run *r;
	
	r = (t_run *) malloc (sizeof (t_run));
	RUN_init (r, NULL);
	return r;
}




void RUN_free (t_run *r)
{
    int i, f, c;
    t_counterData *data;
    
    if (r == NULL) return; 

//    free (r->sumCounts);
 //   r->sumCounts = 0;
	free (r->dataSum);
	
	
	// free list of data
	for (c = 0; c < N_COUNTERS; c++) {
		for (i = 0; i < r->nData[c]; i++) {
			if (r->data[c][i] != NULL) {
				if (r->data[c][i] == r->lastData) r->lastData = NULL;
				COUNTERDATA_free (r->data[c][i]);
				r->data[c][i] = NULL;
			}
		}
		free (r->data[c]);
		r->data[c] = NULL;
		r->nData[c] = 0;
	}

	COUNTERDATA_free (r->lastData);
	free (r->lastData);
	r->lastData = 0;
	
	// free session
	if (r->freeSession) {
		SESSION_free (r->session);
		free (r->session);
		r->session = NULL;
	}

	// free list of time intervals
    for (i = 0; i < N_DETECTORS; i++) {
		TIMEINTERVAL_freeList (r->lTimeIntervals[i]);
		ListDispose (r->lTimeIntervals[i]);
		r->lTimeIntervals[i] = 0;
	}

	Ini_Dispose (r->seqIni);
	r->seqIni = NULL;

	// unlink panel
	if (r->panelCounts > 0) {
		SetPanelAttribute (r->panelCounts, ATTR_CALLBACK_DATA, NULL);
		r->panelCounts = -1;
	}
	
}


int RUN_datasetIndex(t_run *r, int run, int repetition)
{
	return run *r->nRepetitionsPerRun + repetition;
}



int RUN_dataMaxDatasets (t_run *r, int counter)
{
	t_session *s;
	
	s = r->session;
	if (s == NULL) return 0;
	if (!s->counterOn[counter]) return 0;
	
	return r->nRepetitionsPerRun * r->nRuns;
}



/*
int RUN_dataIndex (t_run *r, t_counterData *d)
{
	int 
	mult = s->transferOn ? 2 : 1;
	return (d->run * r->nRepetitionsPerRun * mult) + d->repetition + d->part;
}
*/

/*
int CVICALLBACK RUN_listDataCompare (void *item1, void *item2)
{
	t_counterData *data1, *data2;
	
	data1 = * ((t_counterData **) item1);
	data2 = * ((t_counterData **) item2);
	if (data1->run < data2->run) return -1;
	if (data1->run > data2->run) return 1;
	if (data1->repetition < data2->repetition) return -1;
	if (data1->repetition > data2->repetition) return 1;
	if (data1->counterNr < data2->counterNr) return -1;
	if (data1->counterNr > data2->counterNr) return 1;
	return 0;
}
*/

void RUN_putCounterData (t_run *r, t_counterData *data)
{
	int index;
	int ctr;
	
	if (data == NULL) return;
	
	ctr = data->counterNr;
	
	if (r->data[ctr] == NULL) {
		// allocate pointer array
		r->nData[ctr] = RUN_dataMaxDatasets (r, ctr);
		r->data[ctr] = (t_counterData **) calloc (r->nData[ctr], sizeof (t_counterData *));
	}
	
	index = RUN_datasetIndex(r, data->run, data->repetition);
	if (index >= r->nData[ctr]) return;
	// free old data
	COUNTERDATA_free (r->data[ctr][index]);
	// store pointer to new data
	r->data[ctr][index] = data;
}



//=======================================================================
//
//
//=======================================================================


t_detectionParameters *DETECTIONPAR_ptr (t_session *s, int nr)
{
    t_detectionParameters *d;
    
	if ((nr > ListNumItems (s->lDetectionParameters)) || (nr < 1)) return NULL;
	ListGetItem (s->lDetectionParameters, &d, nr);
	return d;
}


void DETECTIONPAR_init (t_detectionParameters *d)
{
	int i;
	
	d->name[0]    = 0;
	d->atoms[0]   = 0;
	d->detectorActive[0]   = 0;
	d->detectorActive[1]   = 1;	

// DETECTOR 1 (flat)
	// detection ramp
	d->det1_rampStartVoltage = 0.0;
	d->det1_rampStopVoltage  = 0.0;
	d->det1_rampDuration     = 0.0;
	d->det1_rampTrigger		= 0.0;
	d->det1_rampTriggerReference = POS_LASER1;
	// time windows e/g/i
	for (i = 0; i < MAX_LEVELS; i++) {
		d->det1_levelActive[i]  = 1;
		d->det1_timeStart[i] = 0.0;
		d->det1_timeEnd[i]	 = 0.0;
	}

// DETECTOR 2 (roof)
//	d->det2_useTimeWindow   = 0;
	d->det2_timeStart		= 0.0;
	d->det2_timeEnd			= 0.0;
	d->det2_timeReference   = POS_LASER1;
//	d->det2_defaultLevel    = 0;
}



t_detectionParameters *DETECTIONPAR_new (t_session *s)
{
	t_detectionParameters *new;

    new = (t_detectionParameters *) malloc (sizeof (t_detectionParameters));
    ListInsertItem (s->lDetectionParameters, &new, END_OF_LIST);
    
    return new;
}

void DETECTIONPAR_free (t_detectionParameters *d)
{
}

void DETECTIONPAR_delete (t_session *s, int nr)
{
	t_detectionParameters *old;
	
	ListRemoveItem (s->lDetectionParameters, &old, nr);
	DETECTIONPAR_free (old);
}


void DETECTIONPAR_duplicate (t_detectionParameters *dest, 
							 t_detectionParameters *source)
{
 	// copy all data
 	memcpy (dest, source, sizeof (t_detectionParameters));
}


/*
t_detectionParameters *DETECTIONPAR_fromAtom (t_session *s, t_atom *a) 
{
	t_detectionParameters *d;
	
	d = DETECTIONPAR_ptr (s, a->detectionParameters);
	if (d == NULL) return NULL;
	if (d->detector != s->detector) return NULL;
	return d;
}
*/

// put the time intervals of det 1 in
// ascending order
// the array 'order' contains the indices in the right order
int *DETECTIONPAR_orderTimesDet1 (t_session *s, t_detectionParameters *d)
{
	static int order[MAX_LEVELS];
	int wasTaken[MAX_LEVELS];
	int n, i;
	int smallest;
	
	for (i = 0; i < s->nLevels; i++) {
		wasTaken[i] = !d->det1_levelActive[i];
		d->det1_timeStart[i] = 0.05 * round (d->det1_timeStart[i] / 0.05);
		d->det1_timeEnd[i] = 0.05 * round (d->det1_timeEnd[i] / 0.05);
	}
	n = 0;
	do {
		smallest = -1;
		for (i = 0; i < s->nLevels; i++) {
			if (!wasTaken[i]) {
				if (smallest < 0) smallest = i;
				else if (d->det1_timeStart[i] < d->det1_timeStart[smallest]) smallest = i;
			}
		}
		if (smallest >= 0) {
			order[n] = smallest;
			wasTaken[smallest] = 1;
			n++;
		}
	} while (smallest >= 0);
	
	for (i = n; n < MAX_LEVELS; n++) order[i] = -1;
	
	return order;
}



int DETECTIONPAR_inconsistent (t_session *s, t_detectionParameters *d, int detector)
{
	int i, k;
	int *order;
	int n;
	if (d == NULL) return 0;
	
//	if ( round (10.0 * (d->det1_timeEnd[i] - d->det1_timeStart[i])) < 2) error = 1;
	if (!d->detectorActive[detector]) return 0;
	// ----------------------------------------
	//       detector 1
	// ----------------------------------------
	if (detector == 0) {
		order = DETECTIONPAR_orderTimesDet1 (s, d);
 		n = 0;
		k = order[n];
		while (order[n+1] >= 0) { 
			i = order[n];
			k = order[n+1];
			if (round (10.0 * (d->det1_timeEnd[i] - d->det1_timeStart[i])) < 2) return 1;
			if (d->det1_timeEnd[i] <= d->det1_timeStart[i]) return 1;
			if (d->det1_timeStart[k] < d->det1_timeEnd[i]) return 1;
			n++;
		}
		if (d->det1_timeEnd[k] <= d->det1_timeStart[k]) return 1;

	}
	// ----------------------------------------
	//       detector 2
	// ----------------------------------------
	if (detector == 1) {
		d->det2_timeStart = 0.05 * round (d->det2_timeStart / 0.05);
		d->det2_timeEnd = 0.05 * round (d->det2_timeEnd / 0.05);
		if (round (10.0 * (d->det2_timeEnd - d->det2_timeStart)) < 2) return 1;
		return 0;
	}
	
	return 0;
}


int DETECTIONPAR_inconsistentNr (t_session *s, int nr, int detector)
{
	return DETECTIONPAR_inconsistent (s, DETECTIONPAR_ptr (s, nr), detector);
}


ListType DETECTIONPAR_listDuplicate (ListType list)
{
	ListType newList;
	t_detectionParameters *d, *new;
	int i, n;
	
	n = ListNumItems (list);
	newList = ListCreate (sizeof(t_detectionParameters *));
	for (i = 1; i <= n; i++) {
		ListGetItem (list, &d, i);
		new = (t_detectionParameters *) malloc (sizeof (t_detectionParameters));
		DETECTIONPAR_duplicate (new, d);
		ListInsertItem (newList, &new, END_OF_LIST);
	}
	return newList;
	
}





//=======================================================================
//
//
//=======================================================================




t_sweep *SWEEP_ptr (t_session *s, int nr)
{
    t_sweep *d;
    
	if ((nr > ListNumItems (s->lSweeps)) || (nr < 1)) return NULL;
	ListGetItem (s->lSweeps, &d, nr);
	return d;
}



t_sweep *SWEEP_ptrType (t_session *s, int type, int nr, int *swNr)
{
	t_sweep *sw;
	int n;
    
    n = 0;
    for (*swNr = 1; *swNr <= ListNumItems (s->lSweeps); (*swNr)++) {
		sw = SWEEP_ptr (s, *swNr);
		if (sw->type == type) {
			if (n == nr) return sw;
			else n++;
		}
	}
	return NULL;
}



void SWEEP_init (t_sweep *d)
{
	int i;

	d->name[0]    = 0;
	d->type       = -1;
	d->active     = 0;
	d->sweepOn 	  = 1;
	d->channel    = 0;
	d->from		  = 0.0;
	d->to		  = 0.0;
	d->center     = 0.0;
	d->span       = 0.0;
	d->nPoints    = 0;
	d->increment  = 0.0;
	d->stepRepetitions = 1;
	d->plotAxisName[0] = 0;
	d->units[0] = 0;
	d->quantity[0] = 0;
	
	d->rfOn           = SWEEP_DEFAULT_RF_ON;
	d->pulseMode      = 0;
	d->harmonic       = SWEEP_DEFAULT_HARMONIC;
	d->outputPower    = 0;
	
	d->deviceChannel  = 0;
	d->current_mA	  = 0;

	d->panel      = -1;
	
	for (i = 0; i < MAX_SWEEP_CTRLS_CHANGED; i++) {
		d->lastCtrlsChanged[i] = -1;
	}
	

}



t_sweep *SWEEP_new (t_session *s)
{
	t_sweep *new;

    new = (t_sweep *) malloc (sizeof (t_sweep));
    ListInsertItem (s->lSweeps, &new, END_OF_LIST);
    
    return new;
}


void SWEEP_free (t_sweep *d)
{
}



void SWEEP_freeAll (t_session *s)
{
	int i;
	t_sweep *sw;
	
    for (i = ListNumItems (s->lSweeps); i > 0; i--) {
		sw = SWEEP_ptr (s, i);
		SWEEP_free (sw);
		free (sw);
	}
	ListClear (s->lSweeps);
}





void SWEEP_delete (t_session *s, int nr)
{
	t_sweep *old;
	
	ListRemoveItem (s->lSweeps, &old, nr);
	SWEEP_free (old);
	free (old);
}


void SWEEP_duplicate (t_sweep *dest, t_sweep *source)
{
 	// copy all data
 	memcpy (dest, source, sizeof (t_sweep));
}



ListType SWEEP_listDuplicate (ListType list)
{
	ListType newList;
	t_sweep *a, *new;
	int i, n;
	
	n = ListNumItems (list);
	newList = ListCreate (sizeof(t_sweep *));
	for (i = 1; i <= n; i++) {
		ListGetItem (list, &a, i);
		new = (t_sweep *) malloc (sizeof (t_sweep));
		SWEEP_duplicate (new, a);
		ListInsertItem (newList, &new, END_OF_LIST);
	}

	return newList;

}

t_sweep *SWEEP_ptrFromPanel (t_session *s, int panel)
{
	int i;
	t_sweep *sw;
	
	for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
		sw = SWEEP_ptr (s, i);
		if (sw->panel == panel) return sw;
	}
	return NULL;

}


int SWEEP_isSameDeviceActive (t_session *s, t_sweep *old) 
{
	int i;
	t_sweep *sw;
	
	for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
		ListGetItem (s->lSweeps, &sw, i);
		if (   (sw != old) 
		    && (sw->active) 
		    && (sw->type == old->type) 
			&& (sw->channel == old->channel)
			&& (sw->deviceChannel == old->deviceChannel)) return i;
	}
	return 0;
}






/***************************************************************************

     t_event: functions
            
****************************************************************************/


// neue Inhalte des DigitalBlocks anlegen
void EVENT_init (t_event *e)
{
	e->atomStr[0] = 0;
	e->time = 0;
	e->timeIncrement = 0;
	e->duration = 0;
	e->durationIncrement = 0;
	e->alwaysOn = 0;
	e->name[0] = 0;
	e->DIG_channel = -1;
	e->AO_channel  = -1;
	e->constVoltage = 0.0;
	e->voltageVary = 0;
	e->voltageIncrement = 0.0;
	
	e->waveform    = -1;
	e->conflicts  = NULL;
	e->isAbsoluteTimeReference = 0;
}


// alle Inhalte des Digital-Blocks freigeben
void EVENT_free (t_event *e)
{
	free (e->conflicts);
}


void EVENT_freeAll (ListType listOfEvents)
{
	int i;
	t_event *e;
	
	
	if (listOfEvents == NULL) return;
	
	// ---------------------------------------------
	//   free events
	// ---------------------------------------------
    for (i = ListNumItems (listOfEvents); i >= 1; i--) {
		ListGetItem (listOfEvents, &e, i);
		EVENT_free (e);
		free (e);
	}
	ListClear (listOfEvents);
}



//=======================================================================
//
// 	   returns pointer digitalBlock with number 'ID'
//
//=======================================================================
t_event *EVENT_ptr (t_session *s, int ID)
{
    t_event *e;
    
//    if (ID == 0) return NULL;
	if ((ID > ListNumItems (s->lEvents)) || (ID < 1)) return NULL;
	ListGetItem (s->lEvents, &e, ID);
	return e;
}


t_event *EVENT_new (t_session *s)
{
	t_event *new;
	
    new = (t_event *) malloc (sizeof (t_event));
    ListInsertItem (s->lEvents, &new, END_OF_LIST);
	EVENT_init (new);
	
	return new;
}


void EVENT_delete (t_session *s, int nr)
{
	t_event *old;
	
	ListRemoveItem (s->lEvents, &old, nr);
	EVENT_free (old);
	free (old);
}



void EVENT_duplicate (t_event *dest, t_event *source)
{
	memcpy (dest, source, sizeof (t_event));
	dest->conflicts = NULL;
}


ListType EVENT_listDuplicate (ListType list)
{
	ListType newList;
	t_event *e, *new;
	int i, n;
	
	n = ListNumItems (list);
	newList = ListCreate (sizeof(t_event *));
	for (i = 1; i <= n; i++) {
		ListGetItem (list, &e, i);
		new = (t_event *) malloc (sizeof (t_event));
		EVENT_duplicate (new, e);
		ListInsertItem (newList, &new, END_OF_LIST);
	}

	return newList;

}





/***************************************************************************

     t_timeInterval: functions
            
****************************************************************************/



void TIMEINTERVAL_init (t_timeInterval *t)
{
	t->levelNr = 0;
	t->name[0] = 0;
	t->atom = 0;
	t->multiple = 0;
	t->atomNrStr[0] = 0;
//	t->timeStart_us = 0;
//	t->timeEnd_us = 0
	t->timeStart = 0;
	t->timeEnd = 0;
	t->repetition = 0;
	t->idStr[0] = 0;
}


t_timeInterval *TIMEINTERVAL_ptrList (ListType list, int ID)
{
    t_timeInterval *e;
    
	if ((ID > ListNumItems (list)) || (ID < 1)) return NULL;
	ListGetItem (list, &e, ID);
	return e;
}



/*
t_timeInterval *TIMEINTERVAL_ptr (t_session *s, int ID)
{
    return TIMEINTERVAL_ptrList (s->lTimeIntervals, ID);
}
*/



void TIMEINTERVAL_free (t_timeInterval *e)
{
}


void TIMEINTERVAL_freeList (ListType list)
{
	int i,n;
	t_timeInterval *e;
	
	if (list == NULL) return;
	
	// ---------------------------------------------
	//   free events
	// ---------------------------------------------
    n = ListNumItems (list);
    for (i = 1; i <= n; i++) {
		ListGetItem (list, &e, i);
		TIMEINTERVAL_free (e);
		free (e);
	}
	ListClear (list);

}


/*
void TIMEINTERVAL_freeAll (t_session *s)
{
}
*/

t_timeInterval *TIMEINTERVAL_new (ListType list)
{
	t_timeInterval *new;
	
    new = (t_timeInterval *) malloc (sizeof (t_timeInterval));
    ListInsertItem (list, &new, END_OF_LIST);
	TIMEINTERVAL_init (new);
	
	return new;
}



void TIMEINTERVAL_getMinMax (ListType list, int *min, int *max)
{
	int i;
	t_timeInterval *t;
	
	if (ListNumItems (list) == 0) {
		*min = 0;
		*max = 0;
		return;
	}
	*min = INT_MAX;
	*max = INT_MIN;
	for (i = 1; i <= ListNumItems (list); i++) {
		t = TIMEINTERVAL_ptrList (list, i);
		if (t->timeEnd > *max) *max = t->timeEnd;
		if (t->timeStart < *min) *min = t->timeStart;
	}
	
}


t_timeInterval *TIMEINTERVAL_ptrForAtom (ListType list, int atomNr)
{
	int i;
	t_timeInterval *t;
	
	for (i = 1; i <= ListNumItems (list); i++) {
		t = TIMEINTERVAL_ptrList (list, i);
		if (t->atom == atomNr) return t;
	}
	return NULL;
}



int TIMEINTERVAL_nrForAtom (ListType list, int atomNr)
{
	int i;
	t_timeInterval *t;
	
	for (i = 1; i <= ListNumItems (list); i++) {
		t = TIMEINTERVAL_ptrList (list, i);
		if (t->atom == atomNr) return i;
	}
	return 0;
}


int TIMEINTERVAL_getNr (t_session *s, int detector, int atom, int multiple, int level)
{
	int i, n;
	t_timeInterval *t;
	int hasMultiples = 0;
	t_atom *a;
	
	n = ListNumItems (s->lTimeIntervals[detector]);
	a = ATOM_ptr (s, atom);
	if (a != NULL) hasMultiples = a->hasMultiples;
	for (i = 1; i <= n; i++){
		ListGetItem (s->lTimeIntervals[detector], &t, i);
		if ((t->atom == atom) && (t->levelNr == level)) {
			if (!hasMultiples) return i;
			else if (t->multiple == multiple) return i;
//			if (t->levelNr <= 0) return i;
		}
	}
	return 0;
}



int CVICALLBACK TIMEINTERVAL_compareStart (void *item1, void *item2)
{
	t_timeInterval *t1, *t2;
	
	t1 = *((t_timeInterval **) item1);
	t2 = *((t_timeInterval **) item2);
	if (t1->timeStart < t2->timeStart) return -1;
	if (t1->timeStart > t2->timeStart) return 1;
	return 0;
}



void TIMEINTERVAL_insertInOrder (ListType list, t_timeInterval *new)
{
	t_timeInterval *lastItem;
	
	if (ListNumItems (list) > 0) {
		ListGetItem (list, &lastItem, END_OF_LIST);
		if (lastItem->timeStart < new->timeStart) ListInsertItem (list,  &new, END_OF_LIST);
		else ListInsertInOrder (list, &new, (void*)TIMEINTERVAL_compareStart);
	}
	else ListInsertItem (list, &new, END_OF_LIST);
}		
	
	

/*void TIMEINTERVAL_sort (ListType list)
{
	ListQuickSort (list, (void*)TIMEINTERVAL_compareStart);
}
*/

void TIMEINTERVAL_duplicate (t_timeInterval *dest, t_timeInterval *source)
{
 	// copy all data
 	memcpy (dest, source, sizeof (t_timeInterval));
    // assign new name
}



void TIMEINTERVAL_duplicateList (ListType destList, ListType sourceList, int startItem)
{
	int i, n;
	t_timeInterval *new, *old;
	
	TIMEINTERVAL_freeList (destList);
	n = ListNumItems (sourceList);
	for (i = startItem; i <= n; i++) {
		ListGetItem (sourceList, &old, i);
	    new = (t_timeInterval *) malloc (sizeof (t_timeInterval));
	    TIMEINTERVAL_duplicate (new, old);
	    ListInsertItem (destList, &new, END_OF_LIST);
	}
    
}


ListType TIMEINTERVAL_listDuplicate (ListType list)
{
	ListType newList;
	
	newList = ListCreate (sizeof (t_timeInterval *));
	TIMEINTERVAL_duplicateList (newList, list, 1);
	return newList;
}







/****************************************************************************

     t_plotItem: functions
            
****************************************************************************/


// neue Inhalte des DigitalBlocks anlegen
void PLOTITEM_init (t_plotItem *p)
{
	int i, k, j;
	
	p->active = 1;
	p->name[0] = 0;
	p->error   = PLOTITEM_ERR_NONE;
	p->atomNr   = 1;
	p->multiple = 0;
	p->excludeDoubleCounts = 0;
	p->counter = -1;
	p->type = PLOT_TYPE_NCOUNTS;
	p->detector     = 1;
	p->dataFilterID = 0;
	
	p->arrivalTimesBinSize_us  = 2;
	p->arrivalTimesBinAuto     = 1;
	p->arrivalTimesBinStart_us = 0;
	p->arrivalTimesBinEnd_us   = 0;
	p->arrivalTimesNBins       = 0;

	p->velocityStart    = 0.0;
	p->velocityEnd      = 800.0;
	p->velocityNPoints  = 100;
	p->velocityShowPositionAxis = 0;
	p->velocityTimeMultiply_us = 1.0;
	p->velocityShowExperimentParts = 0;		   


	p->transfer = 0;
	p->fixedIntervals = 0;
//	p->useTransferLevels = 0;
	p->level = 0;
	for (i = 0; i < N_DETECTORS; i++) p->interval[i] = 1;
	

	p->plotItemTransfer1 = 0;
	p->plotItemTransfer2 = 0;
	p->keepCurve = 1;
	p->saveCurve = 1;
	p->saveTxt   = 1;
//	p->saveTimes = 0;

	p->plotStyle    = VAL_FAT_LINE;
	p->plotColor    = VAL_COLOR_AUTO;
	
	p->plotStyleCurrent = VAL_THIN_LINE;
	p->plotColorCurrent = VAL_COLOR_AUTO;
	
	p->create2DPlot = 0;
	p->curve        = NULL;
	p->graph 		= NULL;

		
	p->autoSetWindowName = 1;
	p->panelTitle[0] = 0;
	p->panelPos2D = MakeRect (-1,-1,-1,-1);
	p->panelPos = MakeRect (-1,-1,-1,-1);
	p->firstUsed = 1;
	p->session = NULL;
	p->filterResultsCurrent.countsArray = NULL;
	p->filterResultsAll.countsArray = NULL;
	FILTERRESULTS_init (&p->filterResultsCurrent);
	FILTERRESULTS_init (&p->filterResultsAll);
	p->hasDataCalculated = 0;
	p->filter = 0;
	
	p->correlationsNAtoms = 2;
	for (i = 0; i < MAX_CORRELATION_ATOMS; i++) {
		p->correlationsAtomNumber[i] = 0;
		p->correlationsAtomMultiple[i] = 0;
		p->correlationsLevel[0][i] = 0;
		p->correlationsLevel[1][i] = 0;
	}

	p->correlationsFilterIDOneAtom = -1;
	p->correlationsFilterOneAtom = NULL;

	for (i = 0; i < MAX_CORRELATION_CURVES; i++) {
		p->correlationsCurves[i] = 0;
		p->correlationsFilterID[i] = -1;
		p->correlationsFilter[i] = NULL;
	}
	
	p->multipleAsIndexNBinAtoms = 1;
	p->multipleAsIndexFilterForEachMultipleID = 0;
	p->multipleAsIndexSumAllRuns = 0;
	
	
	p->hasTableColumn = 0;
}
	



// alle Inhalte des Digital-Blocks freigeben
void PLOTITEM_free (t_plotItem *e)
{
	GRAPH_RemoveReferenceToPlotItem (e);
	FILTERRESULTS_free (&e->filterResultsCurrent);
	FILTERRESULTS_free (&e->filterResultsAll);
}


//=======================================================================
//
// 	   returns pointer digitalBlock with number 'ID'
//
//=======================================================================
t_plotItem *PLOTITEM_ptr (t_session *s, int ID)
{
    t_plotItem *e;
    	
    if (s == NULL) return NULL;
    
	if ((ID > ListNumItems (s->lPlotItems)) || (ID < 1)) return NULL;
	ListGetItem (s->lPlotItems, &e, ID);
	return e;
}


t_plotItem *PLOTITEM_new (t_session *s)
{
	t_plotItem *new;
	
    new = (t_plotItem *) malloc (sizeof (t_plotItem));
    ListInsertItem (s->lPlotItems, &new, END_OF_LIST);
	PLOTITEM_init (new);
	new->session = s;
	
	return new;
}




void PLOTITEM_delete (t_session *s, int nr)
{
	t_plotItem *old;
	t_filter *f;
	int i;
	
	ListRemoveItem (s->lPlotItems, &old, nr);
	PLOTITEM_free (old);
	free (old);

	// delete filters which references this plotitem
/*
	for (i = ListNumItems (s->lFilters); i > 0; i--) {
		ListGetItem (s->lFilters, &f, i);
		if (f->correlationsPlotItemNr == nr) {
			FILTER_delete (s, i);
		}
		else if (f->correlationsPlotItemNr > nr) {
			f->correlationsPlotItemNr--;
		}
	}
*/	
	
}


void PLOTITEM_deleteReferenceToCurve (t_session *s, t_graph *g, t_curve *c)
{
	int i;
	t_plotItem *p;
	
	if ((s == NULL) || (c == NULL)) return;
	
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
		if (p->curve == c) p->curve = NULL;
		if (p->graph == g) p->graph = NULL;
	}
}



void PLOTITEM_deleteAllReferencesToFilter (t_session *s, int filterID)
{
	int i,j;
	t_plotItem *p;
	int nFilters;
	
	if (s == NULL) return;
	if (filterID == 0) return;
	
	for (i = ListNumItems (s->lPlotItems); i >= 1; i--) {
		ListGetItem (s->lPlotItems, &p, i);
		if (p->dataFilterID == filterID) {
			p->dataFilterID = 0;
			p->filter = NULL;
		}
		else if (p->dataFilterID > filterID) p->dataFilterID --;
		// delete ref to filter in correlation
		nFilters = MAX_CORRELATION_CURVES;
		for (j = 0; j < nFilters; j++) {
			if (p->correlationsFilterID[j] == filterID) {
					p->correlationsFilterID[j] = -1;
					p->correlationsFilter[j]   = NULL;
				}
			else if (p->correlationsFilterID[j] > filterID) p->correlationsFilterID[j]--;
		}
		if (p->correlationsFilterIDOneAtom == filterID) {
				p->correlationsFilterIDOneAtom = -1;
				p->correlationsFilterOneAtom   = NULL;
			}
		else if (p->correlationsFilterIDOneAtom > filterID) p->correlationsFilterIDOneAtom--;
		
	}
}


void PLOTITEM_deleteAllReferencesToCurves (t_session *s)
{
	int i;
	t_plotItem *p;
	
	if (s == NULL) return;
	
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
		p->firstUsed = 1;
		p->curve = NULL;
	}
	p =  PLOTITEM_dig (NULL);
	p->firstUsed = 1;
	p->curve = NULL;
	
}


void PLOTITEM_getPtrToFilter (t_session *s, t_plotItem *p)
{
	int i;
	
	for (i = 0; i < (1<<p->correlationsNAtoms); i++) {
		p->correlationsFilter[i] = FILTER_ptr (s, p->correlationsFilterID[i]);
	}
}



void PLOTITEM_duplicate (t_plotItem *dest, t_plotItem *source)
{
	int i;
	
	memcpy (dest, source, sizeof (t_plotItem));
	for (i = 0; i < MAX_CORRELATION_CURVES; i++) {
		dest->correlationsCurves[i] = 0;
		dest->correlationsFilter[i] = NULL;
	}
	dest->correlationsFilterOneAtom = NULL;
	dest->curve        = NULL;
	dest->graph 		= NULL;
	dest->session = NULL;
	dest->filter = NULL;
}



ListType PLOTITEM_listDuplicate (ListType list)
{
	ListType newList;
	t_plotItem *p, *new;
	int i, n;
	
	n = ListNumItems (list);
	newList = ListCreate (sizeof(t_plotItem *));
	for (i = 1; i <= n; i++) {
		ListGetItem (list, &p, i);
		new = (t_plotItem *) malloc (sizeof (t_plotItem));
		PLOTITEM_duplicate (new, p);
		ListInsertItem (newList, &new, END_OF_LIST);
	}

	return newList;

}


//=======================================================================
//
//    FILTERCRITERION
//
//=======================================================================



void FILTERCRITERION_init (t_filterCriterion *fc)
{
	int i;
	
	fc->active = 0;
	fc->logic = 0;
	fc->detector = 0;
	fc->timeIntervalFrom[0] = 0;
	fc->timeIntervalFrom[1] = 0;
	fc->timeIntervalTo[0] = 0;
	fc->timeIntervalTo[1] = 0;
	fc->hasTimeIntervalTo = 0;
	fc->minCounts = 0;
	fc->maxCounts = 0;
	
	
	fc->hasAdditionalTimeIntervals = 0;
	fc->nAdditionalTimeIntervals = 0;
	for (i = 0; i < MAX_ADDITIONAL_TIMEINTERVALS; i++) {
		fc->additionalTimeIntervals[i] = 0;
	}

}


void FILTERCRITERION_free (t_filterCriterion *fc)
{
}


int FILTERCRITERION_compare (t_filterCriterion *fc1, t_filterCriterion *fc2)
{
	return memcmp (fc1, fc2, sizeof (t_filterCriterion));
}

//=======================================================================
//
//    FILTERs
//
//=======================================================================



void FILTER_init (t_filter *f)
{
	int i;
	
//	f->isActive = 1;
	f->name[0] = 0;
	f->otherFilterID = 0;
	f->otherFilterPtr = NULL;
	
	f->nFilterCriteria = 0;
	for (i = 0; i < MAX_FILTER_CRITERIA; i++) {
	    FILTERCRITERION_init (&f->criterion[i]);	
	}
	
	f->timeIntervalToCountStart = 0;
	f->timeIntervalToCountStop = 0;
	f->keepFilteredDataInResults = 0;
	
/*	f->correlationsPlotItemNr = 0;
//	f->correlationsPlotItemPtr = NULL;
	f->correlationsAtom = -1;
	f->correlationsLevel = -1;
	*/
}


void FILTER_free (void *vf)
{

}

void FILTER_duplicate (t_filter *dest, t_filter *source)
{
	memcpy (dest, source, sizeof (t_filter));
}






int FILTER_compare (t_filter *f1, t_filter *f2)
{
	int i;
	
	if (f1->nFilterCriteria != f2->nFilterCriteria) return 1;
	for (i = 0; i < f1->nFilterCriteria; i++) {
		if (FILTERCRITERION_compare (&f1->criterion[i], &f2->criterion[i]) != 0) return 1;
	}
	if (f1->timeIntervalToCountStart != f2->timeIntervalToCountStart) return 1;
	if (f1->timeIntervalToCountStop != f2->timeIntervalToCountStop) return 1;
	if (f1->otherFilterID != f2->otherFilterID) return 1;
	if (strcmp (f1->name, f2->name) != 0) return 1;
	
	return 0;
}





void FILTER_delete (t_session *s, int filterID)
{
	t_filter *f;
	int i, k;
	int nCorrelationFilters;
	t_plotItem *p;
	
	if ((filterID < 1) || (filterID > ListNumItems (s->lFilters))) return;
	PLOTITEM_deleteAllReferencesToFilter (s, filterID);
	ListRemoveItem (s->lFilters, &f, filterID);
	FILTER_free (f);
	free (f);
	
	for (i = ListNumItems (s->lFilters); i > 0; i--) {
		ListGetItem (s->lFilters, &f, i); 
		if (f->otherFilterID == filterID) {
			f->otherFilterID = -1;
			f->otherFilterPtr = NULL;
		}
		else if (f->otherFilterID > filterID) {
			f->otherFilterID --;
		}
	}

/*	for (i = ListNumItems (s->lPlotItems); i > 0; i--) {
		ListGetItem (s->lPlotItems, &p, i); 
		if (p->correlationsFilterIDOneAtom == filterID) {
			p->correlationsFilterIDOneAtom = -1;
			p->correlationsFilterOneAtom = NULL;
		}
		else if (p->correlationsFilterIDOneAtom > filterID) {
			p->correlationsFilterIDOneAtom  --;
		}
		nCorrelationFilters = 1 << p->correlationsNAtoms;
		for (k = 0; k < nCorrelationFilters; k++) {
			if (p->correlationsFilterID[k] == filterID) {
				p->correlationsFilterID[k] = -1;
				p->correlationsFilter[k] = NULL;
			}
			else if (p->correlationsFilterID[k] > filterID) {
				p->correlationsFilterID[k] --;
			}
		}
	}
*/
	
}



t_filter *FILTER_new (t_session *s)
{
	t_filter *new;
	
	new = (t_filter *) malloc (sizeof (t_filter));
	ListInsertItem (s->lFilters, &new, END_OF_LIST);
	FILTER_init (new);
	return new;
}



// ---------------------------------------------------
//  'default'-filter that calculates just the average
//  number of counts of one time interval
//  of one time interval
// ---------------------------------------------------

t_filter *FILTER_default_Average (void)
{
	static int firstCall = 1;
	static t_filter fAvg; 
	
	if (firstCall) {
		FILTER_init (&fAvg);
		strcpy (fAvg.name, "average (ID=0)");
		fAvg.nFilterCriteria = 1;
		fAvg.criterion[0].logic = 0;
		fAvg.criterion[0].active = 1;
		fAvg.criterion[0].minCounts = 0;
		fAvg.criterion[0].maxCounts = ULONG_MAX;
		fAvg.timeIntervalToCountStart = 0;
		fAvg.timeIntervalToCountStop  = 0;
		firstCall = 0;
	}
//	fAvg.criterion[0].detector = detector;
	return &fAvg;
}



t_filter *FILTER_ptr (t_session *s, int ID)
{
    t_filter *f;
    	
    if (s == NULL) return NULL;
    if (ID < 0) return NULL;
    if (ID == 0) return FILTER_default_Average ();
	if (ID > ListNumItems (s->lFilters)) return NULL;
	ListGetItem (s->lFilters, &f, ID);
	return f;
}




ListType FILTER_listDuplicate (ListType list)
{
	ListType lFilters;
	t_filter *f, *new;
	int i, n;
	
	n = ListNumItems (list);
	lFilters = ListCreate (sizeof(t_filter*));
	for (i = 1; i <= n; i++) {
		ListGetItem (list, &f, i);
		new = (t_filter *) malloc (sizeof (t_filter));
		FILTER_duplicate (new, f);
		ListInsertItem (lFilters, &new, END_OF_LIST);
	}
	return lFilters;
}



char *levelStr (t_session *s, int nr)
{
	if ((nr < 0) || (nr >= MAX_LEVELS)) return "";
	return s->levelNames[nr];
}



