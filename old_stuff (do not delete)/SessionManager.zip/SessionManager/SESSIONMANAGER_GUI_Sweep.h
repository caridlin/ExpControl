#if !defined (SESSIOMANAGER_GUI_SWEEP)
#define SESSIOMANAGER_GUI_SWEEP


int SWEEP_initPanel (void);

void SWEEP_displayAll (t_session *s);

void SWEEP_displayListOfSweeps (t_session *s, int panel, int ctrl);

void SWEEP_createListOfSweeps (t_session *s);

double SWEEP_value2 (t_sweep *s, int nRepetitions, int currentRepetition);

void SWEEP_fillAnalogChannelNamesToRing (int panel, int control);


t_sweep *SWEEP_dig (t_session *s);
t_sweep *SWEEP_repetitionNr (t_session *s);

int SWEEP_getLastActiveNr (t_session *s);



#endif

