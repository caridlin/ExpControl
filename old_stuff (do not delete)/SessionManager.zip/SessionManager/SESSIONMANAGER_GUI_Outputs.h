#if !defined (SESSIOMANAGER_GUI_OUTPUTS)
#define SESSIOMANAGER_GUI_OUTPUTS



int OUTPUTS_initPanel (void);
						 
void OUTPUTS_setValues (t_session *s);


void OUTPUTS_DIRECT_start (void);

#endif
