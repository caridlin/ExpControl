#if !defined(SESSIONMANAGER_LOADSAVE)
#define SESSIONMANAGER_LOADSAVE

												   
												   
int SESSION_load (const char *filename, t_session *s);
int SESSION_save (const char *filename, t_session *s);


int loadMasterSequence (t_smanagerConfig *c);


int writeSessionManagerConfig (t_smanagerConfig *c);

int readSessionManagerConfig (t_smanagerConfig *c);

int Ini_GetPosition (IniText ini, const char *section, const char *tag, int *value);
void Ini_PutPosition (IniText ini, const char *section, const char *tag, int value);



void Ini_PutRun_DataAcquisitionParams (IniText ini, t_run *r);
void Ini_PutRun (IniText ini, t_run *r);

//void Ini_PutRun_AppendDataSet (IniText ini, t_run *r, int repetitionNr, int runNr);

void Ini_GetRun (IniText ini, t_run *r);
void Ini_GetRun_DataAcquisitionParams (IniText ini, t_run *r);

t_run *RUN_load (const char *filename, int showProgress);
int RUN_save (const char *filename, t_run *r, int zipFile);   

t_curve *CURVE_load (const char *filename);
int CURVE_save (const char *filename, t_curve *c, t_graph *g);

t_counterData *COUNTERDATA_loadFilter (const char *filename);


void Ini_GetFilter (IniText ini, t_session *s, int nr);
void Ini_PutFilter (IniText ini, t_session *s, int nr);




#endif
