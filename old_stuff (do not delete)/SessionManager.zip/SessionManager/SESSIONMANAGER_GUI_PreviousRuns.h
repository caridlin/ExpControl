#if !defined (SESSIOMANAGER_GUI_RESULTSMANAGER)
#define SESSIOMANAGER_GUI_RESULTSMANAGER


void COUNTS_displayRun (t_run *r);

void COUNTS_initPanel (int parentPanel, t_run *r, int nPlotItemsCalculated);






void RUNS_loadAndDisplay (const char *filename);

void RUNS_hidePanel (void);
void RUNS_displayPanel (void);

int RUNS_initPanel (void);

void *RUNS_deleteAllReferencesToCurve (t_graph *g, t_curve *c) ;

void RUNS_deleteAllReferencesToPanel (int panel, t_run *activeR);      





#endif
