#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"



int panelConfig    = -1;

int subPanelPositions 	 = -1;
int subPanelRfParameters = -1;
int subPanelSignals = -1;
int subPanelKiller = -1;
int subPanelDetectionParameers = -1;

// transferfunctions of killer
int panelTFkiller[N_CAVITIES] = {-1, -1}; 


#define WIDTH_cavityMode 6.0 // waist of cavity mode
#define WIDTH_cavity 55.0


const int CTRL_SCONFIG_rfFreq[N_RF_CHANNELS] = {
	CONFrf_NUMERIC_rf1,
	CONFrf_NUMERIC_rf2,
	CONFrf_NUMERIC_rf3,
	CONFrf_NUMERIC_rf4
};

const int CTRL_SCONFIG_rfVelocity[N_RF_CHANNELS] = {
	CONFrf_NUMERIC_rf1_v,
	CONFrf_NUMERIC_rf2_v,
	CONFrf_NUMERIC_rf3_v,
	CONFrf_NUMERIC_rf4_v
};

const int CTRL_SCONFIG_rfPower[N_RF_CHANNELS] = {
	CONFrf_NUMERIC_rfPower1,
	CONFrf_NUMERIC_rfPower2,
	CONFrf_NUMERIC_rfPower3,
	CONFrf_NUMERIC_rfPower4
};





void SCONFIG_KILLER_initPanel (void)
{
	if (panelTFkiller[0] != -1) return;
	
	panelTFkiller[0] = LoadPanel (subPanelKiller, SESSIONMANAGER_uirFile,  TFKILLER);
	SetPanelPos (panelTFkiller[0], 0, 0);
	SetCtrlAttribute (panelTFkiller[0], TFKILLER_DECORATION, ATTR_WIDTH, panelWidth (panelTFkiller[0]));
	SetCtrlAttribute (panelTFkiller[0], TFKILLER_DECORATION, ATTR_HEIGHT, panelHeight (panelTFkiller[0]));
	SetPanelAttribute (panelTFkiller[0], ATTR_WIDTH, panelWidth(subPanelKiller));
	SetCtrlAttribute (panelTFkiller[0], TFKILLER_GRAPH, ATTR_TOP, 0);
	SetCtrlAttribute (panelTFkiller[0], TFKILLER_GRAPH, ATTR_HEIGHT, panelHeight(panelTFkiller[0]));
	SetCtrlAttribute (panelTFkiller[0], TFKILLER_GRAPH, ATTR_WIDTH, 
					  panelWidth (panelTFkiller[0]) - ctrlLeft (panelTFkiller[0], TFKILLER_GRAPH));
	DisplayPanel (panelTFkiller[0]);
	
	panelTFkiller[1] = DuplicatePanel(subPanelKiller,panelTFkiller[0],"",panelBottom(panelTFkiller[0]),0);
	SetCtrlVal (panelTFkiller[1], TFKILLER_TEXTMSG_cavity, "Cavity 2");
	DisplayPanel (panelTFkiller[1]);    	
}



void SCONFIG_KILLER_setDefaultVoltages (int panel, int ctrlDefaultV, int ctrlDefaultDetuning, 
										t_session *s, int cavityNr)
{
	t_transferFunction f;
	double value;

	CREATESEQ_makeTransferFunction (&f, s, cavityNr);
	if (s->atomConfig->setDefaultVoltage[cavityNr]) {
		SetCtrlVal (panel, ctrlDefaultV, s->atomConfig->killerDefaultVoltage[cavityNr]);
		value = TRANSFERFUNCT_applyInv (&f, s->atomConfig->killerDefaultVoltage[cavityNr]);
		SetCtrlVal (panel, ctrlDefaultDetuning, value);
		
	}
	else {
		SetCtrlVal (panel, ctrlDefaultDetuning, s->atomConfig->killerDefaultDetuning[cavityNr]);
		value = TRANSFERFUNCT_apply (&f, s->atomConfig->killerDefaultDetuning[cavityNr]);
		SetCtrlVal (panel, ctrlDefaultV, value);
	}
	
}


void SCONFIG_KILLER_setValues (t_session *s, int cavityNr)
{
	t_atomConfig *ac;
	t_transferFunction f;
	
	if (panelTFkiller[cavityNr] <= 0) return;
	ac = s->atomConfig;
	
	SetCtrlVal (panelTFkiller[cavityNr], TFKILLER_NUMERIC_A, ac->parametersTransferFunct[cavityNr][0]);
	SetCtrlVal (panelTFkiller[cavityNr], TFKILLER_NUMERIC_B, ac->parametersTransferFunct[cavityNr][1]);
	SetCtrlVal (panelTFkiller[cavityNr], TFKILLER_NUMERIC_C, ac->parametersTransferFunct[cavityNr][2]);
	
	SetCtrlVal (panelTFkiller[cavityNr], TFKILLER_RING_transferFunction, ac->transferFunct[cavityNr]);
	SetCtrlVal (panelTFkiller[cavityNr], TFKILLER_BINARYSWITCH_defaultV, ac->setDefaultVoltage[cavityNr]);
	
	setCtrlHot (panelTFkiller[cavityNr], TFKILLER_NUMERIC_defaultV, ac->setDefaultVoltage[cavityNr]);
	setCtrlHot (panelTFkiller[cavityNr], TFKILLER_NUMERIC_defaultDet, !ac->setDefaultVoltage[cavityNr]);

	SCONFIG_KILLER_setDefaultVoltages (panelTFkiller[cavityNr], 
									   TFKILLER_NUMERIC_defaultV, 
									   TFKILLER_NUMERIC_defaultDet,
									   s, cavityNr);

	CREATESEQ_makeTransferFunction (&f, s, cavityNr);
	TRANSFERFUNCT_writeFormulasToTextbox (&f, panelTFkiller[cavityNr], TFKILLER_TEXTBOX);
	TRANSFERFUNCT_plotInv (&f, panelTFkiller[cavityNr], TFKILLER_GRAPH, -5.0, 5.0);
									   
}

void SCONFIG_KILLER_getValues (t_session *s, int cavityNr)
{
	t_atomConfig *ac;
	
	if (panelTFkiller[cavityNr] <= 0) return;
	ac = s->atomConfig;
	
	GetCtrlVal (panelTFkiller[cavityNr], TFKILLER_NUMERIC_A, &ac->parametersTransferFunct[cavityNr][0]);
	GetCtrlVal (panelTFkiller[cavityNr], TFKILLER_NUMERIC_B, &ac->parametersTransferFunct[cavityNr][1]);
	GetCtrlVal (panelTFkiller[cavityNr], TFKILLER_NUMERIC_C, &ac->parametersTransferFunct[cavityNr][2]);
	
	GetCtrlVal (panelTFkiller[cavityNr], TFKILLER_RING_transferFunction, &ac->transferFunct[cavityNr]);
	GetCtrlVal (panelTFkiller[cavityNr], TFKILLER_BINARYSWITCH_defaultV, &ac->setDefaultVoltage[cavityNr]);

	if (s->atomConfig->setDefaultVoltage[cavityNr]) {
		GetCtrlVal (panelTFkiller[cavityNr], TFKILLER_NUMERIC_defaultV, &ac->killerDefaultVoltage[cavityNr]);
	}
	else {
		GetCtrlVal (panelTFkiller[cavityNr], TFKILLER_NUMERIC_defaultDet, &ac->killerDefaultDetuning[cavityNr]);
	}
	
	
	
}



int CVICALLBACK SCONFIG_KILLER_parametersEdited_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	
	switch (event)
		{
		case EVENT_COMMIT:
			s = activeSession ();
			SCONFIG_KILLER_getValues (s, 0);
			SCONFIG_KILLER_getValues (s, 1);
			SESSION_setChanges (s, 1);
			SCONFIG_KILLER_setValues (s, 0);
			SCONFIG_KILLER_setValues (s, 1);
			break;
		}
	return 0;
}




/*
int CVICALLBACK ATOMS_KILLER_callback_editTransferFunction (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	int cavityNr;
	
	switch (event) {
		case EVENT_COMMIT:
			if (panelTransferFunction == -1) 
				panelTransferFunction = LoadPanel (0, SESSIONMANAGER_uirFile, TRANSFERF);
			s = activeSession();
			cavityNr = ATOMS_activeCavityNr ();
			SetCtrlVal (panelTransferFunction, TRANSFERF_NUMERIC_cavity, cavityNr+1);
			ATOMS_KILLER_setValuesTransf (s, cavityNr);
			InstallPopup (panelTransferFunction);
			break;
	}
	return 0;
}



int CVICALLBACK ATOMS_KILLER_callback_transferFunctionDone (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	int cavityNr;
	t_point *killerPoints = NULL;
	int nKillerPoints;

	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			cavityNr = ATOMS_activeCavityNr ();
			ATOMS_KILLER_getValuesTransf (s, cavityNr);
			ATOMS_KILLER_setValues (s, cavityNr);
			POINTS_tableToListOfPoints (&ctrlKiller, &killerPoints, &nKillerPoints,1);
			ATOMS_KILLER_displayCalculatedCurve (s, killerPoints, nKillerPoints, cavityNr);
			free (killerPoints);
			RemovePopup (0);
			break;
	}
	return 0;
}



int CVICALLBACK ATOMS_KILLER_callback_transferFunctionDefaultEdited (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_transferFunction f;
	double parameters[3];
	double defaultVoltage;
	double defaultDet;

	switch (event) {
		case EVENT_COMMIT:
			TRANSFERFUNCT_init (&f);
			GetCtrlVal (panelTransferFunction, TRANSFERF_NUMERIC_A, &parameters[0]);
			GetCtrlVal (panelTransferFunction, TRANSFERF_NUMERIC_B, &parameters[1]);
			GetCtrlVal (panelTransferFunction, TRANSFERF_NUMERIC_C, &parameters[2]);
			switch (control) {
				case TRANSFERF_NUMERIC_defaultV:
					GetCtrlVal (panelTransferFunction, TRANSFERF_NUMERIC_defaultV, &defaultVoltage);
					ATOMS_KILLER_makeTransferFunction (&f, parameters[0], parameters[1], parameters[2]);
					defaultDet = TRANSFERFUNCT_applyInv (&f, defaultVoltage);
					SetCtrlVal (panelTransferFunction, TRANSFERF_NUMERIC_defaultDet, defaultDet);
					break;
				case TRANSFERF_NUMERIC_defaultDet:
					GetCtrlVal (panelTransferFunction, TRANSFERF_NUMERIC_defaultDet, &defaultDet);
					ATOMS_KILLER_makeTransferFunction (&f, parameters[0], parameters[1], parameters[2], 0);
					defaultVoltage = TRANSFERFUNCT_apply (&f, defaultDet);
					SetCtrlVal (panelTransferFunction, TRANSFERF_NUMERIC_defaultV, defaultVoltage);
					break;
			}			
			TRANSFERFUNCT_free (&f);
			break;
	}
	return 0;
}



*/


void SCONFIG_discardPanel (void)
{
	EasyTab_RemovePanel (panelConfig, SCONFIG_CANVAS_tabCtrl, subPanelPositions);
	DiscardPanel(subPanelPositions);
	EasyTab_RemovePanel (panelConfig, SCONFIG_CANVAS_tabCtrl, subPanelRfParameters);
	DiscardPanel(subPanelRfParameters);
	EasyTab_RemovePanel (panelConfig, SCONFIG_CANVAS_tabCtrl, subPanelSignals);
	DiscardPanel(subPanelSignals);
	DiscardPanel (panelConfig);			
}


int SCONFIG_initPanel (void)
{
	Rect bounds;
	int i;
	
	
	// -----------------------------------------
    // load subpanels for different device types
	// -----------------------------------------
	EasyTab_ConvertFromCanvas (panelConfig, SCONFIG_CANVAS_tabCtrl);
	if (EasyTab_LoadPanels (panelConfig, SCONFIG_CANVAS_tabCtrl, 1, SESSIONMANAGER_uirFile,
						__CVIUserHInst,
//						CONFdet,   &subPanelDetectionParameters,
						CKILLER,   &subPanelKiller,
						CONFpos,   &subPanelPositions, 
						CONFrf,    &subPanelRfParameters, 
						SIGNALS,   &subPanelSignals, 
						0) < 0) return -1;
	SIGNALS_printInfo (subPanelSignals, SIGNALS_TEXTBOX);
	TCP_initPanelClient (panelConfig);
	EasyTab_AddPanels (panelConfig, SCONFIG_CANVAS_tabCtrl, 1,
					   TCP_panelClient(), 0);
	
	
/*	EasyTab_SetAttribute (panelConfig, SCONFIG_CANVAS_tabCtrl,
						  ATTR_EASY_TAB_ORIENTATION,
						  VAL_EASY_TAB_BTNS_ON_BOTTOM);
*/						  
	// -----------------------------------------
	//    write data to board subpanels
	// -----------------------------------------

	EasyTab_GetBounds (panelConfig, SCONFIG_CANVAS_tabCtrl,
					   VAL_EASY_TAB_EXTERIOR_BOUNDS, &bounds);
    
    setCtrlPos (panelConfig, SCONFIG_BUTTON_setAsDefault,
    		    bounds.top  + bounds.height + 10,
    			bounds.left + bounds.width 
    			- ctrlWidth (panelConfig, SCONFIG_BUTTON_setAsDefault));
    setCtrlPos (panelConfig, SCONFIG_BUTTON_restoreDefault,
    		    ctrlTop (panelConfig, SCONFIG_BUTTON_setAsDefault) ,
    			ctrlLeft (panelConfig, SCONFIG_BUTTON_setAsDefault)
    			- ctrlWidth (panelConfig, SCONFIG_BUTTON_setAsDefault) - 20);
    
	SCONFIG_POSITIONS_initPanel (NULL);
	SCONFIG_KILLER_initPanel ();
//	SCONFIG_SEQGEN_initPanel (smanagerConfig);
	DETECTORS_initPanel ();
	return 0;
}



void SCONFIG_POSITIONS_initRingReference (int panel, int control)
{
 	int i;
 	int nItems;
 	
 	// -----------------------------------------
	//    init subpanel "distances"
	// -----------------------------------------
	nItems = 0;
	for (i = 0; i < N_POSITIONS; i++) {
		if (df(i)->active) nItems ++;
	}

	setNumListItems (panel, control, nItems);
	
	nItems = 0;
	for (i = 0; i < N_POSITIONS; i++) {
		if (df(i)->active) {
		   ReplaceListItem (panel, control, nItems, df(i)->positionName, i);
		   nItems ++;
		}
	}
}


/************************************************************************/
/*
/*   edit rf parameters
/*
/************************************************************************/


void SCONFIG_getRfParameters (t_atomConfig *c)
{
	int i;
	
	for (i = 0; i < N_RF_CHANNELS; i++) {
		GetCtrlVal (subPanelRfParameters, CTRL_SCONFIG_rfFreq[i], 
				&c->rfMultiplexerFrequency[i]);
		GetCtrlVal (subPanelRfParameters, CTRL_SCONFIG_rfVelocity[i], 
				&c->rfMultiplexerVelocity [i]);
		GetCtrlVal (subPanelRfParameters, CTRL_SCONFIG_rfPower[i], 
				&c->rfMultiplexerPower    [i]); 
	}
}


void SCONFIG_setRfParameters (t_atomConfig *c)
{
	int i;
	
	for (i = 0; i < N_RF_CHANNELS; i++) {
		SetCtrlVal (subPanelRfParameters, CTRL_SCONFIG_rfFreq[i], 
				c->rfMultiplexerFrequency[i]);
		SetCtrlVal (subPanelRfParameters, CTRL_SCONFIG_rfVelocity[i], 
				c->rfMultiplexerVelocity [i]);
		SetCtrlVal (subPanelRfParameters, CTRL_SCONFIG_rfPower[i], 
				c->rfMultiplexerPower    [i]); 
	}
}


int CVICALLBACK SCONFIG_rfParametersEdited (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_KEYPRESS:
			break;
		case EVENT_COMMIT:
			SCONFIG_getRfParameters (activeSession()->atomConfig);
			SESSION_setChanges (activeSession(), 1); 
			break;
		}
	return 0;
}


/************************************************************************/
/*
/*   subpanel "acquisition
/*
/************************************************************************/

void SCONFIG_ACQUISITION_initPanel (void)
{
}



/*

void SCONFIG_ACQUISITION_getParameters (t_session *s)
{
/*	GetCtrlVal (subPanelAcquisition, CONFacq_RINGSLIDE_detector,
				&s->detector);
	GetCtrlVal (subPanelAcquisition, CONFacq_RINGSLIDE_acqMode,
				&s->mode);
}



void SCONFIG_ACQUISITION_setParameters (t_session *s)
{
/*	SetCtrlVal (subPanelAcquisition, CONFacq_RINGSLIDE_detector,
				s->detector);
	SetCtrlVal (subPanelAcquisition, CONFacq_RINGSLIDE_acqMode,
				s->mode);
}
*/


int CVICALLBACK SCONFIG_ACQUISITION_parametersEdited (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			RUN_getParameters (activeSession());
			break;
	}
	return 0;
}




/************************************************************************/
/*
/*   subpanel "distances" 
/*
/************************************************************************/


void SCONFIG_POSITIONS_initPanel (t_session *s)
{
    int top, left, height, bottom;
    t_dataField *d;
    int i;
    int distance = 3;
    int visible;
    
    top    = ctrlTop (subPanelPositions, CONFpos_NUMERIC_dummy);
    left   = ctrlLeft (subPanelPositions, CONFpos_NUMERIC_dummy);
    height = ctrlHeight (subPanelPositions, CONFpos_NUMERIC_dummy)  + distance;
    bottom = ctrlTop (subPanelPositions, CONFpos_RING_reference) - height;
    for (i = 0; i < N_POSITIONS; i++) {
    	d = df(i);
    	if (d->controlIDposition == -1) {
			d->controlIDposition = DuplicateCtrl (subPanelPositions,
												   CONFpos_NUMERIC_dummy,
												   subPanelPositions,
												   0, top, left);
			d->controlIDlabel = NewCtrl (subPanelPositions, CTRL_TEXT_MSG, df(i)->positionName, top,
						     left);
		}
		SetCtrlAttribute (subPanelPositions, d->controlIDlabel, ATTR_LEFT, 
						  left - ctrlWidth (subPanelPositions, d->controlIDlabel) - 5);

		SetCtrlAttribute (subPanelPositions, d->controlIDposition, ATTR_VISIBLE, 1);
		SetCtrlAttribute (subPanelPositions, d->controlIDlabel, ATTR_VISIBLE, 1);

		top += height;
		if (top > bottom) {
			top  = ctrlTop (subPanelPositions, CONFpos_NUMERIC_dummy);
			left += ctrlLeft (subPanelPositions, CONFpos_NUMERIC_dummy) +
				  ctrlWidth (subPanelPositions, CONFpos_NUMERIC_dummy);
		}
	}
	SCONFIG_POSITIONS_initRingReference  (subPanelPositions, CONFpos_RING_reference);
}



/*
void SCONFIG_SEQGEN_putGpibCommandNamesToList (int panel, int control, 
										       t_sequence *s)
{
    int i;
    
    ClearListCtrl (panel, control);
	InsertListItem (panel, control, -1, "NONE", 0);
	if (s == NULL) return;
	for (i = 1; i <= ListNumItems (s->lGpibCommands); i++)
	{
	    InsertListItem (panel, control, -1, 
	    				gpibCommandPtr (s, i)->name, i);
	}
}


void SCONFIG_SEQGEN_initPanel (t_smanagerConfig *c)
{
	SetCtrlAttribute (subPanelSequenceGeneration,
					  CONFseq_STRING_shortStr, ATTR_MAX_ENTRY_CHARS,
					  MAX_SHORTSTR_LEN-1);
	if (c->masterSequence == NULL) loadMasterSequence (c);

/*	SCONFIG_SEQGEN_putGpibCommandNamesToList (subPanelSequenceGeneration,
					  CONFseq_RING_circUpper, c->masterSequence);
	SCONFIG_SEQGEN_putGpibCommandNamesToList (subPanelSequenceGeneration, 
					  CONFseq_RING_circLower, c->masterSequence);
	SCONFIG_SEQGEN_putGpibCommandNamesToList (subPanelSequenceGeneration, 
					  CONFseq_RING_voltageRamp, c->masterSequence);

}





void SCONFIG_SEQGEN_getParameters (t_session *s, t_smanagerConfig *c)
{
	GetCtrlVal (subPanelSequenceGeneration,
				CONFseq_STRING_masterSequence, 
				c->masterSequenceFilename);
	GetCtrlVal (subPanelSequenceGeneration,
				CONFseq_STRING_dataDirectory, c->dataDirectory);
/*	getCtrlValLabel (subPanelSequenceGeneration, 
				CONFseq_RING_circUpper, s->gpibCommandCircUpper);
	getCtrlValLabel (subPanelSequenceGeneration, 
				CONFseq_RING_circLower, s->gpibCommandCircLower);
	getCtrlValLabel (subPanelSequenceGeneration, 
				CONFseq_RING_voltageRamp, s->gpibCommandVoltageRamp);
	GetCtrlVal(subPanelSequenceGeneration, CONFseq_STRING_shortStr, 
			    s->shortStr);
}

/*

void SCONFIG_SEQGEN_setParameters (t_session *s, t_smanagerConfig *c)
{
	SetCtrlVal (subPanelSequenceGeneration,
				CONFseq_STRING_masterSequence, 
				c->masterSequenceFilename);
	SetCtrlVal (subPanelSequenceGeneration,
				CONFseq_STRING_dataDirectory, 
				c->dataDirectory);
/*	setCtrlValLabel (subPanelSequenceGeneration, 
				CONFseq_RING_circUpper, s->gpibCommandCircUpper);
	setCtrlValLabel (subPanelSequenceGeneration, 
				CONFseq_RING_circLower, s->gpibCommandCircLower);
	setCtrlValLabel (subPanelSequenceGeneration, 
				CONFseq_RING_voltageRamp, s->gpibCommandVoltageRamp);
	SetCtrlVal (subPanelSequenceGeneration, 
			    CONFseq_STRING_shortStr, s->shortStr);
}



*/

void SCONFIG_getPositions (t_atomConfig *c)
{
	int i;
	
	for (i = 0; i < N_POSITIONS; i++) {
		GetCtrlVal (subPanelPositions, df(i)->controlIDposition, 
				&c->position[i]);
	}
}


void SCONFIG_setPositions (t_atomConfig *c)
{
	int i;
	int validPosition;
	
	for (i = 0; i < N_POSITIONS; i++) {
		validPosition = c->position[i] > -1000;
		SetCtrlAttribute (subPanelPositions, df(i)->controlIDposition, ATTR_DIMMED,
					!validPosition);
		SetCtrlVal (subPanelPositions, df(i)->controlIDposition, 
						  validPosition ? c->position[i] : 0);
		SetCtrlAttribute (subPanelPositions,
						  df(i)->controlIDposition, ATTR_CTRL_MODE,
						  VAL_EDIT_STATE);
		setCtrlMode (subPanelPositions, df(i)->controlIDposition, 
					 !(c->positionReference == i), 0);

	}
	SetCtrlVal (subPanelPositions, CONFpos_RING_reference,
				c->positionReference);
}



int CVICALLBACK SCONFIG_editDistances (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			SCONFIG_getPositions (activeSession()->atomConfig);
			SESSION_setChanges (activeSession(), 1); 
			break;
		}
	return 0;
}


int CVICALLBACK SCONFIG_referenceChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_atomConfig *ac;
	int sub;
	int i;
	
	switch (event)
		{
		case EVENT_COMMIT:
			ac = activeSession()->atomConfig;
			SCONFIG_getPositions (ac); 
			GetCtrlVal (subPanelPositions, CONFpos_RING_reference, &ac->positionReference);
			sub = ac->position[ac->positionReference];
			for (i = 0; i < N_POSITIONS; i++) {
				ac->position[i] -= sub;
			}
			ac->position[ac->positionReference] = 0;
			SCONFIG_setPositions (ac); 
			break;
		}
	return 0;
}





/************************************************************************/
/*
/*   BUTTONS: "set as default", "restore default"
/*
/************************************************************************/


int CVICALLBACK BTN_SCONFIG_Done (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	t_smanagerConfig *c;
	
	switch (event)
		{
		case EVENT_COMMIT:
			s = activeSession();
			c = smanagerConfig;
			SCONFIG_getRfParameters (s->atomConfig);
			SCONFIG_getPositions (s->atomConfig); 
//			SCONFIG_SEQGEN_getParameters (s, c);
			c->TCPserverName = strnewcopy (c->TCPserverName, TCP_getServerName ());
			ATOMS_VELOCITY_initPanel (s);
			SESSION_setChanges (s, 1); 
			writeSessionManagerConfig (c);
			break;
		}
	return 0;
}


int CVICALLBACK BTN_SCONFIG_setAsDefault (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			SCONFIG_getRfParameters (smanagerConfig->defaultAtomConfig);
			SCONFIG_getPositions (smanagerConfig->defaultAtomConfig); 
			smanagerConfig->TCPserverName = strnewcopy (smanagerConfig->TCPserverName, TCP_getServerName ());
			writeSessionManagerConfig (smanagerConfig);
	//			SCONFIG_SEQGEN_getParameters (activeSession(), smanagerConfig);
			break;
		}
	return 0;
}


int CVICALLBACK BTN_SCONFIG_restoreDefault (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
		{
		case EVENT_COMMIT:
			SCONFIG_setRfParameters (smanagerConfig->defaultAtomConfig);
			SCONFIG_setPositions (smanagerConfig->defaultAtomConfig); 
			SCONFIG_getRfParameters (activeSession()->atomConfig);
			SCONFIG_getPositions (activeSession()->atomConfig); 
			SESSION_setChanges (activeSession(), 1); 
			break;
		}
	return 0;
}


void SCONFIG_putAllPositions (t_atomConfig *c, int nRamseyZones)
{
	c->positionReference = POS_LASER1;
	c->position[POS_LASER1] = 0;

	
	if (nRamseyZones == 3) {
		c->position[POS_RAMSEY1]        = POSITION_3R_RAMSEY1;
		c->position[POS_CENTER_CAVITY1] = POSITION_3R_CAVITY1;
		c->position[POS_RAMSEY2]        = POSITION_3R_RAMSEY2;
		c->position[POS_CENTER_CAVITY2] = POSITION_3R_CAVITY2;
		c->position[POS_RAMSEY3]        = POSITION_3R_RAMSEY3;
	}
	else {
		c->position[POS_RAMSEY1]        = POSITION_2R_RAMSEY1;
		c->position[POS_CENTER_CAVITY1] = POSITION_2R_CAVITY1;
		c->position[POS_CENTER_CAVITY2] = POSITION_2R_CAVITY2;
		c->position[POS_RAMSEY3]        = POSITION_2R_RAMSEY3;
		c->position[POS_RAMSEY2]        = POSITION_UNASSIGNED;		
	}

/*	c->position[POS_START_R1] = c->position[POS_RAMSEY1] - HALF_SIZE_RAMSEY;
	c->position[POS_END_R1]   = c->position[POS_RAMSEY1] + HALF_SIZE_RAMSEY;
*/	
	

	c->position[POS_RING1_C1]		= c->position[POS_CENTER_CAVITY1] - HALF_SIZE_CAVITY;
	c->position[POS_RING2_C1]		= c->position[POS_CENTER_CAVITY1] + HALF_SIZE_CAVITY;
	c->position[POS_START_CAVITY1]  = c->position[POS_CENTER_CAVITY1] - HALF_SIZE_MODE;
	c->position[POS_END_CAVITY1]    = c->position[POS_CENTER_CAVITY1] + HALF_SIZE_MODE;

	c->position[POS_RING1_C2]		= c->position[POS_CENTER_CAVITY2] - HALF_SIZE_CAVITY;
	c->position[POS_RING2_C2]		= c->position[POS_CENTER_CAVITY2] + HALF_SIZE_CAVITY;
	c->position[POS_START_CAVITY2]  = c->position[POS_CENTER_CAVITY2] - HALF_SIZE_MODE;
	c->position[POS_END_CAVITY2]    = c->position[POS_CENTER_CAVITY2] + HALF_SIZE_MODE;

	c->position[POS_SHIELDINGBOX_ENTRANCE] = POSITION_SHILEDING_BOX_ENTRANCE;
	c->position[POS_SHIELDINGBOX_EXIT]     = POSITION_SHILEDING_BOX_EXIT;
	c->position[POS_HOLE_CIRC_BOX]  	   = POSITION_HOLE_CIRC_BOX;

	c->position[POS_DETECTOR1] = POSITION_DETECTOR1;
	c->position[POS_DETECTOR2] = POSITION_DETECTOR2;
	
}



int CVICALLBACK SCONFIG_setPositionsRamsey_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nRamseys;
	
	switch (event)
		{
		case EVENT_COMMIT:
			if (control == CONFpos_COMMANDBUTTON_pos3R) nRamseys = 3;
			else nRamseys = 2;
			SCONFIG_putAllPositions (activeSession()->atomConfig, nRamseys);
			SCONFIG_setPositions (activeSession()->atomConfig); 
			SESSION_setChanges (activeSession(), 1); 
			
			break;
		}
	return 0;
}



//void SCONFIG_KILLER_getValues (



int CVICALLBACK SCONFIG_SEQGEN_parametersEdited (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
//			SCONFIG_SEQGEN_getParameters (activeSession(), smanagerConfig);
			break;
	}
	return 0;
}





