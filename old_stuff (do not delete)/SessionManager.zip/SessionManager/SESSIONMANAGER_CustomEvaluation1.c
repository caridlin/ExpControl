#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"




#define CUSTOM_PATH1 "D:\\USER\\Stefan\\2006\\September\\11\\"







int MULTIPLES_nRuns (t_curve *c)
{
	int i;
	
	if (c == NULL) return 0;
	for (i = 0; i < c->nCurves; i++) {
		if (c->yValues[i] == NULL) return i;
	}
	return c->nCurves;
}

int MULTIPLES_nPointsPerCurve (t_curve *c)
{
	if (c == NULL) return 0;
	return c->nValues;
}


int *MULTIPLES_getDatasetInt (t_curve *c, int curveNr, int *sum)
{
	int nElements;
	int *newArray;
	int i;
	int s;
	
	s = 0;
	if (c == NULL) return NULL;
	if (curveNr > c->nCurves) return NULL;
	nElements = MULTIPLES_nPointsPerCurve (c);
	
	newArray = (int *) malloc (sizeof (int)* nElements);
	for (i = 0; i < nElements; i++) {
		newArray[i] = c->yValues[curveNr][i];
		s += newArray[i];
	}
	if (sum != NULL) *sum = s;
	return newArray;
}





int **MULTIPLES_getAllDatasetsInt (t_curve *c, int *nRuns, int *nPointsPerCurve)
{
	int **allData;
	int i;
	
	*nRuns = MULTIPLES_nRuns (c);
	*nPointsPerCurve = MULTIPLES_nPointsPerCurve (c);  
	
	allData = (int **) malloc (sizeof(int*) * (*nRuns));
	for (i = 0; i < *nRuns; i++) {
		allData[i] = MULTIPLES_getDatasetInt (c, i, 0);
	}
	return allData;
}



int **MULTIPLES_getAllDatasetsInt_eg (t_curve *c_g, t_curve *c_e, int *nRuns, int *nPointsPerCurve)
{
	int **allData;
	int i;
	
	*nRuns = MULTIPLES_nRuns (c_g);
	if (MULTIPLES_nRuns (c_e) != *nRuns) return NULL;
	
	*nPointsPerCurve = MULTIPLES_nPointsPerCurve (c_g);  
	if (MULTIPLES_nPointsPerCurve (c_e) != *nPointsPerCurve) return NULL;
	
	allData = (int **) malloc (sizeof(int*) * (*nRuns) * 2);
	for (i = 0; i < *nRuns; i++) {
		allData[2*i]   = MULTIPLES_getDatasetInt (c_g, i, 0);
		allData[2*i+1] = MULTIPLES_getDatasetInt (c_e, i, 0);
	}
	return allData;
}





void CUSTOM1_examplePourMichel (void)
{
	t_curve *c1;
	int nRuns, nPoints;
	int *dataArray;
	int curveNr;
	int sum;
	int i;
	int **allData;
	int lastdataset;
	
	c1 = CURVE_loadAndDisplay (CUSTOM_PATH1 "0123_QND D1 2 serp + atom e\\0123_multiples e.curve");
//	c1 = CURVE_load (CUSTOM_PATH1 "0123_QND D1 2 serp + atom e\\0123_multiples e.curve");
	if (c1 == NULL) return;
	nRuns = MULTIPLES_nRuns (c1);
	nPoints = MULTIPLES_nPointsPerCurve (c1);
	
	// pour recuperer UNE courbe
	curveNr = 10;
	dataArray = MULTIPLES_getDatasetInt (c1, curveNr, &sum);
	
	
	CUSTOM1_printf ("Curve %s contains %d runs with %d points each.\n", c1->name, nRuns, nPoints);
	sum = 0;
	CUSTOM1_printf ("The sum of all points in dataset %d is %d.\n", curveNr , sum);
	
	// pour recuperer TOUTES LES courbes
	allData	= MULTIPLES_getAllDatasetsInt (c1, &nRuns, &nPoints);
	lastdataset = nRuns-1;

	sum = 0;
	for (i = 0; i < nPoints; i++) sum += allData[lastdataset][i];
	CUSTOM1_printf ("The sum of all points in dataset %d is %d.\n", lastdataset, sum);
	
	
	
}


void CUSTOM1_startEvaluation (void)
{
	
	CUSTOM1_examplePourMichel ();
	
}
