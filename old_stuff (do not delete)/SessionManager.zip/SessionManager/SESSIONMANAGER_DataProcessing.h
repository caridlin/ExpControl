#if !defined(DATA_PROCESSING)
#define DATA_PROCESSING

#include "inifile.h"



void FILTERS_setKeepResults (t_session *s, int keep);


double COUNTERDATA_sumInterval (t_counterData *d, int timeInterval, unsigned __int64 *sumI64, unsigned *nSummed);

//double COUNTERDATA_sumInterval (t_counterData *d, int timeInterval, unsigned *nSummed);


double COUNTERDATA_averageInterval (t_counterData *d, int timeInterval);

/*
void COUNTERDATA_sumAllDatasets (t_run *r, 
							 int repetition, int counter, 
							 int nTimeIntervals,
							 int timeInterval,
						 	 double *sum, int *nSummed);
*/						 	 
						 	 
int COUNTERDATA_copyReceivedData (t_counterData *data, char *buffer, unsigned buffersize);

int COUNTERDATA_saveFile (char *buffer, unsigned buffersize);


int COUNTERDATA_calculatePlotItem (t_run *r, t_counterData *d, int repetition, int det, int plotItemNr, int sumAllRuns);

//int COUNTERDATA_calculatePlotItem (t_run *r, t_counterData *d, int plotItemNr, int sumAllRuns);


void RUN_generatePlot (t_run *r);

//int RUN_calculateAllPlotItems (t_run *r, t_counterData *d, int sumAllRuns);
int RUN_calculateAllPlotItems (t_run *r, t_counterData *d, int repetition, int detector, int sumAllRuns);


void RUN_generatePlotFromOldData (t_run *r, int plotItemID);

int RUN_calculateAllPlotItemsForAllData (t_run *r, int *nCalculated, int type);

//int RUN_calculateAllPlotItemsForAllData (t_run *r, int *nCalculated);


void CURVE_addAllPositions (t_session *s, t_curve *c);



//void RUN_generatePlotFromOldData (t_run *r, t_plotItem *p);

double errorTransfer (double n0, double n1);



void PLOTITEM_calculateTransfer_NCOUNTS (t_run *r, t_plotItem *p, 
								 double *transfer, double *errTransfer,
								 double *allTransfer, double *allErrTransfer);
								 
/*								 

void PLOTITEM_calculateTransfer_NCOUNTS (t_run *r, t_plotItem *p, t_counterData *data,
							     int sumAll,
								 double *transfer, double *errTransfer,
								 double *allTransfer, double *allErrTransfer);

*/




#endif
