#include <userint.h>
#include "UIR_SessionManager.h"
#include "INCLUDES_SESSIONMANAGER.h"

int panelSweep;

//int subPanelData         = -1;


//#define N_SWEEPS_ANALOG      3
//#define N_SWEEPS_SYNTHESIZER 2

#define MAX_SWEEP_POINTS 10001
#define MAX_PANEL_DEVICES 8

int **panelSweepDevices = NULL;
int *panelSweepSub = NULL;

//[N_SWEEPTYPES][MAX_PANEL_DEVICES];
//int *panelSweepAnalog      = NULL;
//int *panelSweepSynthesizer = NULL;




// ctrls where to display the number of sweeps
const char *sweepTypeNames[N_SWEEPTYPES] = {
	"analog outputs",
	"signal generators",
	"power supplies"
};






void SWEEP_getValues (t_sweep *s)
{
	if (s->panel < 0) return;
	switch (s->type) {
		case SWEEP_TYPE_ANALOGCHANNEL:
			GetCtrlVal (s->panel, SWEEP_a_CHECKBOX_activate, &s->active);
			GetCtrlVal (s->panel, SWEEP_a_RING_channel, &s->channel);
			GetCtrlVal (s->panel, SWEEP_a_NUMERIC_from, &s->from);
			GetCtrlVal (s->panel, SWEEP_a_NUMERIC_to,   &s->to);
			GetCtrlVal (s->panel, SWEEP_a_CHECKBOX_freqSweep, &s->sweepOn);
			break;
		case SWEEP_TYPE_SYNTHESIZER:
			GetCtrlVal (s->panel, SWEEP_s_CHECKBOX_activate, &s->active);
			GetCtrlVal (s->panel, SWEEP_s_RING_device, &s->channel);
			GetCtrlVal (s->panel, SWEEP_s_NUMERIC_from, &s->from);
			GetCtrlVal (s->panel, SWEEP_s_NUMERIC_to,   &s->to);
			GetCtrlVal (s->panel, SWEEP_s_NUMERIC_center, &s->center);
			GetCtrlVal (s->panel, SWEEP_s_NUMERIC_span,   &s->span);
			GetCtrlVal (s->panel, SWEEP_s_CHECKBOX_freqSweep, &s->sweepOn);
			GetCtrlVal (s->panel, SWEEP_s_RADIOBUTTON_RFon,   &s->rfOn);
			GetCtrlVal (s->panel, SWEEP_s_RADIOBUTTON_pulse,  &s->pulseMode);
			GetCtrlVal (s->panel, SWEEP_s_NUMERIC_outputPower, &s->outputPower);
			GetCtrlVal (s->panel, SWEEP_s_NUMERIC_harmonic, &s->harmonic);
			break;
		case SWEEP_TYPE_POWERSUPPLY:
			GetCtrlVal (s->panel, SWEEP_p_CHECKBOX_activate, &s->active);
			GetCtrlVal (s->panel, SWEEP_p_CHECKBOX_sweep,    &s->sweepOn);
			GetCtrlVal (s->panel, SWEEP_p_RING_device, 	     &s->channel);
			GetCtrlVal (s->panel, SWEEP_p_NUMERIC_from, 	 &s->from);
			GetCtrlVal (s->panel, SWEEP_p_NUMERIC_to,   	 &s->to);
			GetCtrlVal (s->panel, SWEEP_p_NUMERIC_current, 	 &s->current_mA);
			GetCtrlVal (s->panel, SWEEP_p_NUMERIC_devChannel,&s->deviceChannel);
			break;
	}
}



void SWEEP_setValues (t_sweep *s, int nPoints)
{
	if (s->panel < 0) return;
	switch (s->type) {
		case SWEEP_TYPE_ANALOGCHANNEL:
			SetCtrlVal (s->panel, SWEEP_a_CHECKBOX_activate, s->active);
			SetCtrlVal (s->panel, SWEEP_a_CHECKBOX_freqSweep, s->sweepOn);
			SetCtrlVal (s->panel, SWEEP_a_RING_channel, s->channel);
			SetCtrlVal (s->panel, SWEEP_a_NUMERIC_from, s->from);
			SetCtrlVal (s->panel, SWEEP_a_NUMERIC_to,   s->to);
			if (nPoints > 1) 
				SetCtrlVal (s->panel, SWEEP_a_NUMERIC_stepSize,  (s->to - s->from) / (nPoints-1));
			else
				SetCtrlVal (s->panel, SWEEP_a_NUMERIC_stepSize,  0.0);
			if (nPoints > 0) SetCtrlVal (s->panel, SWEEP_a_NUMERIC_nPoints,  nPoints);
			SetAttributeForCtrls (s->panel, ATTR_DIMMED, !s->sweepOn|| !s->active, 0,
								  SWEEP_a_NUMERIC_to,
								  SWEEP_a_TEXTMSG_from,
								  SWEEP_a_TEXTMSG_to, 
								  SWEEP_a_NUMERIC_stepSize,
								  SWEEP_a_TEXTMSG_stepSize,
								  SWEEP_a_NUMERIC_nPoints,
								  0);
			SetAttributeForCtrls (s->panel, ATTR_DIMMED, !s->active, 0,
								  SWEEP_a_RING_channel,
								  SWEEP_a_NUMERIC_from,
								  SWEEP_a_CHECKBOX_freqSweep,
								  0);
			break;
		case SWEEP_TYPE_SYNTHESIZER:
			SetCtrlVal (s->panel, SWEEP_s_CHECKBOX_activate, s->active);
			SetCtrlVal (s->panel, SWEEP_s_RING_device, 	     s->channel);
			SetCtrlVal (s->panel, SWEEP_s_NUMERIC_from, 	 s->from);
			SetCtrlVal (s->panel, SWEEP_s_NUMERIC_to,   	 s->to);
			SetCtrlVal (s->panel, SWEEP_s_NUMERIC_center, 	 s->center);
			SetCtrlVal (s->panel, SWEEP_s_NUMERIC_span,      s->span);
			if (nPoints > 1)
				SetCtrlVal (s->panel, SWEEP_s_NUMERIC_stepsize, 1000.0 * (s->to - s->from) / (nPoints-1) );
			else 
				SetCtrlVal (s->panel, SWEEP_s_NUMERIC_stepsize, 0.0);
			SetCtrlVal (s->panel, SWEEP_s_CHECKBOX_freqSweep, s->sweepOn);
			SetCtrlVal (s->panel, SWEEP_s_RADIOBUTTON_RFon,   s->rfOn);
			SetCtrlVal (s->panel, SWEEP_s_RADIOBUTTON_pulse,  s->pulseMode);
			SetCtrlVal (s->panel, SWEEP_s_NUMERIC_outputPower, s->outputPower);
			SetCtrlVal (s->panel, SWEEP_s_NUMERIC_harmonic, s->harmonic);
			SetCtrlVal (s->panel, SWEEP_s_NUMERIC_nPoints, nPoints);
			
			
			SetAttributeForCtrls (s->panel, ATTR_DIMMED, !s->sweepOn|| !s->active, 0,
								  SWEEP_s_NUMERIC_from,
								  SWEEP_s_TEXTMSG_from,
								  SWEEP_s_NUMERIC_to,
								  SWEEP_s_TEXTMSG_to, 
								  SWEEP_s_NUMERIC_span,
								  SWEEP_s_TEXTMSG_span,
								  SWEEP_s_NUMERIC_stepsize,
								  SWEEP_s_TEXTMSG_stepsize,
								  SWEEP_s_NUMERIC_nPoints,
								  0);
			SetAttributeForCtrls (s->panel, ATTR_DIMMED, !s->active, 0,
								  SWEEP_s_RING_device,
								  SWEEP_s_NUMERIC_center,
								  SWEEP_s_TEXTMSG_center,
								  SWEEP_s_NUMERIC_harmonic,
								  SWEEP_s_CHECKBOX_freqSweep,
								  SWEEP_s_RADIOBUTTON_RFon,
								  SWEEP_s_RADIOBUTTON_pulse,
								  SWEEP_s_TEXTMSG_mode,
								  SWEEP_s_NUMERIC_outputPower,
								  SWEEP_s_TEXTMSG_dBm, 
								  0);
			SetAttributeForCtrls (s->panel, ATTR_DIMMED, !s->active || !GPIBDEVICE_hasPulseMode(s->channel), 0,
								  SWEEP_s_RADIOBUTTON_pulse,
								  SWEEP_s_TEXTMSG_mode,
								  0);
			break;
		case SWEEP_TYPE_POWERSUPPLY:
			SetCtrlVal (s->panel, SWEEP_p_CHECKBOX_activate, s->active);
			SetCtrlVal (s->panel, SWEEP_p_CHECKBOX_sweep,    s->sweepOn);
			SetCtrlVal (s->panel, SWEEP_p_RING_device, 	     s->channel);
			SetCtrlVal (s->panel, SWEEP_p_NUMERIC_from, 	 s->from);
			SetCtrlVal (s->panel, SWEEP_p_NUMERIC_to,   	 s->to);
			SetCtrlVal (s->panel, SWEEP_p_NUMERIC_current, 	 s->current_mA);
			SetCtrlVal (s->panel, SWEEP_p_NUMERIC_devChannel,s->deviceChannel);
			if (nPoints > 1) 
				SetCtrlVal (s->panel, SWEEP_p_NUMERIC_stepSize,  (s->to - s->from) / (nPoints-1));
			else
				SetCtrlVal (s->panel, SWEEP_p_NUMERIC_stepSize,  0.0);
			SetCtrlVal (s->panel, SWEEP_p_NUMERIC_nPoints,  nPoints);
			
			SetAttributeForCtrls (s->panel, ATTR_DIMMED, !s->sweepOn|| !s->active, 0,
								  SWEEP_p_NUMERIC_to,
								  SWEEP_p_TEXTMSG_from,
								  SWEEP_p_TEXTMSG_to, 
								  SWEEP_p_NUMERIC_stepSize,
								  SWEEP_p_TEXTMSG_stepSize,
								  SWEEP_p_NUMERIC_nPoints,
								  0);
			SetAttributeForCtrls (s->panel, ATTR_DIMMED, !s->active, 0,
								  SWEEP_p_RING_device,
//								  SWEEP_p_TEXTMSG_from,
								  SWEEP_p_NUMERIC_from,
								  SWEEP_p_CHECKBOX_sweep,
								  SWEEP_p_NUMERIC_devChannel,
								  SWEEP_p_NUMERIC_current,
								  SWEEP_p_TEXTMSG_mA,
								  0);

			break;
			
	}
}



//void SWEEP_appedAllDataToSession (t_session *s)
/*
void SWEEP_appedAllDataToSession (t_session *s)
{
	 int i;
	 t_sweep *sw;
	 
	 
	 
	 for (i = 0; i < N_SWEEPS_ANALOG; i++) {
	 	sw = SWEEP_new (s);
	 	SWEEP_init (sw);
	 	sw->type  = SWEEP_TYPE_ANALOGCHANNEL;
//	 	sw->panel = panelSweepAnalog[i];
	 	SWEEP_getValues (sw);
	 }
	 
	 for (i = 0; i < N_SWEEPS_SYNTHESIZER; i++) {
	 	sw = SWEEP_new (s);
	 	SWEEP_init (sw);
	 	sw->type  = SWEEP_TYPE_SYNTHESIZER;
	 	sw->panel = panelSweepSynthesizer[i];
	 	SWEEP_getValues (sw);
	 }
}

*/


/*
void SWEEP_fillChangeModesToRing (int panel, int control)
{
	ClearListCtrl (panel, control);
	InsertListItem (panel, control, -1, "every repetition", 
				    SWEEP_CHANGEMODE_REPETITION);
	InsertListItem (panel, control, -1, "every curve", 
				    SWEEP_CHANGEMODE_CURVE);
}
*/


void SWEEP_fillAnalogChannelNamesToRing (int panel, int control)
{
	int i;

	setNumListItems (panel, control, N_ACTIVE_AO_CHANNELS);
	for (i = 0; i < N_ACTIVE_AO_CHANNELS; i++) {
	    ReplaceListItem (panel, control, i, 
	    				strNameName (str_AnalogChannelNames(i), strAOlabel (i)), i);
	}
}


void SWEEP_fillGpibSignalGeneratorNamesToRing (int panel, int control)
{
	int i;

	ClearListCtrl (panel, control);
	for (i = 0; i < N_SIGNALGENERATORS; i++) {
    	InsertListItem (panel, control, -1, 
	    				strNameName (intToStr(GPIB_ADDRESSES_SIGNALGENERATORS[i]), strGPIBlabel (GPIB_ADDRESSES_SIGNALGENERATORS[i])), 
	    				GPIB_ADDRESSES_SIGNALGENERATORS[i]);
	}
}


void SWEEP_fillGpibPowerSupplyNamesToRing (int panel, int control)
{
	int i;

	ClearListCtrl (panel, control);
	for (i = 0; i < N_POWERSUPPLIES; i++) {
    	InsertListItem (panel, control, -1, 
	    				strNameName (intToStr(GPIB_ADDRESSES_POWERSUPPLIES[i]), strGPIBlabel (GPIB_ADDRESSES_POWERSUPPLIES[i])), 
	    				GPIB_ADDRESSES_POWERSUPPLIES[i]);
	}
}


void SWEEP_count (t_session *s)
{
	int i;
	t_sweep *sw;
	
	for (i = 0; i < N_SWEEPTYPES; i++) s->nSweeps[i] = 0;

	for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
		sw = SWEEP_ptr (s, i);
		if ((sw->type >= 0) && (sw->type < N_SWEEPTYPES)) s->nSweeps[sw->type]++;
	}
	
	for (i = 0; i < N_SWEEPTYPES; i++) {
		if (s->nSweeps[i] > MAX_PANEL_DEVICES) s->nSweeps[i] = MAX_PANEL_DEVICES;
		// create at least 1 sweep per type
		if (s->nSweeps[i] == 0) {
		 	sw = SWEEP_new (s);
		 	SWEEP_init (sw);
		 	sw->type  = i;
		}
	}
}



void SWEEP_matchPanelHandles (t_session *s)
{
	int i, n;
	t_sweep *sw;
	int nAttributed[N_SWEEPTYPES];
	
	for (i = 0; i < N_SWEEPTYPES; i++) nAttributed[i] = 0;

	for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
		sw = SWEEP_ptr (s, i);
		if ((sw->type >= 0) && (sw->type < N_SWEEPTYPES)) {
			n = nAttributed[sw->type];
			if (n < MAX_PANEL_DEVICES) sw->panel = panelSweepDevices[sw->type][n];
			nAttributed[sw->type]++;
		}
	}
}




void SWEEP_initPanelDevices (t_session *s)
{
	const int panelID[N_SWEEPTYPES] = {SWEEP_a, SWEEP_s, SWEEP_p};
	int top, topDevice, leftDevice;
	int n, i;
	
	top = 0;
	for (n = 0; n < N_SWEEPTYPES; n++) { 
		topDevice = ctrlBottom (panelSweepSub[n], SWEEP_sub_NUMERIC_nSweeps) + 5;
		leftDevice = ctrlLeft (panelSweepSub[n], SWEEP_sub_TEXTMSG_type + 5);
		for (i = 0; i < s->nSweeps[n]; i++) {
			if (panelSweepDevices[n][i] <= 0) {
				panelSweepDevices[n][i] = LoadPanel (panelSweepSub[n], SESSIONMANAGER_uirFile, panelID[n]);
				switch (n) {
				    case SWEEP_TYPE_ANALOGCHANNEL:
						SWEEP_fillAnalogChannelNamesToRing (panelSweepDevices[n][i], SWEEP_a_RING_channel);
						SetCtrlAttribute (panelSweepDevices[n][i], SWEEP_a_NUMERIC_nPoints, ATTR_MAX_VALUE,
									  MAX_SWEEP_POINTS);
						SetCtrlAttribute (panelSweepDevices[n][i], SWEEP_a_DECORATION, ATTR_TOP, 0);
						SetCtrlAttribute (panelSweepDevices[n][i], SWEEP_a_DECORATION, ATTR_LEFT, -2);
						break;
				 	case SWEEP_TYPE_SYNTHESIZER:
              			SWEEP_fillGpibSignalGeneratorNamesToRing (panelSweepDevices[n][i], SWEEP_s_RING_device);
						SetCtrlAttribute (panelSweepDevices[n][i], SWEEP_s_NUMERIC_nPoints, ATTR_MAX_VALUE,
						  				  MAX_SWEEP_POINTS);
						SetCtrlAttribute (panelSweepDevices[n][i], SWEEP_s_DECORATION, ATTR_TOP, 0);
						SetCtrlAttribute (panelSweepDevices[n][i], SWEEP_s_DECORATION, ATTR_LEFT, -2);
						break;
				 	case SWEEP_TYPE_POWERSUPPLY:
						SWEEP_fillGpibPowerSupplyNamesToRing (panelSweepDevices[n][i], SWEEP_s_RING_device);   
						SetCtrlAttribute (panelSweepDevices[n][i], SWEEP_p_NUMERIC_nPoints, ATTR_MAX_VALUE,
						  				  MAX_SWEEP_POINTS);
						SetCtrlAttribute (panelSweepDevices[n][i], SWEEP_p_DECORATION, ATTR_TOP, 0);
						SetCtrlAttribute (panelSweepDevices[n][i], SWEEP_p_DECORATION, ATTR_LEFT, -2);
						break;
				}
			}
			SetPanelPos (panelSweepDevices[n][i], topDevice, leftDevice);
	 		topDevice += panelHeight (panelSweepDevices[n][i]);
			displayPanel2 (panelSweepDevices[n][i]);
		}
		for (i = s->nSweeps[n]; i < MAX_PANEL_DEVICES; i++) 
			if (panelSweepDevices[n][i] >= 0) HidePanel (panelSweepDevices[n][i]);
		SetPanelSize (panelSweepSub[n], topDevice+5, panelWidth(panelSweep)-20);
	    SetCtrlAttribute (panelSweepSub[n], SWEEP_sub_DECORATION, ATTR_HEIGHT, 
	 				      panelHeight(panelSweepSub[n]));
	    SetCtrlAttribute (panelSweepSub[n], SWEEP_sub_DECORATION, ATTR_WIDTH, 
	 				      panelWidth(panelSweepSub[n]));
		SetPanelPos (panelSweepSub[n], top, 0);
		top += panelHeight (panelSweepSub[n]);
		displayPanel2 (panelSweepSub[n]);
	}
}




int SWEEP_initPanel (void)
{
	 int top, left;
	 t_sweep startValues;
	 int i, n;
	 
	 if (panelSweepDevices == NULL) {
	 	// allocate memory for panel handles 
	 	// and initialize
	 	 panelSweepDevices = (int **) malloc (sizeof (int *) * N_SWEEPTYPES);
	 	 panelSweepSub = (int *) calloc (sizeof (int), N_SWEEPTYPES);
		 for (n = 0; n < N_SWEEPTYPES; n++) {
		 	 panelSweepDevices[n] = (int *) calloc (sizeof (int), MAX_PANEL_DEVICES);
		 	 panelSweepSub[n] = LoadPanel (panelSweep, SESSIONMANAGER_uirFile, SWEEP_sub);
		 	 SetCtrlVal (panelSweepSub[n], SWEEP_sub_TEXTMSG_type, sweepTypeNames[n]); 
		 	 SetCtrlAttribute (panelSweepSub[n], SWEEP_sub_NUMERIC_nSweeps, ATTR_MAX_VALUE, MAX_PANEL_DEVICES); 
		 	 SetCtrlAttribute (panelSweepSub[n], SWEEP_sub_NUMERIC_nSweeps, ATTR_MIN_VALUE, 1); 
		 }
	 }
	return 0; 
	 
}



void SWEEP_displayAll (t_session *s)
{
	t_sweep *sw;
	int i;
	
	SWEEP_count (s);
	SWEEP_initPanelDevices (s);
	SWEEP_matchPanelHandles (s);

	for (i = 0; i < N_SWEEPTYPES; i++) {
		SetCtrlVal (panelSweepSub[i], SWEEP_sub_NUMERIC_nSweeps, s->nSweeps[i]);
	}

	for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
		sw = SWEEP_ptr (s, i);
		SWEEP_setValues (sw, s->nSweepPoints);
	}
	
}




int CVICALLBACK SWEEP_frequencyChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_sweep *sw;
	t_session *s;
	double stepsize;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			sw = SWEEP_ptrFromPanel (s, panel);
			if (sw == NULL) {
//				SWEEP_appedAllDataToSession (s);
				Breakpoint();
				sw = SWEEP_ptrFromPanel (s, panel);
			}
			else {
				SWEEP_getValues (sw);
			}
			switch (control) {
				case SWEEP_s_NUMERIC_center:
				case SWEEP_s_NUMERIC_span:
					// keep old stepsize
					stepsize = (sw->to - sw->from) / (s->nSweepPoints-1);
					// claculate new start and stop values
					sw->from = sw->center - sw->span/2000.0;
					sw->to   = sw->center + sw->span/2000.0;
					s->nSweepPoints = abs (RoundRealToNearestInteger((sw->to - sw->from) / stepsize)) + 1;
					break;
				case SWEEP_s_NUMERIC_from:
				case SWEEP_s_NUMERIC_to:
					sw->span   = (sw->to - sw->from) * 1000.0;
					sw->center =  sw->from + (sw->to - sw->from) / 2;
					break;
			}
			SESSION_setChanges (s, 1);
			SWEEP_setValues (sw, s->nSweepPoints);
			break;
	}
	return 0;
}



int CVICALLBACK SWEEP_ANALOG_stepChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_sweep *sw;
	t_session *s;
	double stepSize;

	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			switch (control) {
				case SWEEP_a_NUMERIC_nPoints: 
					GetCtrlVal (panel, control, &s->nSweepPoints);
					SWEEP_displayAll (s);
					break;
				case SWEEP_a_NUMERIC_stepSize:
					sw = SWEEP_ptrFromPanel (s, panel);
					GetCtrlVal (panel, control, &stepSize);
					if (sw == NULL) {
						Breakpoint();

//						SWEEP_appedAllDataToSession (s);
						sw = SWEEP_ptrFromPanel (s, panel);
					}
					else {
						SWEEP_getValues (sw);
					}
					if (stepSize != 0.0) {
						s->nSweepPoints = abs(RoundRealToNearestInteger ((sw->to - sw->from) / stepSize)) + 1;
						if (s->nSweepPoints > MAX_SWEEP_POINTS) s->nSweepPoints  = MAX_SWEEP_POINTS;
						if (s->nSweepPoints < 2) s->nSweepPoints = 2;
					}
					SWEEP_displayAll (s);
					break;
			}
			break;
	}
	return 0;
}


int CVICALLBACK SWEEP_GPIB_stepChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_sweep *sw;
	t_session *s;
	double stepSize;

	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			sw = SWEEP_ptrFromPanel (s, panel);
			if (sw == NULL) {
//						SWEEP_appedAllDataToSession (s);
				Breakpoint();
				sw = SWEEP_ptrFromPanel (s, panel);
			}
			else {
				SWEEP_getValues (sw);
			}
			switch (control) {
				case SWEEP_s_NUMERIC_nPoints: 
					GetCtrlVal (panel, control, &s->nSweepPoints);
					GetCtrlVal (panel, SWEEP_s_NUMERIC_stepsize, &stepSize);
					if (s->nSweepPoints > 1) {
						sw->span = stepSize * (s->nSweepPoints - 1);
						sw->from = sw->center - sw->span/2000.0;
						sw->to   = sw->center + sw->span/2000.0;
					}
					SWEEP_displayAll (s);
					break;
				case SWEEP_s_NUMERIC_stepsize:
					GetCtrlVal (panel, control, &stepSize);
/*					if (stepSize != 0.0) {  
						s->nSweepPoints = abs (RoundRealToNearestInteger (sw->span / stepSize)) + 1;
						if (s->nSweepPoints > MAX_SWEEP_POINTS) s->nSweepPoints  = MAX_SWEEP_POINTS;
						if (s->nSweepPoints < 2) s->nSweepPoints = 2;
					}
*/					if (s->nSweepPoints > 1) {
						sw->span = stepSize * (s->nSweepPoints - 1);
						sw->from = sw->center - sw->span/2000.0;
						sw->to   = sw->center + sw->span/2000.0;
					}
					SWEEP_displayAll (s);
					break;
			}
			break;
	}
	return 0;
}


int CVICALLBACK SWEEP_parameterChanged (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_sweep *sw;
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();

			sw = SWEEP_ptrFromPanel (s, panel);
			if (sw == NULL) {
				Breakpoint();
//SWEEP_appedAllDataToSession (s);
				sw = SWEEP_ptrFromPanel (s, panel);
			}
			else {
				SWEEP_getValues (sw);
			}
			SESSION_setChanges (s, 1);
			SWEEP_setValues (sw, s->nSweepPoints);
			break;
	}
	return 0;
}


double SWEEP_value (double start, double increment, int nStepRepetitions, int repetition)
{
	int nRun;
	
	if (nStepRepetitions == 0) return 0;
	nRun = repetition / nStepRepetitions;
	return start  + nRun * increment;
}


double SWEEP_value2 (t_sweep *s, int nRepetitions, int currentRepetition)
{
    return getStepOutputVoltage (s->from, s->to,  s->stepRepetitions,
    							 nRepetitions, currentRepetition);
}



void SWEEP_displayListOfSweeps (t_session *s, int panel, int ctrl)
{
	int i, n, firstActiveSweep;
	t_sweep *sw, *lastActiveSweep;
	int nItems, nSweeps;

	SWEEP_createListOfSweeps (s);

	nSweeps = ListNumItems (s->lSweeps);
	nItems = 0;
	for (i = 1; i <= nSweeps; i++) {
		sw = SWEEP_ptr (s, i);
		if (sw->active && sw->sweepOn) nItems++;
	}

	setNumListItems (panel, ctrl, nItems);
	
	n = 0;
	firstActiveSweep = 0;
	for (i = 1; i <= nSweeps; i++) {
		sw = SWEEP_ptr (s, i);
		if (sw->active && sw->sweepOn) {
			if (firstActiveSweep == 0) firstActiveSweep = i;
			ReplaceListItem (panel, ctrl, n, sw->name, i);
			n++;
		}
	}
	
	// check if selected sweep is still active
	// if not: activate other sweep
	lastActiveSweep = SWEEP_ptr (s, s->plotSweepParameter);
	if (lastActiveSweep != NULL) {
		if (!lastActiveSweep->active || !lastActiveSweep->sweepOn) {
			s->plotSweepParameter = firstActiveSweep;
		}
	}
	
	SetCtrlVal (panel, ctrl, s->plotSweepParameter);
	listboxCheckOnlyActiveItem (panel, ctrl);

}



t_sweep *SWEEP_appendActive (t_session *s)
{
	t_sweep *sw;
	
 	sw = SWEEP_new (s);
 	SWEEP_init (sw);
 	sw->active = 1;   
 	return sw;
	
}


	
	// -------------------------------------
	// -------------------------------------
	//     insert swept killer points
	// -------------------------------------
	// -------------------------------------

void SWEEP_createList_insertSweptKillerPoints (t_session *s, int atomNr)
{
	int  c, n;
	t_atom *a;
	t_sweep *sw;
	t_point *p;

 	a = ATOM_ptr (s, atomNr);
 	for (c = 0; c < N_CAVITIES ; c++) {
		// -------------------------------------
		//     variable killer start
		// -------------------------------------
		if (a->killerActive[c]) {
	 		for (n = 0; n < a->nKillerPoints[c]; n++) {
				p = &a->killerPoints[c][n];
	 			if (p->varyTime) {
					// -------------------------------------
					//     point with variable time
					// -------------------------------------
			 		sw =  SWEEP_appendActive (s);
				 	POINTS_calculateValues (p, 1, s->nSweepPoints-1);
				 	sw->from = p->timeStart_ns / 1000;
				 	sw->to   = p->thisTime_ns  / 1000;
				 	sw->increment = p->timeIncrement_ns / 1000;
				 	sw->stepRepetitions = p->stepRepetitions;
				 	sw->nPoints = s->nSweepPoints/ p->stepRepetitions;
				 	sprintf (sw->name, "%1.1f �s --> %1.1f �s (%d points), atom %s, cavity %d, killer point %d",
			 			 	 sw->from, sw->to, sw->nPoints,
			 			 	 strNameName (intToStr(atomNr), a->name), c+1, n+1); 
					strcpy (sw->plotAxisName, "killer point start");
					strcpy (sw->units, "�s");
					strcpy (sw->quantity, "startTime");
	 			}
	 			if (p->varyValue) {
					// -------------------------------------
					//     point with variable frequency
					// -------------------------------------
				 	sw =  SWEEP_appendActive (s);
				 	p = &a->killerPoints[c][n];
				 	POINTS_calculateValues (p, 1, s->nSweepPoints-1);
				 	sw->from = p->valueStart;
				 	sw->to   = p->thisValue;
				 	sw->increment = p->timeIncrement_ns;
				 	sw->stepRepetitions = p->stepRepetitions;
				 	sw->nPoints = s->nSweepPoints/ p->stepRepetitions;
				 	sprintf (sw->name, "%1.2f kHz --> %1.2f kHz (%d pts), atom %s, cavity %d, killer point %d",
				 			 sw->from, sw->to, sw->nPoints,
				 			 strNameName (intToStr(atomNr), a->name), c+1, n+1); 
					strcpy (sw->plotAxisName, "killer point frequency");
					strcpy (sw->units, "kHz");
					strcpy (sw->quantity, "frequency");
	 			}
	 		}
 		}
	}
}


// -------------------------------------
// -------------------------------------
//     insert swept events
// -------------------------------------
// -------------------------------------
void SWEEP_createList_insertSweptEvents (t_session *s, int atomNr)
{
	int i;
	t_atom *a;
	t_sweep *sw;
	t_atomEvent *e;
	char help1[200];

 	a = ATOM_ptr (s, atomNr);

	for (i = 1; i <= ListNumItems (a->lAtomEvents); i++) {
	 	e = ATOMEVENT_ptr (a, i);
	 	if (e->active) {
	 		if (e->pulseStartVary) {
				// -------------------------------------
				//     event with variable start time
				// -------------------------------------
		 		sw =  SWEEP_appendActive (s);
			 	sw->from = e->pulseStartFirst;
				sw->to   = SWEEP_value (e->pulseStartFirst,
										e->pulseStartIncrement,
		 								1, s->nSweepPoints-1);
			 	sw->increment = e->pulseStartIncrement;
			 	sw->nPoints = s->nSweepPoints;
			 	sprintf (sw->name, "%1.1f �s --> %1.1f �s (%d pts), atom %s, event %s, pulse start CH %s",
		 			 	 sw->from, sw->to, sw->nPoints,
		 			 	 strNameName (intToStr(atomNr), a->name),
		 			 	 strNameName (intToStr (i), e->name),
		 			 	 strNameName (str_ChannelNames(e->digitalChannel), strDIGlabel (e->digitalChannel))); 
				sprintf (sw->plotAxisName, "%s start", e->name);
				strcpy (sw->units, "�s");
				strcpy (sw->quantity, "startTime");
	 		}
	 		if (e->pulseDurationVary) {
				// -------------------------------------
				//     event with variable duration
				// -------------------------------------
		 		sw =  SWEEP_appendActive (s);
			 	sw->from = e->pulseDurationFirst;
				sw->to   = SWEEP_value (e->pulseDurationFirst,
										e->pulseDurationIncrement,
		 								1, s->nSweepPoints-1);
			 	sw->increment = e->pulseDurationIncrement;
			 	sw->nPoints = s->nSweepPoints;
			 	sprintf (sw->name, "%1.1f �s --> %1.1f �s (%d pts), atom %s, event %s, pulse duration CH %s",
		 			 	 sw->from, sw->to, sw->nPoints,
		 			 	 strNameName (intToStr(atomNr), a->name),
		 			 	 strNameName (intToStr (i), e->name),
		 			 	 strNameName (str_ChannelNames(e->digitalChannel), strDIGlabel (e->digitalChannel))); 
				sprintf (sw->plotAxisName, "%s duration", e->name);
				strcpy (sw->units, "�s");
				strcpy (sw->quantity, "duration");
	 		}
	 	}
	}
}


void SWEEP_freeAllInternalTypes (t_session *s)
{
	int i;
	t_sweep *sw;
	
	for (i = ListNumItems (s->lSweeps); i > 0; i--) {
   		sw = SWEEP_ptr (s, i);
		if ((sw->type < 0) || (sw->type >= N_SWEEPTYPES)) SWEEP_delete (s, i);
	}
}



void SWEEP_createListOfSweeps (t_session *s)
{
	int i, c, n;
	t_atom *a;
	t_sweep *sw;
	t_point *p;
	t_atomEvent *e;
	
	SWEEP_freeAllInternalTypes (s);	
	for (i = 1; i <= ListNumItems (s->lSweeps); i++) {
		sw = SWEEP_ptr (s, i);
		if (sw->sweepOn && sw->active) {
			switch (sw->type) {
				case SWEEP_TYPE_ANALOGCHANNEL:
				 	sw->nPoints = s->nSweepPoints;
				 	sprintf (sw->name, "%1.3f V --> %1.3f V (%d pts), %s",
							 sw->from, sw->to, sw->nPoints,
							 strNameName (str_AnalogChannelNames(sw->channel), strAOlabel (sw->channel))
				 			 ); 
					sprintf (sw->plotAxisName, "%s", strAOlabel (sw->channel));
					strcpy (sw->units, "V");
					strcpy (sw->quantity, "voltage");
				 	break;
				 case SWEEP_TYPE_SYNTHESIZER:
				 	sw->nPoints = s->nSweepPoints;
				 	sprintf (sw->name, "%1.7f GHz --> %1.7f GHz (%d points), GPIB #%s",
							 sw->from, sw->to, sw->nPoints,
							 strNameName (intToStr(sw->channel), strGPIBlabel (sw->channel)));
					sprintf (sw->plotAxisName, "freq. %s", strGPIBlabel (sw->channel));
					strcpy (sw->units, "GHz");
					strcpy (sw->quantity, "frequency");
					break;
				 case SWEEP_TYPE_POWERSUPPLY:
				 	sw->nPoints = s->nSweepPoints;
				 	sprintf (sw->name, "%1.3f V --> %1.3f V (%d points), GPIB #%s",
							 sw->from, sw->to, sw->nPoints,
							 strNameName (intToStr(sw->channel), strGPIBlabel (sw->channel)));
					sprintf (sw->plotAxisName, "%s", strGPIBlabel (sw->channel));
					strcpy (sw->units, "V");
					strcpy (sw->quantity, "voltage");
					break;
			}
		}
			
	}
	for (i = 1; i <= ListNumItems (s->lAtoms); i++) {
		SWEEP_createList_insertSweptKillerPoints (s, i);
		SWEEP_createList_insertSweptEvents (s, i);
	}


}


 //=======================================================================
//
//    create sweep with number of repetitions as sweep parameter
//
//=======================================================================
t_sweep *SWEEP_repetitionNr (t_session *s) 
{
	static t_sweep d;
	static int firstcall = 1;
	
	if (firstcall) {
		// init static variable if functon is called the first time
		SWEEP_init (&d);
//		strcpy (d.name, "DIG sweep voltage detector 2");
//		strcpy (d.plotAxisName, "voltage detector 2");
//		d.changeMode = SWEEP_CHANGEMODE_CURVE;
		d.type       = SWEEP_TYPE_REPETITION;
		firstcall = 0;
		d.channel	  = -1;
		strcpy (d.name, "repetition no.");
		strcpy (d.plotAxisName, "repetition no.");
		strcpy (d.quantity, "repetitionNo");
		d.active     = 1;
		d.from		  = 1;
	}
	d.to		  = s->nSweepPoints;
	d.nPoints     = s->nSweepPoints;
	d.stepRepetitions = 1;
	return &d;
}





  
//=======================================================================
//
//    create "DIG" sweep
//
//=======================================================================
t_sweep *SWEEP_dig (t_session *s) 
{
	static t_sweep d;
	static int firstcall = 1;
	
	if (firstcall) {
		// init static variable if functon is called the first time
		SWEEP_init (&d);
//		strcpy (d.name, "DIG sweep voltage detector 2");
//		strcpy (d.plotAxisName, "voltage detector 2");
//		d.changeMode = SWEEP_CHANGEMODE_CURVE;
		d.type       = SWEEP_TYPE_ANALOGCHANNEL;
		firstcall = 0;
	}
	d.channel	  = s->DIG_channel;
	strcpy (d.name, "DIG sweep ");
	strcat (d.name, strAOlabel (d.channel));
	strcpy (d.plotAxisName, strAOlabel (d.channel));
	strcpy (d.quantity, "voltage");
	d.active     = 1;
	d.from		  = s->DIG_voltageFrom;
	d.to		  = s->DIG_voltageTo;
	d.nPoints     = s->DIG_nSteps;
	d.stepRepetitions = s->DIG_copiesPerStep;
	return &d;
}



int SWEEP_getTypeFromPanel (int panel)
{
	int i;
	for (i = 0; i < N_SWEEPTYPES; i++) {
		if (panelSweepSub[i] == panel) return i;
	}
	return -1;
	
}

int SWEEP_isEmpty (t_sweep *sw)
{
	int empty;
	
	if (sw == NULL) return 0;
	if ((sw->type < 0) || (sw->type > N_SWEEPTYPES)) return 0;

	empty = (sw->name[0] == 0) && (!sw->active)
		&&  (sw->channel == 0) && (sw->from == 0) && (sw->to == 0);
	switch (sw->type) {
		case SWEEP_TYPE_ANALOGCHANNEL:
			break;
		case SWEEP_TYPE_SYNTHESIZER:
			empty &= (sw->center == 0) 
				  && (sw->span == 0) 
				  && (sw->rfOn == SWEEP_DEFAULT_RF_ON)
				  && (sw->harmonic == SWEEP_DEFAULT_HARMONIC) 
				  && (sw->outputPower == 0);
			break;		
		case SWEEP_TYPE_POWERSUPPLY:
			empty &= (sw->deviceChannel == 0) && (sw->current_mA == 0);
			break;		
		default:
			empty = 0;
	}
	return empty;
}


int CVICALLBACK SWEEP_nSweepsChanged_callback (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int type;
	t_session *s;
	t_sweep *sw;
	int newN, swNumber;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			SWEEP_count (s);
			type = SWEEP_getTypeFromPanel (panel);
			if (type < 0) return 0;
			GetCtrlVal (panel, control, &newN);
			if (newN < s->nSweeps[type]) {
				sw = SWEEP_ptrType (s, type, s->nSweeps[type]-1, &swNumber);
				if (sw == NULL) return 0;
				// delete sweep
				if (!SWEEP_isEmpty (sw)) {
					if (!ConfirmPopup ("Remove sweep parameter set", 
						"Do you really want to remove the sweep parameter set?")) {
						SetCtrlVal (panel, control, s->nSweeps[type]);
						return 0;
					}
				}
				SWEEP_delete (s, swNumber);
			}
			if (newN > s->nSweeps[type]) {
				sw = SWEEP_new (s);
				SWEEP_init (sw);
				sw->type = type;
				sw->active = 0;
			}
			SWEEP_displayAll (s);
			break;
	}
	return 0;
}



int SWEEP_getLastActiveNr (t_session *s)
{
	int i;
	t_sweep *sw;
	
	for (i = ListNumItems (s->lSweeps); i > 0; i--) {
		ListGetItem (s->lSweeps, &sw, i);
		if ((sw->active) && (sw->sweepOn)) return i;
	}
	return 0;
}
