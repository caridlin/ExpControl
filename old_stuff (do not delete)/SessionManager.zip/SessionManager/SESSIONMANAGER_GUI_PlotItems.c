#include <userint.h>
#include "UIR_SessionManager.h"

#include "INCLUDES_SESSIONMANAGER.h"



//=========================================================================
//
//
//      Functions: plotItem
//
//
// =========================================================================


int panelPlotItems = -1;  
int panelPlotRanges = -1;

int panelDisplay = -1;
int panelVelDist = -1;
int panelArrTimes = -1;
int panelCorrelations = -1;
int panelMultipleAsIndex = -1;
int panelSave = -1;
int panelCorrAtoms[MAX_CORRELATION_ATOMS] = {0};


enum {  
	PLOTITEM_COL_NAME,
	PLOTITEM_COL_TYPE,
	PLOTITEM_COL_DETECTOR,
	PLOTITEM_COL_COUNTER,
	PLOTITEM_COL_ATOM,
	PLOTITEM_COL_LEVEL,
	PLOTITEM_COL_INTERVAL,
	PLOTITEM_COL_AUTOSAVECURVE,
	PLOTITEM_COL_AUTOSAVETXT,
	PLOTITEM_COL_2D,
	PLOTITEM_COL_COLOR,
	PLOTITEM_COL_COLOR_CURRENT,
	PLOTITEM_COL_ERROR,
	
	N_PLOTITEM_COL
};


void PLOTITEM_CORR_initPanel (void);


const char *PLOTITEM_typeStr (t_plotItem  *p)
{
	switch (p->type) {
		case PLOT_TYPE_DIG: 		 return "DIG";
//		case PLOT_TYPE_TRANSFER:     return "TRANSF";
		case PLOT_TYPE_VELOCITYDIST: return "VEL_DIST";
		case PLOT_TYPE_ARRIVALTIMES: return "ARR_TIMES";
		case PLOT_TYPE_NCOUNTS:      
			if (p->transfer) return "TRANSFER";
			else return "N_COUNTS";
		default: return "";
	}
}


/*
void PLOTITEM_counterAutoOnOff (t_session *s) 
{
	int i;
	t_plotItem *p;
	
	if (!s->counterAuto) return;
	for (i = 0; i < N_COUNTERS; i++) s->counterOn[i] = 0;
	
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
		if (p->active) {
			PLOTITEM_getCounter (p);
			if (p->counter >= 0) s->counterOn[p->counter] = 1;
		}
	}
}
*/


int	PLOTITEM_initFilterExcludeDoubleCounts (t_session *s, t_plotItem *p)
{

	t_filter *f;
	t_filterCriterion *fc;
	t_timeInterval *currentInterval;
	int int_e,int_g;
//	nTimeIntervals = ListNumItems (s->lTimeIntervals[p->detector]);
	
	f=FILTER_new (s);
	FILTER_init(f);
	f->nFilterCriteria = 1;
	strcpy((f->name),"excludeDoubleCounts");
	fc=&f->criterion[0];
	currentInterval = NULL;
//	for(i=0;i<nTimeIntervals ;i++) {
//	ListGetItem (s->lTimeIntervals[p->detector], &currentInterval,
//						 FRONT_OF_LIST);
	int_e = TIMEINTERVAL_getNr (s, p->detector, p->atomNr, p->multiple,0);
	int_g = TIMEINTERVAL_getNr (s, p->detector, p->atomNr, p->multiple,1); 
	
	fc->active = 1;
	fc->timeIntervalFrom[p->detector] = min(int_e,int_g);
	fc->timeIntervalTo[p->detector] = max(int_e,int_g); 
	fc->hasTimeIntervalTo = 1;
	fc->maxCounts = 1;
	fc->minCounts = 1;

	return 0;	
}



void PLOTITEM_getCounter (t_plotItem *p)
{
	
	if (p->detector > 1) {
		p->counter = -1;
		return;
	}
	switch (p->type) {
		case PLOT_TYPE_NCOUNTS:
//		case PLOT_TYPE_TRANSFER:     
			if (p->transfer) p->counter = -1;
			else p->counter = COUNTERS_NCOUNTS[p->detector];
			break;
		case PLOT_TYPE_VELOCITYDIST:
		case PLOT_TYPE_ARRIVALTIMES: 
			p->counter = COUNTERS_ARRIVALTIMES[p->detector];
			break;
		default: p->counter = -1;
	}
}


t_plotItem *PLOTITEM_dig (t_session *s)
{
	static t_plotItem *dig = NULL;

	if (dig == NULL) {
		// fist call: init plotItem
	    dig = (t_plotItem *) malloc (sizeof (t_plotItem));
		PLOTITEM_init (dig);
		dig->type = PLOT_TYPE_DIG;
		dig->keepCurve = 0;
		dig->saveCurve = 1;
		dig->saveTxt = 1;
		strcpy (dig->name, "DIG");
		strcpy (dig->panelTitle, DEFAULT_DIG_WINDOWNAME);
	}
	if (s == NULL) return dig;
	dig->session = s;
	if (s->mode == SESSIONMODE_DIG) strcpy (dig->panelTitle, s->DIG_windowName);
	
	return dig;	
}



void setTreeCellYes (int panel, int ctrl, int itemNr, int col, int yes) 
{
	SetTreeCellAttribute (panel, ctrl, itemNr, col,
						  ATTR_LABEL_TEXT, yes ? stringYes : " ");
	if (yes) {
		SetTreeCellAttribute (panel, ctrl, itemNr, col,
							  ATTR_LABEL_JUSTIFY,
							  VAL_CENTER_CENTER_JUSTIFIED);
		SetTreeCellAttribute (panel, ctrl, itemNr, col, ATTR_LABEL_FONT, fontYesNo);
		SetTreeCellAttribute (panel, ctrl, itemNr, col, ATTR_LABEL_POINT_SIZE, 16);
	}


}


char *levelName (t_session *s, t_plotItem *p)
{
	if (p == NULL) return "??";	
	if ((p->level < 0) || (p->level >= MAX_LEVELS)) return "";
	return s->levelNames[p->level];
}

char *timeIntervalName (t_session *s, t_plotItem *p)
{
	t_timeInterval *t;
	int d;
	
	if (p == NULL) return "??";	
	d = p->detector;
	t = TIMEINTERVAL_ptrList (s->lTimeIntervals[d], p->interval[d]);
	if (t == NULL) return "??";
	return t->idStr;
}



void PLOTITEM_displayTreeItemError (int panel, int ctrl, t_session *s, t_plotItem *p, int treeRow)
{
	// -----------------------------
	//      display description
	// -----------------------------
	SetTreeCellAttribute (panel, ctrl, treeRow, PLOTITEM_COL_ERROR,
						  ATTR_LABEL_TEXT, PLOTITEM_errStr (p->error, s, p));
	SetTreeCellAttribute (panel, ctrl, treeRow, PLOTITEM_COL_ERROR,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_LEFT_JUSTIFIED);
}


void PLOTITEM_displayTreeItem (int panel, int ctrl, t_session *s, int itemNr)
{
	char *help;
	t_plotItem *p;
	t_plotItem *pTransfer1 = NULL;
	t_plotItem *pTransfer2 = NULL;
	t_sequence *seq;
	int color, colorError;
	int i, d;
	t_timeInterval *t1, *t2;

	p = PLOTITEM_ptr (s, itemNr);
	
	if (p == NULL) return;
	help = getTmpString();
	d = p->detector;
	itemNr --;

	// -----------------------------
	//      display name
	// -----------------------------
	sprintf (help, "%s", p->name);
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_NAME,
						  ATTR_LABEL_TEXT, help);
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_NAME,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display type
	// -----------------------------
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_TYPE,
						  ATTR_LABEL_TEXT, PLOTITEM_typeStr(p));
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_TYPE,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_TYPE,
						     ATTR_LABEL_POINT_SIZE, 10);

	PLOTITEM_calculateTimeIntervals (s, p);
	// -----------------------------
	//      display level
	// -----------------------------
	help[0] = 0;
	switch (p->type) {
		case PLOT_TYPE_NCOUNTS:
			PLOTITEM_calculateTimeIntervals (s, p);
			if (p->transfer) {
				pTransfer1 = PLOTITEM_ptr (s, p->plotItemTransfer1);
				pTransfer2 = PLOTITEM_ptr (s, p->plotItemTransfer2);
				PLOTITEM_calculateTimeIntervals (s, pTransfer1);
				PLOTITEM_calculateTimeIntervals (s, pTransfer2);
			}						  

			if (p->transfer) {
				sprintf (help, "%s,%s", levelName (s, pTransfer1), levelName (s, pTransfer2));           
			}
			else {
				// one level
				if (p->level >= 0) strcpy (help, levelName (s, p));
			}
			break;
		case PLOT_TYPE_VELOCITYDIST: 	
		case PLOT_TYPE_ARRIVALTIMES:
			if ((p->transfer) && (p->detector == 1) && (s->transferOn)) {
				sprintf (help, "%s,%s", s->levelNames[s->transferLevel[0]], s->levelNames[s->transferLevel[1]]);           
			}
			else if (s->transferOn) sprintf (help, levelName (s, p));
			break;
			
	}
	

	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_LEVEL,
						  ATTR_LABEL_TEXT, help);

	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_LEVEL,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display atom number
	// -----------------------------
	help[0] = 0;
	if (p->transfer) {
		if ((pTransfer1 != NULL) && (pTransfer2 != NULL)) {
			sprintf (help, "%s,%s", intToStr(pTransfer1->atomNr),intToStr(pTransfer2->atomNr));
		}
	}
	else {
		if (p->multiple != 0) {
			sprintf (help, "%d.%d", p->atomNr, p->multiple);
		}
		else strcpy (help, intToStr(p->atomNr));
	}
	
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_ATOM,
						  ATTR_LABEL_TEXT, help);
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_ATOM,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);

	// -----------------------------
	//      display interval
	// -----------------------------
	help[0] = 0;
	if (p->type == PLOT_TYPE_NCOUNTS) {
		if (p->transfer) {
			sprintf (help, "%s+%s", timeIntervalName (s, pTransfer1),
									timeIntervalName (s, pTransfer2));
		}
		else {
			strcpy (help, timeIntervalName (s, p));
		}
	}
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_INTERVAL,
						  ATTR_LABEL_TEXT, help);
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_INTERVAL,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display detector
	// -----------------------------
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_DETECTOR,
						  ATTR_LABEL_TEXT, p->transfer ? "" : intToStr(p->detector+1));
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_DETECTOR,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display counter
	// -----------------------------
	PLOTITEM_getCounter (p);
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_COUNTER,
						  ATTR_LABEL_TEXT, ((p->counter >= 0) && (!p->transfer)) ? intToStr(p->counter) : "");
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_COUNTER,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	// -----------------------------
	//      display description
	// -----------------------------
	PLOTITEM_displayTreeItemError (panel, ctrl, s, p, itemNr);
	// -----------------------------
	//      display autosave
	// -----------------------------
	setTreeCellYes (panel, ctrl, itemNr, PLOTITEM_COL_AUTOSAVECURVE, p->saveCurve);
	setTreeCellYes (panel, ctrl, itemNr, PLOTITEM_COL_AUTOSAVETXT, p->saveTxt);
	setTreeCellYes (panel, ctrl, itemNr, PLOTITEM_COL_2D, p->create2DPlot);
	// -----------------------------
	//      check item
	// -----------------------------
	SetTreeItemAttribute (panel, ctrl, itemNr, ATTR_MARK_STATE,
						  p->active);
	if (!p->active) color = VAL_LT_GRAY;
	else {
		switch (p->type) {
			case PLOT_TYPE_NCOUNTS: 
				color = p->transfer ? VAL_DK_RED : VAL_RED;
				break;
			case PLOT_TYPE_ARRIVALTIMES:
				color = p->transfer ? VAL_DK_GREEN : VAL_GREEN;  
				break;
			case PLOT_TYPE_VELOCITYDIST:
				color = p->transfer ? VAL_DK_BLUE : VAL_BLUE;
				break;
			case PLOT_TYPE_CORRELATIONS:
				color = VAL_ORANGE;
				break;
			default:
				color = VAL_BLACK;
				
		}
	}
	
		
	colorError = p->active ? VAL_RED : VAL_LT_GRAY;
	
	for (i = 0; i < N_PLOTITEM_COL; i++) {
		SetTreeCellAttribute (panel, ctrl, itemNr, i,
						      ATTR_LABEL_COLOR,
						      i == PLOTITEM_COL_ERROR ? colorError : color);
		SetTreeCellAttribute (panel, ctrl, itemNr, i,
						      ATTR_LABEL_BOLD, 
						      i == PLOTITEM_COL_ERROR ? 0 : p->active);
	}
	// -----------------------------
	//   display colors
	// -----------------------------
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_COLOR,
						  ATTR_LABEL_TEXT, p->plotColor == VAL_COLOR_AUTO ? "auto" : "");
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_COLOR,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_COLOR,
						  ATTR_LABEL_BGCOLOR,
						  p->plotColor == VAL_COLOR_AUTO ? VAL_WHITE :p->plotColor);
	
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_COLOR_CURRENT,
						  ATTR_LABEL_TEXT, p->plotColorCurrent == VAL_COLOR_AUTO ? "auto" : "");
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_COLOR_CURRENT,
						  ATTR_LABEL_JUSTIFY,
						  VAL_CENTER_CENTER_JUSTIFIED);
	SetTreeCellAttribute (panel, ctrl, itemNr, PLOTITEM_COL_COLOR_CURRENT,
						  ATTR_LABEL_BGCOLOR,
						  p->plotColorCurrent == VAL_COLOR_AUTO ? VAL_WHITE : p->plotColorCurrent);

	
	
	//////////////////////
//	if(p->excludeDoubleCounts)
//	PLOTITEM_initFilterExcludeDoubleCounts (s,p);
	///////////////////////////////
	
}



void PLOTITEM_displayTree (int panel, int ctrl, t_session *s)
{
	int i;
	
	PLOTITEM_checkAllForError (s,0);
	setNumTreeItems (panel, ctrl, ListNumItems (s->lPlotItems));
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		PLOTITEM_displayTreeItem (panel, ctrl, s, i);
	}
}




void PLOTITEM_initTree (int panel, int ctrl)
{
	SetCtrlAttribute (panel, ctrl, ATTR_COLUMN_LABELS_HEIGHT, 35);

	setNumTreeColumns (panel, ctrl, N_PLOTITEM_COL);

	// set attributes for columns
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_NAME,
							ATTR_COLUMN_WIDTH, 120);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_NAME, 
							ATTR_LABEL_TEXT, "name");

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_TYPE,
							ATTR_COLUMN_WIDTH, 80);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_TYPE, 
							ATTR_LABEL_TEXT, "type");
							

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_ATOM,
							ATTR_COLUMN_WIDTH, 35);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_ATOM, 
							ATTR_LABEL_TEXT, "atom");

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_DETECTOR,
							ATTR_COLUMN_WIDTH, 35);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_DETECTOR, 
							ATTR_LABEL_TEXT, "det.");

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_COUNTER,
							ATTR_COLUMN_WIDTH, 35);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_COUNTER, 
							ATTR_LABEL_TEXT, "ctr.");

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_INTERVAL,
							ATTR_COLUMN_WIDTH, 40);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_INTERVAL, 
							ATTR_LABEL_TEXT, "intv.");

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_LEVEL,
							ATTR_COLUMN_WIDTH, 65);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_LEVEL, 
							ATTR_LABEL_TEXT, "level");

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_AUTOSAVECURVE,
							ATTR_COLUMN_WIDTH, 45);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_AUTOSAVECURVE, 
							ATTR_LABEL_TEXT, "save\n\".curve\"");
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_AUTOSAVECURVE,
							ATTR_LABEL_POINT_SIZE, 10);

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_AUTOSAVETXT,
							ATTR_COLUMN_WIDTH, 40);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_AUTOSAVETXT, 
							ATTR_LABEL_TEXT, "save\n\".txt\"");
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_AUTOSAVETXT,
							ATTR_LABEL_POINT_SIZE, 10);

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_2D,
							ATTR_COLUMN_WIDTH, 40);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_2D, 
							ATTR_LABEL_TEXT, "2D\nplot");
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_2D,
							ATTR_LABEL_POINT_SIZE, 10);
							
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_COLOR,
							ATTR_COLUMN_WIDTH, 45);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_COLOR, 
							ATTR_LABEL_TEXT, "color avg");
 	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_COLOR,
							ATTR_LABEL_POINT_SIZE, 10);

	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_COLOR_CURRENT,
							ATTR_COLUMN_WIDTH, 45);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_COLOR_CURRENT, 
							ATTR_LABEL_TEXT, "color");
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_COLOR_CURRENT,
							ATTR_LABEL_POINT_SIZE, 10);


	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_ERROR,
							ATTR_COLUMN_WIDTH, 200);
	SetTreeColumnAttribute (panel, ctrl, PLOTITEM_COL_ERROR, 
							ATTR_LABEL_TEXT, "Error");


}



void PLOTITEM_insertTypes (int panel, int ctrl)
{
	ClearListCtrl (panel, ctrl);
	InsertListItem (panel, ctrl, -1, "N Counts", PLOT_TYPE_NCOUNTS);
//	InsertListItem (panel, ctrl, -1, "transfer", PLOT_TYPE_TRANSFER);
	InsertListItem (panel, ctrl, -1, "velocity distribution", PLOT_TYPE_VELOCITYDIST);
	InsertListItem (panel, ctrl, -1, "arrival times", PLOT_TYPE_ARRIVALTIMES);
	InsertListItem (panel, ctrl, -1, "correlations", PLOT_TYPE_CORRELATIONS);
	InsertListItem (panel, ctrl, -1, "multiple as index", PLOT_TYPE_MULTIPLE_AS_INDEX);
}


void PLOTITEM_resizePanel (int panel)
{
}




int PLOTITEM_initPanel (void) 
{

	panelCorrelations = LoadPanel (panelPlotItems, SESSIONMANAGER_uirFile, PLOT_CORR);
	panelVelDist = LoadPanel (panelPlotItems, SESSIONMANAGER_uirFile, PLOT_VEL);
	panelArrTimes = LoadPanel (panelPlotItems, SESSIONMANAGER_uirFile, PLOT_ARR);
	panelDisplay = LoadPanel (panelPlotItems, SESSIONMANAGER_uirFile, PLOT_DISPL);
	panelSave = LoadPanel (panelPlotItems, SESSIONMANAGER_uirFile, PLOT_SAVE);
	panelMultipleAsIndex = LoadPanel (panelPlotItems, SESSIONMANAGER_uirFile, PLOT_MULT);

/*	EasyTab_ConvertFromCanvas (panelPlotItems, PLOTITEMS_CANVAS);
	EasyTab_LoadPanels (panelPlotItems, PLOTITEMS_CANVAS, 1, SESSIONMANAGER_uirFile,
						__CVIUserHInst, 
						PLOT_VEL, &panelVelDist,
						PLOT_ARR, &panelArrTimes,
//						PLOT_CORR,&panelCorrelations,
						0);
*/						
/*
	EasyTab_LoadPanels (panelPlotItems, PLOTITEMS_CANVAS, 2, SESSIONMANAGER_uirFile,
						__CVIUserHInst, 
//						PLOT_TRANS, &panelTransfer,
						PLOT_DISPL, &panelDisplay,
						PLOT_SAVE, &panelSave,
						
						0);
*/
	PLOTITEM_initTree (panelPlotItems, PLOTITEMS_TREE);
	PLOTITEM_CORR_initPanel ();
	PLOTITEM_insertTypes (panelPlotItems, PLOTITEMS_RINGSLIDE_type);
	CURVE_colorNamesToRing (panelDisplay, PLOT_DISPL_RING_plotColor);
	CURVE_colorNamesToRing (panelDisplay, PLOT_DISPL_RING_plotColorCurrent);
	CURVE_styleNamesToRing (panelDisplay, PLOT_DISPL_RING_plotStyle);
	CURVE_styleNamesToRing (panelDisplay, PLOT_DISPL_RING_plotStyleCurrent);

	EasyTab_ConvertFromCanvas (panelPlotItems, PLOTITEMS_CANVAS);
	EasyTab_AddPanels (panelPlotItems, PLOTITEMS_CANVAS, 1, 
					   panelVelDist, panelArrTimes, panelCorrelations, panelMultipleAsIndex, 0);
	EasyTab_AddPanels (panelPlotItems, PLOTITEMS_CANVAS, 2, 
					   panelDisplay, panelSave, 0);
	
	return 0;
}


void PLOTITEM_setVisibility (t_session *s)
{
	SetAttributeForCtrls (panelPlotItems, ATTR_DIMMED, 
						  ListNumItems(s->lPlotItems) == 0,0,
						  PLOTITEMS_TREE,
						  PLOTITEMS_STRING_name,
						  PLOTITEMS_RINGSLIDE_type,
						  PLOTITEMS_NUMERIC_detector,
						  PLOTITEMS_BTN_delete,
						  0);
}


void PLOTITEM_displayAll (t_session *s) 
{
	int i;
	int nr = 0;
	
	if (s == NULL) return;
//	if (panelPlotItems == -1) PLOTITEM_initPanel ();
	
	// insert events
	PLOTITEM_displayTree (panelPlotItems, PLOTITEMS_TREE, s);
	
	// ----------------------------
	//   init subpanel "transfer"
	// ----------------------------
	ATOMS_fillLevelsToRing (panelPlotItems, PLOTITEMS_RING_level1, s, 1);
	InsertListItem (panelPlotItems, PLOTITEMS_RING_level1, 0, "NONE", -1);
//	ATOMS_fillLevelsToRing (panelPlotItems, PLOTITEMS_RING_level2, s);
//	InsertListItem (panelPlotItems, PLOTITEMS_RING_level2, 0, "NONE", -1);
	TIMEINTERVAL_fillToRing (panelPlotItems, PLOTITEMS_RING_timeInterval1_d1, s, 0);
	TIMEINTERVAL_fillToRing (panelPlotItems, PLOTITEMS_RING_timeInterval1_d2, s, 1);
 	for (i = 0; i < MAX_CORRELATION_ATOMS; i++) {
		ATOMS_fillLevelsToRing (panelCorrAtoms[i], CORR_AT_RING_level1, s, 0);
		ATOMS_fillLevelsToRing (panelCorrAtoms[i], CORR_AT_RING_level2, s, 0);
		ATOMS_fillAtomNamesToRing (panelCorrAtoms[i], CORR_AT_RING_atom, s, 1, 0);
	}	
//	TIMEINTERVAL_fillToRing (panelPlotItems, PLOTITEMS_RING_timeInterval2_d1, s, 0);
//	TIMEINTERVAL_fillToRing (panelPlotItems, PLOTITEMS_RING_timeInterval2_d2, s, 1);
	ATOMS_fillAtomNamesToRing (panelPlotItems, PLOTITEMS_RING_atom, s, 1, 0);
	InsertListItem (panelPlotItems, PLOTITEMS_RING_atom, 0, "NONE", -1);
	// -----------------------------------------
	//   check all plot items for errors
	// -----------------------------------------
	PLOTITEM_checkAllForError (s,0);
	// -----------------------------------------
	//   show/hide items
	// -----------------------------------------
	PLOTITEM_setVisibility (s);
	if ((s->selectedPlotItem > 0) && (s->selectedPlotItem <= ListNumItems (s->lPlotItems)))
		SetCtrlVal (panelPlotItems, PLOTITEMS_TREE, s->selectedPlotItem); 
	GetCtrlIndex (panelPlotItems, PLOTITEMS_TREE, &nr);
	
	PLOTITEM_setValues (s, PLOTITEM_ptr (s, nr+1));
	FILTERS_fillNamesToList (panelPlotItems, PLOTITEMS_RING_dataFilter, s, 1);
	FILTERS_fillNamesToList (panelMultipleAsIndex, PLOT_MULT_RING_dataFilter, s, 1);
}



void PLOTITEM_getBinStartEnd (t_session *s, t_plotItem *p)
{
	if (p->arrivalTimesBinAuto) {
//		smallestTime = ATOMS_getSmallestTimeAll (s);
//		start = round (ATOMS_getSmallestTimeAll (s) * 
		p->arrivalTimesBinStart_us = s->curveStart_us;
		p->arrivalTimesBinEnd_us   = s->curveEnd_us;
	}
	
	if (p->arrivalTimesBinSize_us == 0) p->arrivalTimesNBins = 0;
	else p->arrivalTimesNBins = abs ((p->arrivalTimesBinEnd_us - p->arrivalTimesBinStart_us) / p->arrivalTimesBinSize_us);
}


/*
int PLOTITEM_calculateIntervalNCounts (t_session *s, t_plotItem *p)
{
	int i;
	t_timeInterval *t;
	int d, n;

	if (p->fixedInterval) return 0;
	d = p->detector;
	n = ListNumItems (s->lTimeIntervals[d]);
	for (i = 1; i <= n; i++) {
		t = TIMEINTERVAL_ptrList (s->lTimeIntervals[d], i);
		if ((t->atomNr == p->atom) && (t->levelNr == p->countsLevel)) {
			p->countsInterval[d] = i;				
			return 0;
		}
	}
	p->countsInterval[d] = 0;
	return 0;

}
*/


int PLOTITEM_calculateTimeIntervals (t_session *s, t_plotItem *p)
{
	int i, k;
	t_timeInterval *t;
	int d, n;
	
	if (p == NULL) return 0;
	d = p->detector;
	
	if (p->fixedIntervals) {
		t = TIMEINTERVAL_ptrList (s->lTimeIntervals[d], p->interval[d]);
		if (t != NULL) p->level = t->levelNr;
	}
	else {
		// no fixed time interval --> calculate time interval
		p->interval[d] = TIMEINTERVAL_getNr (s, d, p->atomNr, p->multiple, p->level);
	}
	
	return 0;
}



void PLOTITEM_setValues (t_session *s, t_plotItem *p)
{

//	int activePanel = -1;
	int oldPanel;
	t_atom *a;
	int atomActive;
	int dimmed = 0;
	t_timeInterval *t;
	int d;
	int dimmTI;
	int activePanel;
	int oldState;
	int i;
	
	if (p == NULL) return;

	PLOTITEM_calculateTimeIntervals (s, p);

	if (p == NULL) return;
	a = ATOM_ptr (s, p->atomNr);
	atomActive = (a != NULL) && (a->active);
	d = p->detector;

	
	// ------------------------------------
	//   attributes for "transfer"
	// ------------------------------------
				
	SetCtrlVal (panelPlotItems, PLOTITEMS_BUTTON_showTransfer, p->transfer); 	

	
	SetCtrlVal (panelPlotItems, PLOTITEMS_BUTTON_intManually, p->fixedIntervals); 	
	dimmed = (p->type != PLOT_TYPE_NCOUNTS) || (p->transfer);
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_BUTTON_intManually, ATTR_DIMMED, dimmed); 	
	
	SetCtrlVal (panelPlotItems, PLOTITEMS_RING_level1, p->level);
	
	SetCtrlVal (panelPlotItems, PLOTITEMS_RING_timeInterval1_d1, p->interval[0]);
	SetCtrlVal (panelPlotItems, PLOTITEMS_RING_timeInterval1_d2, p->interval[1]);
	
	SetAttributeForCtrls (panelPlotItems, ATTR_DIMMED, p->transfer, 0,
						  PLOTITEMS_RING_level1,
						  PLOTITEMS_NUMERIC_detector,
						  PLOTITEMS_DECORATION,
						  PLOTITEMS_RING_dataFilter,
						  PLOTITEMS_RING_atom,
						  0);
//	SetCtrlVal (panelPlotItems, PLOTITEMS_RING_timeInterval1_d2, p->interval[0]);
	
	t = TIMEINTERVAL_ptrList (s->lTimeIntervals[d], p->interval[d]);
	SetCtrlVal (panelPlotItems, PLOTITEMS_STRING_timeInterval1, (t == NULL) ? "?" : t->idStr);
	
	// --------------------------
	//   plot type "N COUNTS"
	// --------------------------
	SetCtrlVal (panelPlotItems, PLOTITEMS_RING_atom,  p->atomNr);
	SetCtrlVal (panelPlotItems, PLOTITEMS_NUMERIC_multiple,  p->multiple);
//	SetCtrlVal (panelPlotItems, PLOTITEMS_BUTTON_excludeDouble, p->excludeDoubleCounts);  
	dimmed = (p->fixedIntervals && (p->type == PLOT_TYPE_NCOUNTS)) || 
			 (p->transfer);
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_RING_atom, ATTR_DIMMED, 
					  dimmed);

	dimmed = (a == NULL) || (p->fixedIntervals && (p->type == PLOT_TYPE_NCOUNTS)) || 
			 (p->transfer) || (!a->hasMultiples);
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_NUMERIC_multiple, ATTR_DIMMED, dimmed);
	if ((a!= NULL) && (a->hasMultiples)) SetCtrlAttribute (panelPlotItems, PLOTITEMS_NUMERIC_multiple, 
					  ATTR_MAX_VALUE, a->nMultiples);
	
	
	
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_STRING_timeInterval1,
					  ATTR_DIMMED, (p->type != PLOT_TYPE_NCOUNTS) || p->transfer);
//	SetCtrlAttribute (panelPlotItems, PLOTITEMS_STRING_timeInterval2,
//					  ATTR_DIMMED, !p->transfer || (p->type != PLOT_TYPE_NCOUNTS));
	dimmTI = (p->type != PLOT_TYPE_NCOUNTS) || (!p->fixedIntervals) || p->transfer;
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_RING_timeInterval1_d1,
					  ATTR_DIMMED, (d != 0) || dimmTI);
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_RING_timeInterval1_d2,
					  ATTR_DIMMED, (d != 1) || dimmTI);
	dimmTI = dimmTI || !p->transfer;

	setCtrlHot (panelPlotItems, PLOTITEMS_RING_level1, !p->transfer);
	
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_RING_level1, 
				      ATTR_DIMMED, p->fixedIntervals || p->transfer);	
	
	// ----------------------
	//       transfer			   
	// ----------------------
	PLOTITEM_fillNamesToRing (panelPlotItems, PLOTITEMS_RING_plotItemTransf1, s, 
							  -1, 0);	
	PLOTITEM_fillNamesToRing (panelPlotItems, PLOTITEMS_RING_plotItemTransf2, s, 
							  -1, 0);	
	SetCtrlVal (panelPlotItems, PLOTITEMS_RING_plotItemTransf1, p->plotItemTransfer1); 	
	SetCtrlVal (panelPlotItems, PLOTITEMS_RING_plotItemTransf2, p->plotItemTransfer2); 
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_RING_plotItemTransf1, 
					  ATTR_DIMMED, !p->transfer || (p->type != PLOT_TYPE_NCOUNTS)); 	
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_RING_plotItemTransf2, 
					  ATTR_DIMMED, !p->transfer || (p->type != PLOT_TYPE_NCOUNTS)); 	
//	SetCtrlAttribute (panelPlotItems, PLOTITEMS_TEXTMSG_plotItemsTr, 
//					  ATTR_DIMMED, !p->transfer || (p->type != PLOT_TYPE_NCOUNTS)); 	
	
	
	
	// ------------------------------------
	//   plot type "velocity distribution"
	// ------------------------------------
	SetCtrlVal (panelVelDist, PLOT_VEL_NUMERIC_velocityNPts, p->velocityNPoints);
	SetCtrlVal (panelVelDist, PLOT_VEL_NUMERIC_velocityStart, p->velocityStart);
	SetCtrlVal (panelVelDist, PLOT_VEL_NUMERIC_velocityEnd,   p->velocityEnd);
	SetPanelAttribute (panelVelDist, ATTR_DIMMED, p->type != PLOT_TYPE_VELOCITYDIST);
	
	SetCtrlVal (panelVelDist, PLOT_VEL_RADIOBUTTON_showPos,   p->velocityShowPositionAxis);
	SetCtrlVal (panelVelDist, PLOT_VEL_NUMERIC_timeMultiply,  p->velocityTimeMultiply_us);
	SetCtrlVal (panelVelDist, PLOT_VEL_RADIOBUTTON_showParts, p->velocityShowExperimentParts);
	SetAttributeForCtrls (panelVelDist, ATTR_DIMMED, 
						  !p->velocityShowPositionAxis, 0,
						  PLOT_VEL_NUMERIC_timeMultiply,
						  PLOT_VEL_TEXTMSG_multiply,
						  PLOT_VEL_RADIOBUTTON_showParts, 0);
	
	// ------------------------------------
	//   plot type "arrival times"
	// ------------------------------------
	SetCtrlVal (panelArrTimes, PLOT_ARR_NUMERIC_binsize, p->arrivalTimesBinSize_us);
	SetCtrlVal (panelArrTimes, PLOT_ARR_RADIOBUTTON_auto, p->arrivalTimesBinAuto);
	PLOTITEM_getBinStartEnd (s, p);
	setCtrlHot (panelArrTimes, PLOT_ARR_NUMERIC_binStartTime, !p->arrivalTimesBinAuto);
	SetCtrlVal (panelArrTimes, PLOT_ARR_NUMERIC_binStartTime, p->arrivalTimesBinStart_us);
	setCtrlHot (panelArrTimes, PLOT_ARR_NUMERIC_binEndTime,   !p->arrivalTimesBinAuto);
	SetCtrlVal (panelArrTimes, PLOT_ARR_NUMERIC_binEndTime,   p->arrivalTimesBinEnd_us);
	SetCtrlVal (panelArrTimes, PLOT_ARR_NUMERIC_nBins,        p->arrivalTimesNBins);
	EasyTab_SetTabAttribute (panelPlotItems, PLOTITEMS_CANVAS,
							 panelVelDist, ATTR_EASY_TAB_DIMMED,
							 p->type != PLOT_TYPE_VELOCITYDIST);
	EasyTab_SetTabAttribute (panelPlotItems, PLOTITEMS_CANVAS,
							 panelArrTimes, ATTR_EASY_TAB_DIMMED,
							 p->type != PLOT_TYPE_ARRIVALTIMES);
	EasyTab_SetTabAttribute (panelPlotItems, PLOTITEMS_CANVAS,
								 panelCorrelations, ATTR_EASY_TAB_DIMMED,
								 p->type != PLOT_TYPE_CORRELATIONS);
	EasyTab_SetTabAttribute (panelPlotItems, PLOTITEMS_CANVAS,
								 panelMultipleAsIndex, ATTR_EASY_TAB_DIMMED,
								 p->type != PLOT_TYPE_MULTIPLE_AS_INDEX);
	for (i = 0; i < MAX_CORRELATION_ATOMS; i++) 
		SetPanelAttribute (panelCorrAtoms[i], ATTR_DIMMED, p->type != PLOT_TYPE_CORRELATIONS);					 
							 
	EasyTab_GetAttribute (panelPlotItems, PLOTITEMS_CANVAS,
						  ATTR_EASY_TAB_ACTIVE_PANEL, &activePanel);
	if ((activePanel == panelVelDist) && (p->type != PLOT_TYPE_VELOCITYDIST)) {
		if (p->type == PLOT_TYPE_ARRIVALTIMES) activePanel = panelArrTimes;
		else activePanel = panelSave;
	}
	else if ((activePanel == panelArrTimes) && (p->type != PLOT_TYPE_ARRIVALTIMES)) {
		if (p->type == PLOT_TYPE_VELOCITYDIST) activePanel = panelVelDist;
		else activePanel = panelSave;
	}
	EasyTab_SetAttribute (panelPlotItems, PLOTITEMS_CANVAS,
						  ATTR_EASY_TAB_ACTIVE_PANEL, activePanel);
					
	PLOTITEM_getCounter (p);
	// --------------------------
	//   main items 
	// --------------------------
	
	SetCtrlVal (panelPlotItems, PLOTITEMS_STRING_name, p->name);
	SetCtrlVal (panelPlotItems, PLOTITEMS_RINGSLIDE_type, p->type);

	SetCtrlVal (panelPlotItems, PLOTITEMS_NUMERIC_detector, p->detector+1);
	SetCtrlVal (panelPlotItems, PLOTITEMS_RING_dataFilter, p->dataFilterID);
	
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_RADIOBUTTON_2D, ATTR_DIMMED, 
		p->type == PLOT_TYPE_NCOUNTS);
	if (p->type != PLOT_TYPE_NCOUNTS) 
		SetCtrlVal (panelPlotItems, PLOTITEMS_RADIOBUTTON_2D, p->create2DPlot);
	
	DeleteTextBoxLines (panelPlotItems, PLOTITEMS_TEXTBOX_error, 0, -1);
	SetCtrlVal (panelPlotItems, PLOTITEMS_TEXTBOX_error, PLOTITEM_errStr  (p->error, s, p));

	// --------------------------
	//   save
	// --------------------------
	SetCtrlVal (panelSave, PLOT_SAVE_RADIOBUTTON_saveCurve, p->saveCurve);
	SetCtrlVal (panelSave, PLOT_SAVE_RADIOBUTTON_saveTxt, p->saveTxt);
	SetCtrlVal (panelSave, PLOT_SAVE_RADIOBUTTON_keep, p->keepCurve);


	// --------------------------
	//   display parameters
	// --------------------------
	SetCtrlVal (panelDisplay, PLOT_DISPL_RADIOBUTTON_setName, p->autoSetWindowName);
	oldState = SetBreakOnProtectionErrors (0);
	SetCtrlVal (panelDisplay, PLOT_DISPL_STRING_windowName, p->panelTitle);
	SetBreakOnProtectionErrors (oldState);

	setCtrlHot (panelDisplay, PLOT_DISPL_STRING_windowName, !p->autoSetWindowName);
	
	SetCtrlVal (panelDisplay, PLOT_DISPL_RING_plotColor, p->plotColor);
	SetCtrlVal (panelDisplay, PLOT_DISPL_COLORNUM, 
				p->plotColor == VAL_COLOR_AUTO ? VAL_BLACK : p->plotColor);
	SetCtrlAttribute (panelDisplay, PLOT_DISPL_COLORNUM, ATTR_DIMMED,
					  p->plotColor == VAL_COLOR_AUTO);
	SetCtrlVal (panelDisplay, PLOT_DISPL_RING_plotColor, p->plotColor);
	SetCtrlVal (panelDisplay, PLOT_DISPL_RING_plotStyle, p->plotStyle);
	SetCtrlVal (panelDisplay, PLOT_DISPL_RING_plotColorCurrent, p->plotColorCurrent);
	SetCtrlVal (panelDisplay, PLOT_DISPL_COLORNUM_current, 
				p->plotColorCurrent == VAL_COLOR_AUTO ? VAL_BLACK : p->plotColorCurrent);
	SetCtrlAttribute (panelDisplay, PLOT_DISPL_COLORNUM_current, ATTR_DIMMED,
					  p->plotColorCurrent == VAL_COLOR_AUTO);
	SetCtrlVal (panelDisplay, PLOT_DISPL_RING_plotStyleCurrent, p->plotStyleCurrent);
	
	
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_COMMANDBUTTON_calcAll, ATTR_VISIBLE,
					  s->loadedWithRunData);
	// -----------------------------
	// 	  parameters correlations
	// -----------------------------
	for (i = 0; i < MAX_CORRELATION_ATOMS; i++) {
		SetPanelAttribute (panelCorrAtoms[i], ATTR_VISIBLE, i < p->correlationsNAtoms);
		SetCtrlAttribute (panelCorrAtoms[i], CORR_AT_RING_atom, ATTR_CTRL_VAL, p->correlationsAtomNumber[i]);
		SetCtrlAttribute (panelCorrAtoms[i], CORR_AT_NUMERIC_multiple, ATTR_CTRL_VAL, p->correlationsAtomMultiple[i]);
		a = ATOM_ptr (s,  p->correlationsAtomNumber[i]);
		SetCtrlAttribute (panelCorrAtoms[i], CORR_AT_NUMERIC_multiple, ATTR_DIMMED,
						  (a == NULL) || !a->hasMultiples);
		if ((a != NULL) && (a->hasMultiples)) SetCtrlAttribute (panelCorrAtoms[i], CORR_AT_NUMERIC_multiple,
						  ATTR_MAX_VALUE, a->nMultiples);

		SetCtrlAttribute (panelCorrAtoms[i], CORR_AT_RING_level1, ATTR_CTRL_VAL, p->correlationsLevel[0][i]);
		SetCtrlAttribute (panelCorrAtoms[i], CORR_AT_RING_level2, ATTR_CTRL_VAL, p->correlationsLevel[1][i]);
	}
	SetCtrlVal (panelCorrelations, PLOT_CORR_NUMERIC_nCorrAtoms, p->correlationsNAtoms);
	// ---------------------------------
	// 	  parameters multiples as index
	// ---------------------------------
	
	SetCtrlVal (panelMultipleAsIndex, PLOT_MULT_NUMERIC_nBinAtoms, p->multipleAsIndexNBinAtoms);
	SetCtrlVal (panelMultipleAsIndex, PLOT_MULT_RING_dataFilter, p->multipleAsIndexFilterForEachMultipleID);
	SetCtrlVal (panelMultipleAsIndex, PLOT_MULT_CHECKBOX_sumAllRuns, p->multipleAsIndexSumAllRuns);
	
	


}



void PLOTITEM_getValues (int panel, t_session *s, t_plotItem *p)
{
	int autoSetWindowName = 1;
	int i;
	
	if (p == NULL) return;
	GetCtrlVal (panelPlotItems, PLOTITEMS_STRING_name, p->name);
	GetCtrlVal (panelPlotItems, PLOTITEMS_RINGSLIDE_type, &p->type);
	GetCtrlVal (panelPlotItems, PLOTITEMS_RING_atom, &p->atomNr);
	GetCtrlVal (panelPlotItems, PLOTITEMS_NUMERIC_multiple, &p->multiple);
	GetCtrlVal (panelPlotItems, PLOTITEMS_NUMERIC_detector, &p->detector);
//	GetCtrlVal (panelPlotItems, PLOTITEMS_BUTTON_excludeDouble, &p->excludeDoubleCounts);

	p->detector--;

	GetCtrlVal (panelSave, PLOT_SAVE_RADIOBUTTON_saveCurve, &p->saveCurve);
	GetCtrlVal (panelSave, PLOT_SAVE_RADIOBUTTON_saveTxt, &p->saveTxt);
	GetCtrlVal (panelSave, PLOT_SAVE_RADIOBUTTON_keep, &p->keepCurve);
	if (p->type == PLOT_TYPE_NCOUNTS) p->create2DPlot = 0;
	else GetCtrlVal (panelPlotItems, PLOTITEMS_RADIOBUTTON_2D, &p->create2DPlot);
	GetCtrlVal (panelPlotItems, PLOTITEMS_BUTTON_showTransfer, &p->transfer);
//	GetCtrlVal (panelPlotItems, PLOTITEMS_BUTTON_useTransLevels, &p->useTransferLevels); 	

	GetCtrlVal (panelPlotItems, PLOTITEMS_RING_plotItemTransf1, &p->plotItemTransfer1); 	
	GetCtrlVal (panelPlotItems, PLOTITEMS_RING_plotItemTransf2, &p->plotItemTransfer2);
	GetCtrlVal (panelPlotItems, PLOTITEMS_RING_dataFilter, &p->dataFilterID);
	
	GetCtrlVal (panelPlotItems, PLOTITEMS_BUTTON_intManually, &p->fixedIntervals); 	
	if (p->fixedIntervals && !p->transfer) {
		GetCtrlVal (panelPlotItems, PLOTITEMS_RING_timeInterval1_d1, &p->interval[0]);
		GetCtrlVal (panelPlotItems, PLOTITEMS_RING_timeInterval1_d2, &p->interval[1]);
		// set level
		// calculate levels
	}
	else {
		// get levels and calculate time intervals
		GetCtrlVal (panelPlotItems, PLOTITEMS_RING_level1, &p->level);
	}

	
	GetCtrlVal (panelVelDist, PLOT_VEL_NUMERIC_velocityNPts,  &p->velocityNPoints);
	GetCtrlVal (panelVelDist, PLOT_VEL_NUMERIC_velocityStart, &p->velocityStart);
	GetCtrlVal (panelVelDist, PLOT_VEL_NUMERIC_velocityEnd,   &p->velocityEnd);
	GetCtrlVal (panelVelDist, PLOT_VEL_RADIOBUTTON_showPos,   &p->velocityShowPositionAxis);
	GetCtrlVal (panelVelDist, PLOT_VEL_NUMERIC_timeMultiply,  &p->velocityTimeMultiply_us);
	GetCtrlVal (panelVelDist, PLOT_VEL_RADIOBUTTON_showParts, &p->velocityShowExperimentParts);
	
	
	GetCtrlVal (panelArrTimes, PLOT_ARR_NUMERIC_binsize, &p->arrivalTimesBinSize_us);
	GetCtrlVal (panelArrTimes, PLOT_ARR_RADIOBUTTON_auto, &p->arrivalTimesBinAuto);
	GetCtrlVal (panelArrTimes, PLOT_ARR_NUMERIC_binStartTime, &p->arrivalTimesBinStart_us);
	GetCtrlVal (panelArrTimes, PLOT_ARR_NUMERIC_binEndTime, &p->arrivalTimesBinEnd_us);

	GetCtrlVal (panelDisplay, PLOT_DISPL_RADIOBUTTON_setName, &autoSetWindowName);
	if (autoSetWindowName != p->autoSetWindowName) {
		p->autoSetWindowName = autoSetWindowName;
		if (autoSetWindowName) PLOTITEM_getPanelTitle (s, p, "");
	}
	if (!autoSetWindowName) GetCtrlVal (panelDisplay, PLOT_DISPL_STRING_windowName, p->panelTitle);
	
	GetCtrlVal (panelDisplay, PLOT_DISPL_RING_plotColor, &p->plotColor);
	GetCtrlVal (panelDisplay, PLOT_DISPL_RING_plotStyle, &p->plotStyle);
	GetCtrlVal (panelDisplay, PLOT_DISPL_RING_plotColorCurrent, &p->plotColorCurrent);
	GetCtrlVal (panelDisplay, PLOT_DISPL_RING_plotStyleCurrent, &p->plotStyleCurrent);
	PLOTITEM_checkForError (s, p);	
	
	for (i = 0; i < MAX_CORRELATION_ATOMS; i++) {
		GetCtrlVal (panelCorrAtoms[i], CORR_AT_RING_atom, &p->correlationsAtomNumber[i]);
		GetCtrlVal (panelCorrAtoms[i], CORR_AT_NUMERIC_multiple, &p->correlationsAtomMultiple[i]);
		GetCtrlVal (panelCorrAtoms[i], CORR_AT_RING_level1, &p->correlationsLevel[0][i]);
		GetCtrlVal (panelCorrAtoms[i], CORR_AT_RING_level2, &p->correlationsLevel[1][i]);	  
//		GetCtrlVal (panelCorrAtoms[i], CORR_AT_RING_dataFilter1, &p->correlationsFilterID[i][0]);
//		GetCtrlVal (panelCorrAtoms[i], CORR_AT_RING_dataFilter2, &p->correlationsFilterID[i][1]);
	}
	GetCtrlVal (panelCorrelations, PLOT_CORR_NUMERIC_nCorrAtoms, &p->correlationsNAtoms);

	// ---------------------------------
	// 	  parameters multiples as index
	// ---------------------------------
	
	GetCtrlVal (panelMultipleAsIndex, PLOT_MULT_NUMERIC_nBinAtoms, &p->multipleAsIndexNBinAtoms);
	GetCtrlVal (panelMultipleAsIndex, PLOT_MULT_RING_dataFilter, &p->multipleAsIndexFilterForEachMultipleID);
	GetCtrlVal (panelMultipleAsIndex, PLOT_MULT_CHECKBOX_sumAllRuns, &p->multipleAsIndexSumAllRuns);
	
	
}



int CVICALLBACK PLOTITEM_callback_listBox (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	int i;
	t_session *s;
	t_plotItem *p;
	int checked;

//	DEBUGEVENTS	;
	switch (event) {
		case EVENT_COMMIT:
		case EVENT_MARK_STATE_CHANGE:
		case EVENT_VAL_CHANGED:
			s = activeSession();
			if  (s == NULL) return 0;
//			printf ("1");
			GetNumListItems (panel, control, &nr);
			for (i = 0; i < nr; i++) {
				GetTreeItemAttribute (panel, control, i, ATTR_MARK_STATE,
									  &checked);
				p = PLOTITEM_ptr (s, i+1);
				if (p != NULL) 
					p->active = (checked > 0);
			}
//			printf ("2");
			GetCtrlIndex (panel, control, &nr);
			GetCtrlVal (panel, control, &s->selectedPlotItem);
			p = PLOTITEM_ptr (s, nr+1);
			if (p == NULL) return 0;
//			printf ("3");
			if (panel == panelPlotItems) PLOTITEM_setValues (s, p);
			RUN_parametersError (s);
//			printf ("4");
			RUN_setParameters (s, 0);
			SESSION_setChanges (s, 1);
			PLOTITEM_displayTree (panel, control, s);
//			printf ("5");
			ProcessDrawEvents();

			break;
	}
	return 0;
}



int CVICALLBACK PLOTITEM_callback_new (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	t_plotItem *new;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession ();
		    new = PLOTITEM_new(s);
		    strcpy (new->name, "?");
 			PLOTITEM_setValues (s, new);
 			PLOTITEM_displayTree (panelPlotItems, PLOTITEMS_TREE, s);
 			SetCtrlVal (panelPlotItems, PLOTITEMS_TREE, ListNumItems (s->lPlotItems)-1);
			SESSION_setChanges (s, 1);
			PLOTITEM_setVisibility (s);
			SetActiveCtrl (panelPlotItems, PLOTITEMS_STRING_name);
			break;
	}
		
	return 0;	  
}



void PLOTITEM_deleteSelected (t_session *s)
{
	t_plotItem *p;
	int nItems;
	int *delete;
	int i;
	char help[200];
	int selected;

	nItems = ListNumItems (s->lPlotItems);
	delete = (int *) calloc (nItems, sizeof(int));
	for (i = 0; i < nItems; i++) {
		GetTreeItemAttribute (panelPlotItems, PLOTITEMS_TREE, i, ATTR_SELECTED, &selected);
		if (selected) {		
			p = PLOTITEM_ptr (s, i+1);
			sprintf (help, "Do you really want to delete\nplot item '%s'?", p->name);
			switch (GenericMessagePopup ("Delete plot item", help, "Yes", "No", "Abort", NULL, 0, 0,
								 VAL_GENERIC_POPUP_BTN2,
								 VAL_GENERIC_POPUP_BTN2,
								 VAL_GENERIC_POPUP_BTN3)) {
					case VAL_GENERIC_POPUP_BTN1:
						delete[i] = 1;
						break;
					case VAL_GENERIC_POPUP_BTN3:
						goto ABORT;
			}
		}
	}
	for (i = nItems-1; i >= 0; i--) {
		if (delete[i]) PLOTITEM_delete (s, i+1);
	}
	PLOTITEM_displayTree (panelPlotItems, PLOTITEMS_TREE, s);
	PLOTITEM_setVisibility (s);

ABORT:
	free (delete);
}



int CVICALLBACK PLOTITEM_callback_delete (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession ();
			PLOTITEM_deleteSelected (s);
			PLOTITEM_setVisibility (s);
			break;
	}
	return 0;
}



int CVICALLBACK PLOTITEM_callback_import (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:

			break;
	}
	return 0;
}



int PLOTITEM_isNameDuplicate (t_session *s, t_plotItem *check)
{
	int i;
	t_plotItem *p;

	if (strlen (check->name) == 0) strcpy (check->name, "?");
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
		if ((p != check) && (strcmp (check->name, p->name) == 0)) return 1;
	}
	return 0;
}



int CVICALLBACK PLOTITEM_edit (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	t_session *s;
	t_plotItem *p;
	int len;
	int i;
	
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			GetCtrlIndex (panelPlotItems, PLOTITEMS_TREE, &nr);
			nr ++;
			p = PLOTITEM_ptr (s, nr);
			PLOTITEM_getValues (panel, s, p);
			len = strlen (p->name);
			i = 1;
			if (PLOTITEM_isNameDuplicate (s, p)) {
				do {
					i++;
					sprintf (p->name+len, "_%d", i);
				} while (PLOTITEM_isNameDuplicate (s, p));
				MessagePopupf ("Error", "Duplicate name!\nName has been changed to '%s'.", p->name);
			}
			
			PLOTITEM_checkAllForError (s,1);
			PLOTITEM_displayTreeItem (panelPlotItems, PLOTITEMS_TREE, s, nr);
			PLOTITEM_setValues (s, p);
//			RUN_parametersError (s);
			SESSION_setChanges (s, 1);
			break;
	}
	return 0;
}


int PLOTITEM_hasError (t_session *s, t_plotItem **p) 
{
	int i;
	
	PLOTITEM_checkAllForError (s,0);
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, p, i);
		if ((*p)->active && (*p)->error) return 1;
	}
	
	return 0;
}

int PLOTITEM_isOneActive (t_session *s)
{
	t_plotItem *p;
	int i;

	for (i = ListNumItems (s->lPlotItems); i >= 1; i--) {
		ListGetItem (s->lPlotItems, &p, i);
		if (p->active) return 1;
	}
	return 0;
}


int PLOTITEM_nActive (t_session *s)
{
	t_plotItem *p;
	int i;
	int nActive;

	nActive = 0;
	for (i = ListNumItems (s->lPlotItems); i >= 1; i--) {
		ListGetItem (s->lPlotItems, &p, i);
		if (p->active) nActive ++;
	}
	return nActive;
}




int PLOTITEM_saveAllCurves (const char *dir, t_session *s, int checkForDuplicates)
{
	int i, k;
	t_plotItem *p;
	t_graph *g;
	char *filename;
	char name[MAX_PATHNAME_LEN];
	
	// first: save all .txt files
	// so that Sebasiten can import them even quicker
	for (i = 0; i <= ListNumItems (s->lPlotItems); i++) {
		if (i == 0) p = PLOTITEM_dig(s);
		else ListGetItem (s->lPlotItems, &p, i);
		g = GRAPH_getFromCurve (p->curve); 
		if ((g != NULL) && (p->saveTxt)) {
			sprintf (name, "%04d_%s", p->curve->startNr, p->curve->name);
			filename = generateFilename (dir, suffixCurveTxt+1, name, checkForDuplicates);
			RUN_SAVING_printf ("Curve (ASCII) '%s'...", extractFilename (filename));
			CURVE_saveTxt (filename, p->curve, g);
			RUN_SAVING_printf (" Done.\n");
		}
	}

	// then save all .curve files
	for (i = 0; i <= ListNumItems (s->lPlotItems); i++) {
		if (i == 0) p = PLOTITEM_dig(s);
		else ListGetItem (s->lPlotItems, &p, i);
		g = GRAPH_getFromCurve (p->curve); 
		if ((g != NULL) && (p->saveCurve)) {
			sprintf (name, "%04d_%s", p->curve->startNr, p->curve->name);
			filename = generateFilename (dir, suffixCurve+1, name, checkForDuplicates);
			RUN_SAVING_printf  ("Curve '%s'...", extractFilename (filename));
			CURVE_save (filename, p->curve, g);
			RUN_SAVING_printf (" Done.\n");
		}
	}
	
	return 0;
}


const char*PLOTITEM_errStr (int err, t_session *s, t_plotItem *p) 
{
	t_plotItem *p2;
	
	if (s == NULL) return "";
	if (p == NULL) return "";
	if (err == PLOTITEM_ERR_NONE) return "";
	switch (err) {
		case PLOTITEM_ERR_INVALID_ATOM:
			return "Invalid Atom number.";
		case PLOTITEM_ERR_ATOM_NOT_ACTIVE:
			return "Atom not active.";
		case PLOTITEM_ERR_ATOM_NOT_DETECTED:
			return "Atom not detected.";
		case PLOTITEM_ERR_COUNTER_NOT_ACTIVATED:
			PLOTITEM_getCounter (p);
			return strf ("Counter %d (detector %d) not activated.", p->counter >= 0 ? p->counter : 0, p->detector+1);
		case PLOTITEM_ERR_INVALID_PARAMETERS:
			return "Invalid parameters.";
		case PLOTITEM_ERR_NO_DET1:
			return "No detection parameters for detector 1.";
		case PLOTITEM_ERR_NO_DET2:
			return "No detection parameters for detector 2.";
		case PLOTITEM_ERR_NO_DETECTIONPAR:
			return "No detection parameters selected for atom.";
		case PLOTITEM_ERR_INVALID_LEVEL:
			return "Invalid level.";
		case PLOTITEM_ERR_LEVEL_NOT_DETECTED:
			return "Level not selected for detection.";
		case PLOTITEM_ERR_INVALID_DETECTOR:
			return "Invalid detector.";
		case PLOTITEM_ERR_INVALID_TIMEINTERVAL:
			return "Invalid time interval.";
		case PLOTITEM_ERR_TRANSFERPAR:
			return "Transfer (det. 2) not activated in menu \"Run\".";
		case PLOTITEM_ERR_ATOM_NOT_SELECTED_FOR_TRANSFER:
			return "Atom not selected for transfer (det. 2).";
		case PLOTITEM_ERR_LEVEL_NOT_SELECTED_FOR_TRANSFER:
			return "Level not selected for transfer (det. 2).";
		case PLOTITEM_ERR_IDENTICAL_LEVELS:
			return "Identical levels for transfer.";
		case PLOTITEM_ERR_INVALID_PLOTRANGE_VEL:
			return strf ("Invalid plot range (%3.1f m/s --> %3.1f m/s).", p->velocityStart, p->velocityEnd);
		case PLOTITEM_ERR_INVALID_PLOTRANGE_ARR:
			return strf ("Invalid plot range (%3.1f �s  --> %3.1f �s).", p->arrivalTimesBinStart_us, p->arrivalTimesBinEnd_us);
		case PLOTITEM_ERR_PLOTITEM_TRANSFER1:
			p2 = PLOTITEM_ptr (s, p->plotItemTransfer1);
			return strf ("Plot item '%s' contains an error.", (p2 == NULL) ? "from" : p2->name);
		case PLOTITEM_ERR_PLOTITEM_TRANSFER2:
			p2 = PLOTITEM_ptr (s, p->plotItemTransfer2);
			return strf ("Plot item '%s' contains an error.", (p2 == NULL) ? "to" : p2->name);
		case PLOTITEM_ERR_INVALID_PLOTITEM_TRANSFER1:
			p2 = PLOTITEM_ptr (s, p->plotItemTransfer1);
			return strf ("Plot item '%s' cannot be chosen for transfer.", (p2 == NULL) ? "from" : p2->name);
		case PLOTITEM_ERR_INVALID_PLOTITEM_TRANSFER2:
			p2 = PLOTITEM_ptr (s, p->plotItemTransfer2);
			return strf ("Plot item '%s' cannot be chosen for transfer.", (p2 == NULL) ? "to" : p2->name);
		case PLOTITEM_ERR_NO_PLOTITEM_TRANSFER1:
			return "No plot item 'from' selected.";
		case PLOTITEM_ERR_NO_PLOTITEM_TRANSFER2:
			return "No plot item 'to' selected.";
		case PLOTITEM_ERR_PLOTITEM_TRANSFER1_IS_TRANSFER:
			p2 = PLOTITEM_ptr (s, p->plotItemTransfer1);
			return strf ("Plot item '%s' is itself in mode 'TRANSFER'.", (p2 == NULL) ? "from" : p2->name);
		case PLOTITEM_ERR_PLOTITEM_TRANSFER2_IS_TRANSFER:
			p2 = PLOTITEM_ptr (s, p->plotItemTransfer2);
			return strf ("Plot item '%s' is itself in mode 'TRANSFER'.", (p2 == NULL) ? "to" : p2->name);
		case PLOTITEM_ERR_NOT_ACTIVE_TRANSFER1:
			p2 = PLOTITEM_ptr (s, p->plotItemTransfer1);
			return strf ("Plot item '%s' is not active.", (p2 == NULL) ? "from" : p2->name);
		case PLOTITEM_ERR_NOT_ACTIVE_TRANSFER2:
			p2 = PLOTITEM_ptr (s, p->plotItemTransfer2);
			return strf ("Plot item '%s' is not active.", (p2 == NULL) ? "to" : p2->name);
		case PLOTITEM_ERR_TOO_MANY_COUNTS_IN_2DGRAPH_VEL:
			return strf ("Too many points (%d*%d=%d) in 2D plot. Allowed are %d.\n"
						 "Reduce the number of sweep points or the number of velocity bins.", 
						 p->velocityNPoints, s->nSweepPoints,
						 p->velocityNPoints * s->nSweepPoints, MAX_VALUES_PLOT2D);
		case PLOTITEM_ERR_TOO_MANY_COUNTS_IN_2DGRAPH_ARR:
			return strf ("Too many points (%d*%d=%d) in 2D plot. Allowed are %d.\n", 
						 "Reduce the number of sweep points or the number of bins.", 
						 p->arrivalTimesNBins, s->nSweepPoints,
						 p->arrivalTimesNBins * s->nSweepPoints, MAX_VALUES_PLOT2D);
		case PLOTITEM_ERR_ATOM_HAS_NO_MULTIPLES:
			return "Atom has no multiples.";
		case PLOTITEM_ERR_MULTIPLES_AS_INDEX_MORE_THAN_ONE_SWEEPPOINT:
			return "Only one sweeppoint allowed in 'multiples as index' mode.";
//		case PLOTITEM_ERR_MULTIPLES_AS_INDEX_MORE_THAN_ONE_CURVE :
//			return "Only one curve allowed in 'multiples as index' mode.";
		default:
			return "";
	}
		
}




int PLOTITEM_checkForError (t_session *s, t_plotItem *p)
{
	t_atom *a;
	t_detectionParameters *d;
	int counter;
	int i;
	int det;
	t_plotItem *pTransfer1, *pTransfer2;
	
	p->error = PLOTITEM_ERR_NONE;
	a = ATOM_ptr (s, p->atomNr);
	if (a == NULL) d = NULL;
	else d = DETECTIONPAR_ptr (s, a->detectionParameters);
	det = p->detector;
	
	if ((det < 0) || (det > 1)) return p->error = PLOTITEM_ERR_INVALID_DETECTOR;

	PLOTITEM_getCounter (p); 
	switch (p->type) {
		case PLOT_TYPE_NCOUNTS:
			PLOTITEM_calculateTimeIntervals (s, p);
			if (p->transfer) {
				// check only if plot items for transfer have errors
				pTransfer1 = PLOTITEM_ptr (s, p->plotItemTransfer1);
				if (pTransfer1 == NULL) return p->error = PLOTITEM_ERR_NO_PLOTITEM_TRANSFER1;
				if (pTransfer1->transfer) return p->error = PLOTITEM_ERR_PLOTITEM_TRANSFER1_IS_TRANSFER; 
				PLOTITEM_checkForError (s, pTransfer1);
				if (pTransfer1->error) return p->error = PLOTITEM_ERR_PLOTITEM_TRANSFER1; 
				if (pTransfer1->type != PLOT_TYPE_NCOUNTS) return p->error = PLOTITEM_ERR_INVALID_PLOTITEM_TRANSFER1; 
				if (!pTransfer1->active) return p->error = PLOTITEM_ERR_NOT_ACTIVE_TRANSFER1;
				
				pTransfer2 = PLOTITEM_ptr (s, p->plotItemTransfer2);
				if (pTransfer2 == NULL) return p->error = PLOTITEM_ERR_NO_PLOTITEM_TRANSFER2;
				if (pTransfer2->transfer) return p->error = PLOTITEM_ERR_PLOTITEM_TRANSFER2_IS_TRANSFER; 
				PLOTITEM_checkForError (s, pTransfer2);
				if (pTransfer2->error) return p->error = PLOTITEM_ERR_INVALID_PLOTITEM_TRANSFER2; 
				if (pTransfer2->type != PLOT_TYPE_NCOUNTS) return p->error = PLOTITEM_ERR_INVALID_PLOTITEM_TRANSFER2; 
				if (!pTransfer2->active) return p->error = PLOTITEM_ERR_NOT_ACTIVE_TRANSFER2;

				return p->error = PLOTITEM_ERR_NONE;
			}
			if (!p->fixedIntervals) {
				if (a == NULL) return p->error = PLOTITEM_ERR_INVALID_ATOM;
				if (!a->active) return p->error = PLOTITEM_ERR_ATOM_NOT_ACTIVE;
				if (!a->detect) return p->error = PLOTITEM_ERR_ATOM_NOT_DETECTED;
				// check if level number is valid
				if ((p->level < 0) || (p->level > s->nLevels)) return p->error = PLOTITEM_ERR_INVALID_LEVEL;
				if (det == 0) {
					if (d->detectorActive[0]) {
						if (!d->det1_levelActive[p->level]) return p->error = PLOTITEM_ERR_LEVEL_NOT_DETECTED;
					}
					else return p->error = PLOTITEM_ERR_NO_DET1;
				}
				else {
					if (d == NULL) return p->error = PLOTITEM_ERR_NO_DET2;
					if (!d->detectorActive[1]) return p->error = PLOTITEM_ERR_NO_DET2;
				}
			// detector1: check if level is detected
			// get time interval
				p->interval[det] = TIMEINTERVAL_getNr (s, det, p->atomNr, p->multiple, p->level);
				if (p->interval[det] < 1) return p->error = PLOTITEM_ERR_INVALID_LEVEL;
			}
			counter = COUNTERS_NCOUNTS[p->detector];
			if (!s->counterOn[counter]) return p->error = PLOTITEM_ERR_COUNTER_NOT_ACTIVATED;
				// check if time interval is valid
			if ((p->interval[det] < 1) || (p->interval[det] > ListNumItems (s->lTimeIntervals[det]))) 
				return p->error = PLOTITEM_ERR_INVALID_TIMEINTERVAL; 
			
			break;
		case PLOT_TYPE_VELOCITYDIST:
			if (a == NULL) return p->error = PLOTITEM_ERR_INVALID_ATOM;
			if (!a->active) return p->error = PLOTITEM_ERR_ATOM_NOT_ACTIVE;
			if (!a->detect) return p->error = PLOTITEM_ERR_ATOM_NOT_DETECTED;
			counter = COUNTERS_ARRIVALTIMES[p->detector];
			if (!s->counterOn[counter]) return p->error = PLOTITEM_ERR_COUNTER_NOT_ACTIVATED;
			if (p->velocityStart >= p->velocityEnd) return p->error = PLOTITEM_ERR_INVALID_PLOTRANGE_VEL;
			if ((p->detector == 1) && (!p->transfer) && (s->transferOn)) { 
				// check if selected levels are valid
				if (SESSION_getTransferLevelNr (s, p->level) < 0) return p->error = PLOTITEM_ERR_INVALID_LEVEL; 
			}
			if (p->velocityNPoints * s->nSweepPoints > MAX_VALUES_PLOT2D) 
				return p->error = PLOTITEM_ERR_TOO_MANY_COUNTS_IN_2DGRAPH_VEL;
			
			break;
		case PLOT_TYPE_ARRIVALTIMES:
			counter = COUNTERS_ARRIVALTIMES[p->detector];
			if (!s->counterOn[counter]) return p->error = PLOTITEM_ERR_COUNTER_NOT_ACTIVATED;
			if ((p->detector == 1) && (!p->transfer) && (s->transferOn)) {
				// check if selected levels are valid
				if (SESSION_getTransferLevelNr (s, p->level) < 0) return p->error = PLOTITEM_ERR_INVALID_LEVEL; 
			}
			if (p->arrivalTimesBinStart_us >= p->arrivalTimesBinEnd_us) return p->error = PLOTITEM_ERR_INVALID_PLOTRANGE_ARR;
			if (p->create2DPlot && (p->arrivalTimesNBins * s->nSweepPoints > MAX_VALUES_PLOT2D) && (s->nSweepPoints > 1))
				return p->error = PLOTITEM_ERR_TOO_MANY_COUNTS_IN_2DGRAPH_ARR;
			
			break;
			
		case PLOT_TYPE_MULTIPLE_AS_INDEX:
			if ((a == NULL) || !a->hasMultiples) return p->error = PLOTITEM_ERR_ATOM_HAS_NO_MULTIPLES;
			if (s->nSweepPoints > 1) return p->error = PLOTITEM_ERR_MULTIPLES_AS_INDEX_MORE_THAN_ONE_SWEEPPOINT;
//			if(s->nCurves>1) return p->error = PLOTITEM_ERR_MULTIPLES_AS_INDEX_MORE_THAN_ONE_CURVE;
			break;
	}
	return 0;
}


int PLOTITEM_checkAllForError (t_session *s, int displayInTree)
{
	int i;
	t_plotItem *p;
	int error = 0;
	
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
		if (PLOTITEM_checkForError (s, p)) error = 1;
		if (displayInTree) PLOTITEM_displayTreeItemError (panelPlotItems, PLOTITEMS_TREE, s, p, i-1);
	}
	return error;
}



void PLOTITEM_getPanelTitle (t_session *s, t_plotItem *p, const char *axisName)
{
	if (p->autoSetWindowName) {
		switch (p->type) {
			case PLOT_TYPE_VELOCITYDIST:
				strcpy (p->panelTitle, "Velocity distribution");
				if (axisName[0] != 0) {
					strcat (p->panelTitle, " (");
					strcat (p->panelTitle, axisName);
					strcat (p->panelTitle, ")");
				}
				break;
			case PLOT_TYPE_DIG:
				if (s != NULL) strcpy (p->panelTitle, s->DIG_windowName);
				else strcpy (p->panelTitle, DEFAULT_DIG_WINDOWNAME);
				break;
			case PLOT_TYPE_ARRIVALTIMES:
				strcpy (p->panelTitle, "Arrival times");
				break;
			case PLOT_TYPE_NCOUNTS:
				if (p->transfer) {
					strcpy (p->panelTitle, "Transfer");
					if (axisName[0] != 0) {
						strcat (p->panelTitle, " (");
						strcat (p->panelTitle, axisName);
						strcat (p->panelTitle, ")");
					}
					return;
				}
				else {
					strcpy (p->panelTitle, "Counts");
					if (axisName[0] != 0) {
						strcat (p->panelTitle, " (");
						strcat (p->panelTitle, axisName);
						strcat (p->panelTitle, ")");
					}
				}
				break;
			case PLOT_TYPE_MULTIPLE_AS_INDEX: 
				strcpy (p->panelTitle, "Counts / multiple index");
				break;
			default: 
				strcpy (p->panelTitle, "???");
		}
		if (p->transfer) strcat (p->panelTitle, " (transfer)");
	}
}


int PLOTITEM_checkForDuplicateNames (t_session *s)
{
	int i, n, comp;
	int nEqual;
	char suffixStr[10];
	t_plotItem *compP, *p;
	
	n = ListNumItems (s->lPlotItems);
	for (comp = 1; comp <= n; comp++) {
		ListGetItem (s->lPlotItems, &compP, comp);
		if (compP->active) {
			nEqual = 0;
			for (i = comp+1; i <= n; i++) {
				ListGetItem (s->lPlotItems, &p, i);
				if ((p->active) && (strcmp(compP->name, p->name) == 0)) {
					// two items are equal
					nEqual ++;
					sprintf (suffixStr, "(%d)", nEqual);
					strcat (p->name, suffixStr);
				}
			}
		}
	}
	return 0;
}




int PLOTITEM_plotRangesDifferent (t_session *s, int type)
{
	int i;
	t_plotItem *p;
	int first, different;
	double compareStart, compareEnd;
	int comparePoints;
	char *helpStr;
	
	if (panelPlotRanges <= 0) {
		panelPlotRanges = LoadPanel (0, SESSIONMANAGER_uirFile, PLOTRANGES);
	}
	ClearListCtrl (panelPlotRanges, PLOTRANGES_LISTBOX);
	helpStr = getTmpStr();
	first = 1;
	different = 0;
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
		if ((p->active) && (p->type == type)) {
			// create list item
			switch (type) {
				case  PLOT_TYPE_VELOCITYDIST: 
					if (first) {
						compareStart  = p->velocityStart;
						compareEnd    = p->velocityEnd;
						comparePoints = p->velocityNPoints;
						first = 0;
					}
					else {
						different |= ((compareStart != p->velocityStart) 
						 		   || (compareEnd != p->velocityEnd)
						           || (comparePoints != p->velocityNPoints));
					}
					sprintf (helpStr, "%10s  %2.1f m/s --> %2.1f m/s (%d points)",
							 p->name, p->velocityStart, p->velocityEnd, p->velocityNPoints);
					break;
				case  PLOT_TYPE_ARRIVALTIMES: 
					if (first) {
						compareStart  = p->arrivalTimesBinStart_us;
						compareEnd    = p->arrivalTimesBinEnd_us;
						comparePoints = p->arrivalTimesNBins;
						first = 0;
					}
					else {
						different |= ((compareStart != p->arrivalTimesBinStart_us) 
						 		   || (compareEnd != p->arrivalTimesBinEnd_us)
						           || (comparePoints != p->arrivalTimesNBins));
					}
					sprintf (helpStr, "%11.11s %5.1f �s --> %5.1f �s (%d points) %s",
							 p->name, p->arrivalTimesBinStart_us, p->arrivalTimesBinEnd_us, p->arrivalTimesNBins,
							 p->arrivalTimesBinAuto ? "autoset" : "");
					break;
				default:
					strcpy (helpStr, "???");
			}
			InsertListItem (panelPlotRanges, PLOTRANGES_LISTBOX, -1, helpStr, i);
		}   
	}
	if (!different) return 0;
	
	switch (type) {
		case  PLOT_TYPE_VELOCITYDIST: 
			SetCtrlVal (panelPlotRanges, PLOTRANGES_TEXTMSG_velocity, "velocity distribution.");
			break;
		case  PLOT_TYPE_ARRIVALTIMES: 
			SetCtrlVal (panelPlotRanges, PLOTRANGES_TEXTMSG_velocity, "arrival times.");
			break;
		default:
			SetCtrlVal (panelPlotRanges, PLOTRANGES_TEXTMSG_velocity, "???.");
	}

	return different;
}


int PLOTITEM_checkForDifferentPlotRanges (t_session *s, int type)
{
	void *userReaction;
	int i;
	int pSourceIndex;
	t_plotItem *p, *pSource;
	
	// everything ok --> return;
	// if not --> open dialog:
	
	if (!PLOTITEM_plotRangesDifferent (s, type)) return 0;
	
	SetPanelAttribute (panelPlotRanges, ATTR_CALLBACK_DATA, 0);
	InstallPopup (panelPlotRanges);
	// wait until user has pressed ok
	do {
		ProcessSystemEvents ();
		GetPanelAttribute (panelPlotRanges, ATTR_CALLBACK_DATA, &userReaction);
	} while (((int)userReaction) == 0);
	RemovePopup (1);
	
	if (((int)userReaction) == VAL_USER_ABORT) return -1;
	
	// copy all values from one plotItem
	GetCtrlVal (panelPlotRanges, PLOTRANGES_LISTBOX, &pSourceIndex);
	ListGetItem (s->lPlotItems, &pSource , pSourceIndex);
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
		if ((p->active) && (p->type == type) && (i != pSourceIndex)) {
			switch (type) {
				case  PLOT_TYPE_VELOCITYDIST: 
					p->velocityStart    = pSource->velocityStart;   
					p->velocityEnd      = pSource->velocityEnd;     
					p->velocityNPoints  = pSource->velocityNPoints; 
					break;
				case  PLOT_TYPE_ARRIVALTIMES: 
					p->arrivalTimesBinAuto     = pSource->arrivalTimesBinAuto;
					p->arrivalTimesBinSize_us  = pSource->arrivalTimesBinSize_us;
					p->arrivalTimesBinStart_us = pSource->arrivalTimesBinStart_us;
					p->arrivalTimesBinEnd_us   = pSource->arrivalTimesBinEnd_us;  
					p->arrivalTimesNBins       = pSource->arrivalTimesNBins;      
					break;
			}
		}
	}
	
	return 0;
}
	
	



int PLOTITEM_checkAllForDifferentPlotRanges (t_session *s)
{
	int status;

	PLOTITEM_checkForDuplicateNames (s);

	status = PLOTITEM_checkForDifferentPlotRanges (s, PLOT_TYPE_VELOCITYDIST);
	if (status != 0) return status;
	return PLOTITEM_checkForDifferentPlotRanges (s, PLOT_TYPE_ARRIVALTIMES);
}




int CVICALLBACK PLOTITEM_selectAbort_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			SetPanelAttribute (panelPlotRanges, ATTR_CALLBACK_DATA, (void*)VAL_USER_ABORT);
			break;
	}
	return 0;
}

int CVICALLBACK PLOTITEM_selectDone_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_COMMIT:
			SetPanelAttribute (panelPlotRanges, ATTR_CALLBACK_DATA, (void*)VAL_USER_DONE);
			break;
	}
	return 0;
}


int CVICALLBACK PLOTITEM_selectRangeListbox_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event) {
		case EVENT_LEFT_DOUBLE_CLICK:
			SetPanelAttribute (panelPlotRanges, ATTR_CALLBACK_DATA, (void*)VAL_USER_DONE);
			break;
	}
	return 0;
}



void PLOTITEM_moveinList (t_session *s, int oldIndex, int direction)
{
	int newIndex;
	t_plotItem *newItem, *oldItem;
	t_plotItem *p;
	t_filter *f;
	int i, n;
	
	
	if (s == NULL) return;
	n = ListNumItems (s->lPlotItems);
	if ((oldIndex < 1) || (oldIndex > n)) return;
	newIndex = oldIndex + direction;
	if ((newIndex < 1) || (newIndex > n)) return;
	
	ListGetItem (s->lPlotItems, &oldItem, oldIndex);
	ListGetItem (s->lPlotItems, &newItem, newIndex);
	ListReplaceItem (s->lPlotItems, &newItem, oldIndex);
	ListReplaceItem (s->lPlotItems, &oldItem, newIndex);
	PLOTITEM_displayTreeItem (panelPlotItems, PLOTITEMS_TREE, s, newIndex);
	PLOTITEM_displayTreeItem (panelPlotItems, PLOTITEMS_TREE, s, oldIndex);

	// change references to the plotitems that are swapped
	for (i = ListNumItems(s->lPlotItems); i >= 1; i--) {
		ListGetItem (s->lPlotItems, &p, i);
		if (p->plotItemTransfer1 == oldIndex) p->plotItemTransfer1 = newIndex;
		else if (p->plotItemTransfer1 == newIndex) p->plotItemTransfer1 = oldIndex;
		if (p->plotItemTransfer2 == oldIndex) p->plotItemTransfer2 = newIndex;
		else if (p->plotItemTransfer2 == newIndex) p->plotItemTransfer2 = oldIndex;
	}
	
/*
	// change references (filters) to the plotitems that are swapped
	for (i = ListNumItems (s->lFilters); i > 0; i--) {
		ListGetItem (s->lFilters, &f, i);
		if (f->correlationsPlotItemNr == oldIndex) f->correlationsPlotItemNr  == newIndex;
		if (f->correlationsPlotItemNr == newIndex) f->correlationsPlotItemNr  == oldIndex;
	}
*/	
	PLOTITEM_fillNamesToRing (panelPlotItems, PLOTITEMS_RING_plotItemTransf1, s, 
							  -1, 0);	
	PLOTITEM_fillNamesToRing (panelPlotItems, PLOTITEMS_RING_plotItemTransf2, s, 
							  -1, 0);	
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_TREE,
					  ATTR_CTRL_INDEX, newIndex-1);
	for (i = 0; i < n; i++)  {
		SetTreeItemAttribute (panelPlotItems, PLOTITEMS_TREE, i, ATTR_SELECTED, i == (newIndex-1));
	}
	SetCtrlAttribute (panelPlotItems, PLOTITEMS_TREE,
					  ATTR_CTRL_INDEX, newIndex-1);
}



void PLOTITEM_fillNamesToRing (int panel, int control, t_session *s, int type, int onlyActive)
{
	t_plotItem *p;
	int nItems, nItemsShown;
	char help[100];
	int i;
	int itemNr;
	
	
	nItems = ListNumItems(s->lPlotItems);
	nItemsShown = 1;
	for (i = 1; i <= nItems; i++) {
		ListGetItem (s->lPlotItems, &p, i);
		if (p->active || !onlyActive) {
			if ((type < 0) || ((p->type == type) && (!p->transfer))) {
				nItemsShown ++;
			}
		}
	}
	setNumListItems (panel, control, nItemsShown);
	
	ReplaceListItem (panel, control, 0, "NONE", 0);

	itemNr = 1;
	for (i = 1; i <= nItems; i++) {
		ListGetItem (s->lPlotItems, &p, i);
		if (p->active || !onlyActive) {
			if ((type < 0) || ((p->type == type) && (!p->transfer))) {
				strcpy (help, p->name);
				if (!p->active) strcat (help, " (NOT ACTIVE)");
				ReplaceListItem (panel, control, itemNr, help, i);
				itemNr ++;
			}
		}
	}


}


int CVICALLBACK PLOTITEM_callback_moveUp (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlIndex (panelPlotItems, PLOTITEMS_TREE, &nr);
			PLOTITEM_moveinList (activeSession(), nr+1, -1);
			break;
	}
	return 0;
}


int CVICALLBACK PLOTITEM_callback_moveDown (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int nr = -1;
	
	switch (event) {
		case EVENT_COMMIT:
			GetCtrlIndex (panelPlotItems, PLOTITEMS_TREE, &nr);
			PLOTITEM_moveinList (activeSession(), nr+1, 1);
			break;
	}
	return 0;
}


int CVICALLBACK PLOTITEM_calculateAll_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	switch (event) {
		case EVENT_COMMIT:
			s = activeSession();
			COUNTS_displayRun ((t_run *) s->run);
			break;
	}
	return 0;
}


void PLOTITEM_CORR_initPanel (void)
{
 	int i;
 	int top;
 	
 	if (panelCorrelations <= 0) return;
 	if (panelCorrAtoms[0] > 0) return;
 	panelCorrAtoms[0]= LoadPanel (panelCorrelations, SESSIONMANAGER_uirFile, CORR_AT);
 	
 	top = ctrlBottom (panelCorrelations, PLOT_CORR_TEXTMSG_atom);
 	SetPanelPos (panelCorrAtoms[0],top,0);
 	SetPanelAttribute (panelCorrAtoms[0], ATTR_HEIGHT,
 				       ctrlBottom (panelCorrAtoms[0], CORR_AT_RING_level2)+5);
	 				       
	DisplayPanel (panelCorrAtoms[0]); 	
 	for (i = 1; i < MAX_CORRELATION_ATOMS; i++) {
	 	top+= panelHeight (panelCorrAtoms[0]);
 		panelCorrAtoms[i] = DuplicatePanel (panelCorrelations, panelCorrAtoms[0],"",
 							top, 0);
		DisplayPanel (panelCorrAtoms[i]); 	
 	}
}




void PLOTITEM_deleteAllCurves (t_session *s)
{
	int i;
	t_plotItem *p;
	t_graph *w;
	
	if (s == NULL) return;
	
	GRAPH_setAllDisplayed (0);
	for (i = 1; i <= ListNumItems (s->lPlotItems); i++) {
		ListGetItem (s->lPlotItems, &p, i);
		w = GRAPH_getFromCurve (p->curve);
		CURVE_delete (w, p->curve);
		GRAPH_displayAllCurves (w, 0, 0);

		if (w != NULL) DisplayPanel (w->panelHandle);
		p->curve = NULL;
	}
}	



int PLOTITEM_CORR_initFilterForCorrelation (t_session *s, t_plotItem *p, int combination)
{
	t_atom* at;
	t_filter *f;
	t_filterCriterion *fc;
	int nTimeIntervals;
	int nAtoms;
	int level[MAX_CORRELATION_ATOMS]={0};
	int div;
	int i,a ;
	t_timeInterval *t;
	char help[100];
	
	

	nAtoms = p->correlationsNAtoms;
	f = p->correlationsFilter[combination];
	f->otherFilterID = p->correlationsFilterIDOneAtom;
	f->otherFilterPtr = p->correlationsFilterOneAtom;
	f->nFilterCriteria = 0;
	f->keepFilteredDataInResults = 1;
	
	// depending on combination (1 of 2^nAtoms)
	// determine the levels to detect
	div = 1;
	for (a = 0; a < nAtoms; a++) {
		level[nAtoms - a - 1] = p->correlationsLevel[(combination / div) % 2][a];
		div *= 2;
	}
	
	strcpy (f->name, "CORR ");
	for (a = 0; a < nAtoms; a++) {
		//sprintf (help, "%s%d ", levelStr(s,level[a]), p->correlationsAtom[a]);
		at=ATOM_ptr(s,p->correlationsAtomNumber[a]);
		if(!at->hasMultiples) {
			sprintf (help, "%s%d ", levelStr(s,level[a]), p->correlationsAtomNumber[a]);
			strcat (f->name, help);
			}
		else {
			sprintf (help, "%s%d.%d ", levelStr(s,level[a]), p->correlationsAtomNumber[a], p->correlationsAtomMultiple[a]);
			strcat (f->name, help);
			}
		}
	
	
	sprintf (help, "(PI=%s) ", p->name); 
	strcat (f->name, help);
	
	nTimeIntervals = ListNumItems (s->lTimeIntervals[p->detector]);
	// 1 atom detected in the specific time interval
	
	fc = &f->criterion[f->nFilterCriteria];
	f->nFilterCriteria++; 
	fc->hasTimeIntervalTo = 0;
	fc->logic = 0;
	fc->active = 1;
	fc->detector = p->detector;
	fc->minCounts = nAtoms;
	fc->maxCounts = nAtoms;
	fc->hasAdditionalTimeIntervals = 1;	
	fc->nAdditionalTimeIntervals = nAtoms-1;

	
	for (a = 0; a < nAtoms; a++) {
		for (i = 1; i <= nTimeIntervals; i++) {
			t = TIMEINTERVAL_ptrList (s->lTimeIntervals[p->detector], i);
			at = ATOM_ptr(s,t->atom);
			if ((t->atom == p->correlationsAtomNumber[a]) && ( t->multiple == p->correlationsAtomMultiple[a]|| at->hasMultiples==0 ) && (t->levelNr == level[a])) {
				if (a == 0) fc->timeIntervalFrom[p->detector] = i;
				else if (a <= MAX_ADDITIONAL_TIMEINTERVALS) {
					fc->additionalTimeIntervals[a-1] = i;
				}
			}
		}
	}

	f->timeIntervalToCountStart = fc->timeIntervalFrom[p->detector];
	f->timeIntervalToCountStop = fc->timeIntervalFrom[p->detector];
	return 0;	
}




int	PLOTITEM_CORR_initFilterOneAtomDetected (t_session *s, t_plotItem *p)
{
	t_filter *f;
	t_filterCriterion *fc;
	int nTimeIntervals;
	int nAtoms;
	int i,a,continuum;
	t_timeInterval *t;

	nAtoms = p->correlationsNAtoms;
	f = p->correlationsFilterOneAtom;
	f->nFilterCriteria = 0;
	
	sprintf (f->name, "CORR %d atoms detected, (PI=%s)", nAtoms, p->name);
	

	nTimeIntervals = ListNumItems (s->lTimeIntervals[p->detector]);
	for (a = 0; a < nAtoms; a++) {
		fc = &f->criterion[f->nFilterCriteria];
		if (f->nFilterCriteria < MAX_FILTER_CRITERIA) f->nFilterCriteria++;
		fc->minCounts = 1;
		fc->maxCounts = 1;
		fc->timeIntervalFrom[p->detector] = 0;
		fc->hasTimeIntervalTo = 0;
		fc->logic = 0;
		fc->active = 0;
		fc->detector = p->detector;
		fc->logic = 0;
		fc->active = 1;
		fc->detector = p->detector;
		fc->nAdditionalTimeIntervals = 0;
		continuum = 0;
		for (i = 1; i <= nTimeIntervals; i++) {
			t = TIMEINTERVAL_ptrList (s->lTimeIntervals[p->detector], i);
			if ((t->atom == p->correlationsAtomNumber[a])&&(t->multiple== p->correlationsAtomMultiple[a])) {
			// add time interval to filter criterion
				fc->active = 1;
				if (fc->timeIntervalFrom[p->detector] == 0) 
					{
						fc->timeIntervalFrom[p->detector] = i;
					}
				else
					{
					fc->hasTimeIntervalTo = 1;
					fc->timeIntervalTo[p->detector] = i;
					}
			}
		}
							
/*		fc->timeIntervalFrom[p->detector] = 0;
		fc->hasTimeIntervalTo = 0;
		fc->logic = 0;
		fc->active = 1;
		fc->detector = p->detector;
		fc->minCounts = 1;
		fc->maxCounts = 1;
		fc->nAdditionalTimeIntervals = 0;
		// p->correlationsNAtoms detected 
		// in all of the correlation channels: add detection time intervals of this atom
		for (i = 1; i <= nTimeIntervals; i++) {
			t = TIMEINTERVAL_ptrList (s->lTimeIntervals[p->detector], i);
			if ((t->atomNr == p->correlationsAtomNumber[a])&&(t->copyNr == p->correlationsAtomNCopy[a])) {
				// add time interval to filter criterion
				if (fc->timeIntervalFrom[p->detector] == 0) fc->timeIntervalFrom[p->detector] = i;
				else {
					fc->hasAdditionalTimeIntervals = 1;			
					if (fc->nAdditionalTimeIntervals < MAX_ADDITIONAL_TIMEINTERVALS) {
						fc->additionalTimeIntervals[fc->nAdditionalTimeIntervals] = i;
						fc->nAdditionalTimeIntervals++;
					}
				}
			}
	
		} */
	}
	f->timeIntervalToCountStart = 0;
	f->timeIntervalToCountStop = 0;
	return 0;	
}



void PLOTITEM_CORR_createDataFilters (t_session *s, int nr)
{	
	t_plotItem *p;
	int atom;
	t_filter *f;
	int i;
	int nCorrelationFilters;
	
	if (s == NULL) return;
	p = PLOTITEM_ptr (s, nr);
	if (p == NULL) return;
	
	// install filter: 1 atom detected 
	if (p->correlationsFilterIDOneAtom == 0) p->correlationsFilterIDOneAtom = -1;
	p->correlationsFilterOneAtom = FILTER_ptr (s, p->correlationsFilterIDOneAtom);
	if (p->correlationsFilterOneAtom == NULL) {
		p->correlationsFilterOneAtom = FILTER_new (s);
		p->correlationsFilterIDOneAtom = ListNumItems (s->lFilters);
	}	
	PLOTITEM_CORR_initFilterOneAtomDetected (s, p);
	
	
	nCorrelationFilters = 1 << p->correlationsNAtoms;
	for (i = 0; i < nCorrelationFilters; i++) {
		// get pointer to corresponding filter
		if (p->correlationsFilterID[i] == 0) p->correlationsFilterID[i] = -1;
		p->correlationsFilter[i] = FILTER_ptr (s, p->correlationsFilterID[i]);
		// if no filter exisits --> create new filter
		if (p->correlationsFilter[i] == NULL) {
			p->correlationsFilter[i] = FILTER_new (s);
			p->correlationsFilterID[i] = ListNumItems (s->lFilters);
		}
		PLOTITEM_CORR_initFilterForCorrelation  (s, p, i);
	}	
	
	for (i = nCorrelationFilters; i < MAX_CORRELATION_CURVES; i++) {
		if (p->correlationsFilterID[i] > 0) {
			FILTER_delete (s, p->correlationsFilterID[i]);
			p->correlationsFilterID[i] = -1;
			p->correlationsFilter[i] = NULL;
		}
	}
	
	
	

}



int CVICALLBACK PLOTITEM_createDataFilters_CB (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	t_session *s;
	int nr;
	
	switch (event)
		{
		case EVENT_COMMIT:
			s = activeSession();
			GetCtrlIndex (panelPlotItems, PLOTITEMS_TREE, &nr);
			PLOTITEM_CORR_createDataFilters (s, nr+1);
			FILTERS_fillNamesToList (panelPlotItems, PLOTITEMS_RING_dataFilter, s, 1);
			break;
		}
	return 0;
}
