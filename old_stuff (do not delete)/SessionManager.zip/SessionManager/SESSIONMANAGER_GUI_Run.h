#if !defined (SESSIOMANAGER_GUI_RUN)
#define SESSIOMANAGER_GUI_RUN



int RUN_inactive (void);


int RUN_subPanelResume (void);
int RUN_subPanelStd (void);

int panelDig(void);


void RUN_protocolCls (void);

void RUN_printf (char* format, ... );


int RUN_initPanel (void);


void RUN_displayRunNr (t_run *r);

void RUN_setParameters (t_session *s, int updateRunNr);
void RUN_getParameters (t_session *s);	



void RUN_SAVE_initPanel (void);
void RUN_SAVE_setParameters (t_session *s);
void RUN_SAVE_getParameters (t_session *s);


//int RUN_ACQ_initPanel (void);



//void RUN_ACQ_setParameters (t_session *s);
//void RUN_ACQ_getParameters (t_session *s);

void RUN_DIG_setParameters (t_session *s);
void RUN_DIG_getParameters (t_session *s);

void RUN_STD_setParameters (t_session *s);
void RUN_STD_getParameters (t_session *s);




void RUN_displayAll (t_session *s);

void RUN_initGraphWindows (t_run *r);



void RUN_SAVING_progress (double percent);

void RUN_SAVING_displayPanel (void);

void RUN_SAVING_removePanel (void);

void RUN_SAVING_printf (char* format, ... );


void RUN_displayListOfTimeIntervalsInNewWindow (t_session *s);

void TIMEINTERVALS_copyTree (void);


#endif
