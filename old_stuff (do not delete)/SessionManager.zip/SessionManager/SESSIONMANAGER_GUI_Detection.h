#if !defined (SESSIOMANAGER_GUI_DETECTION)
#define SESSIOMANAGER_GUI_DETECTION



void DETECTORS_initPanel (void);
void DETECTORS_displayAll (t_session *s);
void DETECTORS_fillNamesToListbox (int panel, int control, t_session *s);

//void DETECTION_initPanel (void);


void DETECTORS_displayPanel (t_session *s);


#endif

