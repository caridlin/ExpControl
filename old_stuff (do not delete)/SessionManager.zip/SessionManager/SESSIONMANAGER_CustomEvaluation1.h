#if !defined (SESSIOMANAGER_CUSTOM1)
#define SESSIOMANAGER_CUSTOM1

void CUSTOM1_startEvaluation (void);

int MULTIPLES_nRuns (t_curve *c);

int MULTIPLES_nPointsPerCurve (t_curve *c);

int *MULTIPLES_getDatasetInt (t_curve *c, int curveNr, int *sum);

int **MULTIPLES_getAllDatasetsInt (t_curve *c, int *nRuns, int *nPointsPerCurve);

int **MULTIPLES_getAllDatasetsInt_eg (t_curve *c_g, t_curve *c_e, int *nRuns, int *nPointsPerCurve);

#endif
