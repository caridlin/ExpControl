#if !defined (SESSIOMANAGER_CREATE_SEQUENCE)
#define SESSIOMANAGER_CREATE_SEQUENCE


#define N_ACTIVE_DIG_CHANNELS 32
#define N_ACTIVE_AO_CHANNELS 8



// define the output channels
// see funtion "strDIGlabel" to change the labels

#define CH_52D_52F	CH_A0
#define CH_PURIF_E	CH_A1
#define CH_PURIF_G	CH_A2
#define CH_RAMSEY1	CH_A3
#define CH_RAMSEY2	CH_A4
#define CH_RAMSEY3	CH_A5
#define CH_CAVITY1  CH_A6
#define CH_CAVITY2  CH_A7

#define CH_TRIG_OSCILLOSCOPE     CH_B0
//#define CH_COPY_LASER1_L1        CH_B1

#define CH_TRIG_LECROY_KILLER   CH_B2
#define CH_TRIG_LECROY_CIRC     CH_B3
#define CH_TRIG_LECROY_DET_RAMP CH_B4
#define CH_TRIG_RF_CIRC   		CH_B5
#define CH_GATE_DET1		    CH_B6
#define CH_GATE_DET2		    CH_B7


#define CH_LASER1			 CH_C0
#define CH_LASER2			 CH_C1

#define CH_REP_FREQUENCY_E1	 CH_C2
#define CH_REP_FREQUENCY_E2	 CH_C3
#define CH_REP_POWER_E1		 CH_C4
#define CH_REP_POWER_E2		 CH_C5
#define CH_DEPUMPER_SHUTTER	 CH_C6
#define CH_REPUMPER			 CH_C7   

#define CH_MW_AMPLIFIER 	 CH_D0
#define CH_RAMAN			 CH_D1
#define CH_DEPUMPER_ANGLE 	 CH_D2
#define CH_OPT_PUMPING		 CH_D3
#define CH_DET1_ON   	     CH_D4 // BIT enable detector 1

//#define CH_COUNTER0			 CH_D0
//#define CH_COUNTER1			 CH_D1


#define	COUNTER_NCOUNTS_DET1 0	
#define	COUNTER_NCOUNTS_DET2 1
#define	COUNTER_ARRIVALTIMES_DET1 6
#define	COUNTER_ARRIVALTIMES_DET2 7


extern const int COUNTERS_NCOUNTS[2];
extern const int COUNTERS_ARRIVALTIMES[2];


#define DURATION_FIRST_BLOCK_ns 2000.0
//#define DURATION_INIT_PULSE 2


#define DURATION_ADD_us 50.0   // time added at end of sequence
							   // for syncro with analog board + stop signals

#define DURATION_LECROY_TRIG 1 // 1 �s
//#define TOF_DETECTOR (2*VAL_us)
#define DURATION_PULSE_DET1_ON 25.0 // 
#define DELAY_PULSE_DET1_ON    -10.0  // delay beween trig det. ramp and DET1 ON


#define KILLER_UPDATE_INTERVAL_us 0.05   // 50 ns corresponds to 20 MHz clock (SCLK)
#define KILLER_MAX_POINTS_LECROY 500000      // 1 MB memory per channel
#define KILLER_MAX_POINTS_MI6021 (128*1024*1024/4)
#define KILLER_MAX_DURATION_LECROY_us (KILLER_UPDATE_INTERVAL_us*KILLER_MAX_POINTS_LECROY-DURATION_FIRST_BLOCK_ns-DURATION_ADD_us)
#define KILLER_MAX_DURATION_MI6021_us (KILLER_UPDATE_INTERVAL_us*KILLER_MAX_POINTS_MI6021-DURATION_FIRST_BLOCK_ns-DURATION_ADD_us)

#define ALWAYS_ON (-1)

#define GPIB_ADDRESS_KILLER        1
#define GPIB_ADDRESS_DET_RAMP      3

#define N_SIGNALGENERATORS 8
// de
#define GPIB_ADDRESS_ANRITSU_fred   5
#define GPIB_ADDRESS_ANRITSU_george 6
#define GPIB_ADDRESS_ANRITSU_charly 7
#define GPIB_ADDRESS_ANRITSU_billy  8
#define GPIB_ADDRESS_SML02          10
#define GPIB_ADDRESS_SML02_2        11
#define GPIB_ADDRESS_AGILENT_33250A_1 12          
#define GPIB_ADDRESS_AGILENT_33250A_2 13          

// if you add GPIB devices, update also the table
// GPIB_ADDRESSES_SIGNALGENERATORS[...]
// in file SESSIONMANAGER_CreateSequence.c
extern const int GPIB_ADDRESSES_SIGNALGENERATORS[N_SIGNALGENERATORS];


#define N_POWERSUPPLIES 6

#define GPIB_ADDRESS_SRS_P350_1 	17
#define GPIB_ADDRESS_SRS_P350_2 	18
#define GPIB_ADDRESS_SRS_P350_3 	19
#define GPIB_ADDRESS_SRS_P350_4 	20
#define GPIB_ADDRESS_PL330DP 	    16
#define GPIB_ADDRESS_AGILENT_6612C  15



extern const int GPIB_ADDRESSES_POWERSUPPLIES[N_POWERSUPPLIES];


//#define KILLER_OUTPUT_CH    1
//#define CH_GPIB_KILLER 		(N_DAC_CHANNELS + 2*GPIB_ADDRESS_KILLER-2)

#define A_CH_VOLTAGE_DETECTOR CH_DAC0
#define A_CH_CONTREPLAQUE     CH_DAC1


#define A_CH_GPIB_KILLER (N_DAC_CHANNELS+2*GPIB_ADDRESS_KILLER-2)
#define TIMEBASE_LECROY_KILLER 1  //in units of 50ns



#define N_DIG_REPETITIONS 99999


#ifdef _CVI_DEBUG_	
	#define MIN_ATOMS_DISPLAY_PROGRESS 100
#else
	#define MIN_ATOMS_DISPLAY_PROGRESS 500
#endif



int getIntTime (double time_us);



void SIGNALS_printInfo (int panel, int ctrl);

//int getTransferDetector2 (t_session *s, t_plotItem **pReturn);


const char *strDIGlabel (int channel);
const char *strAOlabel (int channel);
const char *strGPIBlabel (int channel);

int GPIBDEVICE_hasPulseMode (int channel);


double roundTimeAnalogBoard (double time_us);




int SESSIONMANAGER_createSequence (t_session *s, char *filename, int showErrMsg);

int SESSIONMANAGER_transmitSequence (t_session *s);

int SESSIONMANAGER_executeSequence (t_session *s);



t_event *EVENTS_insertDIGPulse (ListType lEvents, char* atomStr, int channel, 
						       double time_us, double duration_us, int putString, 
						       const char *format, ...);



//double EVENTS_calculateSmallestTime (ListType listOfEvents, t_session *s);



t_event *EVENTS_insertAOPulse (ListType lEvents, char* atomStr, 
						  int AOchannel, 
						  int waveform, 
						  double constVoltage,
						  double time_us, 
						  double duration_us, 
						  const char *format, ...);



void EVENTS_displayPanel (t_session *s);

int EVENTS_checkForConflicts (t_session *s, int putStrings,  int showError, char **errorStr, int progressDialog);

int EVENTS_checkTimesOfEvents (t_session *s, int showError, char **errorMsg, int progressDialog);

double CREATESEQ_getKillerDefaultDetuning (t_session *s, int cavityNr);


void CREATESEQ_makeTransferFunction (t_transferFunction *f, t_session *s, int cavityNr);

void CREATESEQ_makeWaveform (t_waveform *wfm, t_session *s, t_point *points, int nPoints, double defaultValue, double *pretrig_us);

//void CREATESEQ_makeWaveform (t_waveform *wfm, t_session *s, t_point *points, 
//						     int nPoints, double *pretrig_us);


//int CREATESEQ_insertPulsesAtom (ListType lEvents, t_session *s, 
//								 int i, int createKillerWaveform);

int CREATESEQ_insertPulsesAtom (ListType lEvents, t_session *s, int i, int createKillerWaveform,
								int *atomCounter, int nAtoms, int progressDialog);
								 
								 
int CREATESEQ_isChannelInverted (int channel);

char *CREATESEQ_getErrorStr (void);

								 

#ifndef EXPERIMENTCONTROL   
int launchExperimentControl (int wait, int ignoreLaunchStateFlag);

#endif



#endif
