#include <userint.h>
#include "UIR_SessionManager.h"


#include "INCLUDES_SESSIONMANAGER.h"
#include "Driver_MI6021.h"

extern int panelSMain;

int handleExperimentControl = -1;

int quitProgramFlag = 0;
int gThreadPoolHandle = 0;

#define DEBUG_LOAD_CURVES 0
/* 
#ifdef _CVI_DEBUG_
const char filenameExperimentControl[] = "ExperimentControl_dbg.exe /REMOTE";
#else
const char filenameExperimentControl[] = "ExperimentControl.exe /REMOTE";
#endif
*/


const char EXE_filename[] = "ExperimentControl.exe /REMOTE /FAKEDATA";


int launchExperimentControl (int wait, int ignoreLaunchStateFlag)
{
	int terminated;
	int errorCode;
	int i;
	
	// do no longer launch EXPCONTROL, since
	// it runs on a different computer
	return 0;
	// lanuch ExperimentControl if server == localhost
	// 
	if (smanagerConfig != NULL) {
		if (CompareStrings (smanagerConfig->TCPserverName, 0, "localhost", 0, 0) != 0) return 0;
	}
	
	if (!ignoreLaunchStateFlag && (getLaunchState() == 1)) return 0;
	
	if (handleExperimentControl != -1) {
		terminated = ExecutableHasTerminated (handleExperimentControl);
		if (terminated == 0) {
			// executable is still running: do nothing
			return -1;
		}
		else handleExperimentControl = -1;
	}
	
	errorCode = LaunchExecutableEx (EXE_filename, LE_SHOWMINIMIZED,
								    &handleExperimentControl); 
	if (errorCode != 0) {
		MessagePopupf ("Error!", "Error launching executable '%s'.\n%s", EXE_filename, errorStringUtility(errorCode));
		return -1;
	}
	if (!wait) return 0;
	for (i = 0; i < 70; i++) {
		Delay (0.1);
		if (getLaunchState () == 1) return 0;
	}
	return -1;
}

	

void test ()
{
	int a[1000];
	IniText ini;
	int i;
	
	for (i = 0; i < 1000; i++) a[i] = 0;
	a[1] = 10;
	a[3] = 10;
	a[6] = 10;
	a[10] = 10;
	ini = Ini_New (0);
	Ini_PutDataArray (ini, "test", "array", a, 1000, VAL_INTEGER);
	Ini_DisplayContents (ini, 0);
	for (i = 0; i < 1000; i++) a[i] = 0xFFFF;
	Ini_GetDataArrayEx (ini, "test", "array", a, 1000, VAL_INTEGER);
	
	Ini_Dispose (ini);
	while (1) {};
	
}


void DEBUG_loadCurves (void)
{
	t_curve *c;
	
	//	D:\tmp\2006\March\15\0021_test R2_1freq
//	c = CURVE_loadAndDisplay ("D:\\tmp\\206\\March\\15\\0021_test R2_1freq\\0021_trans de velocity.curve");    
//	if (c == NULL) return;
//	CURVE_addAllPositions (activeSession(), c);
//   	if (c->values2D != NULL) CURVE2D_displayCurve (c, c->panelPos2D);


	CURVE_loadAndDisplay ("D:\\DATA\\2005\\November\\25\\0170_cavity_scan+det 1000-1500 cav2\\0170_transfer.curve");
	CURVE_loadAndDisplay ("D:\\DATA\\2005\\November\\25\\0171_cavity_scan+det 1000-1500 cav2\\0171_transfer.curve");
	CURVE_loadAndDisplay ("D:\\DATA\\2005\\November\\25\\0172_cavity_scan+det 1000-1500 cav2\\0172_transfer.curve");
	CURVE_loadAndDisplay ("D:\\DATA\\2005\\November\\25\\0173_cavity_scan+det 1000-1500 cav2\\0173_transfer.curve");
	CURVE_loadAndDisplay ("D:\\DATA\\2005\\November\\25\\0174_cavity_scan+det 1000-1500 cav2\\0174_transfer.curve");
	CURVE_loadAndDisplay ("D:\\DATA\\2005\\November\\25\\0175_cavity_scan+det 1000-1500 cav2\\0175_transfer.curve");
	CURVE_loadAndDisplay ("D:\\DATA\\2005\\November\\25\\0176_cavity_scan+det 1000-1500 cav2\\0176_transfer.curve");

}


void TEST_DIRECTORY (void)
{

	int panel;
	
	panel = LoadPanel (0, SESSIONMANAGER_uirFile, DIR);
	recurseDirectoryIntoTree (panel, DIR_TREE, "D:\\temp", "*.txt");
	DisplayPanel (panel);

}


void ttest (void)
{
	t_digitizeParameters digParameters;
	double result;
        
        //debug
	digParameters = *digitizeParameters_MI6021 (2); 
	
	result = AnalogToDigital (0, &digParameters);
	result = AnalogToDigital (10, &digParameters);
	result = AnalogToDigital (-10, &digParameters);
		

}


int MULTITHREADING_Init (void)
{
  if (CmtNewThreadPool(1, &gThreadPoolHandle) < 0) return -1;
  return 0;

}

int MULTITHREADING_Discard (void)
{
	if (CmtDiscardThreadPool(gThreadPoolHandle) < 0) return -1;
	return 0;
}

//#include "session_MAIN.h"
int main (int argc, char *argv[])
{
	
	int error;
    int thereIsAnother;
    int panelStart = 0;
    
	
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */

	if (CheckForDuplicateAppInstance (ACTIVATE_OTHER_INSTANCE, &thereIsAnother) < 0)
		return -1; /* out of memory, or not Win 2000/NT/9x */
	if (thereIsAnother) return 0; /* prevent duplicate instance */


	SetSleepPolicy (VAL_SLEEP_SOME);
	
	DisableBreakOnLibraryErrors ();

	panelStart = LoadPanel (0, SESSIONMANAGER_uirFile, START);
	setCtrlStrf (panelStart, START_TEXTMSG_TITLE, "Session Manager V%1.2f", ProgramVersion);

#ifdef _CVI_DEBUG_	
	SetCtrlAttribute (panelStart, START_TEXTMSG_DEBUG, ATTR_VISIBLE, 1);
#else
	SetCtrlAttribute (panelStart, START_TEXTMSG_DEBUG, ATTR_VISIBLE, 0);
#endif

	DisplayPanel (panelStart);

    

	SESSIONMANAGER_init (panelStart, START_STRING_status);
	
	
	DRIVER_MI6021_init ();
	
//	DRIVER_MI6021_generateTestCurve ();
	

    launchExperimentControl (0, 0);

	SetMenuBarAttribute (MAINMENU, MAINMENU_FILE_QUIT,
						 ATTR_CALLBACK_FUNCTION_POINTER,
						 SMAIN_MENU_Quit);

//	PLOT_test (PLOT_openPlotWindow (0));

	HidePanel (panelStart);
	DisplayPanel (panelSMain);
	
	if (DEBUG_LOAD_CURVES) DEBUG_loadCurves ();
	RunUserInterface ();

	
	quitProgramFlag = 1;
	SESSIONMANAGER_discardPanel ();
	return 0;
}



